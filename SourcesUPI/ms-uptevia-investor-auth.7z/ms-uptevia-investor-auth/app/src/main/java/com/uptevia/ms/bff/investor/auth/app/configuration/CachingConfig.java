package com.uptevia.ms.bff.investor.auth.app.configuration;


import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.Scheduled;

import java.util.Arrays;
import java.util.logging.Logger;


//@Configuration
//@EnableCaching
public class CachingConfig {

/**
    Logger logger = Logger.getLogger(CachingConfig.class.getName());
    @Bean
    public CacheManager cacheManager() {
        final SimpleCacheManager cacheManager = new SimpleCacheManager();
        cacheManager.setCaches(Arrays.asList(new ConcurrentMapCache("logos"), new ConcurrentMapCache("traductions")));
        logger.info("cacheManager init");
        return cacheManager;
    }

    @CacheEvict(value = "logos", allEntries = true)
    @Scheduled(fixedRateString = "${caching.spring.logoListTTL}")
    public void emptyLogoCache() {
        logger.info("emptying Logo cache");
    }

    @CacheEvict(value = "traductions", allEntries = true)
    @Scheduled(fixedRateString = "${caching.spring.tradListTTL}")
    public void emptyTraductionCache() {
        logger.info("emptying traduction cache");
    }
    */
}

