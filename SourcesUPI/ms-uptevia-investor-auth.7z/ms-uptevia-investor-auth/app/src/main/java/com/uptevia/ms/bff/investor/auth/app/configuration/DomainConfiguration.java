package com.uptevia.ms.bff.investor.auth.app.configuration;

import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.IForgotRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.ISignUpRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.IUpdatePasswordRepository;
import com.uptevia.ms.bff.investor.auth.domain.service.AuthService;
import com.uptevia.ms.bff.investor.auth.domain.service.ForgotIdentifiantService;
import com.uptevia.ms.bff.investor.auth.domain.service.SignupService;
import com.uptevia.ms.bff.investor.auth.domain.service.UpdatePasswordService;
import com.uptevia.ms.bff.investor.auth.domain.service.impl.AuthServiceImpl;
import com.uptevia.ms.bff.investor.auth.domain.service.impl.ForgotIdentifiantServiceImpl;
import com.uptevia.ms.bff.investor.auth.domain.service.impl.SignupServiceImpl;
import com.uptevia.ms.bff.investor.auth.domain.service.impl.UpdatePasswordServiceImpl;
import com.uptevia.ms.bff.investor.auth.infra.repositories.AuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.infra.repositories.UpdatePasswordRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DomainConfiguration {

    @Bean
    AuthService getAuthService(AuthenticateRepository authenticateRepository) {
        return new AuthServiceImpl(authenticateRepository);
    }

    @Bean
    UpdatePasswordService getUpdatePasswordService(final UpdatePasswordRepository updatePasswordRepository,
                                                   final AuthenticateRepository authenticateRepository){
        return new UpdatePasswordServiceImpl(updatePasswordRepository, authenticateRepository);
    }

    @Bean
    SignupService getSignupService(final ISignUpRepository iSignUpRepository, final IUpdatePasswordRepository iUpdatePasswordRepository, final IAuthenticateRepository iAuthenticateRepository){
        return new SignupServiceImpl(iSignUpRepository, iUpdatePasswordRepository, iAuthenticateRepository);
    }

    @Bean
    ForgotIdentifiantService getForgotIdentifiantService(final IForgotRepository iForgotRepository, final IAuthenticateRepository iAuthenticateRepository){
        return new ForgotIdentifiantServiceImpl(iForgotRepository, iAuthenticateRepository);
    }
}
