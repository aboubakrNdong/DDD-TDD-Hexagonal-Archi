package com.uptevia.ms.bff.investor.auth.app.controller;

import com.uptevia.ms.bff.investor.auth.api.AuthenticateApi;
import com.uptevia.ms.bff.investor.auth.api.model.*;
import com.uptevia.ms.bff.investor.auth.app.exception.CustomResponseStatusException;
import com.uptevia.ms.bff.investor.auth.app.mapper.LoginRequestMapper;
import com.uptevia.ms.bff.investor.auth.app.mapper.UserJsonMapper;
import com.uptevia.ms.bff.investor.auth.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.auth.app.mapper.*;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.service.AuthService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/api/v1")
public class AuthController implements AuthenticateApi {


    private static final String AUTHORIZATION = "Authorization";
    @Autowired
    JwtUtils jwtUtils;

    private final AuthService authService;

    public AuthController(final AuthService authService) {
        this.authService = authService;
    }


    /**
     * GET /authenticate
     * Recherche si actionnaire existe dans la table Acti
     *
     * @param loginRequestJson login (required)
     * @return Un actionnaire a été trouvé pour ces parametres (status code 200)
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     * or Actionnaire non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */

    @Override
    public ResponseEntity<UserJson> authenticate(final LoginRequestJson loginRequestJson) {
        UserDTO userDTO = null;
        String token = "";
        HttpHeaders headers = null;
        try {
            LoginRequestDTO loginRequest = LoginRequestMapper.INSTANCE.jsonToDto(loginRequestJson);

            userDTO = authService.authenticate(loginRequest);

            if(StringUtils.equals(token, "")) {
                token = jwtUtils.generateJwtToken(userDTO);
            }
            userDTO.setToken(token);

        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, ex.getCode(), ex.getContextParams());
        }

        return ResponseEntity.ok().body(UserJsonMapper.INSTANCE.DtoToJson(userDTO));
    }

    @Override
    public ResponseEntity<ResultStatusJson> getOnboardingStatus(String login) {
        ResultStatusDTO resultStatusDTO ;
        try {
            resultStatusDTO = authService.getOnboardingStatus(login);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>(ResultStatusMapper.INSTANCE.DtoToJson(resultStatusDTO), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Boolean> updateOtpValidation(String login) {

        try {
            authService.updateDateMajOtp(login);
        } catch (Exception ex) {
            return new ResponseEntity<>(Boolean.FALSE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return   new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
    }


    @Override
    public ResponseEntity<List<UserJson>> ancientOlisAccount(final LoginRequestJson loginRequestJson) {
        List<UserDTO> userDTOs = null;
        LoginRequestDTO loginRequestDTO = LoginRequestMapper.INSTANCE.jsonToDto(loginRequestJson);
        try {
            userDTOs = authService.ancientOlisAccount(loginRequestDTO);

        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, ex.getCode(), ex.getContextParams());
        }

        return new ResponseEntity<>(userDTOs.stream()
                .map(UserJsonMapper.INSTANCE::DtoToJson).toList(), HttpStatus.OK);
    }

    /**
     * @param planetShareRequestJson Emitter code (required)
     * @return list des anciens user planetshare
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Actionnaire non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     * @author FBOUCHNAK
     */
    @Override
    public ResponseEntity<List<UserPlanetShareJson>> ancientPlanetShare(final PlanetShareRequestJson planetShareRequestJson) {

        List<UserPlanetShareDTO> userPlanetShareDTOS = new ArrayList<>();
        PlanetShareRequestDTO planetShareRequestDTO = PlanetShareRequestMapper.INSTANCE.jsonToDto(planetShareRequestJson);
        try {
            userPlanetShareDTOS = authService.ancientPlanetShare(planetShareRequestDTO.getEmetIden(),
                    planetShareRequestDTO.getAccessCode(), planetShareRequestDTO.getPassword());
        } catch (final FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, ex.getCode(), ex.getContextParams());
        }
        return new ResponseEntity<>(userPlanetShareDTOS.stream()
                .map(UserPlanetShareJsonMapper.INSTANCE::DtoToJson).toList(), HttpStatus.OK);
    }


    /**
     * @author FBOUCHNAK
     * @param eabonnementJson  (optional)
     * @return void
     */
    @Override
    public ResponseEntity<Void> acceptCgu(final EabonnementJson eabonnementJson) {

        EabonnementDTO eabonnementDTO = EabonnementMapper.INSTANCE.jsonToDto(eabonnementJson);
        try {
            authService.acceptCgu(eabonnementDTO);
        }catch (final FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ex.getCode(), ex.getContextParams());
        }
        return new ResponseEntity<>(HttpStatus.CREATED);
    }
}
