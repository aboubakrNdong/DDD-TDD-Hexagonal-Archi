package com.uptevia.ms.bff.investor.auth.app.controller;


import com.uptevia.ms.bff.investor.auth.api.ForgotApi;
import com.uptevia.ms.bff.investor.auth.api.model.NewIdentifiantJson;
import com.uptevia.ms.bff.investor.auth.api.model.SendEmailJson;
import com.uptevia.ms.bff.investor.auth.api.model.UserLightJson;
import com.uptevia.ms.bff.investor.auth.app.exception.CustomResponseStatusException;
import com.uptevia.ms.bff.investor.auth.app.mapper.*;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.service.ForgotIdentifiantService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/v1")
@Slf4j
public class ForgotController implements ForgotApi {


    private final ForgotIdentifiantService forgotIdentifiantService;

    public ForgotController(ForgotIdentifiantService forgotIdentifiantService) {
        this.forgotIdentifiantService = forgotIdentifiantService;
    }


    /**
     * POST /forgot/forgot-identifiant
     * Renvoyer l&#39;identifiant d&#39;un actionnaire en cas d&#39;oubli de sa part
     *
     * @param newIdentifiantJson (optional)
     * @return les données saisies matchent bien avec l&#39;identifiant utilisé (status code 200)
     * or Identifiant non trouvé pour ces données (status code 404)
     */

    @Override
    public ResponseEntity<String> verifyIdentifiant(NewIdentifiantJson newIdentifiantJson) {


        String verifyId;
        NewIdentifiantDTO newIdentifiantDTO = ForgotMapper.instance.jsonToDto(newIdentifiantJson);

        try {
            verifyId = forgotIdentifiantService.verifyIdentifiant(newIdentifiantDTO);
        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.NOT_FOUND, ex.getCode(), ex.getContextParams());
        }
        return new ResponseEntity<>(verifyId, HttpStatus.OK);
    }

    /**
     * GET /forgot/set-password
     * creating a PasswordResetToken to use it for setting or resetting the user’s password
     *
     * @param login login (required)
     * @param buttonChoice Choix de l&#39;envoi du mail (required)
     * @return An email is successfully sent to user. (status code 200)
     *         or Retour de la procédure stockée incorrect (status code 400)
     *         or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     *         or Comptes non trouvé pour ces parametres (status code 404)
     *         or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */
    @Override
    public ResponseEntity<SendEmailJson> sendResetToken(String login, String buttonChoice) {
        SendEmailDTO sendEmailDTO;
        try {
            sendEmailDTO = forgotIdentifiantService.sendResetTokenByEmail(login, buttonChoice);
        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ex.getCode(), ex.getContextParams());
        }

        return new ResponseEntity<>(SendEmailMapper.INSTANCE.DtoToJson(sendEmailDTO), HttpStatus.OK);
    }


    /**
     * @param sd La chaine cryptee (required)
     * @return
     */
    @Override
    public ResponseEntity<UserLightJson>verifyToken(String sd) {


        UserDTO userDTO;
        try {
            userDTO = forgotIdentifiantService.verifyResetToken(sd);
        } catch (Exception e) {

            throw new RuntimeException(e);
        }
        return new ResponseEntity<>(new UserLightJson().email(userDTO.getEmail()).login(userDTO.getLogin()), HttpStatus.OK);
    }


}
