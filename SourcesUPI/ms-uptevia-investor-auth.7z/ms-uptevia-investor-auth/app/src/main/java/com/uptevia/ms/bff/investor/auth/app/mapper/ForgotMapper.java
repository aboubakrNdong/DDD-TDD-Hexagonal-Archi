package com.uptevia.ms.bff.investor.auth.app.mapper;


import com.uptevia.ms.bff.investor.auth.api.model.NewIdentifiantJson;
import com.uptevia.ms.bff.investor.auth.domain.model.NewIdentifiantDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ForgotMapper {

    ForgotMapper instance = Mappers.getMapper(ForgotMapper.class);

    NewIdentifiantDTO jsonToDto (NewIdentifiantJson newIdentifiantJson);

}
