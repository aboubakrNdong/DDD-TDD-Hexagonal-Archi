package com.uptevia.ms.bff.investor.auth.app.mapper;

import com.uptevia.ms.bff.investor.auth.api.model.QuestionnaireJson;
import com.uptevia.ms.bff.investor.auth.domain.model.QuestionnaireDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface QuestionnaireMapper {

    QuestionnaireMapper QUESTIONNAIRE_MAPPER = Mappers.getMapper(QuestionnaireMapper.class);

    QuestionnaireDTO jsonToDto(QuestionnaireJson questionnaireJson);
}
