package com.uptevia.ms.bff.investor.auth.app.mapper;

import com.uptevia.ms.bff.investor.auth.api.model.ResultStatusJson;
import com.uptevia.ms.bff.investor.auth.domain.model.ResultStatusDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ResultStatusMapper {
    ResultStatusMapper INSTANCE = Mappers.getMapper(ResultStatusMapper.class);

    ResultStatusJson DtoToJson(ResultStatusDTO resultStatusDTO);
}
