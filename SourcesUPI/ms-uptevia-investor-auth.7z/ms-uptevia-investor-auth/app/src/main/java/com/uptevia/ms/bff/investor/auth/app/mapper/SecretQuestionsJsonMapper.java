package com.uptevia.ms.bff.investor.auth.app.mapper;

import com.uptevia.ms.bff.investor.auth.api.model.SecretQuestionsJson;
import com.uptevia.ms.bff.investor.auth.domain.model.SecretQuestionsDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SecretQuestionsJsonMapper {

    SecretQuestionsJsonMapper SECRET_QUESTIONS_JSON_MAPPER = Mappers.getMapper(SecretQuestionsJsonMapper.class);

    SecretQuestionsJson dtoToJson (SecretQuestionsDTO secretQuestionsDTO);
}
