package com.uptevia.ms.bff.investor.auth.app.mapper;

import com.uptevia.ms.bff.investor.auth.api.model.SendEmailJson;
import com.uptevia.ms.bff.investor.auth.domain.model.SendEmailDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SendEmailMapper {
    SendEmailMapper INSTANCE = Mappers.getMapper(SendEmailMapper.class);

    SendEmailJson DtoToJson(SendEmailDTO sendEmailDTO);
}
