package com.uptevia.ms.bff.investor.auth.app.mapper;

import com.uptevia.ms.bff.investor.auth.api.model.UserJson;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface UserJsonMapper {

    UserJsonMapper INSTANCE = Mappers.getMapper(UserJsonMapper.class);

    UserJson DtoToJson(UserDTO detailTituDTO);

}