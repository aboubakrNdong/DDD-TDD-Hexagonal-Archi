package com.uptevia.ms.bff.investor.auth.app.mapper;

import com.uptevia.ms.bff.investor.auth.api.model.UserJson;
import com.uptevia.ms.bff.investor.auth.api.model.UserPlanetShareJson;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserPlanetShareDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface UserPlanetShareJsonMapper {

    UserPlanetShareJsonMapper INSTANCE = Mappers.getMapper(UserPlanetShareJsonMapper.class);

    UserPlanetShareJson DtoToJson(UserPlanetShareDTO userPlanetShareDTO);
}
