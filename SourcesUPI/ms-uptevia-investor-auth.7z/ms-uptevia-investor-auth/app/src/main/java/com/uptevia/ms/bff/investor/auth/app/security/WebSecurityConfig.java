package com.uptevia.ms.bff.investor.auth.app.security;


import com.uptevia.ms.bff.investor.auth.app.security.jwt.AuthTokenFilter;
import com.uptevia.ms.bff.investor.auth.app.security.jwt.JwtUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@Slf4j
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    private static final String[] AUTH_WHITELIST = {
            // -- Swagger UI v3 (OpenAPI)
            "/v3/api-docs/**",
            "/ms-investor-auth.v1.json",
            "/swagger-ui.html",
            "/swagger-ui/**",
            "/**/authenticate/**",
            "/**/set-password/**",
            "/**/forgot/**",
            "/**/actuator/**",
            "/**/ancient-planetshare/**",
            "/**/secret-questions/**",
            "/**/savePassword/**",
            "/**/save-secret-questions/**",
            "/**/check-questions-answers/**",
            "/**/mail-phone/**"
    };

    @Autowired
    private JwtUtils jwtUtils;

    @Bean
    public AuthTokenFilter authenticationJwtTokenFilter() {
        return new AuthTokenFilter(jwtUtils);
    }


    @Override
    protected void configure(final HttpSecurity http) throws Exception {

        log.info("Begin auth secure context ... ");
        // Disable CSRF (cross site request forgery)
        http.csrf().disable();

        http.formLogin().disable();

        // No session will be created or used by spring security
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        // Entry points
        http.authorizeRequests()
                //List of urls to be allowed
                .antMatchers(AUTH_WHITELIST).permitAll()
                // Disallow everything else..
                .anyRequest().authenticated();

        // If a user try to access a resource without having enough permissions
        http.exceptionHandling().accessDeniedPage("/login");

        // Apply JWT
        http.addFilterAfter(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);

    }

}
