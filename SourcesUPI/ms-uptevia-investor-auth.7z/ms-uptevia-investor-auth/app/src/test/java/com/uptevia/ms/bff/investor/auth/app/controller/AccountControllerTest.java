package com.uptevia.ms.bff.investor.auth.app.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.DetailConnexionDTO;
import com.uptevia.ms.bff.investor.auth.domain.service.UpdatePasswordService;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;


import static org.mockito.Mockito.doThrow;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(AccountController.class)
class AccountControllerTest {
    private static final String URL_UPDATE_PWD_LINKS = "/api/v1/account/updatePassword";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UpdatePasswordService updatePasswordService;

    private DetailConnexionDTO detailConnexionDTO = DetailConnexionDTO.builder()
            .login("99963514")
            .newPassword("1")
            .oldPassword("1")
            .email("test@test.com")
            .build();

    /**
     * Test the update password functionality part
     */
    /*@Test
    void should_return_update_pwd_ok() throws Exception {


        String hashed = DigestUtils.sha256Hex(detailConnexionDTO.getLogin() + StringUtils.lowerCase(StringUtils.defaultIfBlank(detailConnexionDTO.getEmail(), "")) + detailConnexionDTO.getNewPassword());

        detailConnexionDTO.setNewPassword(hashed);

        updatePasswordService.updatePassword(detailConnexionDTO);

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_UPDATE_PWD_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(detailConnexionDTO))
                        .characterEncoding("UTF-8"))
                .andExpect(status().isOk());

    }


    @Test
    void should_return_update_pwd_and_return_500() throws Exception {

        detailConnexionDTO = null;

        doThrow(new FunctionnalException("code", "message")).when(updatePasswordService).updatePassword(detailConnexionDTO);

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_UPDATE_PWD_LINKS)
                        .content(asJsonString(detailConnexionDTO))
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());
    }*/



    public static String asJsonString(final Object obj) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
