package com.uptevia.ms.bff.investor.auth.app.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.LoginRequestDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.PlanetShareRequestDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserPlanetShareDTO;
import com.uptevia.ms.bff.investor.auth.domain.service.AuthService;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.List;
import java.util.stream.Collectors;

import static org.mockito.ArgumentMatchers.any;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(AuthController.class)
class AuthenticateControllerTest {

    private static final String URL_GET_ACTIONNAIRE_LINKS = "/api/v1/authenticate";

    private static final String URL_GET_OLIS_ACTIONNAIRE_LINK = "/api/v1/authenticate/ancient-olis-account";

    private static final String URL_GET_PLANETSHARE_ACTIONNAIRE_LINK = "/api/v1/authenticate/ancient-planetshare";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AuthService authService;


    private final EasyRandom easyRandom = new EasyRandom();

    private final LoginRequestDTO loginRequestDTO = LoginRequestDTO.builder()
            .login("99963514")
            .password("2")
            .build();

    private final PlanetShareRequestDTO planetShareRequestDTO = PlanetShareRequestDTO.builder()
            .emetIden(12345)
            .accessCode("testTest")
            .password("password")
            .build();

    /* @Test
    void should_return_get_user_ok() throws Exception {

        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);

        Mockito.when(authService.authenticate(loginRequestDTO)).thenReturn(userDTO);

        userDTO.setPassword(DigestUtils.sha256Hex(loginRequestDTO.getLogin() + StringUtils.lowerCase(StringUtils.defaultIfBlank(userDTO.getEmail(), "")) + loginRequestDTO.getPassword()));

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_GET_ACTIONNAIRE_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(loginRequestDTO))
                .characterEncoding("UTF-8"))
                .andExpect(status().isOk());

    }

    @Test
    void should_return_get_user_and_return_500() throws Exception {

        Mockito.when(authService.authenticate(any(LoginRequestDTO.class))).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_GET_ACTIONNAIRE_LINKS)
                        .content(asJsonString(loginRequestDTO))
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void should_return_get_user_and_return_400() throws Exception {

        Mockito.when(authService.authenticate(any(LoginRequestDTO.class))).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_GET_ACTIONNAIRE_LINKS)
                        .content(asJsonString(loginRequestDTO))
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void should_return_get_olis_user_ok() throws Exception {

        List<UserDTO> userDTOS = easyRandom.objects(UserDTO.class, 3).collect(Collectors.toList());

        Mockito.when(authService.ancientOlisAccount(loginRequestDTO)).thenReturn(userDTOS);

        UserDTO userDTO = userDTOS.get(0);

        userDTO.setPassword(DigestUtils.sha256Hex(loginRequestDTO.getLogin() + StringUtils.lowerCase(StringUtils.defaultIfBlank(userDTO.getEmail(), "")) + loginRequestDTO.getPassword()));

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_GET_OLIS_ACTIONNAIRE_LINK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(loginRequestDTO))
                        .characterEncoding("UTF-8"))
                .andExpect(status().isOk());

    }

    @Test
    void should_return_get_olis_user_and_return_500() throws Exception {

        Mockito.when(authService.ancientOlisAccount(any(LoginRequestDTO.class))).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_GET_OLIS_ACTIONNAIRE_LINK)
                        .content(asJsonString(loginRequestDTO))
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void should_return_get_olis_user_and_return_400() throws Exception {

        Mockito.when(authService.ancientOlisAccount(any(LoginRequestDTO.class))).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_GET_OLIS_ACTIONNAIRE_LINK)
                        .content(asJsonString(loginRequestDTO))
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isBadRequest());
    }


    @Test
    void should_return_get_user_planetShare_ok() throws Exception {

        List<UserPlanetShareDTO> userPlanetShareDTOS = easyRandom.objects(UserPlanetShareDTO.class, 3).collect(Collectors.toList());

        Mockito.when(authService.ancientPlanetShare(1234, "testtest", "password")).thenReturn(userPlanetShareDTOS);

        UserPlanetShareDTO userPlanetShareDTO = userPlanetShareDTOS.get(0);

        userPlanetShareDTO.setPassword(DigestUtils.sha256Hex(StringUtils.defaultIfBlank(userPlanetShareDTO.getSaltPassword(), "")) + userPlanetShareDTO.getPassword());

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_GET_PLANETSHARE_ACTIONNAIRE_LINK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(planetShareRequestDTO))
                        .characterEncoding("UTF-8"))
                .andExpect(status().isOk());
    }

    @Test
    void should_return_get_planetShare_user_and_return_500() throws Exception {

        Mockito.when(authService.ancientPlanetShare(planetShareRequestDTO.getEmetIden(), planetShareRequestDTO.getAccessCode(), planetShareRequestDTO.getPassword()))
                .thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_GET_PLANETSHARE_ACTIONNAIRE_LINK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(planetShareRequestDTO))
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void should_return_get_planetShare_user_and_return_400() throws Exception {

        Mockito.when(authService.ancientPlanetShare(planetShareRequestDTO.getEmetIden(), planetShareRequestDTO.getAccessCode(), planetShareRequestDTO.getPassword()))
                .thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_GET_PLANETSHARE_ACTIONNAIRE_LINK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(planetShareRequestDTO))
                        .characterEncoding("UTF-8"))
                .andExpect(status().isBadRequest());
    }*/

    public static String asJsonString(final Object obj) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
