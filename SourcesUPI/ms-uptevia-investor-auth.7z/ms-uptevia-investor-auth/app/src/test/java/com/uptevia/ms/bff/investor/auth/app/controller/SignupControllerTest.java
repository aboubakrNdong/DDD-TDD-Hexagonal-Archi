package com.uptevia.ms.bff.investor.auth.app.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.EmetteurDetailsDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.SecretQuestionsDTO;
import com.uptevia.ms.bff.investor.auth.domain.service.SignupService;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(SignupController.class)
class SignupControllerTest {

    private static final String URL_SIGNUP_SECRET_QUESTIONS_LINKS = "/api/v1/signup/secret-questions";

    private static final String URL_SIGNUP_VERIFY_IDENTITY_LINKS = "/api/v1/signup/verifyIdentity";

    private static final String URL_SIGNUP_SAVE_PASSWORD_LINKS = "/api/v1/signup/savePassword";

    private static final String URL_SIGNUP_SAVE_SECRET_QUESTIONS_LINKS = "/api/v1/signup/save-secret-questions";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private SignupService signupService;

    private final EmetteurDetailsDTO emetteurDetailsDTO = EmetteurDetailsDTO.builder()
            .email("test@test.fr")
            .dateNaissance(LocalDate.parse("2023-10-20"))
            .emetFirstname("emetteur")
            .identifiant("123456789")
            .numCpte("1")
            .nomFamille("test")
            .prenom("test")
            .telephone("079854321")
            .build();

    private final EasyRandom easyRandom = new EasyRandom();

    /*@Test
    void should_return_verify_identity_ok() throws Exception {

        Mockito.when(signupService.verifyIdentity(emetteurDetailsDTO)).thenReturn(true);

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_SIGNUP_VERIFY_IDENTITY_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(emetteurDetailsDTO))
                        .characterEncoding("UTF-8"))
                .andExpect(status().isOk());

    }


    @Test
    void should_return_verify_identity_404() throws Exception {

        Mockito.when(signupService.verifyIdentity(Mockito.any(EmetteurDetailsDTO.class))).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_SIGNUP_VERIFY_IDENTITY_LINKS)
                        .content(asJsonString(emetteurDetailsDTO))
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());
    }


    @Test
    void should_return_secret_questions_OK() throws Exception {

        String idListe = "1";
        Integer emetIden = 123456;
        List<SecretQuestionsDTO> secretQuestionsDTOS = easyRandom.objects(SecretQuestionsDTO.class, 3)
                .collect(Collectors.toList());

        Mockito.when(signupService.secretQuestions(idListe, emetIden)).thenReturn(secretQuestionsDTOS);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_SIGNUP_SECRET_QUESTIONS_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("idListe", idListe)
                        .queryParam("emetIden", String.valueOf(emetIden))
                        .characterEncoding("UTF-8"))
                .andExpect(jsonPath("$.*").isArray())
                .andExpect(jsonPath("$.[0].idQuestion").exists())
                .andExpect(jsonPath("$.[0].questionKey").exists())
                .andExpect(jsonPath("$.[0].questionKey").value(secretQuestionsDTOS.get(0).getQuestionKey()));
    }

    @Test
    void should_return_secret_questions_404() throws Exception {
        String idListe = "1";
        Integer emetIden = 123456;

        Mockito.when(signupService.secretQuestions(idListe, emetIden)).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_SIGNUP_SECRET_QUESTIONS_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("idListe", idListe)
                        .queryParam("emetIden", String.valueOf(emetIden))
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());
    }

    @Test
    void should_return_secret_questions_400() throws Exception {
        String idListe = "1";
        Integer emetIden = 123456;

        Mockito.when(signupService.secretQuestions(idListe, emetIden)).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_SIGNUP_SECRET_QUESTIONS_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("emetIden", String.valueOf(emetIden))
                        .characterEncoding("UTF-8"))
                .andExpect(status().isBadRequest());
    }

    @Test
    void should_return_secret_questions_500() throws Exception {
        String idListe = "1";
        Integer emetIden = 123456;

        Mockito.when(signupService.secretQuestions(idListe, emetIden)).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_SIGNUP_SECRET_QUESTIONS_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("idListe", idListe)
                        .queryParam("emetIden", String.valueOf(emetIden))
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());
    }*/
    public static String asJsonString(final Object obj) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
