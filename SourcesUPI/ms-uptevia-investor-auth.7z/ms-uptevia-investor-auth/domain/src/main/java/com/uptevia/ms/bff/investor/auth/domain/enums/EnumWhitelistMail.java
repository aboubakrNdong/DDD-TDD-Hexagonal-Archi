package com.uptevia.ms.bff.investor.auth.domain.enums;

public enum EnumWhitelistMail {

    ABOUBAKR("aboubakr-assadiq.ndong@uptevia.com"),

    BORIS("boris.sodoloufo@uptevia.com"),

    STEPHANE("stephane.duris@uptevia.com"),

    JULIEN("julien.maillard@uptevia.com"),

    JULIENBIS("jul.maillard@gmail.com"),

    KATIA("katia.boukais@uptevia.com"),

    SANDRINE("sandrine.brenot@uptevia.com"),

    HERITIER("heritier.icard@uptevia.com"),

    LUDOVIC ("ludovic.tennerel@uptevia.com"),

    GUILHEM("guilhem.becane@uptevia.com"),

    IBTISSEM ("ibtissem.belhadj-sliman@uptevia.com");

    private final String mail;

    EnumWhitelistMail(String authorizedmail) {
        this.mail = authorizedmail;
    }

    public String getMail() {
        return mail;
    }

    @Override
    public String toString() {
        return mail;
    }
    public static boolean isInWhiteList(String email){
        for(EnumWhitelistMail whitelistMail : EnumWhitelistMail.values()) {
            if(whitelistMail.getMail().equalsIgnoreCase(email)){
                return true;
            }
        }
        return false;
    }

}