package com.uptevia.ms.bff.investor.auth.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
public class DetailConnexionDTO {

    private String login;

    private String newPassword;

    private String oldPassword;

    private String email;

}
