package com.uptevia.ms.bff.investor.auth.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter
public class EabonnementDTO {

    private String login;

    private String emetIden;

    private String actiIden;

    private Integer tituNume;

    private String choix;
}
