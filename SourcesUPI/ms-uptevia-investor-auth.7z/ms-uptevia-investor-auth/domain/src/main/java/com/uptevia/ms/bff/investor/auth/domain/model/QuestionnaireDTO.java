package com.uptevia.ms.bff.investor.auth.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class QuestionnaireDTO {

    private String login;

    private String password;

    private Integer firstQuestion;

    private String firstAnswer;

    private String encryptionkeyFirstAnswer;

    private Integer secondQuestion;

    private String secondAnswer;

    private String encryptionKeySecondAnswer;

    private String buttonChoice;

}
