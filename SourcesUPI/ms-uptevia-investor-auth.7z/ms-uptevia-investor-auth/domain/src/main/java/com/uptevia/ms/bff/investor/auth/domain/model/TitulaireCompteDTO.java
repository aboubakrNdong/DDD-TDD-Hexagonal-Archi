package com.uptevia.ms.bff.investor.auth.domain.model;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@Builder
public class TitulaireCompteDTO {

    private Integer idenTifiant;

    private String nom;

    private String prenom;

    private LocalDate dateNaissance;

    private String email;

    private String telephone;

    private String numCpte;

    private String emetFirstname;
}
