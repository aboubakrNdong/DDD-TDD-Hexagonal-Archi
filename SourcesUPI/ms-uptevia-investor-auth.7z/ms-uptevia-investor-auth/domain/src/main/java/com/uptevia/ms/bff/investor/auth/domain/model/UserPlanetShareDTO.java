package com.uptevia.ms.bff.investor.auth.domain.model;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class UserPlanetShareDTO {

    private String password;

    private String saltPassword;

    private String emetIden;

    private String actiIden;

    private String tituNume;

    private String loginUpi;

    private String email;
    private String numMobile;

}
