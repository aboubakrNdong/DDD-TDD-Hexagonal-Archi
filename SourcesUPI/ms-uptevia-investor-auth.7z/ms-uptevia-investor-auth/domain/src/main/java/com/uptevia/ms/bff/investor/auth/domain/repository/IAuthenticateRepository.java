package com.uptevia.ms.bff.investor.auth.domain.repository;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.EabonnementDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserPlanetShareDTO;

import java.util.List;

public interface IAuthenticateRepository {

    UserDTO authenticate(final String login, final String password) throws FunctionnalException;

    Long updateNbAcces(final String login) throws FunctionnalException;

    Long updateNbEssai(final String login,final int number) throws FunctionnalException;

    List<UserDTO> ancientOlisAccount(final String login) throws FunctionnalException;

    List<UserPlanetShareDTO> ancientPlanetShare(final Integer emetIden, final String accessCode) throws FunctionnalException;

    UserDTO getUpiUtilUser(String login);

    Long updateDateMajOtp(String login) throws FunctionnalException;
    void acceptCgu(final EabonnementDTO eabonnementDTO);

}

