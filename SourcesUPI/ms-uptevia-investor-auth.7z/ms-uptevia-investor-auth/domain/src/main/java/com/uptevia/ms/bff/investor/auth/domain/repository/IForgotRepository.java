package com.uptevia.ms.bff.investor.auth.domain.repository;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.ForgotIdentifiantDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.SendEmailDTO;

import java.time.LocalDate;

public interface IForgotRepository {

    ForgotIdentifiantDTO getIdentifiant(String pEmetIden, String pActiIden, String pNom, String pPrenom, LocalDate pDateNais) throws FunctionnalException;

    String getFrontUrl();

    boolean sendEmailWithURL(SendEmailDTO sendEmailDTO);
}