package com.uptevia.ms.bff.investor.auth.domain.repository;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;

import java.util.List;

public interface ISignUpRepository {

    TitulaireCompteDTO getTitulareComptes(final String login) throws FunctionnalException;

    UserDTO questionsAnswerCheck(final String login, final String password) throws FunctionnalException;


    List<SecretQuestionsDTO> secretQuestions(final String idListe, final Integer emetIden) throws FunctionnalException;

    void saveSecretQuestions(final QuestionnaireDTO questionnaireDTO);

    boolean sendTheEmailURL(SendEmailDTO sendEmailDTO);



}
