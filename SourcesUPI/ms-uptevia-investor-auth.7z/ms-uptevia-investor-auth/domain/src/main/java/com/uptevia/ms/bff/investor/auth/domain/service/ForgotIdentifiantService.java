package com.uptevia.ms.bff.investor.auth.domain.service;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;



public interface ForgotIdentifiantService {

    String verifyIdentifiant(final NewIdentifiantDTO newIdentifiantDTO) throws FunctionnalException;

    SendEmailDTO sendResetTokenByEmail(String login, String buttonChoice) throws FunctionnalException;

    UserDTO verifyResetToken(String chaine) throws Exception;
}
