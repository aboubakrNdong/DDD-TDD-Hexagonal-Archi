package com.uptevia.ms.bff.investor.auth.domain.service;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;

import java.util.List;

public interface SignupService {

    boolean verifyIdentity(final EmetteurDetailsDTO emetteurDetailsDTO) throws FunctionnalException;

    boolean checkQuestionsAnswers(final QuestionnaireDTO questionnaireDTO) throws FunctionnalException;


    void savePassword(final DetailConnexionDTO detailConnexionDTO) throws FunctionnalException;

    List<SecretQuestionsDTO> secretQuestions(final String idListe, final Integer emetIden) throws FunctionnalException;

    void saveSecretQuestions(final QuestionnaireDTO questionnaireDTO) throws FunctionnalException;
}
