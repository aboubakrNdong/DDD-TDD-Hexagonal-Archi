package com.uptevia.ms.bff.investor.auth.domain.service.impl;


import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.IntPredicate;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SuppressWarnings("java:S1118")
public abstract class AbstractAuthService {

    private  static final String DATE_REGEX = "^([0-2][\\d]||3[0-1])/(0[\\d]||1[0-2])/([\\d][\\d])?[\\d][\\d]$";
    private static final Pattern Date_PATTERN = Pattern.compile(DATE_REGEX);

    private static final String SPECIAL_CHARACTER = "[^a-zA-Z0-9]";

    private static final String NUMERIC_CONSECUTIVE_SEQUENCE = ".*\\d{6}.*";

    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }

    public static boolean isAlphaNumeric(String s) {
        return s != null && s.matches("^[a-zA-Z0-9]");
    }

    /**
     * method to check if a date is valid using "jj/mm/aaaa" pattern
     * @param date
     * @return
     */
    public static boolean dateValidator(String date)
    {
        Matcher matcher = Date_PATTERN.matcher(date);
        return matcher.matches();
    }


    public static boolean hasSpecialCharacter(final String chaine) {
        return chaine.equals(chaine.replaceAll(SPECIAL_CHARACTER, ""));
    }

    public static boolean hasNumber(final String chaine) {
        String regex = "(.)*(\\d)(.)*";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(chaine);
        return matcher.matches();
    }

    private static boolean contains(String value, IntPredicate predicate) {
        return value.chars().anyMatch(predicate);
    }

    public static boolean containsLowerCase(String value) {
        return contains(value, i -> Character.isLetter(i) && Character.isLowerCase(i));
    }

    public static boolean containsUpperCase(String value) {
        return contains(value, i -> Character.isLetter(i) && Character.isUpperCase(i));
    }

    public static String cryptedHashePwd(final String login, final String newPassword, final String email) {
        return DigestUtils.sha256Hex(login + StringUtils.lowerCase(StringUtils.defaultIfBlank(email, "")) + newPassword);
    }

    /**
     * method to check if string contains sequence of 6 consecutive digits
     * @return boolean
     */
    public static boolean containsSequence(String value) {
        Pattern pattern = Pattern.compile(NUMERIC_CONSECUTIVE_SEQUENCE);
        Matcher matcher = pattern.matcher(value);
        return matcher.matches();
    }
}
