package com.uptevia.ms.bff.investor.auth.domain.service.impl;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.uptevia.ms.bff.investor.auth.domain.enums.EnumWhitelistMail;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.IForgotRepository;
import com.uptevia.ms.bff.investor.auth.domain.service.ForgotIdentifiantService;

import java.io.IOException;
import java.util.*;

import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;
import com.uptevia.ms.bff.investor.auth.domain.util.ToolsManager;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.uptevia.ms.bff.investor.auth.domain.util.Constantes.LOGIN_TEXT_BAD_CREDENTIALS;
import static com.uptevia.ms.bff.investor.auth.domain.util.Constantes.MANDATORY_FIELD;
import static com.uptevia.ms.bff.investor.auth.domain.util.Constantes.MAIL_NOT_IN_WHITELIST;


public class ForgotIdentifiantServiceImpl implements ForgotIdentifiantService {
    //TODO implements logs
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final IForgotRepository iForgotRepository;

    private final IAuthenticateRepository iAuthenticateRepository;

    public static final String buttonForgotPassword = "forgotpassword";

    public static final String buttonFirstConnexion = "firstconnexion";

    public static final String buttonOldOlis = "oldolis";


    public static final String buttonOldPls = "oldpls";


    public static final String buttonForgotIdentifiant = "forgotidentifiant";


    public String mailTextBody = "";

    public String mailSubject = "";

    public static String userEmail = "";


    public ForgotIdentifiantServiceImpl(IForgotRepository iForgotRepository, IAuthenticateRepository iAuthenticateRepository) {
        this.iForgotRepository = iForgotRepository;
        this.iAuthenticateRepository = iAuthenticateRepository;
    }


    @Override
    public String verifyIdentifiant(final NewIdentifiantDTO newIdentifiantDTO) throws FunctionnalException {

        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("pActiIden", newIdentifiantDTO.getPActiIden());

        //if nom or prenom are null throws exception
        if (StringUtils.isBlank(newIdentifiantDTO.getPNom()) || StringUtils.isBlank(newIdentifiantDTO.getPPrenom())) {
            contextParams.put("pNom, pPrenom ", newIdentifiantDTO.getPNom());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        ForgotIdentifiantDTO forgotIdentifiantDTO = iForgotRepository.getIdentifiant(newIdentifiantDTO.getPEmetIden(), newIdentifiantDTO.getPActiIden(), newIdentifiantDTO.getPNom(), newIdentifiantDTO.getPPrenom(), newIdentifiantDTO.getPDateNais());

        if (StringUtils.isBlank(forgotIdentifiantDTO.getLoginUpi())) {
            contextParams.put("le login est vide ", newIdentifiantDTO.getPActiIden());
            throw new FunctionnalException(LOGIN_TEXT_BAD_CREDENTIALS, LOGIN_TEXT_BAD_CREDENTIALS, contextParams);
        }


        return forgotIdentifiantDTO.getLoginUpi();
    }


    private String createURLTokenForResetPassword(String login, String destEmail) throws FunctionnalException {

        ObjectMapper objectMap = new ObjectMapper();
        ObjectNode json = objectMap.createObjectNode();

        json.put(Constantes.JSON_PARAM_EMAIL, destEmail);
        json.put(Constantes.JSON_PARAM_TIME, new Date().getTime());
        json.put(Constantes.JSON_PARAM_ACTION, Constantes.MAIL_MDP_PERDU);
        json.put(Constantes.JSON_PARAM_LOGIN, login);

        String encrypted = ToolsManager.asHex(ToolsManager.encryptJSONStringToBytes(ToolsManager.SECRET_KEY, ToolsManager.IV_PARAMETER_SPEC, json.toString()));
        return iForgotRepository.getFrontUrl() + "#/setpassword?sd=" + encrypted;

    }

    @Override
    public SendEmailDTO sendResetTokenByEmail(String login, String buttonChoice) throws FunctionnalException {
        //TODO: A partir du login, récupérer le mail de l'utilisateur: utiliser TitulaireCompteDTO

        logger.info("le butonChoice est  : " + buttonChoice);

        if(!StringUtils.isBlank(login)){
            UserDTO psSelDetailTituDTO = iAuthenticateRepository.authenticate(login, "");
            this.userEmail =  psSelDetailTituDTO.getEmail();
        }

        if (StringUtils.equals(buttonChoice, buttonForgotIdentifiant)) {
            this.mailTextBody = "Voici votre Login UPI: " + login + ", vous pouvez à present vous connecter! <br /> " +
                     "<br /> <br /> <br />";
            this.mailSubject ="Votre Login UPI";
        }

        if (StringUtils.equals(buttonChoice, buttonForgotPassword)) {
            this.mailTextBody = "Vous avez demandé une réinitialisation de votre mot de passe. Merci de cliquer sur le lien suivant: <br /> " +
                    createURLTokenForResetPassword(login, userEmail) + "<br /> <br /> <br />";
            this.mailSubject ="Réinitialisation de votre mot de passe";
        }

        if (StringUtils.equals(buttonChoice, buttonFirstConnexion)) {
            this.mailTextBody = "C'est votre premiére connexion sur UPI.Pour configurer votre Mot De Passe, Merci de cliquer sur le lien suivant: <br /> " +
                    createURLTokenForFirstConnexion(login, userEmail) + "<br /> <br /> <br />";
            this.mailSubject = "Premiére connexion sur UPI";
        }

        if (StringUtils.equals(buttonChoice, buttonOldOlis)) {
            this.mailTextBody = "Vous etes un ancien client OLIS.Pour configurer votre Mot De Passe, Merci de cliquer sur le lien suivant: <br /> " +
                    createURLTokenForOldOlis(login, userEmail) + "<br /> <br /> <br />";
            this.mailSubject = "Ancien client OLIS";
        }
        if (StringUtils.equals(buttonChoice, buttonOldPls)) {
            this.mailTextBody = "Vous etes un Ancien Planet Share.Pour configurer votre Mot De Passe, Merci de cliquer sur le lien suivant: <br /> " +
                    createURLTokenForExPlaneshare(login, userEmail) + "<br /> <br /> <br />" +
                    "Attention! ce lien est valable 24 heures <br /> <br /> <br />";
            this.mailSubject = "Ancien Planet Share premiére connexion ";
        }

        List<String> recipient = List.of(userEmail);

        //TODO: Pourquoi Attachement serait mandatory pour ce type de mail ?
        final AttachmentsDTO attachDoc = AttachmentsDTO.builder()
                .fileName("New Login")
                .file("")
                .build();
        List<AttachmentsDTO> attachmentsList = Arrays.asList(attachDoc);

        return SendEmailDTO.builder()
                .from("no-reply@uptevia.com")
                .textBody(mailTextBody)
                .htmlBody("")
                .subject(mailSubject)//TODO: Prevoir une traduction en fonction des langues
                .typeMail("string")
                .recipients(recipient)
                .attachments(attachmentsList)
                .build();
    }

    /**
     * @param chaine
     * @return
     * @throws IOException
     */
    @Override
    public UserDTO verifyResetToken(final String chaine) throws IOException, FunctionnalException {

        JsonNode jObj;
        try {
            if (StringUtils.isBlank(chaine)) {
                return null;
            }

            byte[] bSd = ToolsManager.hexToByteArray(chaine);
            bSd = ToolsManager.decryptAes(bSd);
            String decrypt = new String(bSd);

            ObjectMapper mapper = new ObjectMapper();
            JsonFactory factory = mapper.getJsonFactory();

            JsonParser parser = factory.createJsonParser(decrypt);
            jObj = mapper.readTree(parser);


            // On teste l'ancienneté de la requête
            Long askDate = jObj.get("time").asLong();
            Long delayAsLong = Constantes.DELAY;
            long now = System.currentTimeMillis();
            if (now > (askDate + (delayAsLong * 60 * 1000))) {
                logger.warn("!La requête est trop ancienne " + decrypt);
                return null;
            }

        } catch (Exception e1) {
            logger.warn("Exception" + e1);
            return null;
        }


        String login = jObj.get("lg").asText();
        UserDTO userDTO = null;
        if (!StringUtils.isBlank(login)) {
            userDTO = iAuthenticateRepository.authenticate(login, "");
        }

        return userDTO;
    }

    private String createURLTokenForFirstConnexion(final String login, final String destEmail) throws FunctionnalException {

        ObjectMapper objectMap = new ObjectMapper();
        ObjectNode json = objectMap.createObjectNode();

        json.put(Constantes.JSON_PARAM_EMAIL, destEmail);
        json.put(Constantes.JSON_PARAM_TIME, new Date().getTime());
        json.put(Constantes.JSON_PARAM_ACTION, Constantes.MAIL_MDP_PERDU);
        json.put(Constantes.JSON_PARAM_LOGIN, login);

        String encrypted = ToolsManager.asHex(ToolsManager.encryptJSONStringToBytes(ToolsManager.SECRET_KEY, ToolsManager.IV_PARAMETER_SPEC, json.toString()));
        return iForgotRepository.getFrontUrl() + "#/setpassword?dt=" + encrypted;

    }

    private String createURLTokenForOldOlis(String login, String destEmail) throws FunctionnalException {

        ObjectMapper objectMap = new ObjectMapper();
        ObjectNode json = objectMap.createObjectNode();

        json.put(Constantes.JSON_PARAM_EMAIL, destEmail);
        json.put(Constantes.JSON_PARAM_TIME, new Date().getTime());
        json.put(Constantes.JSON_PARAM_ACTION, Constantes.MAIL_MDP_PERDU);
        json.put(Constantes.JSON_PARAM_LOGIN, login);

        String encrypted = ToolsManager.asHex(ToolsManager.encryptJSONStringToBytes(ToolsManager.SECRET_KEY, ToolsManager.IV_PARAMETER_SPEC, json.toString()));
        return iForgotRepository.getFrontUrl() + "#/setpassword?ol=" + encrypted;

    }

    private String createURLTokenForExPlaneshare(final String login, final String destEmail) throws FunctionnalException {

        ObjectMapper objectMap = new ObjectMapper();
        ObjectNode json = objectMap.createObjectNode();

        json.put(Constantes.JSON_PARAM_EMAIL, destEmail);
        json.put(Constantes.JSON_PARAM_TIME, new Date().getTime());
        json.put(Constantes.JSON_PARAM_ACTION, Constantes.MAIL_MDP_PERDU);
        json.put(Constantes.JSON_PARAM_LOGIN, login);

        String encrypted = ToolsManager.asHex(ToolsManager.encryptJSONStringToBytes(ToolsManager.SECRET_KEY, ToolsManager.IV_PARAMETER_SPEC, json.toString()));
        return iForgotRepository.getFrontUrl() + "#/setpassword?pl=" + encrypted;

    }

}
