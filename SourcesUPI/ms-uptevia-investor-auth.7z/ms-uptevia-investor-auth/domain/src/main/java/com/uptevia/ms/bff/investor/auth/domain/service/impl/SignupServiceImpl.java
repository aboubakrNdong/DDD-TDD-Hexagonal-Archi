package com.uptevia.ms.bff.investor.auth.domain.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.ISignUpRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.IUpdatePasswordRepository;
import com.uptevia.ms.bff.investor.auth.domain.service.SignupService;
import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;

import com.uptevia.ms.bff.investor.auth.domain.util.ToolsManager;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;  //TODO implements logs
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

import static com.uptevia.ms.bff.investor.auth.domain.service.impl.ForgotIdentifiantServiceImpl.userEmail;


public class SignupServiceImpl extends AbstractAuthService implements SignupService {


    //TODO implements logs
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final ISignUpRepository iSignUpRepository;

    private final IUpdatePasswordRepository iUpdatePasswordRepository;

    private static final String GLOBAL_FIELDS_COINCIDENCE_CHECK = "field.text.global";

    public static final String buttonForgotIdentifiant = "forgotidentifiant";

    private final IAuthenticateRepository iAuthenticateRepository;

    public SignupServiceImpl(ISignUpRepository iSignUpRepository, IUpdatePasswordRepository iUpdatePasswordRepository, IAuthenticateRepository iAuthenticateRepository) {
        this.iSignUpRepository = iSignUpRepository;
        this.iUpdatePasswordRepository = iUpdatePasswordRepository;
        this.iAuthenticateRepository = iAuthenticateRepository;
    }


    @Override
    public boolean verifyIdentity(final EmetteurDetailsDTO emetteurDetailsDTO) throws FunctionnalException {

        TitulaireCompteDTO titulaireCompteDTO = iSignUpRepository.getTitulareComptes(emetteurDetailsDTO.getIdentifiant());

        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("identifiant", emetteurDetailsDTO.getIdentifiant());

        /*
         * si ça matche pas alors on affichera un message général : identifiants et données ne coincïdent pas.
         * Merci de contrôler votre saisie
         */
        verifyAll(titulaireCompteDTO, emetteurDetailsDTO, contextParams);

        /*
         * nom de famille du titulaire ne correspond pas
         */
        if (titulaireCompteDTO.getNom() != null && emetteurDetailsDTO.getNomFamille() != null
                && !StringUtils.equals(titulaireCompteDTO.getNom(), emetteurDetailsDTO.getNomFamille())) {
            contextParams.put("nom famille", emetteurDetailsDTO.getNomFamille());
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_SURNAME, Constantes.LOGIN_TEXT_BAD_SURNAME, contextParams);
        }

        /*
         * prénom du titulaire ne correspond pas
         */
        if (titulaireCompteDTO.getPrenom() != null && emetteurDetailsDTO.getPrenom() != null
                && !StringUtils.equals(titulaireCompteDTO.getPrenom(), emetteurDetailsDTO.getPrenom())) {
            contextParams.put("prenom", emetteurDetailsDTO.getPrenom());
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_FIRSTNAME, Constantes.LOGIN_TEXT_BAD_FIRSTNAME, contextParams);
        }

        /*
         * date de naissance du titulaire ne correspond pas
         */
        if (titulaireCompteDTO.getDateNaissance() != null && emetteurDetailsDTO.getDateNaissance() != null
                && !titulaireCompteDTO.getDateNaissance().isEqual(emetteurDetailsDTO.getDateNaissance())) {
            contextParams.put("date naissance", emetteurDetailsDTO.getDateNaissance());
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_DOB, Constantes.LOGIN_TEXT_BAD_DOB, contextParams);
        }

        /*
         * Telephone du titulaire ne correspond pas
         */
        if (titulaireCompteDTO.getTelephone() != null && emetteurDetailsDTO.getTelephone() != null
                && !StringUtils.equals(titulaireCompteDTO.getTelephone(), emetteurDetailsDTO.getTelephone())) {
            contextParams.put("telephone", emetteurDetailsDTO.getTelephone());
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_PHONE, Constantes.LOGIN_TEXT_BAD_PHONE, contextParams);
        }

        /*
         * email du titulaire ne correspond pas
         */
        if (titulaireCompteDTO.getEmail() != null && emetteurDetailsDTO.getEmail() != null
                && !StringUtils.equals(titulaireCompteDTO.getEmail(), emetteurDetailsDTO.getEmail())) {
            contextParams.put("email", emetteurDetailsDTO.getEmail());
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_EMAIL, Constantes.LOGIN_TEXT_BAD_EMAIL, contextParams);
        }

        /*
         * nom de l'emetteur ne correspond pas
         */
        if (titulaireCompteDTO.getEmetFirstname() != null && emetteurDetailsDTO.getEmetFirstname() != null
                && !StringUtils.equals(titulaireCompteDTO.getEmetFirstname(), emetteurDetailsDTO.getEmetFirstname())) {
            contextParams.put("nom emetteur", emetteurDetailsDTO.getEmetFirstname());
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_EMETNAME, Constantes.LOGIN_TEXT_BAD_EMETNAME, contextParams);
        }

        /*
         * Numéro de compte Uptevia de l'emetteur ne correspond pas
         */
        if (titulaireCompteDTO.getNumCpte() != null && emetteurDetailsDTO.getNumCpte() != null
                && !StringUtils.equals(titulaireCompteDTO.getNumCpte(), emetteurDetailsDTO.getNumCpte())) {
            contextParams.put("num compte", emetteurDetailsDTO.getNumCpte());
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_NUMCOMPTE, Constantes.LOGIN_TEXT_BAD_NUMCOMPTE, contextParams);
        }

        return true;
    }

    @Override
    public void savePassword(final DetailConnexionDTO detailConnexionDTO) throws FunctionnalException {

        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("identifiant", detailConnexionDTO.getLogin());

        UserDTO userpls = iAuthenticateRepository.authenticate(detailConnexionDTO.getLogin(), "");
        /*
         * Hachage et cryptage du nouveau mot de passe
         */
        String hachedCryptedPwd = "";
        if (!StringUtils.isBlank(detailConnexionDTO.getNewPassword())) {
            hachedCryptedPwd = DigestUtils.sha256Hex(detailConnexionDTO.getNewPassword() + userpls.getSltPassword());
                    //cryptedHashePwd(detailConnexionDTO.getLogin(), detailConnexionDTO.getNewPassword(), detailConnexionDTO.getEmail());
        }
        /*
         * Recuperer les trois derniers mot de passe utilisés
         * Appel au fontion stockée: UPI_UTIL_IS_LAST_PWD
         */
        if (iUpdatePasswordRepository.getHistoricPasswords(detailConnexionDTO.getLogin(), hachedCryptedPwd, 3) > 0) {
            throw new FunctionnalException("majpassword.text.used", "majpassword.text.used", contextParams);
        }

        /*
         * si le mot de passe est trop simple (contient son identifiant ou contient une suite numérique de 6 chiffres)
         * le nouveau mot de passe n'est pas assez robuste, veuillez le modifier avant de cliquer sur Enregistrer
         */
        if (detailConnexionDTO.getNewPassword().contains(detailConnexionDTO.getLogin())
                || containsSequence(detailConnexionDTO.getNewPassword())) {
            contextParams.put("password", detailConnexionDTO.getLogin());
            throw new FunctionnalException("password.text.weak", "password.text.weak", contextParams);
        }

        /*
         * If all thing goes well then proceed to
         * saving password with the hached and crypted: password
         */
        iUpdatePasswordRepository.updatePassword(detailConnexionDTO.getLogin(), hachedCryptedPwd);
    }

    @Override
    public List<SecretQuestionsDTO> secretQuestions(final String idListe, final Integer emetIden) throws FunctionnalException {

        return iSignUpRepository.secretQuestions(idListe, emetIden);

    }

    @Override
    public void saveSecretQuestions(final QuestionnaireDTO questionnaireDTO) throws FunctionnalException {
        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("login", questionnaireDTO.getLogin());

        try {

            ObjectMapper objectMap = new ObjectMapper();
            ObjectNode json = objectMap.createObjectNode();

            json.put(Constantes.JSON_PARAM_ACTION, Constantes.SECRET_QUESTIONS);

            // Chiffrer la première réponse
            json.put(Constantes.JSON_PARAM_LOGIN, questionnaireDTO.getFirstAnswer());
            String encryptedFirst = ToolsManager.asHex(ToolsManager.encryptJSONStringToBytes(ToolsManager.SECRET_KEY, ToolsManager.IV_PARAMETER_SPEC, questionnaireDTO.getFirstAnswer()));

            // Chiffrer la deuxieme réponse
            json.put(Constantes.JSON_PARAM_LOGIN, questionnaireDTO.getSecondAnswer());
            String encryptedSecond = ToolsManager.asHex(ToolsManager.encryptJSONStringToBytes(ToolsManager.SECRET_KEY, ToolsManager.IV_PARAMETER_SPEC, questionnaireDTO.getSecondAnswer()));

            questionnaireDTO.setFirstAnswer(encryptedFirst);
            questionnaireDTO.setSecondAnswer(encryptedSecond);
            questionnaireDTO.setEncryptionkeyFirstAnswer(ToolsManager.SECRET_KEY);
            questionnaireDTO.setEncryptionKeySecondAnswer(ToolsManager.SECRET_KEY);


            // Sauvegarder dans la base de données
            iSignUpRepository.saveSecretQuestions(questionnaireDTO);

            logger.info("le buttonChoice est : " + questionnaireDTO.getButtonChoice());

        } catch (Exception e) {
            // Gérer les erreurs de chiffrement
            e.printStackTrace();
        }
    }


    @Override
    public boolean checkQuestionsAnswers(final QuestionnaireDTO questionnaireDTO) throws FunctionnalException {

        UserDTO userDTO = iSignUpRepository.questionsAnswerCheck(questionnaireDTO.getLogin(), questionnaireDTO.getPassword());

        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("login", questionnaireDTO.getLogin());
        String answerDecrypted1 = "";
        String answerDecrypted2 = "";

        try {
            answerDecrypted1 = ToolsManager.decryptSecretAnswer(userDTO.getReponseQuestionSecurite1());
            answerDecrypted2 = ToolsManager.decryptSecretAnswer(userDTO.getReponseQuestionSecurite2());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        /*
         * si ça matche pas alors on affichera un message général : Questions et réponses ne coincïdent pas.
         * Merci de contrôler votre saisie
         */
        checkAll(userDTO, questionnaireDTO, contextParams);

        /*
         * id de la premiereQuestion ne correspond pas
         */
        if (!(questionnaireDTO.getFirstQuestion() == 0 && userDTO.getIdQuestionSecurite1() == 0) && !(questionnaireDTO.getFirstQuestion() == userDTO.getIdQuestionSecurite1())) {
            contextParams.put("Id QuestionSecurite 1", questionnaireDTO.getFirstQuestion());
            throw new FunctionnalException(Constantes.SECRET_QUESTION_BAD_QUESTION1, Constantes.SECRET_QUESTION_BAD_QUESTION1, contextParams);
        }

        /*
         * id de la DeuxiemeQuestion ne correspond pas
         */
        if (!(questionnaireDTO.getSecondQuestion() == 0 && userDTO.getIdQuestionSecurite2() == 0) && !(questionnaireDTO.getSecondQuestion() == userDTO.getIdQuestionSecurite2())) {
            contextParams.put("Id QuestionSecurite 2", questionnaireDTO.getSecondQuestion());
            throw new FunctionnalException(Constantes.SECRET_QUESTION_BAD_QUESTION2, Constantes.SECRET_QUESTION_BAD_QUESTION2, contextParams);
        }

        /* Check  Answer1. */
        if (!StringUtils.equals(questionnaireDTO.getFirstAnswer(), answerDecrypted1 )) {
            throw new FunctionnalException(Constantes.SECRET_QUESTION_BAD_ANSWER1, Constantes.SECRET_QUESTION_BAD_ANSWER1, contextParams);
        }
        /* Check  Answer2. */
        if (!StringUtils.equals(questionnaireDTO.getSecondAnswer(), answerDecrypted2)) {
            throw new FunctionnalException(Constantes.SECRET_QUESTION_BAD_ANSWER2, Constantes.SECRET_QUESTION_BAD_ANSWER2, contextParams);
        }

            checkAll(userDTO, questionnaireDTO, contextParams);

            logger.info("le buttonChoice est : " + questionnaireDTO.getButtonChoice());

            return true;
    }


    private void verifyAll(final TitulaireCompteDTO titulaireCompteDTO, final EmetteurDetailsDTO emetteurDetailsDTO, final Map<String, Object> contextParams) throws FunctionnalException {
        if (ObjectUtils.allNotNull(titulaireCompteDTO.getNom(), titulaireCompteDTO.getPrenom(), titulaireCompteDTO.getTelephone(),
                titulaireCompteDTO.getEmetFirstname(), titulaireCompteDTO.getDateNaissance(), titulaireCompteDTO.getEmail(),
                titulaireCompteDTO.getNumCpte())
                && ObjectUtils.allNotNull(emetteurDetailsDTO.getNomFamille(), emetteurDetailsDTO.getPrenom(), emetteurDetailsDTO.getTelephone(),
                emetteurDetailsDTO.getEmetFirstname(), emetteurDetailsDTO.getDateNaissance(), emetteurDetailsDTO.getEmail(),
                emetteurDetailsDTO.getNumCpte())
                && (!StringUtils.equals(titulaireCompteDTO.getNumCpte(), emetteurDetailsDTO.getNumCpte())
                && !StringUtils.equals(titulaireCompteDTO.getEmetFirstname(), emetteurDetailsDTO.getEmetFirstname())
                && !StringUtils.equals(titulaireCompteDTO.getEmail(), emetteurDetailsDTO.getEmail())
                && !StringUtils.equals(titulaireCompteDTO.getTelephone(), emetteurDetailsDTO.getTelephone())
                && !titulaireCompteDTO.getDateNaissance().isEqual(emetteurDetailsDTO.getDateNaissance())
                && !StringUtils.equals(titulaireCompteDTO.getPrenom(), emetteurDetailsDTO.getPrenom())
                && !StringUtils.equals(titulaireCompteDTO.getNom(), emetteurDetailsDTO.getNomFamille()))) {
            throw new FunctionnalException(GLOBAL_FIELDS_COINCIDENCE_CHECK, GLOBAL_FIELDS_COINCIDENCE_CHECK, contextParams);
        }
    }


    private void checkAll(final UserDTO userDTO, final QuestionnaireDTO questionnaireDTO, final Map<String, Object> contextParams) throws FunctionnalException {
        if (ObjectUtils.allNotNull(userDTO.getIdQuestionSecurite1(), userDTO.getIdQuestionSecurite2())
                && ObjectUtils.allNotNull(questionnaireDTO.getFirstQuestion(), questionnaireDTO.getFirstAnswer(), questionnaireDTO.getSecondQuestion(), questionnaireDTO.getSecondAnswer())
                && !(userDTO.getIdQuestionSecurite1() == questionnaireDTO.getFirstQuestion())
                && !(userDTO.getIdQuestionSecurite2() == questionnaireDTO.getSecondQuestion())) {
            throw new FunctionnalException(GLOBAL_FIELDS_COINCIDENCE_CHECK, GLOBAL_FIELDS_COINCIDENCE_CHECK, contextParams);
        }
    }

}
