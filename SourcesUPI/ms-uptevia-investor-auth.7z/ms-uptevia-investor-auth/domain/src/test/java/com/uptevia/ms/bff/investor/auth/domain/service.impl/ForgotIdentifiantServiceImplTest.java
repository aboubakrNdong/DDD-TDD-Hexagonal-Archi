package com.uptevia.ms.bff.investor.auth.domain.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.IForgotRepository;
import com.uptevia.ms.bff.investor.auth.domain.service.ForgotIdentifiantService;
import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;
import com.uptevia.ms.bff.investor.auth.domain.util.ToolsManager;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;


import java.time.LocalDate;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ForgotIdentifiantServiceImplTest {

    @Mock
    private IForgotRepository iForgotRepository = mock(IForgotRepository.class);

    @Mock
    private IAuthenticateRepository iAuthenticateRepository = mock(IAuthenticateRepository.class);

    private ForgotIdentifiantService forgotIdentifiantService;

    @BeforeEach
    public void setUp() {
        forgotIdentifiantService = new ForgotIdentifiantServiceImpl(iForgotRepository, iAuthenticateRepository);
    }

    private final EasyRandom easyRandom = new EasyRandom();


    private final NewIdentifiantDTO newIdentifiantDTO = NewIdentifiantDTO.builder()
            .pEmetIden("99963514")
            .pActiIden("1")
            .pDateNais(LocalDate.now())
            .pNom("CHEVALIER")
            .pPrenom("THOMAS")
            .build();


    private final ForgotIdentifiantDTO forgotIdentifiantDTO = ForgotIdentifiantDTO.builder()
            .loginUpi("61691966")
            .build();

    @Test
    void should_verifyIdentifiant_return_ok() throws FunctionnalException {
        //Given
        String emetIden = "99963514";
        String actiIden = "1";
        LocalDate datenaiss = LocalDate.now();
        String nom = "CHEVALIER";
        String prenom = "THOMAS";
        Mockito.when(iForgotRepository.getIdentifiant(emetIden, actiIden, nom, prenom, datenaiss)).thenReturn(forgotIdentifiantDTO);
        Assertions.assertThat(forgotIdentifiantService.verifyIdentifiant(newIdentifiantDTO));
    }

    @Test
    void should_verifyIdentifiant_return_ko() throws FunctionnalException {
        //Given
        String emetIden = "99963514";
        String actiIden = "1";
        LocalDate datenaiss = LocalDate.now();
        String nom = "CHEVALIER";
        String prenom = "THOMAS";

        forgotIdentifiantDTO.setLoginUpi("");
        Mockito.when(iForgotRepository.getIdentifiant(emetIden, actiIden, nom, prenom, datenaiss)).thenReturn(forgotIdentifiantDTO);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> forgotIdentifiantService.verifyIdentifiant(newIdentifiantDTO));
        assertEquals(Constantes.LOGIN_TEXT_BAD_CREDENTIALS, exception.getCode());
    }

/*
    @Test
    void should_verifyResetToken_moinsDe10min_ok() throws Exception {

        ObjectMapper objectMap = new ObjectMapper();
        ObjectNode json = objectMap.createObjectNode();

        String login = "61691966";
        json.put(Constantes.JSON_PARAM_EMAIL, "aboubakr-assadiq.ndong@uptevia.com");
        json.put(Constantes.JSON_PARAM_TIME, new Date().getTime());
        json.put(Constantes.JSON_PARAM_ACTION, Constantes.MAIL_MDP_PERDU);
        json.put(Constantes.JSON_PARAM_LOGIN, login);

        String encrypted = ToolsManager.asHex(ToolsManager.encryptJSONStringToBytes(ToolsManager.SECRET_KEY, ToolsManager.IV_PARAMETER_SPEC, json.toString()));

        assertEquals(forgotIdentifiantService.verifyResetToken(encrypted).toString(), login);

    }

    @Test
    void should_ko_when_verify_expiredToken() throws Exception {

        long minutesLater = System.currentTimeMillis() - (Constantes.DELAY + 2) * 60 * 1000;
        ObjectMapper objectMap = new ObjectMapper();
        ObjectNode json = objectMap.createObjectNode();

        json.put(Constantes.JSON_PARAM_EMAIL, "aboubakr-assadiq.ndong@uptevia.com");
        json.put(Constantes.JSON_PARAM_TIME, new Date(minutesLater).getTime());
        json.put(Constantes.JSON_PARAM_ACTION, Constantes.MAIL_MDP_PERDU);
        json.put(Constantes.JSON_PARAM_LOGIN, "61691966");

        String encrypted = ToolsManager.asHex(ToolsManager.encryptJSONStringToBytes(ToolsManager.SECRET_KEY, ToolsManager.IV_PARAMETER_SPEC, json.toString()));

        assertNull(forgotIdentifiantService.verifyResetToken(encrypted));

    }
    */

}