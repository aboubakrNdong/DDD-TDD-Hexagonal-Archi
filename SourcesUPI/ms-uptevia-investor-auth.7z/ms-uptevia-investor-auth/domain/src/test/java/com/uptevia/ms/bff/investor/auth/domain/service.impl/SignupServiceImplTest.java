package com.uptevia.ms.bff.investor.auth.domain.service.impl;


import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.ISignUpRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.IUpdatePasswordRepository;
import com.uptevia.ms.bff.investor.auth.domain.service.SignupService;
import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SignupServiceImplTest {

    @Mock
    private IUpdatePasswordRepository iUpdatePasswordRepository = mock(IUpdatePasswordRepository.class);

    @Mock
    private ISignUpRepository iSignUpRepository = mock(ISignUpRepository.class);

    @Mock
    private IAuthenticateRepository iAuthenticateRepository = mock(IAuthenticateRepository.class);

    private SignupService signupService;


    @BeforeEach
    public void setUp() {
        signupService = new SignupServiceImpl(iSignUpRepository, iUpdatePasswordRepository, iAuthenticateRepository);
    }

    private final EasyRandom easyRandom = new EasyRandom();

    private final EmetteurDetailsDTO emetteurDetailsDTO = EmetteurDetailsDTO.builder()
            .email("test@test.fr")
            .dateNaissance(LocalDate.now())
            .emetFirstname("emetteur")
            .identifiant("123456789")
            .numCpte("1")
            .nomFamille("test")
            .prenom("test")
            .telephone("079854321")
            .build();


    private final QuestionnaireDTO questionnaireDTO = QuestionnaireDTO.builder()
            .login("123456789")
            .password("")
            .firstQuestion(1)
            .firstAnswer("testreponse1")
            .secondQuestion(2)
            .secondAnswer("testreponse2")
            .build();

    private final DetailConnexionDTO detailConnexionDTO = DetailConnexionDTO.builder()
            .login("123456789")
            .newPassword("password")
            .build();

    private final UserDTO userDTO = UserDTO.builder()
            .idQuestionSecurite1(1)
            .reponseQuestionSecurite1("testreponse1")
            .idQuestionSecurite2(2)
            .reponseQuestionSecurite2("testreponse2")
            .build();

    private final TitulaireCompteDTO titulaireCompteDTO = TitulaireCompteDTO.builder()
            .email("test@test.fr")
            .dateNaissance(LocalDate.now())
            .emetFirstname("emetteur")
            .numCpte("1")
            .nom("test")
            .prenom("test")
            .telephone("079854321")
            .build();



    @Test
    void should_verify_return_ok() throws FunctionnalException {
        Mockito.when(iSignUpRepository.getTitulareComptes(emetteurDetailsDTO.getIdentifiant())).thenReturn(titulaireCompteDTO);
        Assertions.assertThat(signupService.verifyIdentity(emetteurDetailsDTO)).isTrue();
    }

    @Test
    void when_idQuestion1_changed_should_checkQuestionsAnswers_return_KO() throws FunctionnalException {
        questionnaireDTO.setFirstQuestion(0);
        Mockito.when(iSignUpRepository.questionsAnswerCheck(questionnaireDTO.getLogin(), questionnaireDTO.getPassword())).thenReturn(userDTO);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> signupService.checkQuestionsAnswers(questionnaireDTO));
        assertEquals(Constantes.SECRET_QUESTION_BAD_QUESTION1, exception.getCode());
    }

    @Test
    void when_idQuestion2_changed_should_checkQuestionsAnswers_return_KO() throws FunctionnalException {
        questionnaireDTO.setSecondQuestion(0);
        Mockito.when(iSignUpRepository.questionsAnswerCheck(questionnaireDTO.getLogin(), questionnaireDTO.getPassword())).thenReturn(userDTO);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> signupService.checkQuestionsAnswers(questionnaireDTO));
        assertEquals(Constantes.SECRET_QUESTION_BAD_QUESTION2, exception.getCode());
    }

    @Test
    void when_email_changed_should_verify_return_KO() throws FunctionnalException {
        emetteurDetailsDTO.setEmail("");
        Mockito.when(iSignUpRepository.getTitulareComptes(emetteurDetailsDTO.getIdentifiant())).thenReturn(titulaireCompteDTO);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> signupService.verifyIdentity(emetteurDetailsDTO));
        assertEquals(Constantes.LOGIN_TEXT_BAD_EMAIL, exception.getCode());
    }

    @Test
    void when_name_changed_should_verify_return_KO() throws FunctionnalException {
        emetteurDetailsDTO.setNomFamille("");
        Mockito.when(iSignUpRepository.getTitulareComptes(emetteurDetailsDTO.getIdentifiant())).thenReturn(titulaireCompteDTO);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> signupService.verifyIdentity(emetteurDetailsDTO));
        assertEquals(Constantes.LOGIN_TEXT_BAD_SURNAME, exception.getCode());
    }

    @Test
    void when_surname_changed_should_verify_return_KO() throws FunctionnalException {
        emetteurDetailsDTO.setPrenom("");
        Mockito.when(iSignUpRepository.getTitulareComptes(emetteurDetailsDTO.getIdentifiant())).thenReturn(titulaireCompteDTO);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> signupService.verifyIdentity(emetteurDetailsDTO));
        assertEquals(Constantes.LOGIN_TEXT_BAD_FIRSTNAME, exception.getCode());
    }

    @Test
    void when_dob_changed_should_verify_return_KO() throws FunctionnalException {
        emetteurDetailsDTO.setDateNaissance(LocalDate.parse("2023-10-05"));
        Mockito.when(iSignUpRepository.getTitulareComptes(emetteurDetailsDTO.getIdentifiant())).thenReturn(titulaireCompteDTO);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> signupService.verifyIdentity(emetteurDetailsDTO));
        assertEquals(Constantes.LOGIN_TEXT_BAD_DOB, exception.getCode());
    }

    @Test
    void when_phone_changed_should_verify_return_KO() throws FunctionnalException {
        emetteurDetailsDTO.setTelephone("560932456");
        Mockito.when(iSignUpRepository.getTitulareComptes(emetteurDetailsDTO.getIdentifiant())).thenReturn(titulaireCompteDTO);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> signupService.verifyIdentity(emetteurDetailsDTO));
        assertEquals(Constantes.LOGIN_TEXT_BAD_PHONE, exception.getCode());
    }

    @Test
    void when_firstname_changed_should_verify_return_KO() throws FunctionnalException {
        emetteurDetailsDTO.setEmetFirstname("Robert");
        Mockito.when(iSignUpRepository.getTitulareComptes(emetteurDetailsDTO.getIdentifiant())).thenReturn(titulaireCompteDTO);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> signupService.verifyIdentity(emetteurDetailsDTO));
        assertEquals(Constantes.LOGIN_TEXT_BAD_EMETNAME, exception.getCode());
    }

    @Test
    void when_compte_changed_should_verify_return_KO() throws FunctionnalException {
        emetteurDetailsDTO.setNumCpte("9");
        Mockito.when(iSignUpRepository.getTitulareComptes(emetteurDetailsDTO.getIdentifiant())).thenReturn(titulaireCompteDTO);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> signupService.verifyIdentity(emetteurDetailsDTO));
        assertEquals(Constantes.LOGIN_TEXT_BAD_NUMCOMPTE, exception.getCode());
    }

    @Test
    void should_update_password_return_OK() throws FunctionnalException {
        UserDTO userPls = easyRandom.nextObject(UserDTO.class);
        String hashed = DigestUtils.sha256Hex(detailConnexionDTO.getNewPassword() + userPls.getSltPassword());

        Mockito.when(iAuthenticateRepository.authenticate(emetteurDetailsDTO.getIdentifiant(), "")).thenReturn(userPls);

        Mockito.when(iUpdatePasswordRepository.updatePassword(emetteurDetailsDTO.getIdentifiant(), hashed)).thenReturn(1L);

        signupService.savePassword(detailConnexionDTO);

        verify(iUpdatePasswordRepository, times(1)).updatePassword(emetteurDetailsDTO.getIdentifiant(), hashed);
    }

    @Test
    void when_password_contains_login_should_return_KO() throws FunctionnalException {
        UserDTO userPls = easyRandom.nextObject(UserDTO.class);
        Mockito.when(iAuthenticateRepository.authenticate(emetteurDetailsDTO.getIdentifiant(), "")).thenReturn(userPls);
        detailConnexionDTO.setNewPassword(emetteurDetailsDTO.getIdentifiant());
        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> signupService.savePassword(detailConnexionDTO));
        assertEquals("password.text.weak", exception.getCode());
    }

    @Test
    void when_password_contains_digit_sequence_should_return_KO()  throws FunctionnalException {
        UserDTO userPls = easyRandom.nextObject(UserDTO.class);
        Mockito.when(iAuthenticateRepository.authenticate(emetteurDetailsDTO.getIdentifiant(), "")).thenReturn(userPls);
        detailConnexionDTO.setNewPassword("1234567");
        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> signupService.savePassword(detailConnexionDTO));
        assertEquals("password.text.weak", exception.getCode());
    }

    /*
     * Partie de test de secretQuestions
     */
    @Test
    void when_secret_questions_not_found_should_return_KO() throws FunctionnalException {

        String idListe = "1";
        Integer emetIden = 123456;
        List<SecretQuestionsDTO> secretQuestionsDTOS = easyRandom.objects(SecretQuestionsDTO.class, 3)
                .collect(Collectors.toList());
        lenient().when(iSignUpRepository.secretQuestions(idListe, emetIden)).thenReturn(secretQuestionsDTOS);
        assertEquals(secretQuestionsDTOS.size(), 3);
    }

    @Test
    void when_secret_questions_should_return_OK() throws FunctionnalException {

        String idListe = "1";
        Integer emetIden = 123456;
        List<SecretQuestionsDTO> secretQuestionsDTOS = easyRandom.objects(SecretQuestionsDTO.class, 3)
                .collect(Collectors.toList());

        Mockito.when(iSignUpRepository.secretQuestions(idListe, emetIden)).thenReturn(secretQuestionsDTOS);

        Assertions.assertThat(signupService.secretQuestions(idListe, emetIden)).isEqualTo(secretQuestionsDTOS);
    }
}
