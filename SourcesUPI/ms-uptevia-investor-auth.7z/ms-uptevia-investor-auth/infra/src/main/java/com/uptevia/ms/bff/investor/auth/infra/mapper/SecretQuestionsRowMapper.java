package com.uptevia.ms.bff.investor.auth.infra.mapper;

import com.uptevia.ms.bff.investor.auth.domain.model.SecretQuestionsDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SecretQuestionsRowMapper implements RowMapper<SecretQuestionsDTO> {
    @Override
    public SecretQuestionsDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        System.out.println(rs.toString());
        return SecretQuestionsDTO.builder()
                .idQuestion(rs.getInt("ID_ELEMENT_LISTE"))
                .questionKey(rs.getString("LIBELLE_CLE"))
                .build();
    }
}
