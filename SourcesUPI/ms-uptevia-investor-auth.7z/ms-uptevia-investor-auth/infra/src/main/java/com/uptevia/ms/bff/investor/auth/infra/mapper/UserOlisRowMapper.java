package com.uptevia.ms.bff.investor.auth.infra.mapper;

import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

public class UserOlisRowMapper implements RowMapper<UserDTO> {

    @Override
    public UserDTO mapRow(final ResultSet rs, final int rowNum) throws SQLException {

        UserDTO userOlisDTO = UserDTO.builder()

                .login(rs.getString("LOGIN_OLIS"))
                .loginUpi(rs.getString("LOGIN_UPI"))
                .emetIden(rs.getString("EMET_IDEN"))
                .actiIden(rs.getString("ACTI_IDEN"))
                .tituNume(rs.getString("TITU_NUME"))
                .email(rs.getString("EMAIL"))
                .password(rs.getString("PASSWORD"))
                .build();


        ZoneOffset offset = ZoneOffset.UTC;

        if (rs.getDate("DATE_ACCES") != null) {
            LocalDateTime dateTimeAcces = rs.getTimestamp("DATE_ACCES").toLocalDateTime();
            userOlisDTO.setDateAccess(dateTimeAcces.atOffset(offset));
        }

        if (rs.getDate("DATE_VALIDITE_DEB") != null) {
            LocalDateTime dateDeb = rs.getTimestamp("DATE_VALIDITE_DEB").toLocalDateTime();
            userOlisDTO.setDateValiditeDEB(dateDeb.atOffset(offset));
        }

        if (rs.getDate("DATE_VALIDITE_FIN") != null) {
            LocalDateTime dateFin = rs.getTimestamp("DATE_VALIDITE_FIN").toLocalDateTime();
            userOlisDTO.setDateValiditeFin(dateFin.atOffset(offset));
        }

        return userOlisDTO;
    }
}
