package com.uptevia.ms.bff.investor.auth.infra.repositories;


import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;
import com.uptevia.ms.bff.investor.auth.infra.mapper.UserOlisRowMapper;
import com.uptevia.ms.bff.investor.auth.infra.mapper.UserPlanetShareRowMapper;
import com.uptevia.ms.bff.investor.auth.infra.mapper.UserRowMapper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class AuthenticateRepository implements IAuthenticateRepository {


    private final Logger logger = LoggerFactory.getLogger(this.getClass());


    @Autowired
    private JdbcTemplate jdbcTemplate;

    private static final String UPI_TITU_GET_BY_CRITERIA = "UPI_TITU_GET_BY_CRITERIA";

    private static final String PS_CUR = "PS_CUR";

    @Value("${base.business.url}")
    private String baseBusinessUrl;

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;


    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }
    @Override
    public UserDTO authenticate(final String login, final String password) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.UPI_UTIL_GET_BY_LOGIN)
                .returningResultSet(Constantes.PS_CUR,
                        new UserRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login)
                .addValue(Constantes.PARAM_PASSWORD, "");


        Map<String, Object> out = jdbcCall.execute(in);

        List<UserDTO> result = (List<UserDTO>) out.get(Constantes.PS_CUR);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("login", login);
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_CREDENTIALS, Constantes.LOGIN_TEXT_BAD_CREDENTIALS, contextParams);
        }

        return result.get(0);


    }

    @Override
    public Long updateNbAcces(final String login) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName(Constantes.UPI_UTIL_UPDATE_NB_ACCES); //function name

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login)
                .addValue(Constantes.PARAM_USER_MAJ, login);

        return jdbcCall.executeFunction(BigDecimal.class, in).longValue();

    }

    @Override
    public Long updateNbEssai(final String login, final int number) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName(Constantes.UPI_UTIL_UPDATE_NB_ESSAI); //function name

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login)
                .addValue(Constantes.PARAM_USER_MAJ, login)
                .addValue("PARAM_NB_ESSAIS", number);
        return jdbcCall.executeFunction(BigDecimal.class, in).longValue();
    }

    @Override
    public List<UserDTO> ancientOlisAccount(final String login) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.UPI_UTIL_GET_BY_LOGIN_OLIS)
                .returningResultSet("PS_CUR",
                        new UserOlisRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login);

        Map<String, Object> out = jdbcCall.execute(in);

        List<UserDTO> result = (List<UserDTO>) out.get("PS_CUR");

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("login", login);
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_CREDENTIALS, Constantes.EMPTY_DATA_EXCEPTION, contextParams);
        }

        return result;
    }


    @Override
    public List<UserPlanetShareDTO> ancientPlanetShare(final Integer emetIden, final String accessCode) throws FunctionnalException {

        logger.info("Begin getting data for planetshare user...");
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.UPI_UTIL_GET_BY_LOGIN_PLANETSHARES)
                .returningResultSet(Constantes.PS_CUR,
                        new UserPlanetShareRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_EMET_IDEN", StringUtils.leftPad(String.valueOf(emetIden), 5, "0"))
                .addValue("P_CDE_UTIL", accessCode);

        Map<String, Object> out = jdbcCall.execute(in);

        List<UserPlanetShareDTO> result = (List<UserPlanetShareDTO>) out.get(Constantes.PS_CUR);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("identifier", emetIden);
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_CREDENTIALS, Constantes.EMPTY_DATA_EXCEPTION, contextParams);
        }

        return result;
    }

    @Override
    public UserDTO getUpiUtilUser(String login) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.UPI_UTIL_GET_BY_LOGIN)
                .returningResultSet(Constantes.PS_CUR,
                        new UserRowMapper());
        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login)
                .addValue(Constantes.PARAM_PASSWORD, "");

        Map<String, Object> out = jdbcCall.execute(in);
        List<UserDTO> result = (List<UserDTO>) out.get(Constantes.PS_CUR);

        if (result.isEmpty()) {
            return  null;
        }
        return result.get(0);

    }

    @Override
    public Long updateDateMajOtp(final String login) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName(Constantes.UPI_UTIL_UPDATE_DATE_MAJ_OTP);

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login)
                .addValue(Constantes.PARAM_USER_MAJ, login);

        return jdbcCall.executeFunction(BigDecimal.class, in).longValue();

    }

    public void acceptCgu(final EabonnementDTO eabonnementDTO) {

        String compteKey = buildCompteKey(eabonnementDTO.getEmetIden(), eabonnementDTO.getActiIden(),
                String.valueOf(eabonnementDTO.getTituNume()), "", "", "");
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName(Constantes.UPI_UTIL_CPTE_UPDATE_CGU); //function name

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_COMPTE_KEY", compteKey)
                .addValue(Constantes.PARAM_USER_MAJ, eabonnementDTO.getLogin());

        jdbcCall.executeFunction(BigDecimal.class, in);
    }

    public static String buildCompteKey(String emetIden, String actiIden, String tituNume, String titrIdCat, String titrCreelia, String idAutre){
        return StringUtils.leftPad(StringUtils.defaultIfBlank(emetIden,"0"), 8, "0")
                + "-" +StringUtils.leftPad(StringUtils.defaultIfBlank(actiIden,"0"), 7, "0")
                + "-" +StringUtils.leftPad(StringUtils.defaultIfBlank(tituNume,"0"), 2, "0")
                + "-" +StringUtils.defaultIfBlank(titrCreelia, "0")
                + "-" +StringUtils.defaultIfBlank(titrIdCat, "0")
                + "-" +StringUtils.defaultIfBlank(idAutre, "0");
    }
}
