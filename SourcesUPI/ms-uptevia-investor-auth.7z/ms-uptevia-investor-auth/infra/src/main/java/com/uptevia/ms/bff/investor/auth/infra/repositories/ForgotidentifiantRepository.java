package com.uptevia.ms.bff.investor.auth.infra.repositories;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.repository.IForgotRepository;
import com.uptevia.ms.bff.investor.auth.infra.mapper.ForgotIdentifiantRowMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.PostConstruct;
import java.util.*;
import java.time.LocalDate;



@Repository
@SuppressWarnings("unchecked")
public class ForgotidentifiantRepository implements IForgotRepository {

    private static final String UPI_TITU_GET_BY_CRITERIA = "UPI_TITU_GET_BY_CRITERIA";

    private static final String PS_CUR = "PS_CUR";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());


    @Value("${base.business.url}")
    private String baseBusinessUrl;

    @Value("${base.front.url}")
    private String baseFrontUrl;

    @Autowired
    private JdbcTemplate jdbcTemplate;


    public ForgotidentifiantRepository(@Qualifier("jdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    @PostConstruct
    public void init() {
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public ForgotIdentifiantDTO getIdentifiant(String pEmetIden, String pActiIden, String pNom, String pPrenom, LocalDate pDateNais) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(UPI_TITU_GET_BY_CRITERIA)
                .returningResultSet(PS_CUR,
                        new ForgotIdentifiantRowMapper());


        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_EMET_IDEN", null)
                .addValue("P_ACTI_IDEN", pActiIden)
                .addValue("P_NOM", pNom)
                .addValue("P_PRENOM", pPrenom)
                .addValue("P_EMAIL", null)
                .addValue("P_DATE_NAIS", null)
                .addValue("P_NUM_TEL", null)
                .addValue("P_LOGIN",null);

        Map<String, Object> out = jdbcCall.execute(in);

        List<ForgotIdentifiantDTO> result = (List<ForgotIdentifiantDTO>) out.get(PS_CUR);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }
        logger.info("the login UPI is : " + result.get(0).getLoginUpi());

        return result.get(0);

    }


    @Override
    public String getFrontUrl(){
        return baseFrontUrl;
    }

    @Override
    public boolean sendEmailWithURL(SendEmailDTO sendEmailDTO) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseBusinessUrl + "sendMail")
                .queryParam("from", sendEmailDTO.getFrom())
                .queryParam("textBody", sendEmailDTO.getTextBody())
                .queryParam("htmlBody", sendEmailDTO.getHtmlBody())
                .queryParam("subject", sendEmailDTO.getSubject())
                .queryParam("typeMail", sendEmailDTO.getTypeMail())
                .queryParam("recipients", sendEmailDTO.getRecipients())
                .queryParam("attachments", sendEmailDTO.getAttachments());

        String apiUrl = builder.toUriString();

        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<SendEmailDTO> response = restTemplate.postForEntity(apiUrl, sendEmailDTO, SendEmailDTO.class);

        return response.getStatusCode().is2xxSuccessful();
    }

}
