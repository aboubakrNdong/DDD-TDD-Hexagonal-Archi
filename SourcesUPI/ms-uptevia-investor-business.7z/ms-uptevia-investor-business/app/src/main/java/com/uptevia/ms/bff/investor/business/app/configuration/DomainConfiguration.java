package com.uptevia.ms.bff.investor.business.app.configuration;

import com.uptevia.ms.bff.investor.business.domain.repository.*;
import com.uptevia.ms.bff.investor.business.domain.service.*;
import com.uptevia.ms.bff.investor.business.domain.service.impl.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;

@Configuration
public class DomainConfiguration {

    @Bean
    ActionnaireService getActionnaireService(IActionnaireRepository actionnaireRepository, IPaysSepaRepository iPaysSepaRepository, IDataBancaireRepository iDataBancaireRepository, IDataPersoRepository iDataPersoRepository) {
        return new ActionnaireServiceImpl(actionnaireRepository, iPaysSepaRepository, iDataBancaireRepository, iDataPersoRepository);
    }

    @Bean
    NewsService getNewsService(INewsRepository newsRepository) {
        return new NewsServiceImpl(newsRepository);
    }

    @Bean
    PositionsDetailsService getPositionsDetailsService(IPositionsDetailsRepository detailsRepository) {
        return new PositionsDetailsServiceImpl(detailsRepository);
    }

    @Bean
    SelfCareService getSelfCareService(ISelfCareRepository iSelfCareRepository) {
        return new SelfCareServiceImpl(iSelfCareRepository);
    }

    @Bean
    OperationService getOperationService(IValeurDetailRepository valeurDetailRepo, IOperationRepository operationRepository, IActionnaireRepository actionnaireRepository) {
        return new OperationServiceImpl(valeurDetailRepo, operationRepository, actionnaireRepository);
    }

    @Bean
    DocumentationService getDocumentationService(IDocumentationRepository iDocumentationRepository) {
        return new DocumentationServiceImpl(iDocumentationRepository);
    }

    @Bean
    EabonnementService insertEabonnementService(IEabonnementRepository iabonnementRepository) {
        return new EabonnementServiceImpl(iabonnementRepository);
    }

    @Bean
    PortefeuilleService portefeuilleService(IAvoirTitreRepository avoirTitresRepository, IValeurDetailRepository valeurDetailRepository) {
        return new PortefeuilleServiceImpl(avoirTitresRepository, valeurDetailRepository);
    }

    @Bean
    EmailService emailService(final JavaMailSender javaMailSender, final freemarker.template.Configuration freemarkerConfiguration) {
        return new EmailServiceImpl(javaMailSender, freemarkerConfiguration);
    }
}
