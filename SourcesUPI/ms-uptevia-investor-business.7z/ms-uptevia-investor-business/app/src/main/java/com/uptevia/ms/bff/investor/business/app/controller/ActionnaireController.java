package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.api.model.*;
import com.uptevia.ms.bff.investor.business.app.mapper.*;
import com.uptevia.ms.bff.investor.business.api.ActionnaireApi;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.service.ActionnaireService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/api/v1")
public class ActionnaireController implements ActionnaireApi {
    Logger logger = Logger.getLogger(ActionnaireController.class.getName());
    private static final String MESSAGE = "with the param : ";
    private final ActionnaireService actionnaireService;

    public ActionnaireController(final ActionnaireService actionnaireService) {
        this.actionnaireService = actionnaireService;
    }


    /**
     * GET /actionnaire
     * Recherche si actionnaire existe dans la table Acti
     *
     * @param emetIden Code emetteur (required)
     * @param actiIden CCN (required)
     * @param tituNume Rang du titulaire (required)
     * @return Un actionnaire a été trouvé pour ces parametres (status code 200)
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     * or Actionnaire non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */
    @Override
    public ResponseEntity<TitulaireJson> checkActionnaire(Integer emetIden, Integer actiIden, Integer tituNume) {
        PsSelDetailTituDTO detailTituDTO = null;
        try {
            detailTituDTO = actionnaireService.getActionnaire(emetIden, actiIden, tituNume);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
                return new ResponseEntity<>(
                        HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(
                TitulaireJsonMapper.INSTANCE.DtoToJson(
                        detailTituDTO
                ), HttpStatus.OK);
    }

    /**
     * GET /comptes
     * Recherche si compte existe dans la table compte
     *
     * @param login login (required)
     * @return Un comptes a été trouvé pour ces parametres (status code 200)
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     * or Comptes non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */
    @Override
    public ResponseEntity<List<ComptesJson>> getComptes(String login) {
        List<CompteDTO> comptes = null;
        try {
            comptes = actionnaireService.getComptes(login);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE+ e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(comptes
                .stream()
                .map(CompteJsonMapper.INSTANCE::dtoToJson)
                .toList(), HttpStatus.OK);

    }

    /**
     * GET /paysSepa
     * return la liste des pays autorisé a modifié leur données bancaire
     *
     * @param emetIden Code Emetteur  (required)
     * @param paramName nom du parameter (required)
     * @return une liste des pays a été trouvé pour ce emetteur (status code 200)
     *         or Retour de la procédure stockée incorrect (status code 400)
     *         or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     *         or parametrage non trouvé pour ces parametres (status code 404)
     *         or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */

      @Override
    public ResponseEntity<PaysSefaJson> getPaysSepa(Integer emetIden, String paramName) {
        PaysSepaDTO paysSepaDTO = null;

        try {
            paysSepaDTO = actionnaireService.getPaysSepa(emetIden, paramName);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE+ e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(PaysSepaJsonMapper.INSTANCE.dtoToJson(paysSepaDTO),
                HttpStatus.OK);
    }

    /**
     * @param login login (required)
     * @return
     */
    @Override
    public ResponseEntity<TitulaireJson> getTitulaire(String login) {
        PsSelDetailTituDTO detailTituDTO = null;
        try {
            detailTituDTO = actionnaireService.getFirstActionnaireByLogin(login);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(
                TitulaireJsonMapper.INSTANCE.DtoToJson(
                        detailTituDTO
                ), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Codeiso2Json> getCodeiso2(String paysIden, String codeLangue) {
        CodeIso2DTO codeIso2DTO = null;

        try {
            codeIso2DTO = actionnaireService.getCodeIso2(paysIden, codeLangue);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(CodeIso2JsonMapper.INSTANCE.dtoToJson(codeIso2DTO),
                HttpStatus.OK);
    }


    /**
     * POST /update/donnees-bancaire
     * create a request to save profile updates
     *
     * @param demandeBancaireJson  (optional)
     * @return mise à jour effectuée avec succés  (status code 201)
     *         or Bad request. Mise à jour non effectuée. (status code 400)
     *         or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     *         or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */

    @Override
    public ResponseEntity<Void> updateDonneesBancaire(DemandeBancaireJson demandeBancaireJson) {
        DemandeBancaireDTO demandeBancaire = DemandeBancaireDTOMapper.INSTANCE.JsonToDto(demandeBancaireJson);
        try {
            actionnaireService.updateDemandeBancaire(demandeBancaire);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(HttpStatus.CREATED);
    }


    /**
     * POST /update/donnees-bancaire
     * create a request to save profile updates
     *
     * @param demandePersoJson  (optional)
     * @return mise à jour effectuée avec succés  (status code 201)
     *         or Bad request. Mise à jour non effectuée. (status code 400)
     *         or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     *         or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */


    @Override
    public ResponseEntity<Void> updateDonneesPerso(DemandePersoJson demandePersoJson) {
        DemandePersoDTO demandePerso = DemandePersoDTOMapper.INSTANCE.JsonToDto(demandePersoJson);
        try {
            actionnaireService.updateDemandePerso(demandePerso);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<Boolean> updateMailPhone(ReqUpdateMailPhoneJson reqUpdateMailPhoneJson) {
        ReqUpdateMailPhone req = ReqUpdateMailPhoneJsonMapper.INSTANCE.jsonToDto(reqUpdateMailPhoneJson);

        try {
            actionnaireService.updateMailPhone(req);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(true, HttpStatus.OK);
    }


    @Override
    public ResponseEntity<Boolean> chekTitulaireKyc(String login) {
        boolean result;
        try {
            result = actionnaireService.chekTitulaireKyc(login);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(result, HttpStatus.OK);
    }


}
