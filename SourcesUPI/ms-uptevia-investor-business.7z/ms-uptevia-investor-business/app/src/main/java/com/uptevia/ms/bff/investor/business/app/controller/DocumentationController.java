package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.api.DocumentationApi;
import com.uptevia.ms.bff.investor.business.api.model.FileJson;
import com.uptevia.ms.bff.investor.business.api.model.TypeDocumentsJson;
import com.uptevia.ms.bff.investor.business.app.mapper.FileJsonMapper;
import com.uptevia.ms.bff.investor.business.app.mapper.TypeDocumentJsonMapper;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.FileDTO;
import com.uptevia.ms.bff.investor.business.domain.model.TypeDocumentDTO;
import com.uptevia.ms.bff.investor.business.domain.service.DocumentationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class DocumentationController implements DocumentationApi {

    Logger logger = LoggerFactory.getLogger(DocumentationController.class.getName());

    private final DocumentationService documentationService;

    public DocumentationController(final DocumentationService documentationService) {
        this.documentationService = documentationService;
    }

    /**
     * GET /documentation
     * Affiche le type du document et les details
     *
     * @param emetIden Code emetteur (required)
     * @param actiIden CCN (required)
     * @param tituNume Rang du titulaire (required)
     * @return informations trouvées pour ces parametres (status code 200)
     *         or Retour de la procédure stockée incorrect (status code 400)
     *         or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     *         or Fichiers non trouvé pour ces parametres (status code 404)
     *         or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */
    @Override
    public ResponseEntity<List<TypeDocumentsJson>> getTypeDocument(Integer emetIden, Integer actiIden, Integer tituNume) {
        List<TypeDocumentDTO> typeDocumentDTO = null;
        try {
            typeDocumentDTO = documentationService.getTypeDocuments(emetIden, actiIden, tituNume);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() , " with the param : " , e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(typeDocumentDTO.stream()
                .map(TypeDocumentJsonMapper.INSTANCE::dtoToJson).toList(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<List<FileJson>> getFiles(Integer emetIden, Integer actiIden, Integer tituNume, Integer docId, String codeLangue) {

        List<FileDTO> files = null;
        try {
            files = documentationService.getFiles(emetIden, actiIden, tituNume, docId, codeLangue);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() ," with the param : " , e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(files
                .stream()
                .map(FileJsonMapper.INSTANCE::dtoToJson)
                .toList(), HttpStatus.OK);
    }
}