package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.api.EabonnementApi;
import com.uptevia.ms.bff.investor.business.api.model.*;
import com.uptevia.ms.bff.investor.business.app.mapper.*;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.service.EabonnementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/v1")
public class EabonnementController implements EabonnementApi {
    Logger logger = LoggerFactory.getLogger(EabonnementController.class.getName());
    private static final String MESSAGE = "with the param : ";
    private final EabonnementService eabonnementService;

    public EabonnementController(final EabonnementService eabonnementService) {
        this.eabonnementService = eabonnementService;
    }


    /**
     * POST /insert/Eabonnement
     * requete pour insérer le module d&#39;abonnement aux e-services
     *
     * @param eabonnementJson  (optional)
     * @return mise à jour effectuée avec succés  (status code 201)
     *         or Bad request. Mise à jour non effectuée. (status code 400)
     *         or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     *         or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */

    @Override
    public ResponseEntity<Void> insertEabonnement(EabonnementJson eabonnementJson) {
        EabonnementDTO eabonnement = EabonnementDTOMapper.INSTANCE.JsonToDto(eabonnementJson);
        try {
            eabonnementService.insertEabonnement(eabonnement);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(HttpStatus.CREATED);
    }



}
