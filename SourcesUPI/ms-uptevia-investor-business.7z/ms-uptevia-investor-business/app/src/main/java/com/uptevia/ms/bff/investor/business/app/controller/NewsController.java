package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.api.NewsApi;
import com.uptevia.ms.bff.investor.business.api.model.NewsJson;
import com.uptevia.ms.bff.investor.business.app.mapper.NewsJsonMapper;
import com.uptevia.ms.bff.investor.business.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.NewsDTO;
import com.uptevia.ms.bff.investor.business.domain.service.NewsService;
import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/api/v1")
public class NewsController implements NewsApi {

    Logger logger = Logger.getLogger(NewsController.class.getName());

    private final NewsService newsService;

    @Autowired
    private JwtUtils jwtUtils;

    public NewsController(final NewsService newsService) {
        this.newsService = newsService;
    }

    /**
     * GET /news
     * Rtourne les news (actualités) d'un actionnaire
     * @param emetIden Code emetteur (required)
     * @param actiIden CCN (required)
     * @param tituNume Rang du titulaire (required)
     * @return Un actionnaire a été trouvé pour ces parametres (status code 200)
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     * or Actionnaire non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */
    @Override
    public ResponseEntity<NewsJson> getNews() {
        NewsDTO newsDTO = null;
        try {
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));
            newsDTO = newsService.getNews(Integer.valueOf(claims.get("emetIden").toString()),
                    Integer.valueOf(claims.get("actiIden").toString()),
                    Integer.valueOf(claims.get("titunume").toString()));
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(
                NewsJsonMapper.INSTANCE.dtoToJson(
                        newsDTO
                ), HttpStatus.OK);
    }
}
