package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.api.OperationApi;
import com.uptevia.ms.bff.investor.business.api.model.*;
import com.uptevia.ms.bff.investor.business.app.exception.CustomResponseStatusException;
import com.uptevia.ms.bff.investor.business.app.mapper.*;
import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.service.ActionnaireService;
import com.uptevia.ms.bff.investor.business.domain.service.OperationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.stream.Collectors;


@RestController
@RequestMapping("/api/v1")
public class OperationController implements OperationApi {


    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final OperationService operationService;
    private final ActionnaireService actionnaireService;

    public OperationController(final OperationService operationService, ActionnaireService actionnaireService) {
        this.operationService = operationService;
        this.actionnaireService = actionnaireService;
    }

    /**
     * GET /valeurDetails
     *
     * @param emetIden
     * @param isValeurEtrangere
     * @param valeIden
     * @param baremeWeb
     * @param valeNatu
     */
    @Override
    public ResponseEntity<ValeurDetailJson> getValeurDetails(Integer emetIden, Integer isValeurEtrangere, String valeIden, String baremeWeb, String valeNatu) {
        ValeurDetailDTO valeurDetail = null;
        try {
            valeurDetail = operationService.getValeurDetails(emetIden, isValeurEtrangere, valeIden, valeNatu, baremeWeb);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " getValeurDetails with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<>(
                ValeurDetailJsonMapper.INSTANCE.dtoToJson(
                        valeurDetail
                ), HttpStatus.OK);
    }


    @Override
    public ResponseEntity<OperationPrerequisResponseJson> getValeurs(String login) {

        List<CompteDTO> comptes = null;
        OperationPrerequisDTO prerequisOperation = null;
        try {
            comptes = actionnaireService.getComptes(login);
            Integer emetIden = comptes.get(0).getEmetIden();
            Integer actiIden = comptes.get(0).getActiIden();
            Integer tituNume = comptes.get(0).getTituNume();

            prerequisOperation = operationService.checkPrerequisOperation(emetIden, actiIden, tituNume);

            return new ResponseEntity<>(
                    new OperationPrerequisResponseJson()
                            .serverDateTime(prerequisOperation.getServerDateTime())
                            .peutVendre(prerequisOperation.getPeutVendre())
                            .motifsBlocageVente(prerequisOperation.getMotifsBlocageVente())
                            .peutAcheter(prerequisOperation.getPeutAcheter())
                            .motifsBlocageAchat(prerequisOperation.getMotifsBlocageAchat())
                            .valeurs(prerequisOperation.getValeurs()
                                    .stream()
                                    .map(ValeurJsonMapper.INSTANCE::dtoToJson)
                                    .toList()), HttpStatus.OK);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }
    }


    @Override
    public ResponseEntity<OrdreBourseResponseJson> insertOrdreBourse(OrdreBourseJson ordreBourseJson) {
        try {
            OrdreBourseDTO ordreBourse = OrdreBourseDTOMapper.INSTANCE.jsonToDto(ordreBourseJson);

            String refOrdreBourse = operationService.processOrdreBourse(ordreBourse);
            boolean isInTime = false;
            LocalTime target = LocalTime.parse(Constantes.HEURE_LIMITE_ORDRE);
            isInTime = LocalTime.now().isBefore(target);

            return new ResponseEntity<>(
                    new OrdreBourseResponseJson()
                            .refDemande(refOrdreBourse)
                            .isInTime(isInTime),
                    HttpStatus.CREATED);
        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, ex.getCode(), ex.getContextParams());
        }
    }

    @Override
    public ResponseEntity<Map<String, List<LigneAvoirsJson>>> getAvoirsAvendre(Integer emetIden, Integer actiIden, String valeIden) {
        logger.info("Call to controler with the param : " + valeIden);
        List<LigneAvoirsDTO> lignesAvoirs = null;
        Map<String, List<LigneAvoirsJson>> avoirsAvendreGroupBy;
        try {
            lignesAvoirs = operationService.getAvoirsAvendre(emetIden, actiIden, valeIden);
            Map<String, List<LigneAvoirsDTO>> lignesAvoirsGroupedByCategory = operationService.groupTitresByCategory(lignesAvoirs);

            avoirsAvendreGroupBy = lignesAvoirsGroupedByCategory.entrySet().stream()
                    .collect(Collectors.toMap(Map.Entry::getKey,
                            entry -> entry.getValue().stream()
                                    .map(LigneAvoirsJsonMapper.INSTANCE::dtoToJson)
                                    .collect(Collectors.toList())));

        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(avoirsAvendreGroupBy, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<List<LocalDate>> getClosedDays(LocalDate dateDebut, LocalDate dateFin) {
        List<LocalDate> days;
        try {
            days = operationService.getClosedDays(dateDebut, dateFin);

        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(days
                .stream().toList(), HttpStatus.OK);
    }

    /**
     * @param login login (required)
     * @return
     */
    @Override
    public ResponseEntity<List<OperationJson>> getOperationsByActi(String login) {
        List<OperationDTO> operations = null;

        try {
            operations = operationService.getOperationsByActi(login);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<>(operations
                .stream()
                .map(OperationJsonMapper.INSTANCE::dtoToJson)
                .toList(), HttpStatus.OK);
    }

}