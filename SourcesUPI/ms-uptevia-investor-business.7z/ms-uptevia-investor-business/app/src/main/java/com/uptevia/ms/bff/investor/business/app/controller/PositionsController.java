package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.api.PositionsApi;
import com.uptevia.ms.bff.investor.business.api.model.PositionsJson;
import com.uptevia.ms.bff.investor.business.app.exception.CustomResponseStatusException;
import com.uptevia.ms.bff.investor.business.app.mapper.PositionsJsonMapper;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.PositionsDTO;
import com.uptevia.ms.bff.investor.business.domain.service.PositionsDetailsService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.logging.Logger;


@RestController
@RequestMapping("/api/v1")
public class PositionsController implements PositionsApi {
    //
    Logger logger = Logger.getLogger(PositionsController.class.getName());

    private PositionsDetailsService detailsService = null;

    public PositionsController(final PositionsDetailsService pDetailsService) {
        this.detailsService = pDetailsService;
    }


    public ResponseEntity<PositionsJson> getPositions(Integer emetIden, Integer actiIden) {
        PositionsDTO positionsDTO;

        try {
            positionsDTO = detailsService.getPositions(emetIden, actiIden);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NO_CONTENT);
        }
        
        return new ResponseEntity<>(
                PositionsJsonMapper.INSTANCE.dtoToJson(
                        positionsDTO
                ), HttpStatus.OK);

    }

}
