package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.api.SelfcareApi;
import com.uptevia.ms.bff.investor.business.api.model.CategoriesJson;
import com.uptevia.ms.bff.investor.business.api.model.DemandeJson;
import com.uptevia.ms.bff.investor.business.app.mapper.CategoriesJsonMapper;
import com.uptevia.ms.bff.investor.business.app.mapper.DemandeDTOMapper;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.CategoriesDTO;
import com.uptevia.ms.bff.investor.business.domain.model.DemandeDTO;
import com.uptevia.ms.bff.investor.business.domain.service.SelfCareService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/api/v1")
public class SelfCareController implements SelfcareApi {

    Logger logger = Logger.getLogger(SelfCareController.class.getName());


    private final SelfCareService selfCareService;

    public SelfCareController(final SelfCareService selfCareService) {
        this.selfCareService = selfCareService;
    }

    /**
     * GET /categories
     * get categories and sous categories for Faq Forms
     *
     * @param pIndiLogged connecté / non connecté (required)
     * @return une liste des categories et sous categories a été trouvé pour ces parametres (status code 200)
     *         or Retour de la procédure stockée incorrect (status code 400)
     *         or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     *         or Categories non trouvé pour ces parametres (status code 404)
     *         or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */

    @Override
    public ResponseEntity<List<CategoriesJson>> getCategories(String pIndiLogged) {
        List<CategoriesDTO> categoriesDTOS = null;

        try {
            categoriesDTOS = selfCareService.getCategories(pIndiLogged);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(categoriesDTOS.stream()
                .map(CategoriesJsonMapper.INSTANCE::dtoToJson).toList(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> createSelfCare(DemandeJson demandeJson) {
        DemandeDTO demandeTosave = DemandeDTOMapper.INSTANCE.JsonToDto(demandeJson);
        try {
            selfCareService.createSelfCare(demandeTosave);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

}
