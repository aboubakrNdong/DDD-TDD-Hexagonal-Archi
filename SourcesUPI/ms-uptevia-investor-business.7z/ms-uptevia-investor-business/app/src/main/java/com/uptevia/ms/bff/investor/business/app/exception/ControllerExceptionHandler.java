package com.uptevia.ms.bff.investor.business.app.exception;

import com.uptevia.ms.bff.investor.business.api.model.MSExceptionDTOJson;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@RestControllerAdvice
@Slf4j
public class ControllerExceptionHandler {

    Logger logger = LoggerFactory.getLogger(ControllerExceptionHandler.class.getName());
    @ExceptionHandler(value = {FunctionnalException.class})
    public ResponseEntity<MSExceptionDTOJson> resourceNotFoundException(FunctionnalException ex, WebRequest request) {
        MSExceptionDTOJson message = new MSExceptionDTOJson()
                .message(ex.getMessage())
                .errorCode(ex.getCode())
                .contextParams(ex.getContextParams());
        logger.error("Error found: {}, caused by : {}", ex.getMessage() , ex.getContextParams());
        return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = {RuntimeException.class})
    public ResponseEntity<MSExceptionDTOJson> resourceRuntimeException(RuntimeException ex, WebRequest request) {
        MSExceptionDTOJson message = new MSExceptionDTOJson()
                .message(ex.getMessage());

        return new ResponseEntity<>(message, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
