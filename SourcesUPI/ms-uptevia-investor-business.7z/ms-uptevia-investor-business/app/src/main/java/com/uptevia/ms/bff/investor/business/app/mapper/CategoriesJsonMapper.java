package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.CategoriesJson;
import com.uptevia.ms.bff.investor.business.domain.model.CategoriesDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CategoriesJsonMapper {

    CategoriesJsonMapper INSTANCE = Mappers.getMapper(CategoriesJsonMapper.class);
    CategoriesJson dtoToJson(CategoriesDTO categoriesDTO);
}
