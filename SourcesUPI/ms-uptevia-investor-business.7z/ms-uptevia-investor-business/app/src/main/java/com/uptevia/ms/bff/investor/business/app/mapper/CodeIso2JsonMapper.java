package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.CodeIso2DTO;
import com.uptevia.ms.bff.investor.business.api.model.Codeiso2Json;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CodeIso2JsonMapper {

    CodeIso2JsonMapper INSTANCE = Mappers.getMapper(CodeIso2JsonMapper.class);
    Codeiso2Json dtoToJson(CodeIso2DTO codeIso2DTO);

}
