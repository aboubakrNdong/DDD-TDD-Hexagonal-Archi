package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.ComptesJson;
import com.uptevia.ms.bff.investor.business.domain.model.CompteDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface CompteJsonMapper {


    CompteJsonMapper INSTANCE = Mappers.getMapper(CompteJsonMapper.class);

    ComptesJson dtoToJson(CompteDTO compteDTO);
}
