package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.DemandeBancaireJson;
import com.uptevia.ms.bff.investor.business.domain.model.DemandeBancaireDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DemandeBancaireDTOMapper {

    DemandeBancaireDTOMapper INSTANCE = Mappers.getMapper(DemandeBancaireDTOMapper.class);
    DemandeBancaireDTO JsonToDto(DemandeBancaireJson profilJson);

}
