package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.EabonnementJson;
import com.uptevia.ms.bff.investor.business.domain.model.EabonnementDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface EabonnementDTOMapper {

    EabonnementDTOMapper INSTANCE = Mappers.getMapper(EabonnementDTOMapper.class);
    EabonnementDTO JsonToDto(EabonnementJson eabonnementJson);

}
