package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.FileJson;
import com.uptevia.ms.bff.investor.business.domain.model.FileDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface FileJsonMapper {

    FileJsonMapper INSTANCE = Mappers.getMapper(FileJsonMapper.class);
    FileJson dtoToJson(FileDTO fileDTO);

}
