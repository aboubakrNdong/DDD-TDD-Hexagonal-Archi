package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.NewsJson;
import com.uptevia.ms.bff.investor.business.domain.model.NewsDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface NewsJsonMapper {

    NewsJsonMapper INSTANCE = Mappers.getMapper(NewsJsonMapper.class);
    NewsJson dtoToJson(NewsDTO newsDTO);

}
