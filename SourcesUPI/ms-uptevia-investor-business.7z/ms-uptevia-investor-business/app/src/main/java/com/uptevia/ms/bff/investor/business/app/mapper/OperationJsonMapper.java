package com.uptevia.ms.bff.investor.business.app.mapper;


import com.uptevia.ms.bff.investor.business.api.model.OperationJson;
import com.uptevia.ms.bff.investor.business.domain.model.OperationDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface OperationJsonMapper {
    OperationJsonMapper INSTANCE = Mappers.getMapper(OperationJsonMapper.class);
    OperationJson dtoToJson(OperationDTO dto);
}
