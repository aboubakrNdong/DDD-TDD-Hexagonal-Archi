package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.PaysSefaJson;
import com.uptevia.ms.bff.investor.business.domain.model.PaysSepaDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PaysSepaJsonMapper {

    PaysSepaJsonMapper INSTANCE = Mappers.getMapper(PaysSepaJsonMapper.class);
    PaysSefaJson dtoToJson(PaysSepaDTO paysSepaDTO);

}
