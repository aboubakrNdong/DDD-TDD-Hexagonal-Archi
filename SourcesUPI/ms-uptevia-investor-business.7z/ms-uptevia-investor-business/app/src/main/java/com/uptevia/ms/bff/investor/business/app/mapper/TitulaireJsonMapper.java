package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.TitulaireJson;
import com.uptevia.ms.bff.investor.business.domain.model.PsSelDetailTituDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TitulaireJsonMapper {

    TitulaireJsonMapper INSTANCE = Mappers.getMapper(TitulaireJsonMapper.class);

    TitulaireJson DtoToJson(PsSelDetailTituDTO detailTituDTO);
}