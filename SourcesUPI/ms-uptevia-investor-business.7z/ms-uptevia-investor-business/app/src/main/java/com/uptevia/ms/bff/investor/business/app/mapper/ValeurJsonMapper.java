package com.uptevia.ms.bff.investor.business.app.mapper;


import com.uptevia.ms.bff.investor.business.api.model.ValeurJson;
import com.uptevia.ms.bff.investor.business.domain.model.ValeurDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ValeurJsonMapper {

    ValeurJsonMapper INSTANCE = Mappers.getMapper(ValeurJsonMapper.class);
    ValeurJson dtoToJson(ValeurDTO valeurDTO);

}
