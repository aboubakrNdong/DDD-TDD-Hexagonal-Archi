package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.CompteDTO;
import com.uptevia.ms.bff.investor.business.domain.model.PsSelDetailTituDTO;
import com.uptevia.ms.bff.investor.business.domain.service.ActionnaireService;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = ActionnaireController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
class ActionnaireControllerTest {

    private final static String URL_GET_ACTIONNAIRE_LINKS = "/api/v1/profile";
    private final static String URL_GET_COMPTES_LINKS = "/api/v1/titulaires";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ActionnaireService actionnaireService;


    private EasyRandom easyRandom = new EasyRandom();
    @Test
    void should_return_get_actionnaire_ok() throws Exception {

        PsSelDetailTituDTO psSelDetailTituDTO = easyRandom.nextObject(PsSelDetailTituDTO.class);

        Mockito.when(actionnaireService.getActionnaire(99963514, 2, 1)).thenReturn(psSelDetailTituDTO);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_ACTIONNAIRE_LINKS)
                .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "2")
                        .queryParam("tituNume", "1")
                .characterEncoding("UTF-8"))
                .andExpect(jsonPath("$.*").isArray())
                .andExpect(jsonPath("$.emetIden").exists())
                .andExpect(jsonPath("$.emetIden").value(psSelDetailTituDTO.getEmetIden()))
                .andExpect(jsonPath("$.emailPro").value(psSelDetailTituDTO.getEmailPro()))
                .andExpect(jsonPath("$.ribBank").value(psSelDetailTituDTO.getRibBank()))
                .andExpect(jsonPath("$.natioIso3").value(psSelDetailTituDTO.getNatioIso3()));

    }

    @Test
    void should_return_get_actionnaire_and_return_500() throws Exception {

        Mockito.when(actionnaireService.getActionnaire(99963514, 2, 1)).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_ACTIONNAIRE_LINKS)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "2")
                        .queryParam("tituNume", "1")
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void should_return_get_actionnaire_and_return_404() throws Exception {

        Mockito.when(actionnaireService.getActionnaire(99963514, 2, 1)).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_ACTIONNAIRE_LINKS)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "2")
                        .queryParam("tituNume", "1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());
    }

    @Test
    void should_return_get_compte_ok() throws Exception {


        List<CompteDTO> comptes = easyRandom.objects(CompteDTO.class, 5)
                .collect(Collectors.toList());

        String login = "61691966";

        Mockito.when(actionnaireService.getComptes(login)).thenReturn(comptes);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_COMPTES_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("login", login)
                        .characterEncoding("UTF-8"))
                .andExpect(jsonPath("$.*").isArray())
                .andExpect(jsonPath("$.[0].emetIden").exists())
                .andExpect(jsonPath("$.[1].actiIden").exists());

    }

    @Test
    void should_return_get_compte_and_return_500() throws Exception {
        String login = "61691966";
        Mockito.when(actionnaireService.getComptes(login)).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_COMPTES_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("login", login)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void should_return_get_compte_and_return_404() throws Exception {

        String login = "61691966";
        Mockito.when(actionnaireService.getComptes(login)).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_COMPTES_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("login", login)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());
    }


}
