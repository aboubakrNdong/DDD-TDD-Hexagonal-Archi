package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.FileDTO;
import com.uptevia.ms.bff.investor.business.domain.model.TypeDocumentDTO;
import com.uptevia.ms.bff.investor.business.domain.service.DocumentationService;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = DocumentationController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
class DocumentationControllerTest {

    private static String URL_GET_TYPEDOCUMENT_LINKS = "/api/v1/typeDocument";
    private static String URL_GET_FILES_LINKS = "/api/v1/files";

    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private DocumentationService documentationService;
    private EasyRandom easyRandom = new EasyRandom();
    @Test
    void should_return_get_typeDocument_ok() throws Exception {

        int idEmet = 99963514;
        int idActi = 2;
        int pTituNume = 1;

        List<TypeDocumentDTO> typeDocument = easyRandom.objects(TypeDocumentDTO.class, 1)
                .collect(Collectors.toList());
        typeDocument.forEach(e -> {
            e.setDocumentTypeId(1);
            e.setDocumentTypeTraductionKey("document.type.caceis.guides.pratiques");
        });
        Mockito.when(documentationService.getTypeDocuments(idEmet, idActi,pTituNume)).thenReturn(typeDocument);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_TYPEDOCUMENT_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "2")
                        .queryParam("tituNume", "1")

                        .characterEncoding("UTF-8"))
                .andExpect(jsonPath("$.*").isArray())
                .andExpect(jsonPath("$.[0].documentTypeId").exists());
    }

    @Test
    void should_return_get_typeDocument_and_return_500() throws Exception {

        Mockito.when(documentationService.getTypeDocuments(99963514, 2, 1)).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_TYPEDOCUMENT_LINKS)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "2")
                        .queryParam("tituNume", "1")

                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());
    }

    @Test
    void should_return_get_typedocument_and_return_404() throws Exception {

        Mockito.when(documentationService.getTypeDocuments(99963514, 2, 1)).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_TYPEDOCUMENT_LINKS)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "2")
                        .queryParam("tituNume", "1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());
    }

    @Test
    void should_return_get_files_ok() throws Exception {

        int idEmet = 99963514;
        int idActi = 2;
        int pTituNume = 1;
        int pDocId = 1;
        String pCodeLangue = "FRA";

        List<FileDTO> files = easyRandom.objects(FileDTO.class, 1)
                .collect(Collectors.toList());
        files.forEach(e -> {
            e.setDocumentId(1);
            e.setDocumentContentType("application/pdf");
        });
        Mockito.when(documentationService.getFiles(idEmet, idActi,pTituNume,pDocId, pCodeLangue)).thenReturn(files);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_FILES_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "2")
                        .queryParam("tituNume", "1")
                        .queryParam("docId", "1")
                        .queryParam("codeLangue", "FRA")

                        .characterEncoding("UTF-8"))
                .andExpect(jsonPath("$.*").isArray())
                .andExpect(jsonPath("$.[0].documentContentType").exists());
    }

    @Test
    void should_return_get_files_and_return_500() throws Exception {

        Mockito.when(documentationService.getFiles(99963514, 2, 1, 1, "FRA")).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_FILES_LINKS)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "2")
                        .queryParam("tituNume", "1")
                        .queryParam("docId", "1")
                        .queryParam("codeLangue", "FRA")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void should_return_get_files_and_return_404() throws Exception {

        Mockito.when(documentationService.getFiles(99963514, 2, 1, 1, "FRA")).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_FILES_LINKS)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "2")
                        .queryParam("tituNume", "1")
                        .queryParam("docId", "1")
                        .queryParam("codeLangue", "FRA")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());
    }

}
