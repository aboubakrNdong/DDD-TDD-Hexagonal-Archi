package com.uptevia.ms.bff.investor.business.app.controller;


import com.uptevia.ms.bff.investor.business.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.NewsDTO;

import com.uptevia.ms.bff.investor.business.domain.service.NewsService;
import org.jeasy.random.EasyRandom;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = NewsController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
class NewsControllerTest {

    private static String URL_API_GET = "/api/v1/news";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private NewsService newsService;

    @MockBean
    private JwtUtils jwtUtils;

    private EasyRandom easyRandom = new EasyRandom();

    @Test
    void should_return_get_news_ok() throws Exception {
        //Given
        NewsDTO newsDTO = easyRandom.nextObject(NewsDTO.class);
        int idEmet = 99963514;
        int idActi = 1;
        int pTituNume = 1;

        // When
        Mockito.when(newsService.getNews(idEmet, idActi, pTituNume)).thenReturn(newsDTO);

        //Then
        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_API_GET)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "1")
                        .queryParam("tituNume", "1")
                        .characterEncoding("UTF-8"))
                .andExpect(jsonPath("$.*").isArray());

    }

    @Test
    void should_return_get_news_and_return_500() throws Exception {
        //Given
        NewsDTO newsDTO = easyRandom.nextObject(NewsDTO.class);
        int idEmet = 99963514;
        int idActi = 1;
        int pTituNume = 1;

        // When
        Mockito.when(newsService.getNews(idEmet, idActi, pTituNume)).thenThrow(NullPointerException.class);

        //Then
        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_API_GET)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "1")
                        .queryParam("tituNume", "1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }


    //@Test
    void should_return_get_news_and_return_404() throws Exception {
        //Given
        int idEmet = 99963514;
        int idActi = 1;
        int pTituNume = 1;

        // When
        Mockito.when(newsService.getNews(idEmet, idActi, pTituNume)).thenThrow(new FunctionnalException("code", "message"));

        //Then
        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_API_GET)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "1")
                        .queryParam("tituNume", "1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());

    }


}