package com.uptevia.ms.bff.investor.business.app.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.CompteDTO;
import com.uptevia.ms.bff.investor.business.domain.model.LigneAvoirsDTO;

import com.uptevia.ms.bff.investor.business.domain.model.OrdreBourseDTO;
import com.uptevia.ms.bff.investor.business.domain.service.ActionnaireService;
import com.uptevia.ms.bff.investor.business.domain.service.OperationService;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;


import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@ExtendWith(SpringExtension.class)
@WebMvcTest(value = OperationController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
class OperationControllerTest {

    private final static String URL_GET_AVOIRS_LINK = "/api/v1/operation/avoirs-a-vendre";
    private final static String URL_POST_ORDRE = "/api/v1/operation/avoirs-a-vendre";
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private OperationService operationService;
    @MockBean
    private ActionnaireService actionnaireService;


    private EasyRandom easyRandom = new EasyRandom();


    @Test
    void should_return_get_lignes_avoirs_ok() throws Exception {
        List<LigneAvoirsDTO> lignesAvoirs = easyRandom.objects(LigneAvoirsDTO.class, 5)
                .collect(Collectors.toList());

        List<CompteDTO> comptes = easyRandom.objects(CompteDTO.class, 5)
                .collect(Collectors.toList());

        String login = "61691966";

        Integer idEmet = comptes.get(0).getEmetIden();
        Integer idActi = comptes.get(0).getActiIden();
        String valeIden = "FR0004040608";

        // Configurez le service mock pour retourner les lignes d'avoirs fictives
        Mockito.when(operationService.getAvoirsAvendre(idEmet, idActi, valeIden)).thenReturn(lignesAvoirs);
        // Pour un élément, Vérifiez que des champs exisent
        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_AVOIRS_LINK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("emetIden", Integer.toString(idEmet))
                        .queryParam("actiIden", Integer.toString(idActi))
                        .queryParam("valeIden", valeIden)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isOk());


    }


    @Test
    void should_return_get_lignes_avoirs_and_return_500() throws Exception {
        int idEmet = 11111;
        int idActi = 0;
        String valeIden = "OOPPPDD";
        Mockito.when(operationService.getAvoirsAvendre(idEmet, idActi, valeIden)).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_AVOIRS_LINK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("emetIden", Integer.toString(idEmet))
                        .queryParam("actiIden", Integer.toString(idActi))
                        .queryParam("valeIden", valeIden)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void should_return_get_lignes_avoirs_and_return_404() throws Exception {

        int idEmet = 0000;
        int idActi = 0;
        String valeIden = "ABCD";
        Mockito.when(operationService.getAvoirsAvendre(idEmet, idActi, valeIden)).thenThrow(new FunctionnalException("code", "message"));


        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_AVOIRS_LINK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("emetIden", Integer.toString(idEmet))
                        .queryParam("actiIden", Integer.toString(idActi))
                        .queryParam("valeIden", valeIden)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());
    }


    @Test
    void should_not_allow_send_uncompleted_ordre() throws Exception {

        OrdreBourseDTO demande = OrdreBourseDTO.builder()
                .idDemande(1)
                .actiIden(1)
                .coursLimite(2)
                .emetIden(99963514)
                .login("92605493")
                .ocbIdTransaction(1L)
                .nbActions(30)
                .build();

        mockMvc.perform( MockMvcRequestBuilders
                        .post(URL_POST_ORDRE)
                        .content(toJsonString(demande))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is4xxClientError());

    }

    private static String toJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
