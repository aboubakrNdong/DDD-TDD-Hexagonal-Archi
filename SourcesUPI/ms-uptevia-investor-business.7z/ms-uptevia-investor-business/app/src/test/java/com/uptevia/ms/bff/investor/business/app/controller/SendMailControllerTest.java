package com.uptevia.ms.bff.investor.business.app.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uptevia.ms.bff.investor.business.domain.service.EmailService;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = SendMailController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
public class SendMailControllerTest {

    private static String URL_SEND_MAIL = "/api/v1/sendMail";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EmailService emailService;

 
    private EasyRandom easyRandom = new EasyRandom();
  /*  @Test
    void should_send_mail_ok() throws Exception {

        List<String> list = new ArrayList<>();
        list.add("farhat.bouchnak@uptevia.com");
        list.add("farhat.bouchnak@uptevia.com");
        EmailDetailsDTO emailToSend = EmailDetailsDTO.builder()
                        .subject("").typeMail("").htmlBody("")
                        .recipients(list).build();

        mockMvc.perform( MockMvcRequestBuilders
                        .post(URL_SEND_MAIL)
                        .content(asJsonString(emailToSend))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());


    }*/

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
