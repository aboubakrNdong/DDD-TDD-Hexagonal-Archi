package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.*;

import java.io.Serializable;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
public class ActusDTO implements Serializable {

    private String level;

    private String type;

    private String traductionKey;

    private List<String> traductionParams;

    private Integer priority;
}
