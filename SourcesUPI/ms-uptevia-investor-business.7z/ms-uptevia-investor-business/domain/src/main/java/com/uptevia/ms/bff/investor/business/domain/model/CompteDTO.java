package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class CompteDTO {
    private Integer emetIden;

    private Integer actiIden;

    private Integer tituNume;

    private Integer themeId;

    private String nom;

    private String prenom;

    private String qualite;

    private String actiTypeCompte;
    private String typeCpte;
}
