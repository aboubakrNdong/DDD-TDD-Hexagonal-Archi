package com.uptevia.ms.bff.investor.business.domain.model;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.ExtensionMethod;

@Getter
@Setter
@Builder
@ExtensionMethod({
        DemandeBancaireDTO.class
})
public class DemandeBancaireDTO {

    private String pLogin;

    private String pEmet;

    private String pActi;

    private Integer pTituNume;

    private String pUser;

    private String pDeviseOld;

    private String pPaysOld;

    private String pReglementOld;

    private String pBicOld;

    private String pIbanOld;

    private String pDomiciliationOld;

    private String pDevise;

    private String pPays;

    private String pReglement;

    private String pBic;

    private String pIban;

    private String pDomiciliation;

    private String pExtension;

}

