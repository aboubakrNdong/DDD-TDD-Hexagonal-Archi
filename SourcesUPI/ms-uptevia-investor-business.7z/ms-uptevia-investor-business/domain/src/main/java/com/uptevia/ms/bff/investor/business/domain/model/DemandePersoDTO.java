package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;


@Getter
@Setter
@Builder
public class DemandePersoDTO {

    private String pUser;

    private String pOrig;

    private Integer pEmetIden;

    private Integer pActiIden;

    private Integer pTituNume;

    private String pFlagDenomination;

    private String pTituQual;

    private String pTituTitr;

    private String pTituNom;

    private String pTituPren;

    private String pTituNomJf;

    private String pFlagAdressePostale;

    private String pAdreInfoBati;

    private String pAdreInfoRue;

    private String pAdreComp;

    private String pAdreCodp;

    private String pAdreNomComu;

    private String pAdrePaysIden;

    private String pAdreIndiBloq;

    private String pFlagAdresseFiscale;

    private String pAdreFiscInfoBati;

    private String pAdreFiscInfoRue;

    private String pAdreFiscComp;

    private String pAdreFiscCodp;

    private String pAdreFiscNomComu;

    private String pAdreFiscPaysIden;

    private String pAdreFiscIndiBloq;

    private String pFlagNaissance;

    private LocalDate pTituDateNais;

    private String pTituComuNais;

    private String pTituDeptNais;

    private String pPaysNaisIden;

    private String pTituComuNaisCode;

    private String pFlagCsp;

    private String pTituCsp;

    private String pFlagEMail;

    private String pTituEMail;

    private String pFlagEMail2;

    private String pTituEMail2;

    private String pFlagNumeTel;

    private String pTituNumeTel;

    private String pFlagNumeTel2;

    private String pTituNumeTel2;

    private String pFlagNumMobilePro;

    private String pTituNumMobilePro;

    private String pFlagNumMobilePerso;

    private String pTituNumMobilePerso;

    private String pFlagNumFaxPro;

    private String pTituNumFaxPro;

    private String pFlagNumFaxPerso;

    private String pTituNumFaxPerso;
}

