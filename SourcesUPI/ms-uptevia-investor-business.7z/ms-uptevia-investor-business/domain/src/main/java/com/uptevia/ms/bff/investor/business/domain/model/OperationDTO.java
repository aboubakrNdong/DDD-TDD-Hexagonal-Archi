package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Builder
@Getter
@Setter
public class OperationDTO {
    private Long idDemande;
    private LocalDate dateDemande;
    private Integer natureDemande;
    private String refDemande;
    private String statutDemande;
    private String statutExecution;
    private Integer nbActions;
    private Boolean annulable;
    private BigDecimal montantNet;
    private Integer qteTrade;
}
