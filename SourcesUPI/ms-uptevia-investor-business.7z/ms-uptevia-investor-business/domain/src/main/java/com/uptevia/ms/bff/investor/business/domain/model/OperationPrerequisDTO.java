package com.uptevia.ms.bff.investor.business.domain.model;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;
import java.util.List;

@Builder
@Getter
@Setter
public class OperationPrerequisDTO {
    private OffsetDateTime serverDateTime;
    private Boolean peutVendre;
    private List<String> motifsBlocageVente;
    private Boolean peutAcheter;
    private List<String> motifsBlocageAchat;
    private List<ValeurDTO> valeurs;
}
