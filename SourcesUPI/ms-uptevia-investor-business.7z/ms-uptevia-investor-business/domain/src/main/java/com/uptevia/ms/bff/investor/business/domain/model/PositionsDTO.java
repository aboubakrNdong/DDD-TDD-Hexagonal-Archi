package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PositionsDTO {

    private PositionsTypeDTO titres;

    private PositionsTypeDTO droits;

    private PositionsTypeDTO fonds;

}
