package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class PositionsDetailsDTO {

    private String typePosition;
    private String derniereMaj;
    private int qte;
    private String natureJuridique;
    private String codeLibelle;
    private String devise;
    private double valorisation;

}
