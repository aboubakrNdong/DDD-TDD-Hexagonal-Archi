package com.uptevia.ms.bff.investor.business.domain.model;


import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class PositionsTypeDTO {

    private String typePosition;

    private String derniereMaj;

    private Integer qteTotale;

    private BigDecimal valorisationTotale;

    private String devise;

    private  List<PositionsDetailsDTO> details ;

}
