package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter
public class ReqUpdateMailPhone {
    private String login;
    private String mail;
    private String telephone;
}
