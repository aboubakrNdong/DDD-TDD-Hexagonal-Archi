package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;


@Getter
@Builder
@Setter

public class SousMenuDTO {

    private String moduleGroupeNom;

    private String moduleGroupeUrl;

    private int moduleGroupeOrdre;

    private boolean moduleGroupeIndicateur;

    private String moduleGroupeImgName;

    private String moduleNom;

    private String moduleUrl;

    private int moduleOrdre;

    private boolean moduleIndicateur;

    private String moduleImgName;

    private String useFormodule;

}
