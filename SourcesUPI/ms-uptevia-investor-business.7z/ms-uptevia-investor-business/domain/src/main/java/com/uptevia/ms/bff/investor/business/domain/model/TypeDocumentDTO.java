package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter

public class TypeDocumentDTO {

    private int documentId;

    private String documentLangueIso3;

    private String versionLangueIso3;

    private String documentTraductionKey;

    private int documentTypeId;

    private String documentTypeTraductionKey;

    private String documentTypeCodeCouleurHtml;

}
