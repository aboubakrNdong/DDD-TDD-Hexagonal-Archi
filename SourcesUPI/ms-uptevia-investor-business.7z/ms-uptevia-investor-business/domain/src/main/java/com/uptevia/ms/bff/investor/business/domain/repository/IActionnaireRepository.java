package com.uptevia.ms.bff.investor.business.domain.repository;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;

import java.util.List;

public interface IActionnaireRepository {

    PsSelDetailTituDTO getActionnaire(final int idEmet, final int idActi, final int pTituNume) throws FunctionnalException;

    List<CompteDTO> getComptes(String login) throws FunctionnalException;

    CodeIso2DTO getCodeIso2(String paysIden, String codeLangue) throws FunctionnalException;

    List<OperationDTO> getOperations(String login) throws FunctionnalException;

    PsSelDetailTituDTO getFirstActionnaireByLogin(String login) throws FunctionnalException;

    long updateMailPhone(ReqUpdateMailPhone req) throws FunctionnalException;

    boolean chekTitulaireKyc(String login) throws FunctionnalException;
}

