package com.uptevia.ms.bff.investor.business.domain.repository;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.AvoirTitreDTO;


import java.util.List;

public interface IAvoirTitreRepository {

    List<AvoirTitreDTO> getAllAvoirTitres(int idEmet, int idActi) throws FunctionnalException;
}
