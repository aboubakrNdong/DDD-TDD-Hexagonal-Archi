package com.uptevia.ms.bff.investor.business.domain.repository;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.DemandePersoDTO;



public interface IDataPersoRepository {

    DemandePersoDTO updatedemandePerso(DemandePersoDTO demandePerso) throws FunctionnalException;

}
