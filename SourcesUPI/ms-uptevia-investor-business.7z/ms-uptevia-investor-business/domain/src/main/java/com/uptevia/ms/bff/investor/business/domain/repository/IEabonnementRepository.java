package com.uptevia.ms.bff.investor.business.domain.repository;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.EabonnementDTO;

public interface IEabonnementRepository {

    Long insertEabonnement(EabonnementDTO eabonnement) throws FunctionnalException;

}
