package com.uptevia.ms.bff.investor.business.domain.repository;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.OrdreBourseDTO;

import java.time.LocalDate;
import java.util.List;

public interface IOperationRepository {
    List<LocalDate> getClosedDays(LocalDate dateDebut, LocalDate dateFin) throws FunctionnalException;

    OrdreBourseDTO insertDemandeOlis(OrdreBourseDTO demandeAchat) throws FunctionnalException;

    Long insertOrdreBourse(OrdreBourseDTO demandeAchat) throws FunctionnalException;
    int insertReglement(OrdreBourseDTO demandeAchat) throws FunctionnalException;

    int insertAvoirsAVendre(OrdreBourseDTO demande);

    int confirmTransactionCB(OrdreBourseDTO demande) throws Exception;
}
