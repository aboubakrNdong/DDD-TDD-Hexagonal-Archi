package com.uptevia.ms.bff.investor.business.domain.repository;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.PositionsDetailsDTO;

import java.util.List;

public interface IPositionsDetailsRepository {


    List<PositionsDetailsDTO> getAllPositionsDetails(int idEmet, int idActi) throws FunctionnalException;
}
