package com.uptevia.ms.bff.investor.business.domain.service;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;

import java.util.List;

public interface ActionnaireService {

    PsSelDetailTituDTO getActionnaire(final int idEmet, final int idActi, final int pTituNume) throws FunctionnalException;

    List<CompteDTO> getComptes(final String login) throws FunctionnalException;

    PaysSepaDTO getPaysSepa(Integer emetIden, String paramName) throws FunctionnalException;

    CodeIso2DTO getCodeIso2(String paysIden, String codeLangue) throws FunctionnalException;

    void updateDemandeBancaire(DemandeBancaireDTO demandeBancaire)  throws FunctionnalException;

    DemandePersoDTO updateDemandePerso(DemandePersoDTO demandePerso)  throws FunctionnalException;

    PsSelDetailTituDTO getFirstActionnaireByLogin(String login) throws FunctionnalException;

    void updateMailPhone(ReqUpdateMailPhone req) throws FunctionnalException;

    boolean chekTitulaireKyc(String login) throws FunctionnalException;
}
