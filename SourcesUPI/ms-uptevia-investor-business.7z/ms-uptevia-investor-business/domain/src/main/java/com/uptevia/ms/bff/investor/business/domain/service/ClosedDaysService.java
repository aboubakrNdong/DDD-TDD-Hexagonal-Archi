package com.uptevia.ms.bff.investor.business.domain.service;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;

import java.time.LocalDate;
import java.util.List;
public interface ClosedDaysService {
    List<LocalDate> getClosedDays(LocalDate dateDebut, LocalDate dateFin) throws FunctionnalException;
}
