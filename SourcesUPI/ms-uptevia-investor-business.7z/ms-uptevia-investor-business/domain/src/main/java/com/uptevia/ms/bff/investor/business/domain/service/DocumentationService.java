package com.uptevia.ms.bff.investor.business.domain.service;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.FileDTO;
import com.uptevia.ms.bff.investor.business.domain.model.TypeDocumentDTO;

import java.util.List;

public interface DocumentationService {
    List<TypeDocumentDTO> getTypeDocuments( int idEmet, int idActi, int pTituNume) throws FunctionnalException;

    List<FileDTO> getFiles(int idEmet, int idActi, int pTituNume, int pDocId, String pCodeLangue) throws FunctionnalException;


}
