package com.uptevia.ms.bff.investor.business.domain.service;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.NewsDTO;

public interface NewsService {

    NewsDTO getNews(final int idEmet, final int idActi, final int pTituNume) throws FunctionnalException;
}
