package com.uptevia.ms.bff.investor.business.domain.service.impl;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class AbstractBusinessService {

    private static final String DATE_REGEX = "^([0-2][\\d]||3[0-1])/(0[\\d]||1[0-2])/([\\d][\\d])?[\\d][\\d]$";

    private static final Pattern Date_PATTERN = Pattern.compile(DATE_REGEX);

    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }

    public static boolean isAlphaNumeric(String s) {
        return s != null && s.matches("^[a-zA-Z0-9]");
    }

    public static boolean isTelephoneValid(String s) {
        return s != null && s.matches("[0-9]+");
    }

    public static boolean isEmailValid(String s) {
        return s != null && s.matches("^[A-Za-z.]+@[A-Za-z.]+fr");
    }

    public static boolean isBicValid(String s) {
        return s != null && s.matches("[A-Za-z]{4}[A-Za-z]{2}[A-Za-z0-9]{2}([A-Za-z0-9]{3})?");
    }

    /**
     * method to convert O,o, n or N into boolean
     *
     * @param string
     * @return
     */
    public static boolean ONtoBoolean(String string) {
        if (string != null && string.equalsIgnoreCase("o")) {
            return true;
        } else if (string != null && string.equalsIgnoreCase("n")) {
            return false;
        } else {
            throw new IllegalArgumentException("Input must be O,o, n or N");
        }
    }

    public static boolean int2boolean(int val) {
        return val == 1;
    }


    /**
     * method to check if a date is valid using "jj/mm/aaaa" pattern
     *
     * @param date
     * @return
     */
    public static boolean dateValidator(String date) {
        Matcher matcher = Date_PATTERN.matcher(date);
        return matcher.matches();
    }


    public static LocalDate convertNotNullDate(java.sql.Date databaseValue) {
        if (databaseValue != null) {
            return databaseValue.toLocalDate();
        }
        return null;
    }

    public static boolean isTitreDisponible(String categ) {
        List dispos = Arrays.asList(new String[]{"DISPO", "DEROGATOIRE"});
        return dispos.contains(categ);
    }

    public static String translateIntToON(int unouZero) {
        if (unouZero == 0) {
            return "N";
        } else if (unouZero == 1) {
            return "O";
        } else {
            throw new IllegalArgumentException("input must be 0 or 1");
        }
    }


    public static String formatDateForProc(LocalDate dateFromFront) {
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.US);
        String formattedDate = dateFromFront.format(outputFormatter);
        return formattedDate;
    }
}
