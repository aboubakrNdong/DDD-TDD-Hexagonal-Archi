package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IActionnaireRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IDataBancaireRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IDataPersoRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IPaysSepaRepository;
import com.uptevia.ms.bff.investor.business.domain.service.ActionnaireService;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.routines.checkdigit.CheckDigitException;
import org.apache.commons.validator.routines.checkdigit.IBANCheckDigit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActionnaireServiceImpl extends AbstractBusinessService implements ActionnaireService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String MANDATORY_FIELD = "form.field.validator.mandatory";

    private static final String NOT_VALID_FIELD = "form.field.validator.invalid";

    private final IDataBancaireRepository iDataBancaireRepository;

    private final IDataPersoRepository iDataPersoRepository;

    private final IActionnaireRepository actionnaireRepository;

    private final IPaysSepaRepository paysSepaRepository;

    private static final String UPDATE_ERROR = "error.update.data";

    public ActionnaireServiceImpl(final IActionnaireRepository actionnaireRepository, final IPaysSepaRepository paysSepaRepository, final IDataBancaireRepository iDataBancaireRepository, final IDataPersoRepository iDataPersoRepository) {
        this.actionnaireRepository = actionnaireRepository;
        this.paysSepaRepository = paysSepaRepository;
        this.iDataBancaireRepository = iDataBancaireRepository;
        this.iDataPersoRepository = iDataPersoRepository;

    }

    @Override
    public PsSelDetailTituDTO getActionnaire(final int idEmet, final int idActi, final int pTituNume) throws FunctionnalException {
        return actionnaireRepository.getActionnaire(idEmet, idActi, pTituNume);
    }

    @Override
    public List<CompteDTO> getComptes(String login) throws FunctionnalException {
        return actionnaireRepository.getComptes(login);
    }

    @Override
    public PaysSepaDTO getPaysSepa(Integer emetIden, String paramName) throws FunctionnalException {
        return paysSepaRepository.getPaysSepa(emetIden, paramName);
    }

    @Override
    public CodeIso2DTO getCodeIso2(String paysIden, String codeLangue) throws FunctionnalException {
        return actionnaireRepository.getCodeIso2(paysIden, codeLangue);
    }

    @Override
    public void updateDemandeBancaire(DemandeBancaireDTO demandeBancaire) throws FunctionnalException {

        Map<String, Object> contextParams = new HashMap<>();


        /**
         Nom de l’établissement => champ libre à la saisie / obligatoire
         *Si l’actionnaire laisse vide, un message d’erreur apparait :
         Merci de renseigner le(s) champs encadré(s)
         */

        if (demandeBancaire.getPDomiciliation() == null || StringUtils.isBlank(demandeBancaire.getPDomiciliation())) {
            contextParams.put("pDomiciliation", demandeBancaire.getPDomiciliation());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        /**
         *
         * *L’IBAN a une longueur définie (paramètre registrar), à défaut, un message apparait :
         * Le champ doit avoir une longueur de {0} caractères
         * Où {0} est le nb caractères de registrar
         * *L’IBAN est soumis à la règle CléModulo97, à défaut, un message apparait :
         * Le champ est incorrect, merci de revoir votre saisie
         * *L’IBAN est incohérent avec le pays de règlement choisi (code iso2 du début selon v26 registrar)
         * Le champ est incorrect, merci de revoir votre saisie
         */

        if (StringUtils.isBlank(demandeBancaire.getPIban())) {
            if (contextParams.get("pIban") == null) {
                contextParams.put("pIban", demandeBancaire.getPIban());
            }
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);

        } else {
            IBANCheckDigit a = new IBANCheckDigit();
            try {
                String checkDigit = a.calculate(demandeBancaire.getPIban());
                a.isValid(checkDigit);
                logger.info(" Iban is valid : ");

            } catch (CheckDigitException e) {
                logger.info("Invalid IBAN");
                throw new FunctionnalException(NOT_VALID_FIELD, NOT_VALID_FIELD, contextParams);
            }
        }


        /**
         * BIC => s’affiche tout le temps / champ obligatoire
         * *Si l’actionnaire laisse vide, un message d’erreur apparait :
         * Merci de renseigner le(s) champs encadré(s)
         * *Le BIC est composé de 8 ou 11 caractères, à défaut, un message apparait :
         * Le champ est incorrect, merci de revoir votre saisie
         * *Le BIC doit être lié au pays de règlement (champ 5 et 6), à défaut, un message apparait :
         * Le champ est incorrect, merci de revoir votre saisie
         */

        if (demandeBancaire.getPBic() == null || StringUtils.isBlank(demandeBancaire.getPBic())) {
            contextParams.put("pBic", demandeBancaire.getPBic());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        String codeIso2 = (demandeBancaire.getPIban()).substring(0, 2);
        String checkIso2 = (demandeBancaire.getPBic()).substring(4, 6);

        if (codeIso2.equals(checkIso2)) {
            logger.info(" BIC codeiso2 valid ");

        } else {
            logger.info(" BIC codeiso2 not valid, please check ");
            throw new FunctionnalException(NOT_VALID_FIELD, NOT_VALID_FIELD, contextParams);
        }

        if (demandeBancaire.getPBic().length() != 8 && demandeBancaire.getPBic().length() != 11) {
            contextParams.put("pBic", demandeBancaire.getPBic());
            throw new FunctionnalException(NOT_VALID_FIELD, NOT_VALID_FIELD, contextParams);
        }

        if (!isBicValid(demandeBancaire.getPBic())) {
            logger.info(" BIC regex not valid ");

            contextParams.put("pBic", demandeBancaire.getPBic());
            throw new FunctionnalException(NOT_VALID_FIELD, NOT_VALID_FIELD, contextParams);
        }

        this.iDataBancaireRepository.updateDemandeBancaire(demandeBancaire);

    }

    @Override
    public DemandePersoDTO updateDemandePerso(DemandePersoDTO demandePerso) throws FunctionnalException {
        Map<String, Object> contextParams = new HashMap<>();

        validatePTituNume(demandePerso, contextParams);
        validatePEmetIden(demandePerso, contextParams);
        validatePTituEMail(demandePerso, contextParams);
        validatePTituNumMobilePerso(demandePerso, contextParams);
        validatePAdreFiscInfoRue(demandePerso, contextParams);
        validatePAdreCodp(demandePerso, contextParams);
        validatePAdreInfoRue(demandePerso, contextParams);
        validatePAdreNomComu(demandePerso, contextParams);

        return iDataPersoRepository.updatedemandePerso(demandePerso);
    }


    private void validatePTituNume(DemandePersoDTO demandePerso, Map<String, Object> contextParams) throws FunctionnalException {
        /**
         * PTITUNUME est obligatoire
         */
        if (demandePerso.getPTituNume() == null) {
            contextParams.put("pTituNume", demandePerso.getPTituNume());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }
    }

    private void validatePEmetIden(DemandePersoDTO demandePerso, Map<String, Object> contextParams) throws FunctionnalException {
        /**
         * PEMETIDEN est obligatoire
         */
        if (demandePerso.getPEmetIden() == null) {
            contextParams.put("pEmetIden", demandePerso.getPEmetIden());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }
    }

    private void validatePTituEMail(DemandePersoDTO demandePerso, Map<String, Object> contextParams) throws FunctionnalException {

        /**
         * On ne peut pas effacer les 2 emails. Au moins un doit exister
         * Si l’actionnaire efface les deux emails, un message d’erreur apparait :
         * Vous devez avoir au moins un email de renseigner
         * L’email doit être au format xx@xx.fr
         * Si l’actionnaire efface les deux emails, un message d’erreur apparait :
         * Merci de vérifier le(s) champ(s) encadré(s)
         */

        if (StringUtils.isBlank(demandePerso.getPTituEMail())) {
            contextParams.put("pTituEMail", demandePerso.getPTituEMail());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }


        if (!isEmailValid(demandePerso.getPTituEMail())) {
            contextParams.put("pTituEMail", demandePerso.getPTituEMail());
            throw new FunctionnalException(NOT_VALID_FIELD, NOT_VALID_FIELD, contextParams);
        }
    }

    private void validatePTituNumMobilePerso(DemandePersoDTO demandePerso, Map<String, Object> contextParams) throws FunctionnalException {
        /**
         * Téléphone est un champ obligatoire : champ texte libre / obligatoire / vide par défaut
         * si pas de choix fait , afficher message : ce champ est obligatoire
         * Ne prends que des chiffres
         */

        if (demandePerso.getPTituNumMobilePerso() == null) {
            contextParams.put("pEmetIden", demandePerso.getPTituNumMobilePerso());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        if (!isTelephoneValid(demandePerso.getPTituNumMobilePerso())) {
            contextParams.put("pTituNumMobilePerso", demandePerso.getPTituNumMobilePerso());
            throw new FunctionnalException(NOT_VALID_FIELD, NOT_VALID_FIELD, contextParams);
        }
    }

    private void validatePAdreFiscInfoRue(DemandePersoDTO demandePerso, Map<String, Object> contextParams) throws FunctionnalException {
        /**
         * Rue adresse fiscale : champ texte libre / obligatoire / vide par défaut
         * si pas de texte saisi fait , afficher message : ce champ est obligatoire
         */
        if (StringUtils.isBlank(demandePerso.getPAdreFiscInfoRue())) {
            contextParams.put("pAdreFiscInfoRue", demandePerso.getPAdreFiscInfoRue());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }
    }

    private void validatePAdreCodp(DemandePersoDTO demandePerso, Map<String, Object> contextParams) throws FunctionnalException {
        /**
         * Code postale  adresse fiscale : champ texte libre / obligatoire / vide par défaut
         *
         * si pas de choix fait , afficher message : ce champ est obligatoire
         */
        if (StringUtils.isBlank(demandePerso.getPAdreCodp())) {
            contextParams.put("pAdreFiscCodp", demandePerso.getPAdreCodp());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }
    }

    private void validatePAdreInfoRue(DemandePersoDTO demandePerso, Map<String, Object> contextParams) throws FunctionnalException {
        /**
         * Rue adresse postale : champ texte libre / obligatoire / vide par défaut
         *
         * si pas de choix fait , afficher message : ce champ est obligatoire
         */
        if (StringUtils.isBlank(demandePerso.getPAdreInfoRue())) {
            contextParams.put("pAdreInfoRue", demandePerso.getPAdreInfoRue());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }
    }

    private void validatePAdreNomComu(DemandePersoDTO demandePerso, Map<String, Object> contextParams) throws FunctionnalException {
        /**
         * Ville adresse postale : champ texte libre / obligatoire / vide par défaut
         *
         * si pas de choix fait , afficher message : ce champ est obligatoire
         */
        if (StringUtils.isBlank(demandePerso.getPAdreNomComu())) {
            contextParams.put("pAdreNomComu", demandePerso.getPAdreNomComu());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }
    }

    /**
     * @param login
     * @return
     * @throws FunctionnalException
     */
    @Override
    public PsSelDetailTituDTO getFirstActionnaireByLogin(String login) throws FunctionnalException {
        PsSelDetailTituDTO psSelDetailTituDTO = actionnaireRepository.getFirstActionnaireByLogin(login);
        psSelDetailTituDTO.setAcceptCGU(isAcceptedCgu(psSelDetailTituDTO.getDateAcceptCGU()));

        return psSelDetailTituDTO;
    }

    boolean isAcceptedCgu(String dateAsString) {
        if (dateAsString == null) {
            return false;
        }
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDate datecgu = LocalDate.parse(dateAsString, formatter);
        LocalDate date90dayAgo = today.minusDays(90);
        return datecgu.isAfter(date90dayAgo) || datecgu.isEqual(date90dayAgo);
    }

    @Override
    public void updateMailPhone(ReqUpdateMailPhone req) throws FunctionnalException {
        Map<String, Object> contextParams = new HashMap<>();
        long result = actionnaireRepository.updateMailPhone(req);
        if (result != 1) {
            contextParams.put("updateLogin", req.getLogin());
            contextParams.put("updatePhone", req.getTelephone());
            contextParams.put("updateMail", req.getMail());
            contextParams.put("Proc Result", result);
            throw new FunctionnalException(UPDATE_ERROR, UPDATE_ERROR, contextParams);
        }
    }

    @Override
    public boolean chekTitulaireKyc(String login) throws FunctionnalException {
        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("login", login);
        return actionnaireRepository.chekTitulaireKyc(login);
    }


}


