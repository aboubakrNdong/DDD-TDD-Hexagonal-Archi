package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IAvoirTitreRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IValeurDetailRepository;
import com.uptevia.ms.bff.investor.business.domain.service.PortefeuilleService;

import java.util.*;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

public class PortefeuilleServiceImpl implements PortefeuilleService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private final IAvoirTitreRepository avoirsTitresRepository;
    private final IValeurDetailRepository valeurDetailRepository;

    private List<ValeurDTO> allValeursEmet = null;


    public PortefeuilleServiceImpl(final IAvoirTitreRepository avoirsTitresRepository, IValeurDetailRepository valeurDetailRepository) {
        this.avoirsTitresRepository = avoirsTitresRepository;
        this.valeurDetailRepository = valeurDetailRepository;
    }


    @Override
    public PortefeuilleTitreDTO getPortefeuilleTitres(int idEmet, int idActi) throws FunctionnalException {

        //Tous les titres de la BD pour ces idEmet, idActi et Toutes les valeurs de la BD pour cet idEmet
        List<AvoirTitreDTO> titres = avoirsTitresRepository.getAllAvoirTitres(idEmet, idActi);
        allValeursEmet = valeurDetailRepository.getValeurs(idEmet);

        if (titres.isEmpty() || allValeursEmet.isEmpty())
            return null;

        List<GroupeTitreDTO> groupeTitres = createGroupeTitres(titres);

        double valorisationTotal = groupeTitres.stream()
                .mapToDouble(groupe -> groupe.getValorisationGroupe())
                .sum();

        int titresTotal = groupeTitres.stream()
                .mapToInt(GroupeTitreDTO::getNbreTitres)
                .sum();

        int titresDispo = groupeTitres.stream()
                .mapToInt(GroupeTitreDTO::getTitresDispo)
                .sum();

        int titresIndispo = groupeTitres.stream()
                .mapToInt(GroupeTitreDTO::getTitresIndispo)
                .sum();


        return PortefeuilleTitreDTO.builder()
                .devise(titres.get(0).getDevise())
                .titresTotal(titresTotal)
                .valorisationTotal(valorisationTotal)
                .titresDispo(titresDispo)
                .titresIndispo(titresIndispo)
                .droitsVote(calculDroitsVode(titres))
                .groupeTitres(groupeTitres)
                .build();
    }

    private Long calculDroitsVode(List<AvoirTitreDTO> titres) {
        return titres.stream()
                .mapToLong(AvoirTitreDTO::getVoix)
                .sum();
    }

    Optional<ValeurDTO> getValeurByIden(List<ValeurDTO> listlValeurs, String valeIden) {
        return listlValeurs.stream()
                .filter(valeur -> valeur.getValeIden().equals(valeIden))
                .findFirst();
    }

    private List<ValeurTitreDTO> createGroupeValeurTitres(List<AvoirTitreDTO> listTitres) {

        List<ValeurTitreDTO> listValeurs = new ArrayList<>();
        // Regroupement des titres par le champ "valeur"
        Map<String, List<AvoirTitreDTO>> groupedTitresByVal = listTitres.stream()
                .collect(Collectors.groupingBy(AvoirTitreDTO::getValeIden));


        for (Map.Entry<String, List<AvoirTitreDTO>> entry : groupedTitresByVal.entrySet()) {
            String valeIden = entry.getKey();

            Optional<ValeurDTO> valeurOptional = getValeurByIden(allValeursEmet, valeIden);
            double dernierCours = valeurOptional.map(ValeurDTO::getDernierCours).orElse(0.0);
            String valeLibe = valeurOptional.map(ValeurDTO::getValeLibe).orElse("");

            ValeurTitreDTO groupe = ValeurTitreDTO.builder()
                    .valeIden(valeIden)
                    .valeLibe(valeLibe)
                    .dernierCours(dernierCours)
                    .listOrigines(createGroupeOrigines(entry.getValue()))
                    .build();

            listValeurs.add(groupe);
        }

        return listValeurs;
    }

    private List<GroupeTitreDTO> createGroupeTitres(List<AvoirTitreDTO> listTitres) {


        // Regroupement des titres par natureJuridique
        Map<String, List<AvoirTitreDTO>> groupedTitresBynatureJuridique = groupTitresBynatureJuridique(listTitres);

        List<GroupeTitreDTO> groupeTitres = new ArrayList<>();

        for (Map.Entry<String, List<AvoirTitreDTO>> entry : groupedTitresBynatureJuridique.entrySet()) {
            String natureJuridique = entry.getKey();
            List<AvoirTitreDTO> titresDansGroupe = entry.getValue();

            double valorisationGroupe = titresDansGroupe.stream()
                    .mapToDouble(AvoirTitreDTO::getValorisation)
                    .sum();

            int nbreTitres = titresDansGroupe.stream()
                    .mapToInt(AvoirTitreDTO::getQuantite)
                    .sum();

            int titresDispo = (int) titresDansGroupe.stream()
                    .filter(AvoirTitreDTO::getDisponible)
                    .mapToInt(AvoirTitreDTO::getQuantite)
                    .sum();

            int titresIndispo = nbreTitres - titresDispo;


            GroupeTitreDTO groupeTitre = GroupeTitreDTO.builder()
                    .nomGroupe(natureJuridique)
                    .valorisationGroupe(valorisationGroupe)
                    .nbreTitres(nbreTitres)
                    .titresDispo(titresDispo)
                    .titresIndispo(titresIndispo)
                    .listValeurs(createGroupeValeurTitres(titresDansGroupe))
                    .build();

            groupeTitres.add(groupeTitre);
        }

        return groupeTitres;
    }


    private List<OrigineTitreDTO> createGroupeOrigines(List<AvoirTitreDTO> listTitres) {
        Map<String, List<AvoirTitreDTO>> groupedTitresByOrigine = listTitres.stream()
                .collect(Collectors.groupingBy(AvoirTitreDTO::getCategorie));

        return groupedTitresByOrigine.entrySet().stream()
                .map(entry -> {
                    String origine = entry.getKey();
                    List<AvoirTitreDTO> titresDansOrigine = entry.getValue();

                    OrigineTitreDTO origineTitreDTO = OrigineTitreDTO.builder()
                            .origine(origine)
                            .listTitres(titresDansOrigine)
                            .build();

                    return origineTitreDTO;
                })
                .collect(Collectors.toList());
    }

    Map<String, List<AvoirTitreDTO>> groupTitresBynatureJuridique(List<AvoirTitreDTO> allTitres) {
        // NatureJuridique
        return allTitres.stream()
                .collect(Collectors.groupingBy(dto -> {
                    String origine = dto.getNatureJuridique();
                    switch (origine) {
                        case "L", "B", "N", "W", "R":
                            return "titres.nominatifs";
                        case "S":
                            return "titres.plans.droits";
                        case "P":
                            return "titres.plans.salaries";
                        case "G":
                            return "titres.paga";
                        default:
                            return "titres.autres";
                    }
                }));
    }
}
