package com.uptevia.ms.bff.investor.business.domain.util;

/**
 * <b>Description : Classe utilitaire contenant des constantes utilisees frequemment</b>
 *
 * @author Boris SODOLOUFO
 */
public class Constantes {


    private Constantes() {

    }

    public static final String HEURE_LIMITE_ORDRE = "17:30:00";
    public static final String PROC_PAS_DE_COTATION = "PS_SEL_VALE_TICK_TRANCHE";
    public static final String PROC_BAREME = "PS_SEL_BAREME_EMET";
    public static final String PROC_RECAP_SOLDE = "UPI_RECAP_SOLDE";
    public static final String PROC_VALEURS_CESSIBLES = "PS_SEL_SOLDE_BY_VALE_IDEN2";
    public static final String PROC_VALEURS = "PS_SEL_INFO_VALEUR";
    public static final String PROC_AVOIRS_A_VENDRE = "PS_SEL_AVOIRS_A_VENDRE2";

    public static final String PS_CUR = "PS_CUR";
    public static final String ID_EMET = "IDEMET";
    public static final String ID_ACTI = "IDACTI";
    public static final String VALEUR = "VALEUR";
    public static final String GET_CONFIRM_TRANSACTION = "CB_UPD_TRANSACTION_ID_DMD";
    public static final String APPLICATION = "UPI";
    public static final int PARAM_ID_TYPE_CANAL = 9;// 9 c'est identifiant UPI pour PosteRI
    public static final String PROC_JOURS_FERMES = "PS_SEL_JOURS_FERMES";
    public static final String PROC_AVOIR_TITRE = "UPI_RECAP_AVOIR_TITRE";
    public static final String PROC_HISTORIQUE_OPS = "UPI_OP_ACHAT_VENTE_BY_ACTI";

    public static final String AUTHORIZATION = "Authorization";
}
