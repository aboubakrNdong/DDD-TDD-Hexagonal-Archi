package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.CodeIso2DTO;
import com.uptevia.ms.bff.investor.business.domain.model.CompteDTO;
import com.uptevia.ms.bff.investor.business.domain.model.DemandePersoDTO;
import com.uptevia.ms.bff.investor.business.domain.model.DemandeBancaireDTO;
import com.uptevia.ms.bff.investor.business.domain.model.PaysSepaDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.IActionnaireRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IDataPersoRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IDataBancaireRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IPaysSepaRepository;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class ActionnaireServiceImplTest {

    Logger logger = LoggerFactory.getLogger(ActionnaireServiceImplTest.class.getName());

    @Mock
    private IPaysSepaRepository paysSepaRepository;

    @Mock
    private IDataBancaireRepository dataProfilRepository;

    @Mock
    private IDataPersoRepository dataPersoRepository;

    @Mock
    private IActionnaireRepository actionnaireRepository;

    @InjectMocks
    ActionnaireServiceImpl actionnaireService;

    private EasyRandom easyRandom = new EasyRandom();

    private static final String MANDATORY_FIELD = "form.field.validator.mandatory";

    private static final String NOT_VALID_FIELD = "form.field.validator.invalid";


    private static final String PPAYS = "DEU";

    private static final String PDEVISE = "EUR";

    private static final String PIBAN = "DE90518500791101010046";

    private static final String PBIC = "DEUTDEFFXXX";

    private static final String PUSER = "ABOUBAKR";

    private static final String PORIG = "GRC";

    private static final Integer PEMETIDEN = 150;

    private static final Integer PACTIIDEN = 810;
    private static final Integer PTITUNUME = 1;
    private static final String PTITUEMAIL = "aboubakr.ndong@gmail.fr";
    private static final String PTITUNUMEMOBILEPERSO = "0758919832";
    private static final String PADREFISCINFORUE =  "8 RUE DU PORT AUX CERISES";
    private static final String PADREFISCCODP = "91123";
    private static final String PADREINFORUE ="5 PLACE DES GARDIANS";
    private static final String PADRENOMCOMU = "PARIS";


    @Test
    void should_return_get_comptes_ok() throws Exception {

        String login = "61691966";
        List<CompteDTO> comptes = easyRandom.objects(CompteDTO.class, 5)
                .collect(Collectors.toList());

        Mockito.when(actionnaireRepository.getComptes(login)).thenReturn(comptes);

        Assertions.assertThat(actionnaireService.getComptes(login).size()).isEqualTo(comptes.size());

    }

    @Test
    void should_return_paysSepa_ok() throws Exception {

        //Given
        int idEmet = 99963514;
        String paramName = "MAJ_COORD_BANK_PAYS_AUTORISE";
        PaysSepaDTO paysSepa = easyRandom.nextObject(PaysSepaDTO.class);

        // When
        Mockito.when(actionnaireService.getPaysSepa(idEmet, paramName)).thenReturn(paysSepa);

        //Then
        Assertions.assertThat(actionnaireService.getPaysSepa(idEmet, paramName)).isSameAs(paysSepa);
    }

    @Test
    void should_return_CodeIso2_ok() throws Exception {

        //Given
        String paysIden = "FRA";
        String codeLangue = "FR";
        CodeIso2DTO codeIso2DTO = easyRandom.nextObject(CodeIso2DTO.class);

        // When
        Mockito.when(actionnaireService.getCodeIso2(paysIden, codeLangue)).thenReturn(codeIso2DTO);

        //Then
        Assertions.assertThat(actionnaireService.getCodeIso2(paysIden, codeLangue)).isSameAs(codeIso2DTO);
    }


    @Test
    void when_bic_Null_should_return_update_profil_KO() throws FunctionnalException {

        DemandeBancaireDTO demandeBancaireDTO = easyRandom.nextObject(DemandeBancaireDTO.class);

        demandeBancaireDTO.setPPays(PPAYS);
        demandeBancaireDTO.setPDevise(PDEVISE);
        demandeBancaireDTO.setPIban(PIBAN);
        demandeBancaireDTO.setPBic("");

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> actionnaireService.updateDemandeBancaire(demandeBancaireDTO));
        assertEquals(MANDATORY_FIELD, exception.getCode());

    }

    @Test
    void when_bic_RegexInvalid_should_return_update_profil_KO() throws FunctionnalException {

        DemandeBancaireDTO demandeBancaireDTO = easyRandom.nextObject(DemandeBancaireDTO.class);

        demandeBancaireDTO.setPPays(PPAYS);
        demandeBancaireDTO.setPDevise(PDEVISE);
        demandeBancaireDTO.setPIban(PIBAN);
        demandeBancaireDTO.setPBic("DEUTD@FFXXX");

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> actionnaireService.updateDemandeBancaire(demandeBancaireDTO));
        assertEquals(NOT_VALID_FIELD, exception.getCode());

    }

    @Test
    void should_return_send_updatebanque_KO() throws Exception {

        DemandeBancaireDTO demandeBancaireDTO = easyRandom.nextObject(DemandeBancaireDTO.class);

        demandeBancaireDTO.setPPays(PPAYS);
        demandeBancaireDTO.setPDevise(PDEVISE);
        // demandeProfilDTO.setPIban(PIBAN);
        demandeBancaireDTO.setPBic(PBIC);

        assertThrows(FunctionnalException.class, () -> actionnaireService.updateDemandeBancaire(demandeBancaireDTO));

    }

    @Test
    void when_iban_Null_should_return_update_profil_KO() throws FunctionnalException {

        DemandeBancaireDTO demandeBancaireDTO = easyRandom.nextObject(DemandeBancaireDTO.class);

        demandeBancaireDTO.setPPays(PPAYS);
        demandeBancaireDTO.setPDevise(PDEVISE);
        demandeBancaireDTO.setPIban("");
        demandeBancaireDTO.setPBic(PBIC);

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> actionnaireService.updateDemandeBancaire(demandeBancaireDTO));
        assertEquals(MANDATORY_FIELD, exception.getCode());

    }

    @Test
    void should_update_donne_bancaire_OK() throws Exception {

        DemandeBancaireDTO demandeBancaireDTO = easyRandom.nextObject(DemandeBancaireDTO.class);

        demandeBancaireDTO.setPIban(PIBAN);
        demandeBancaireDTO.setPBic(PBIC);

        Mockito.when(dataProfilRepository.updateDemandeBancaire(demandeBancaireDTO)).thenReturn(Long.valueOf(1));

        actionnaireService.updateDemandeBancaire(demandeBancaireDTO);

        verify(dataProfilRepository, times(1)).updateDemandeBancaire(any());

    }

    @Test
    void when_iban_Invalid_should_return_update_profil_KO() throws FunctionnalException {

        DemandeBancaireDTO demandeBancaireDTO = easyRandom.nextObject(DemandeBancaireDTO.class);

        demandeBancaireDTO.setPPays(PPAYS);
        demandeBancaireDTO.setPDevise(PDEVISE);
        demandeBancaireDTO.setPIban("ZZ90518500791101010046");
        demandeBancaireDTO.setPBic(PBIC);

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> actionnaireService.updateDemandeBancaire(demandeBancaireDTO));
        assertEquals(NOT_VALID_FIELD, exception.getCode());

    }


    @Test
    void when_ptituNume_Null_should_return_update_profil_KO() throws FunctionnalException {

        DemandePersoDTO demandePersoDTO = easyRandom.nextObject(DemandePersoDTO.class);

        demandePersoDTO.setPUser(PUSER);
        demandePersoDTO.setPOrig(PORIG);
        demandePersoDTO.setPEmetIden(PEMETIDEN);
       //demandePersoDTO.setPActiIden(PACTIIDEN);
        demandePersoDTO.setPTituNume(null);
        demandePersoDTO.setPTituEMail(PTITUEMAIL);
        demandePersoDTO.setPTituNumMobilePerso(PTITUNUMEMOBILEPERSO);
        demandePersoDTO.setPAdreFiscInfoRue(PADREFISCINFORUE);
        demandePersoDTO.setPAdreFiscCodp(PADREFISCCODP);
        demandePersoDTO.setPAdreInfoRue(PADREINFORUE);
        demandePersoDTO.setPAdreNomComu(PADRENOMCOMU);

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> actionnaireService.updateDemandePerso(demandePersoDTO));
        assertEquals(MANDATORY_FIELD, exception.getCode());

    }

    @Test
    void when_PEmetIden_null_should_return_update_profil_KO() throws FunctionnalException {

        DemandePersoDTO demandePersoDTO = easyRandom.nextObject(DemandePersoDTO.class);

        demandePersoDTO.setPUser(PUSER);
        demandePersoDTO.setPOrig(PORIG);
        demandePersoDTO.setPEmetIden(null);
        demandePersoDTO.setPActiIden(PACTIIDEN);
        demandePersoDTO.setPTituNume(PTITUNUME);
        demandePersoDTO.setPTituEMail(PTITUEMAIL);
        demandePersoDTO.setPTituNumMobilePerso(PTITUNUMEMOBILEPERSO);
        demandePersoDTO.setPAdreFiscInfoRue(PADREFISCINFORUE);
        demandePersoDTO.setPAdreFiscCodp(PADREFISCCODP);
        demandePersoDTO.setPAdreInfoRue(PADREINFORUE);
        demandePersoDTO.setPAdreNomComu(PADRENOMCOMU);

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> actionnaireService.updateDemandePerso(demandePersoDTO));
        assertEquals(MANDATORY_FIELD, exception.getCode());

    }

    @Test
    void when_telephone_null_should_return_insert_update_KO() throws Exception {

        DemandePersoDTO demandePersoDTO = easyRandom.nextObject(DemandePersoDTO.class);

        demandePersoDTO.setPUser(PUSER);
        demandePersoDTO.setPOrig(PORIG);
        demandePersoDTO.setPEmetIden(PEMETIDEN);
        demandePersoDTO.setPActiIden(PACTIIDEN);
       // demandePersoDTO.setPTituNume(PTITUNUME);
        //demandePersoDTO.setPTituEMail(PTITUEMAIL);
        demandePersoDTO.setPTituNumMobilePerso(PTITUNUMEMOBILEPERSO);
        demandePersoDTO.setPAdreFiscInfoRue(PADREFISCINFORUE);
        demandePersoDTO.setPAdreFiscCodp(PADREFISCCODP);
        demandePersoDTO.setPAdreInfoRue(PADREINFORUE);
        demandePersoDTO.setPAdreNomComu(PADRENOMCOMU);

        assertThrows(FunctionnalException.class, () -> actionnaireService.updateDemandePerso(demandePersoDTO));

    }

    @Test
    void when_regexEmail_not_valid_should_return_update_profil_KO() throws FunctionnalException {

        DemandePersoDTO demandePersoDTO = easyRandom.nextObject(DemandePersoDTO.class);

        demandePersoDTO.setPUser(PUSER);
        demandePersoDTO.setPOrig(PORIG);
        demandePersoDTO.setPEmetIden(PEMETIDEN);
        demandePersoDTO.setPActiIden(PACTIIDEN);
        demandePersoDTO.setPTituNume(PTITUNUME);
        demandePersoDTO.setPTituEMail("testemailregex");
        demandePersoDTO.setPTituNumMobilePerso(PTITUNUMEMOBILEPERSO);
        demandePersoDTO.setPAdreFiscInfoRue(PADREFISCINFORUE);
        demandePersoDTO.setPAdreFiscCodp(PADREFISCCODP);
        demandePersoDTO.setPAdreInfoRue(PADREINFORUE);
        demandePersoDTO.setPAdreNomComu(PADRENOMCOMU);

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> actionnaireService.updateDemandePerso(demandePersoDTO));
        assertEquals(NOT_VALID_FIELD, exception.getCode());

    }

    @Test
    void should_update_donne_personnelle_OK() throws Exception {

        DemandePersoDTO demandePersoDTO = easyRandom.nextObject(DemandePersoDTO.class);

        demandePersoDTO.setPUser(PUSER);
        demandePersoDTO.setPOrig(PORIG);
        demandePersoDTO.setPEmetIden(PEMETIDEN);
        demandePersoDTO.setPActiIden(PACTIIDEN);
        demandePersoDTO.setPTituNume(PTITUNUME);
        demandePersoDTO.setPTituEMail(PTITUEMAIL);
        demandePersoDTO.setPTituNumMobilePerso(PTITUNUMEMOBILEPERSO);
        demandePersoDTO.setPAdreFiscInfoRue(PADREFISCINFORUE);
        demandePersoDTO.setPAdreFiscCodp(PADREFISCCODP);
        demandePersoDTO.setPAdreInfoRue(PADREINFORUE);
        demandePersoDTO.setPAdreNomComu(PADRENOMCOMU);

        Mockito.when(dataPersoRepository.updatedemandePerso(demandePersoDTO)).thenReturn((demandePersoDTO));

        actionnaireService.updateDemandePerso(demandePersoDTO);

        verify(dataPersoRepository, times(1)).updatedemandePerso(any());

    }

    @Test
    void when_Telephone_regexInvalid_should_return_update_profil_KO() throws FunctionnalException {

        DemandePersoDTO demandePersoDTO = easyRandom.nextObject(DemandePersoDTO.class);

        demandePersoDTO.setPUser(PUSER);
        demandePersoDTO.setPOrig(PORIG);
        demandePersoDTO.setPEmetIden(PEMETIDEN);
        demandePersoDTO.setPActiIden(PACTIIDEN);
        demandePersoDTO.setPTituNume(PTITUNUME);
        demandePersoDTO.setPTituEMail(PTITUEMAIL);
        demandePersoDTO.setPTituNumMobilePerso("testphone");
        demandePersoDTO.setPAdreFiscInfoRue(PADREFISCINFORUE);
        demandePersoDTO.setPAdreFiscCodp(PADREFISCCODP);
        demandePersoDTO.setPAdreInfoRue(PADREINFORUE);
        demandePersoDTO.setPAdreNomComu(PADRENOMCOMU);

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> actionnaireService.updateDemandePerso(demandePersoDTO));
        assertEquals(NOT_VALID_FIELD, exception.getCode());

    }
}
