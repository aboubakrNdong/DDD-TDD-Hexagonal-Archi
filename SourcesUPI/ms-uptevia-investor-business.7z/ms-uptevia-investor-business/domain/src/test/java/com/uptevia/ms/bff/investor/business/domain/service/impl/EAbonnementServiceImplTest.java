package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IEabonnementRepository;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class EAbonnementServiceImplTest {

    Logger logger = LoggerFactory.getLogger(EAbonnementServiceImplTest.class.getName());

    @Mock
    private IEabonnementRepository eabonnementRepository;

    @InjectMocks
    EabonnementServiceImpl eabonnementService;

    private EasyRandom easyRandom = new EasyRandom();

    private static final String MANDATORY_FIELD = "form.field.validator.mandatory";
    private static final String NOT_VALID_FIELD = "form.field.validator.invalid";

    @Test
    void when_paramChoix_null_should_return_insertEabonnement_KO() throws FunctionnalException {

        EabonnementDTO eabonnementDTO = easyRandom.nextObject(EabonnementDTO.class);

        eabonnementDTO.setParamLogin("1");
        eabonnementDTO.setParamActiIden(2);
        eabonnementDTO.setParamTituNume(1);
        eabonnementDTO.setParamChoix("");
        eabonnementDTO.setParamDateChoix(null);

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> eabonnementService.insertEabonnement(eabonnementDTO));
        assertEquals(MANDATORY_FIELD, exception.getCode());

    }


    @Test
    void when_paramChoix_notequals_to_1_or_0_should_return_insertEabonnement_KO() throws FunctionnalException {

        EabonnementDTO eabonnementDTO = easyRandom.nextObject(EabonnementDTO.class);

        eabonnementDTO.setParamLogin("1");
        eabonnementDTO.setParamActiIden(2);
        eabonnementDTO.setParamTituNume(1);
        eabonnementDTO.setParamChoix("5");
        eabonnementDTO.setParamDateChoix(null);

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> eabonnementService.insertEabonnement(eabonnementDTO));
        assertEquals(NOT_VALID_FIELD, exception.getCode());

    }


    @Test
    void should_insert_eabonnement_OK() throws Exception {

        EabonnementDTO eabonnementDTO = easyRandom.nextObject(EabonnementDTO.class);

        eabonnementDTO.setParamLogin("1");
        eabonnementDTO.setParamActiIden(2);
        eabonnementDTO.setParamTituNume(1);
        eabonnementDTO.setParamChoix("1");
        eabonnementDTO.setParamDateChoix(null);

        Mockito.when(eabonnementRepository.insertEabonnement(eabonnementDTO)).thenReturn(Long.valueOf(1));

        eabonnementService.insertEabonnement(eabonnementDTO);

        verify(eabonnementRepository, times(1)).insertEabonnement(any());

    }
}
