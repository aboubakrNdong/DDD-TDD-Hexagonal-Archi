package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IActionnaireRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IOperationRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IValeurDetailRepository;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.jeasy.random.EasyRandomParameters;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OperationServiceImplTest {


    @Mock
    private IValeurDetailRepository valeurDetailRepository;

    @Mock
    private IOperationRepository operationRepository;

    @Mock
    private IActionnaireRepository actionnaireRepository;

    @InjectMocks
    OperationServiceImpl OperationService;

    private EasyRandom easyRandom = new EasyRandom();


    @Test
    void should_return_get_valeurs_ok() throws Exception {

        int idEmet = 99963514;

        List<ValeurDTO> valeurs = easyRandom.objects(ValeurDTO.class, 1)
                .collect(Collectors.toList());

        valeurs.forEach(
                e -> {
                    e.setDeviseCours("EUR");
                }
        );

        Mockito.when(valeurDetailRepository.getValeurs(idEmet)).thenReturn(valeurs);
        Assertions.assertThat(OperationService.getValeurs(idEmet, 1)).hasSameSizeAs(valeurs);
    }

    @Test
    void should_return_get_valeur_details_ok() throws Exception {

        // Création des données de test
        int idEmet = 123;
        int isValeurEtrangere = 0;
        String valeIden = "DEMF00130577";
        String valeNatu = "ACTION";
        String baremeWeb = "O";

        List<PasCotationDTO> mockPasCotation = new ArrayList<>(); // Créez des objets PasCotationDTO pour les tests
        BaremeDTO mockBareme = easyRandom.nextObject(BaremeDTO.class); // Créez un objet BaremeDTO pour les tests


        when(valeurDetailRepository.getPasCotation(valeIden)).thenReturn(mockPasCotation);
        when(valeurDetailRepository.getBareme(idEmet, isValeurEtrangere, valeIden, valeNatu, baremeWeb)).thenReturn(mockBareme);

        // Appel de la méthode à tester
        ValeurDetailDTO valeurDetailDTO = OperationService.getValeurDetails(idEmet, isValeurEtrangere, valeIden, valeNatu, baremeWeb);

        // Assertions
        assertEquals(mockPasCotation, valeurDetailDTO.getPasCotation());
        assertEquals(mockBareme, valeurDetailDTO.getBareme());
    }


    @Test
    void should_process_achat_order_ok() throws FunctionnalException {
        // Créer une instance d'AchatOrderRequest avec des données factices
        OrdreBourseDTO newDemandeAchat = easyRandom.nextObject(OrdreBourseDTO.class);

        newDemandeAchat.setNatureDemande(8); //Pour le cas d’un achat, renseigner 8.
        // Simuler le comportement du repository
        when(operationRepository.insertDemandeOlis(any())).thenReturn(newDemandeAchat); // Supposons que l'insertion a réussi
        when(operationRepository.insertOrdreBourse(any())).thenReturn(456612L); // Supposons que l'insertion a réussi
        when(operationRepository.insertReglement(any())).thenReturn(1); // Supposons que l'insertion a réussi

        OrdreBourseDTO createdDemandeAchat = easyRandom.nextObject(OrdreBourseDTO.class);


        // Appeler la méthode à tester
        OperationService.processOrdreBourse(createdDemandeAchat);

        // Assertions pour vérifier que le service fonctionne correctement
        // Par exemple, vérifiez que les méthodes du repository ont été appelées avec les bons arguments
        verify(operationRepository, times(1)).insertDemandeOlis(any());
        verify(operationRepository, times(1)).insertOrdreBourse(any());
        verify(operationRepository, times(1)).insertReglement(any());
    }

    @Test
    void should_confirm_transactionCB_ok() throws Exception {

        OrdreBourseDTO newOrdreBourseAchat = easyRandom.nextObject(OrdreBourseDTO.class);

        newOrdreBourseAchat.setNatureDemande(8); //8 pour un achat

        when(operationRepository.confirmTransactionCB(any())).thenReturn(1);

        OrdreBourseDTO ordreAchat = easyRandom.nextObject(OrdreBourseDTO.class);

        OperationService.confirmTransactionCB(ordreAchat);

        verify(operationRepository, times(1)).confirmTransactionCB(any());
    }

    @Test
    void should_process_vente_order_ok() throws FunctionnalException {
        OrdreBourseDTO newDemandeVente = easyRandom.nextObject(OrdreBourseDTO.class);

        newDemandeVente.setNatureDemande(4); //Vente
        List<LigneAvoirsDTO> titresTest = easyRandom.objects(LigneAvoirsDTO.class, 3)
                .collect(Collectors.toList());
        newDemandeVente.setTitres(titresTest);

        when(operationRepository.insertDemandeOlis(any())).thenReturn(newDemandeVente);
        when(operationRepository.insertOrdreBourse(any())).thenReturn(456612L);
        when(operationRepository.insertReglement(any())).thenReturn(1);

        OrdreBourseDTO createdDemandeVente = easyRandom.nextObject(OrdreBourseDTO.class);

        OperationService.processOrdreBourse(createdDemandeVente);

        verify(operationRepository, times(1)).insertDemandeOlis(any());
        verify(operationRepository, times(1)).insertOrdreBourse(any());
        verify(operationRepository, times(1)).insertReglement(any());
    }

    @Test
    void should_return_get_valeurs_cessibles_ok() throws FunctionnalException {

        // Créez des valeurs fictives pour simuler la réponse de la couche de données (repository)
        List<ValeurDTO> valeursCessibles = easyRandom.objects(ValeurDTO.class, 1)
                .collect(Collectors.toList());

        valeursCessibles.forEach(
                e -> {
                    e.setDeviseCours("EUR");
                }
        );
        // Définissez le comportement attendu lors de l'appel à la méthode du repository
        when(valeurDetailRepository.getValeursCessibles(anyInt(), anyInt())).thenReturn(valeursCessibles);

        // Appelez la méthode du service que vous testez
        List<ValeurDTO> result = OperationService.getValeursCessibles(1, 2);

        // Vérifiez que le résultat est correct en fonction des valeurs fictives
        assertEquals(valeursCessibles, result);

        // Vérifiez que la méthode du repository a été appelée une fois avec les bons paramètres
        verify(valeurDetailRepository, times(1)).getValeursCessibles(1, 2);
    }

    @Test
    void should_return_get_lignes_avoirs_ok() throws FunctionnalException {

        // Créez des valeurs fictives pour simuler la réponse de la couche de données (repository)
        int testStreamSize = 25;

        List<LigneAvoirsDTO> titresNominatifsL = easyRandom.objects(LigneAvoirsDTO.class, 3)
                .collect(Collectors.toList());
        titresNominatifsL.forEach(e -> {
            e.setNatureJuridique("L");
        }); // (catégories L,B,N,W,R)

        List<LigneAvoirsDTO> titresNominatifsB = easyRandom.objects(LigneAvoirsDTO.class, 2)
                .collect(Collectors.toList());
        titresNominatifsB.forEach(e -> {
            e.setNatureJuridique("B");
        }); // (catégories L,B,N,W,R)


        List<LigneAvoirsDTO> lignesAvoirs = easyRandom.objects(LigneAvoirsDTO.class, testStreamSize)
                .collect(Collectors.toList());
        // les titres.nominatifs
        for (int i = 0; i < 3; i++) {
            lignesAvoirs.get(i).setNatureJuridique("L");
        }

        for (int i = 3; i < 6; i++) {
            lignesAvoirs.get(i).setNatureJuridique("B");
        }

        for (int i = 6; i < 9; i++) {
            lignesAvoirs.get(i).setNatureJuridique("N");
        }

        //titres.plans.droits
        for (int i = 9; i < 12; i++) {
            lignesAvoirs.get(i).setNatureJuridique("S");
        }

        //titres.plans.salaries
        for (int i = 12; i < 15; i++) {
            lignesAvoirs.get(i).setNatureJuridique("P");
        }

        //titres.paga
        for (int i = 15; i < 18; i++) {
            lignesAvoirs.get(i).setNatureJuridique("G");
        }

        //titres.autres
        for (int i = 18; i < 21; i++) {
            lignesAvoirs.get(i).setNatureJuridique("X");
        }


        Map<String, List<LigneAvoirsDTO>> lesGroupes = OperationService.groupTitresByCategory(lignesAvoirs);
        //On devrait avoir 5 groupes
        assertEquals(5, lesGroupes.size());

        // Vérifiez que le regroupement a été effectué correctement
        assertTrue(lesGroupes.containsKey("titres.plans.droits"));
        assertTrue(lesGroupes.containsKey("titres.plans.salaries"));
        assertTrue(lesGroupes.containsKey("titres.paga"));
        assertTrue(lesGroupes.containsKey("titres.autres"));


        //Vérifiez le contenu de chaque groupe

        List<LigneAvoirsDTO> categorieNominatif = lesGroupes.get("titres.nominatifs");
        List<LigneAvoirsDTO> categorieP = lesGroupes.get("titres.plans.salaries");

        assertNotNull(categorieNominatif);
        assertNotNull(categorieP);
        assertEquals(9, categorieNominatif.size()); //3+3+3
        assertEquals(3, categorieP.size());

    }



    @Test
    void should_return_closed_dates_ok() throws Exception {

        LocalDate dateDebut = LocalDate.parse("2023-04-07");
        LocalDate dateFin = LocalDate.parse("2023-12-07");

        // Mocking the behavior of the repository
        List<LocalDate> expectedDates = generateRandomDates(5);

        when(operationRepository.getClosedDays(dateDebut, dateFin)).thenReturn(expectedDates);

        // Calling the service method
        List<LocalDate> actualDates = OperationService.getClosedDays(dateDebut, dateFin) ;

        // Asserting the results
        assertEquals(expectedDates, actualDates);

    }

    private List<LocalDate> generateRandomDates(int count) {

        LocalDate currentDate = LocalDate.now();
        LocalDate earliestDate = LocalDate.of(currentDate.getYear(), Month.JANUARY, 1);
        LocalDate latestDate = LocalDate.of(currentDate.getYear(), Month.DECEMBER, 31);

        EasyRandomParameters parameters = new EasyRandomParameters()
                .seed(System.currentTimeMillis())
                .objectPoolSize(100)
                .randomizationDepth(3)
                .dateRange(earliestDate, latestDate);

        EasyRandom easyRandom = new EasyRandom(parameters);

        List<LocalDate> randomDates = easyRandom.objects(LocalDate.class, count).collect(Collectors.toList());

        return randomDates;
    }




}