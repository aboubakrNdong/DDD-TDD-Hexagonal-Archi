package com.uptevia.ms.bff.investor.business.domain.service.impl;

import static org.junit.jupiter.api.Assertions.*;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.AvoirTitreDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.IAvoirTitreRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IValeurDetailRepository;

import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@ExtendWith(MockitoExtension.class)
public class PortefeuilleServiceImplTest {

    @Mock
    private IValeurDetailRepository valeurDetailRepository;

    @Mock
    private IAvoirTitreRepository avoirsTitresRepository;

    @InjectMocks
    private PortefeuilleServiceImpl portefeuilleService;

    private EasyRandom easyRandom = new EasyRandom();



    @Test
    void should_group_titres_by_nature_ok() throws FunctionnalException {
        
        int testStreamSize = 25;

        List<AvoirTitreDTO> titresNominatifsL = easyRandom.objects(AvoirTitreDTO.class, 3)
                .collect(Collectors.toList());
        titresNominatifsL.forEach(e -> {
            e.setNatureJuridique("L");
        });

        List<AvoirTitreDTO> titresNominatifsB = easyRandom.objects(AvoirTitreDTO.class, 2)
                .collect(Collectors.toList());
        titresNominatifsB.forEach(e -> {
            e.setNatureJuridique("B");
        });


        List<AvoirTitreDTO> titresAvoirs = easyRandom.objects(AvoirTitreDTO.class, testStreamSize)
                .collect(Collectors.toList());
        for (int i = 0; i < 3; i++) {
            titresAvoirs.get(i).setNatureJuridique("L");
        }

        for (int i = 3; i < 6; i++) {
            titresAvoirs.get(i).setNatureJuridique("B");
        }

        for (int i = 6; i < 9; i++) {
            titresAvoirs.get(i).setNatureJuridique("N");
        }

        for (int i = 9; i < 12; i++) {
            titresAvoirs.get(i).setNatureJuridique("S");
        }

        for (int i = 12; i < 15; i++) {
            titresAvoirs.get(i).setNatureJuridique("P");
        }

        for (int i = 15; i < 18; i++) {
            titresAvoirs.get(i).setNatureJuridique("G");
        }

        for (int i = 18; i < 21; i++) {
            titresAvoirs.get(i).setNatureJuridique("X");
        }


        Map<String, List<AvoirTitreDTO>> lesGroupes = portefeuilleService.groupTitresBynatureJuridique(titresAvoirs);
        assertEquals(5, lesGroupes.size());

        assertTrue(lesGroupes.containsKey("titres.plans.droits"));
        assertTrue(lesGroupes.containsKey("titres.plans.salaries"));
        assertTrue(lesGroupes.containsKey("titres.paga"));
        assertTrue(lesGroupes.containsKey("titres.autres"));


        List<AvoirTitreDTO> categorieNominatif = lesGroupes.get("titres.nominatifs");
        List<AvoirTitreDTO> categorieP = lesGroupes.get("titres.plans.salaries");

        assertNotNull(categorieNominatif);
        assertNotNull(categorieP);
        assertEquals(9, categorieNominatif.size());
        assertEquals(3, categorieP.size());

    }




}

