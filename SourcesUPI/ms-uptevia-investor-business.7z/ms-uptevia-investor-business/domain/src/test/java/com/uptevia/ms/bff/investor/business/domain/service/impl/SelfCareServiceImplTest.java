package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.DemandeDTO;
import com.uptevia.ms.bff.investor.business.domain.model.SousCategoriesDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.ISelfCareRepository;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;


import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class SelfCareServiceImplTest {

    @Mock
    private ISelfCareRepository selfCareRepository;
    @InjectMocks
    SelfCareServiceImpl selfCareService;
    private final EasyRandom easyRandom = new EasyRandom();

    @Test
    void should_return_piecejointe_ok() throws Exception {

        String pIndiLogged = "O";
        List<SousCategoriesDTO> allSousCategoriesDTO = easyRandom.objects(SousCategoriesDTO.class, 5)
                .collect(Collectors.toList());

        allSousCategoriesDTO.forEach(e -> {
            e.setCateTypoOrdre(1);
            e.setSousTypoIndiPjObligatoire("O");
        });

        Mockito.when(selfCareRepository.getCategories(pIndiLogged)).thenReturn(allSousCategoriesDTO);
        Assertions.assertThat(selfCareService.getCategories(pIndiLogged).size()).isEqualTo(5);
    }

    @Test
    void should_return_send_demande_KO() throws Exception {

        DemandeDTO demandeDTO = easyRandom.nextObject(DemandeDTO.class);

        demandeDTO.setPIndiLogged("N");

        demandeDTO.setActiIden("88824NOOP");

        assertThrows(FunctionnalException.class, () -> selfCareService.createSelfCare(demandeDTO));

        demandeDTO.setDob("29/10/2023");

        assertThrows(FunctionnalException.class, () -> selfCareService.createSelfCare(demandeDTO));
    }


    @Test
    void should_return_send_demande_OK() throws Exception {

        DemandeDTO demandeDTO = easyRandom.nextObject(DemandeDTO.class);

        Mockito.when(selfCareRepository.createSelfCare(demandeDTO)).thenReturn(Long.valueOf(1));

        selfCareService.createSelfCare(demandeDTO);
    }

}