package com.uptevia.ms.bff.investor.business.infra.configuration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;


import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
public class DataSourceConfig {

    @Value("${spring.datasource.jndi-name}")
    private String datasourceJndiName; //Uptevia

    @Value("${spring.datasource.oraoaec01.jndi-name}")
    private String datasourceOraoaec01JndiName; //Oraoaec01

    @Value("${spring.datasource.olis.jndi-name}")
    private String datasourceOlisJndiName; //OLIS

    @Value("${spring.datasource.olis.jndi-name}")
    private String datasourceRegisJndiName;  //REGIS



    @Bean(name = "jdbcTemplate")
    public JdbcTemplate jdbcTemplate1(@Qualifier("dataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean(name = "jdbcTemplate2")
    public JdbcTemplate jdbcTemplate2(@Qualifier("dataSource2") DataSource dataSource2) {
        return new JdbcTemplate(dataSource2);
    }

    @Bean(name = "jdbcTemplate3")
    public JdbcTemplate jdbcTemplate3(@Qualifier("dataSource3") DataSource dataSource3) {
        return new JdbcTemplate(dataSource3);
    }

    @Bean(name = "jdbcTemplate4")
    public JdbcTemplate jdbcTemplate4(@Qualifier("dataSource4") DataSource dataSource4) {
        return new JdbcTemplate(dataSource4);
    }

    @Primary
    @Bean(name = "dataSource")
    @Qualifier("dataSource")
    public DataSource dataSource() throws NamingException {
        Context ctx = new InitialContext();
        return (DataSource) ctx.lookup(datasourceJndiName);
    }

    @Bean(name = "dataSource2")
    @Qualifier("dataSource2")
    public DataSource dataSource2() throws NamingException {
        Context ctx = new InitialContext();
        return (DataSource) ctx.lookup(datasourceOraoaec01JndiName);
    }

    @Bean(name = "dataSource3")
    @Qualifier("dataSource3")
    public DataSource dataSource3() throws NamingException {
        Context ctx = new InitialContext();
        return (DataSource) ctx.lookup(datasourceOlisJndiName);
    }

    @Bean(name = "dataSource4")
    @Qualifier("dataSource4")
    public DataSource dataSource4() throws NamingException {
        Context ctx = new InitialContext();
       return (DataSource) ctx.lookup(datasourceRegisJndiName);
    }

    // Configuration du gestionnaire de transactions transactionManager3
    @Bean
    public PlatformTransactionManager transactionManager(@Qualifier("dataSource3") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

}
