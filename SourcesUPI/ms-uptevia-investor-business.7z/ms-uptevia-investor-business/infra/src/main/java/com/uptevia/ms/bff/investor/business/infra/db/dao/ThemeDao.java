package com.uptevia.ms.bff.investor.business.infra.db.dao;

import com.uptevia.ms.bff.investor.business.infra.db.entity.Theme;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ThemeDao extends JpaRepository<Theme, Integer> {
    @Procedure(name = Theme.NamedQuery_PS_SEL_THEME)
    Theme getTheme(@Param("codeEmetteur") String codeEmetteur);
}