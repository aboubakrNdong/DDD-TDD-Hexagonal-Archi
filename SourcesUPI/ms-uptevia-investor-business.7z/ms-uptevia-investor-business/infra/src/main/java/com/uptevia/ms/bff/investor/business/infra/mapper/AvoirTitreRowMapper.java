package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.AvoirTitreDTO;
import org.springframework.jdbc.core.RowMapper;

import static com.uptevia.ms.bff.investor.business.domain.service.impl.AbstractBusinessService.convertNotNullDate;
import static com.uptevia.ms.bff.investor.business.domain.service.impl.AbstractBusinessService.isTitreDisponible;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AvoirTitreRowMapper implements RowMapper<AvoirTitreDTO> {
    @Override
    public AvoirTitreDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        return AvoirTitreDTO.builder()
                .disponible(isTitreDisponible(rs.getString("CATEGORIE_VENTE")))
                .devise(rs.getString("DEVISE"))
                .quantite(rs.getInt("NB_ACTION_DISPO"))
                .voix(rs.getLong("VOIX"))
                .restriction("cptetitre.typologie." + rs.getString("C_REST_JURI"))
                .valeIden((rs.getString("VALE_IDEN")))
                .dernierCours(rs.getDouble("COURS"))
                .natureJuridique(rs.getString("NATURE_JURI"))
                .coursAcquisition(rs.getDouble("PRIX_ACQUISITION"))
                .prixSouscription(rs.getDouble("PRIX_ACQUISITION"))
                .coursLevee(rs.getDouble("PRIX_ACQUISITION"))
                .prixAcquisition(rs.getDouble("PRIX_ACQUISITION"))
                .categorie(rs.getString("CATEGORIE"))
                .valeLibe(rs.getString("LIBELLE_PLAN"))
                .valorisation(rs.getDouble("VALORISATION"))
                .qualificatif(rs.getString("QUALIFICATIF"))
                .cpteIden(rs.getString("CPTE_IDEN"))
                .typeDetention(rs.getString("TYPE_DETENTION"))
                .valeIdenPlan(rs.getString("VALE_IDEN_PLAN"))
                .admiIden(String.valueOf(rs.getInt("ADMI_IDEN")))
                .dateLevee(convertNotNullDate(rs.getDate("DATE_LEVEE")))
                .dateSoaa(convertNotNullDate(rs.getDate("SOAA_DATE")))
                .dateVoteDoubleBrut(convertNotNullDate(rs.getDate("D_VOTE_DOUBLE_BRUT")))
                .dateDetentionBrut(convertNotNullDate(rs.getDate("D_DETENTION_BRUT")))
                .dateAcquisition(convertNotNullDate(rs.getDate("D_DETENTION_BRUT")))
                .dateDispo(convertNotNullDate(rs.getDate("DATE_DISPO")))
                .dateSouscription(convertNotNullDate(rs.getDate("D_SOUSCRIPTION")))
                .dateCessFiscale(convertNotNullDate(rs.getDate("DATE_CESS_FISCALE")))
                .dateVoteDouble(convertNotNullDate(rs.getDate("DATE_VOTE_DOUBLE")))
                .build();
    }
}
