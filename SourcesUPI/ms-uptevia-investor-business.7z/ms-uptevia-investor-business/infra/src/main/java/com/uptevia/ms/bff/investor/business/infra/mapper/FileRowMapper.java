package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.FileDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class FileRowMapper implements RowMapper<FileDTO> {

    @Override
    public FileDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        return FileDTO.builder()
                .documentId(rs.getInt("DOCUMENT_ID"))
                .documentFileName(rs.getString("DOCUMENT_FILENAME"))
                .documentContentType(rs.getString("DOCUMENT_CONTENT_TYPE"))
                .documentContent(rs.getBytes("DOCUMENT_CONTENT"))
                .build();
    }
}
