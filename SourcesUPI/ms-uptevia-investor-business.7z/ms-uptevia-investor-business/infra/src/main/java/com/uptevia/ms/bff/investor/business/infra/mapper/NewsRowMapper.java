package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uptevia.ms.bff.investor.business.domain.model.ActusDTO;
import com.uptevia.ms.bff.investor.business.domain.model.NewsDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class NewsRowMapper implements RowMapper<NewsDTO> {

    @Override
    public NewsDTO mapRow(final ResultSet rs, final int rowNum) throws SQLException {

        NewsDTO newsDTO = new NewsDTO();

        String actus = rs.getString("ACTUS"); //Actus est du json venant de la PS

        ObjectMapper objectMapper = new ObjectMapper();

        try {
            JsonNode jsonArray = objectMapper.readTree(actus);

            List<ActusDTO> list = new ArrayList<>();

            for (JsonNode element : jsonArray) {

                ActusDTO actusDTO = objectMapper.treeToValue(element, ActusDTO.class);
                list.add(actusDTO);
            }

            newsDTO.setActus(list);

        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return newsDTO;
    }
}
