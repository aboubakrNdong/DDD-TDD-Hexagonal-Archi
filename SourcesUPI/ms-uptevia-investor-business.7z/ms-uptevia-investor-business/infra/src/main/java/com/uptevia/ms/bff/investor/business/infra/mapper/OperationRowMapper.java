package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.OperationDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.uptevia.ms.bff.investor.business.domain.service.impl.AbstractBusinessService;

public class OperationRowMapper implements RowMapper<OperationDTO> {
    @Override
    public OperationDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        return OperationDTO.builder()
                .idDemande(rs.getLong("id_demande"))
                .dateDemande(rs.getDate("date_demande").toLocalDate())
                .natureDemande(rs.getInt("nature_demande"))
                .refDemande(rs.getString("num_demande"))
                .statutDemande("operation.histo.etape." + rs.getString("statut_demande"))
                .statutExecution("operation.histo.statutExecution." + rs.getString("statut_execution"))
                .nbActions(rs.getInt("nb_actions_a_vendre"))
                .annulable(AbstractBusinessService.int2boolean(rs.getInt("annulable")))
                .montantNet(rs.getBigDecimal("montant_net"))
                .qteTrade(rs.getInt("qte_trade"))
                .build();
    }

}
