package com.uptevia.ms.bff.investor.business.infra.mapper;


import com.uptevia.ms.bff.investor.business.domain.model.PasCotationDTO;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PasCotationRowMapper implements RowMapper<PasCotationDTO> {
    @Override
    public PasCotationDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        return PasCotationDTO.builder()
                .tickSize(rs.getInt("TICK_SIZE"))
                .tranMin(rs.getDouble("TRAN_MIN"))
                .tranMax(rs.getDouble("TRAN_MAX"))
                .eche(rs.getDouble("ECHE"))
                .build();
    }
}
