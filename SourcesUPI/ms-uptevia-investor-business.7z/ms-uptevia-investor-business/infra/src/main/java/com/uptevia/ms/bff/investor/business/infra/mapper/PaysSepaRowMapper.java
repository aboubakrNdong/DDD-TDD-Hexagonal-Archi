package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.PaysSepaDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PaysSepaRowMapper implements RowMapper<PaysSepaDTO> {
    @Override
    public PaysSepaDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<String> paramValue = new ArrayList<>();
        PaysSepaDTO result = new PaysSepaDTO();
        String[] splited = rs.getString("PARAM_VALUE").split(";");
        for(String s : splited){
            paramValue.add(s);
        }
        result.setParamValue(paramValue);
        result.setParamName(rs.getString("PARAM_NAME"));
        return result;
    }
}
