package com.uptevia.ms.bff.investor.business.infra.mapper;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ReglementRowMapper implements RowMapper<Long> {
    @Override
    public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
        return  rs.getLong("REGLEMENT_CURRVAL");
    }
}
