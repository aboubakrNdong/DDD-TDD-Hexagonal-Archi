package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.SousCategoriesDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SousCategoryRowMapper implements RowMapper<SousCategoriesDTO> {

    @Override
    public SousCategoriesDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        return SousCategoriesDTO.builder()
                .cateTypoId(rs.getInt("typo_id"))
                .cateTypoTraductionKey(rs.getString("typo_traduction_key"))
                .cateTypoOrdre(rs.getInt("typo_ordre"))
                .sousTypoId(rs.getInt("sous_typo_id"))
                .sousTypoTraductionKey(rs.getString("sous_typo_traduction_key"))
                .sousTypoIndiPjObligatoire(rs.getString("sous_typo_indi_pj_obligatoire"))
                .sousTypoOrdre(rs.getInt("sous_typo_ordre"))
                .build();
    }
}
