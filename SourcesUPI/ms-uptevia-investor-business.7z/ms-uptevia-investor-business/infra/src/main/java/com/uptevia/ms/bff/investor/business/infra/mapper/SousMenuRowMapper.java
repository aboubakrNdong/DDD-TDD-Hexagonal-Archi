package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.SousMenuDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SousMenuRowMapper implements RowMapper<SousMenuDTO> {
    @Override
    public SousMenuDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        String useFormodule = rs.getString("module_indicateur_menu");

        boolean storeValue = false;

        if (useFormodule.equals("O")) {
            storeValue = true;
        }

        return SousMenuDTO.builder()
                .moduleGroupeNom(rs.getString("module_groupe_traduction_key"))
                .moduleGroupeUrl(rs.getString("module_groupe_nom"))
                .moduleGroupeOrdre(rs.getInt("module_groupe_ordre"))
                .moduleGroupeIndicateur(storeValue)
                .moduleGroupeImgName(rs.getString("module_groupe_img_filename"))
                .moduleNom(rs.getString("module_traduction_key"))
                .moduleUrl(rs.getString("module_nom"))
                .moduleOrdre(rs.getInt("module_ordre"))
                .useFormodule(rs.getString("module_indicateur_menu"))
                .moduleImgName(rs.getString("module_img_filename"))
                .moduleIndicateur(storeValue)
                .build();
    }
}