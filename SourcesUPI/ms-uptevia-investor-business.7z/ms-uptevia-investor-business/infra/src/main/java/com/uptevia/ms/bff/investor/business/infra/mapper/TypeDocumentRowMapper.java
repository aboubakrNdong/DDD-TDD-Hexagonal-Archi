package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.TypeDocumentDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TypeDocumentRowMapper implements RowMapper<TypeDocumentDTO> {
    @Override
    public TypeDocumentDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        return TypeDocumentDTO.builder()
                .documentId(rs.getInt("DOCUMENT_ID"))
                .versionLangueIso3(rs.getString("VERSION_LANGUE_ISO3"))
                .documentLangueIso3(rs.getString("DOCUMENT_LANGUE_ISO3"))
                .documentTraductionKey(rs.getString("DOCUMENT_TRADUCTION_KEY"))
                .documentTypeId(rs.getInt("DOCUMENT_TYPE_ID"))
                .documentTypeTraductionKey(rs.getString("DOCUMENT_TYPE_TRADUCTION_KEY"))
                .documentTypeCodeCouleurHtml(rs.getString("DOCUMENT_TYPE_CODE_COULEUR_HTML"))
                .build();
    }
}
