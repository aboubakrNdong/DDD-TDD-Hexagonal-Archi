package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IActionnaireRepository;
import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import com.uptevia.ms.bff.investor.business.infra.mapper.CodeIso2RowMapper;
import com.uptevia.ms.bff.investor.business.infra.mapper.CompteRowMapper;
import com.uptevia.ms.bff.investor.business.infra.mapper.OperationRowMapper;
import com.uptevia.ms.bff.investor.business.infra.mapper.TituDetailRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.sql.Types;
import java.util.*;
import java.util.logging.Logger;

@Repository
public class ActionnaireRepository implements IActionnaireRepository {

    Logger logger = Logger.getLogger(ActionnaireRepository.class.getName());

    private static final String UPI_UTIL_GET_COMPTES = "UPI_UTIL_GET_COMPTES";

    private static final String UPI_UTIL_GET_CODEISO2 = "SITE_GET_PAYS";
    private static final String ID_EMET = "idEmet";

    private static final String ID_ACTI = "idActi";

    private static final String PS_CUR = "PS_CUR";

    @Autowired
    private JdbcTemplate jdbcTemplate;


    public ActionnaireRepository(@Qualifier("jdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;


    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public PsSelDetailTituDTO getActionnaire(int idEmet, int idActi, int pTituNume) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("UPI_TITU_GET_DETAIL")
                .returningResultSet(PS_CUR,
                        new TituDetailRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(ID_EMET, idEmet)
                .addValue(ID_ACTI, idActi)
                .addValue("pTituNume", pTituNume);


        Map<String, Object> out = jdbcCall.execute(in);

        List<PsSelDetailTituDTO> result = (List<PsSelDetailTituDTO>) out.get(PS_CUR);

        if (result.isEmpty()) {
            return null;
        }
/*


        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put(ID_EMET, idEmet);
            contextParams.put(ID_ACTI, idActi);
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        if (result.size() > 1) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put(ID_EMET, idEmet);
            contextParams.put(ID_ACTI, idActi);
            throw new FunctionnalException("MDX", "Multi_Data_Exception", contextParams);
        }
 */
        PsSelDetailTituDTO psSelDetailTituDTO = result.get(0);
        psSelDetailTituDTO.setActiIden(idActi);
        psSelDetailTituDTO.setEmetIden(idEmet);
        return psSelDetailTituDTO;


    }

    @Override
    public List<CompteDTO> getComptes(String login) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(UPI_UTIL_GET_COMPTES)
                .returningResultSet(PS_CUR,
                        new CompteRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_LOGIN", login);


        Map<String, Object> out = jdbcCall.execute(in);

        List<CompteDTO> result = (List<CompteDTO>) out.get(PS_CUR);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("login", login);
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }
        return result;
    }

    @Override
    public CodeIso2DTO getCodeIso2(String paysIden, String codeLangue) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(UPI_UTIL_GET_CODEISO2)
                .returningResultSet(PS_CUR,
                        new CodeIso2RowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_PAYS_IDEN", paysIden)
                .addValue("P_CODE_LANGUE", codeLangue);
        Map<String, Object> out = jdbcCall.execute(in);

        List<CodeIso2DTO> result = (List<CodeIso2DTO>) out.get(PS_CUR);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return result.get(0);
    }


    public List<OperationDTO> getOperations(String login) throws FunctionnalException {
        //Avec le login, récupérer le premier compte
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(UPI_UTIL_GET_COMPTES)
                .returningResultSet(PS_CUR,
                        new CompteRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_LOGIN", login);

        Map<String, Object> out = jdbcCall.execute(in);

        List<CompteDTO> comptes = (List<CompteDTO>) out.get(PS_CUR);

        if (comptes.isEmpty()) {
            return Collections.emptyList();
        }

        //Pour le moment on prend le premier compte
        Integer emetIden = comptes.get(0).getEmetIden();
        Integer actiIden = comptes.get(0).getActiIden();


        SimpleJdbcCall jdbcCall2 = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.PROC_HISTORIQUE_OPS)
                .returningResultSet(Constantes.PS_CUR,
                        new OperationRowMapper());


        SqlParameterSource in2 = new MapSqlParameterSource()
                .addValue("P_EMET_IDEN", emetIden)
                .addValue("P_ACTI_IDEN", actiIden);


        Map<String, Object> out2 = jdbcCall2.execute(in2);
        List<OperationDTO> result = (List<OperationDTO>) out2.get(Constantes.PS_CUR);

        return result.isEmpty() ? Collections.emptyList() : result;
    }

    /**
     * @param login
     * @return
     * @throws FunctionnalException
     */
    @Override
    public PsSelDetailTituDTO getFirstActionnaireByLogin(String login) throws FunctionnalException {
        //Avec le login, récupérer le premier compte
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(UPI_UTIL_GET_COMPTES)
                .returningResultSet(PS_CUR,
                        new CompteRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_LOGIN", login);

        Map<String, Object> out = jdbcCall.execute(in);

        List<CompteDTO> comptes = (List<CompteDTO>) out.get(PS_CUR);

        if (comptes.isEmpty()) {
            return null;
        }

        //Pour le moment on prend le premier compte
        Integer emetIden = comptes.get(0).getEmetIden();
        Integer actiIden = comptes.get(0).getActiIden();

        return getActionnaire(emetIden, actiIden, 1);

    }

    @Override
    public long updateMailPhone(ReqUpdateMailPhone req) throws FunctionnalException {
        long returnValue = 0;
        try {

            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                    .withFunctionName("UPI_UTIL_UPDATE_EMAIL_TEL")
                    .declareParameters(
                            new SqlParameter("P_TEL", Types.VARCHAR),
                            new SqlParameter("P_MAIL", Types.VARCHAR),
                            new SqlParameter("P_LOGIN", Types.VARCHAR),
                            new SqlOutParameter("RETURN VALUE", Types.NUMERIC)
                    );

            // Créez un HashMap pour les paramètres d'entrée
            Map<String, Object> inParams = new HashMap<>();
            inParams.put("P_LOGIN", req.getLogin());
            inParams.put("P_MAIL", req.getMail());
            inParams.put("P_TEL", req.getTelephone());

            Map<String, Object> result = jdbcCall.execute(inParams);

            // Récupération de la valeur de retour
            returnValue = ((Number) result.get("RETURN VALUE")).intValue();
        } catch (DataAccessException e) {
            Map<String, Object> contextParams = new HashMap<>();
            // Gérez l'erreur SQL
            Throwable rootCause = e.getRootCause();
            if (rootCause != null) {
                contextParams.put("login", req.getLogin());
                throw new FunctionnalException("SDX", rootCause.getMessage(), contextParams);
            }
        }
        return returnValue;
    }

    @Override
    public boolean chekTitulaireKyc(String login) throws FunctionnalException {
        String returnValue;
        boolean checking = false;
        try {
            PsSelDetailTituDTO actionnaire = getFirstActionnaireByLogin(login);
            if (actionnaire == null) return false;

            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                    .withFunctionName("UPI_CHECK_KYC")
                    .declareParameters(
                            new SqlParameter("P_EMET_IDEN", Types.VARCHAR),
                            new SqlParameter("P_ACTI_IDEN", Types.VARCHAR),
                            new SqlParameter("P_TITU_NUME", Types.VARCHAR),
                            new SqlOutParameter("RETURN VALUE", Types.VARCHAR)
                    );

            // Créez un HashMap pour les paramètres d'entrée
            Map<String, Object> inParams = new HashMap<>();
            inParams.put("P_EMET_IDEN", actionnaire.getEmetIden().toString());
            inParams.put("P_ACTI_IDEN", actionnaire.getActiIden().toString());
            inParams.put("P_TITU_NUME", "1");

            Map<String, Object> result = jdbcCall.execute(inParams);

            // Récupération de la valeur de retour
            returnValue = ((String) result.get("RETURN VALUE")).toString().trim();

            checking = returnValue.contains("KYC COMPLET");

        } catch (DataAccessException e) {
            Map<String, Object> contextParams = new HashMap<>();
            // Gérez l'erreur SQL
            Throwable rootCause = e.getRootCause();
            if (rootCause != null) {
                contextParams.put("login", login);
                throw new FunctionnalException("SDX", rootCause.getMessage(), contextParams);
            }
        }

        return checking;
    }
}
