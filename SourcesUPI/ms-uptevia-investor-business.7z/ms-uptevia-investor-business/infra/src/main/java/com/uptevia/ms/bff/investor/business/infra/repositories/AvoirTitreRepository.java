package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.AvoirTitreDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.IAvoirTitreRepository;
import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import com.uptevia.ms.bff.investor.business.infra.mapper.AvoirTitreRowMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Repository
public class AvoirTitreRepository implements IAvoirTitreRepository {


    private final JdbcTemplate jdbcTemplate;


    public AvoirTitreRepository(@Qualifier("jdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    @PostConstruct
    public void init() {
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public List<AvoirTitreDTO> getAllAvoirTitres(int idEmet, int idActi) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.PROC_AVOIR_TITRE)
                .returningResultSet(Constantes.PS_CUR,
                        new AvoirTitreRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_EMET_IDEN", idEmet)
                .addValue("P_ACTI_IDEN", idActi)
                .addValue("P_VALEUR", null);


        Map<String, Object> out = jdbcCall.execute(in);

        List<AvoirTitreDTO> result = (List<AvoirTitreDTO>) out.get(Constantes.PS_CUR);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return result;
    }
}

