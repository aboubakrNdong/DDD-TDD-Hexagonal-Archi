package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IDataBancaireRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;


import org.springframework.jdbc.core.SqlOutParameter;


@Repository
public class DataBancaireRepository implements IDataBancaireRepository {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final JdbcTemplate jdbcTemplate;

    public DataBancaireRepository(@Qualifier("jdbcTemplate2") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public Long updateDemandeBancaire(DemandeBancaireDTO demandeBancaire) throws FunctionnalException {
        int returnValue = 0;
        try {
            logger.info(" beginning save value with ActiIDen: " + demandeBancaire.getPActi());

            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                    .withFunctionName("FC_INSERT_COORD_BANK")
                    .declareParameters(
                            new SqlParameter("p_login", Types.VARCHAR),
                            new SqlParameter("p_emet", Types.VARCHAR),
                            new SqlParameter("p_acti", Types.VARCHAR),
                            new SqlParameter("p_titu_nume", Types.NUMERIC),
                            new SqlParameter("p_user", Types.VARCHAR),
                            new SqlParameter("P_DEVISE_OLD", Types.VARCHAR),
                            new SqlParameter("P_PAYS_OLD", Types.VARCHAR),
                            new SqlParameter("P_REGLEMENT_OLD", Types.VARCHAR),
                            new SqlParameter("P_BIC_OLD", Types.VARCHAR),
                            new SqlParameter("P_IBAN_OLD", Types.VARCHAR),
                            new SqlParameter("P_DOMICILIATION_OLD", Types.VARCHAR),
                            new SqlParameter("P_DEVISE", Types.VARCHAR),
                            new SqlParameter("P_PAYS", Types.VARCHAR),
                            new SqlParameter("P_REGLEMENT", Types.VARCHAR),
                            new SqlParameter("P_BIC", Types.VARCHAR),
                            new SqlParameter("P_IBAN", Types.VARCHAR),
                            new SqlParameter("P_DOMICILIATION", Types.VARCHAR),
                            new SqlParameter("P_EXTENSION", Types.VARCHAR),
                            new SqlOutParameter("RETURN VALUE", Types.NUMERIC)
                    );

            // Créez un HashMap pour les paramètres d'entrée
            Map<String, Object> inParams = new HashMap<>();
            inParams.put("p_login", demandeBancaire.getPLogin());
            inParams.put("p_emet", demandeBancaire.getPEmet());
            inParams.put("p_acti", demandeBancaire.getPActi());
            inParams.put("p_titu_nume", demandeBancaire.getPTituNume());
            inParams.put("p_user", demandeBancaire.getPUser());
            inParams.put("P_DEVISE_OLD", demandeBancaire.getPDeviseOld());
            inParams.put("P_PAYS_OLD", demandeBancaire.getPPaysOld());
            inParams.put("P_REGLEMENT_OLD", demandeBancaire.getPReglementOld());
            inParams.put("P_BIC_OLD", demandeBancaire.getPBicOld());
            inParams.put("P_IBAN_OLD", demandeBancaire.getPIbanOld());
            inParams.put("P_DOMICILIATION_OLD", demandeBancaire.getPDomiciliationOld());
            inParams.put("P_DEVISE", demandeBancaire.getPDevise());
            inParams.put("P_PAYS", demandeBancaire.getPPays());
            inParams.put("P_REGLEMENT", demandeBancaire.getPReglement());
            inParams.put("P_BIC", demandeBancaire.getPBic());
            inParams.put("P_IBAN", demandeBancaire.getPIban());
            inParams.put("P_DOMICILIATION", demandeBancaire.getPDomiciliation());
            inParams.put("P_EXTENSION", "PDF");

            Map<String, Object> result = jdbcCall.execute(inParams);

            // Récupération de la valeur de retour
            returnValue = ((Number) result.get("RETURN VALUE")).intValue();
        } catch (DataAccessException e) {
            Map<String, Object> contextParams = new HashMap<>();
            // Gérez l'erreur SQL
            Throwable rootCause = e.getRootCause();
            if (rootCause != null) {
                contextParams.put("login", demandeBancaire.getPLogin());
                contextParams.put("emetIden", demandeBancaire.getPEmet());
                throw new FunctionnalException("SDX", rootCause.getMessage(), contextParams);
            }
        }
        return (long) returnValue;
    }
}


