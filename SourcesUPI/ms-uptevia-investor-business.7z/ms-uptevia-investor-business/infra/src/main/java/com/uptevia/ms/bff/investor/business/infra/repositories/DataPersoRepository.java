package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IDataPersoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;


@Repository
public class DataPersoRepository implements IDataPersoRepository {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final JdbcTemplate jdbcTemplate;

    public DataPersoRepository(@Qualifier("jdbcTemplate4") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public DemandePersoDTO updatedemandePerso(DemandePersoDTO demandePerso) throws FunctionnalException {
        try {
            logger.info(" beginning save value with ActiIDen: " + demandePerso.getPEmetIden());

            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                    .withProcedureName("REGIS.P_MAJ_TITU")
                    .declareParameters(
                            new SqlParameter("P_USER", Types.VARCHAR),
                            new SqlParameter("P_ORIG", Types.VARCHAR),
                            new SqlParameter("P_EMET_IDEN", Types.NUMERIC),
                            new SqlParameter("P_ACTI_IDEN", Types.NUMERIC),
                            new SqlParameter("P_TITU_NUME", Types.NUMERIC),
                            new SqlParameter("P_FLAG_DENOMINATION", Types.VARCHAR),
                            new SqlParameter("P_TITU_QUAL", Types.VARCHAR),
                            new SqlParameter("P_TITU_TITR", Types.VARCHAR),
                            new SqlParameter("P_TITU_NOM", Types.VARCHAR),
                            new SqlParameter("P_TITU_PREN", Types.VARCHAR),
                            new SqlParameter("P_TITU_NOM_JF", Types.VARCHAR),
                            new SqlParameter("P_FLAG_ADRESSE_POSTALE", Types.VARCHAR),
                            new SqlParameter("P_ADRE_INFO_BATI", Types.VARCHAR),
                            new SqlParameter("P_ADRE_INFO_RUE", Types.VARCHAR),
                            new SqlParameter("P_ADRE_COMP", Types.VARCHAR),
                            new SqlParameter("P_ADRE_CODP", Types.VARCHAR),
                            new SqlParameter("P_ADRE_NOM_COMU", Types.VARCHAR),
                            new SqlParameter("P_ADRE_PAYS_IDEN", Types.VARCHAR),
                            new SqlParameter("P_ADRE_INDI_BLOQ", Types.VARCHAR),
                            new SqlParameter("P_FLAG_ADRESSE_FISCALE", Types.VARCHAR),
                            new SqlParameter("P_ADRE_FISC_INFO_BATI", Types.VARCHAR),
                            new SqlParameter("P_ADRE_FISC_INFO_RUE", Types.VARCHAR),
                            new SqlParameter("P_ADRE_FISC_COMP", Types.VARCHAR),
                            new SqlParameter("P_ADRE_FISC_CODP", Types.VARCHAR),
                            new SqlParameter("P_ADRE_FISC_NOM_COMU", Types.VARCHAR),
                            new SqlParameter("P_ADRE_FISC_PAYS_IDEN", Types.VARCHAR),
                            new SqlParameter("P_ADRE_FISC_INDI_BLOQ", Types.VARCHAR),
                            new SqlParameter("P_FLAG_NAISSANCE", Types.VARCHAR),
                            new SqlParameter("P_TITU_DATE_NAIS", Types.DATE),
                            new SqlParameter("P_TITU_COMU_NAIS", Types.VARCHAR),
                            new SqlParameter("P_TITU_DEPT_NAIS", Types.VARCHAR),
                            new SqlParameter("P_PAYS_NAIS_IDEN", Types.VARCHAR),
                            new SqlParameter("P_TITU_COMU_NAIS_CODE", Types.VARCHAR),
                            new SqlParameter("P_FLAG_CSP", Types.VARCHAR),
                            new SqlParameter("P_TITU_CSP", Types.VARCHAR),
                            new SqlParameter("P_FLAG_E_MAIL", Types.VARCHAR),
                            new SqlParameter("P_TITU_E_MAIL", Types.VARCHAR),
                            new SqlParameter("P_FLAG_E_MAIL2", Types.VARCHAR),
                            new SqlParameter("P_TITU_E_MAIL2", Types.VARCHAR),
                            new SqlParameter("P_FLAG_NUME_TEL", Types.VARCHAR),
                            new SqlParameter("P_TITU_NUME_TEL", Types.VARCHAR),
                            new SqlParameter("P_FLAG_NUME_TEL2", Types.VARCHAR),
                            new SqlParameter("P_TITU_NUME_TEL2", Types.VARCHAR),
                            new SqlParameter("P_FLAG_NUM_MOBILE_PRO", Types.VARCHAR),
                            new SqlParameter("P_TITU_NUM_MOBILE_PRO", Types.VARCHAR),
                            new SqlParameter("P_FLAG_NUM_MOBILE_PERSO", Types.VARCHAR),
                            new SqlParameter("P_TITU_NUM_MOBILE_PERSO", Types.VARCHAR),
                            new SqlParameter("P_FLAG_NUM_FAX_PRO", Types.VARCHAR),
                            new SqlParameter("P_TITU_NUM_FAX_PRO", Types.VARCHAR),
                            new SqlParameter("P_FLAG_NUM_FAX_PERSO", Types.VARCHAR),
                            new SqlParameter("P_TITU_NUM_FAX_PERSO", Types.VARCHAR)
                    );

            // Créez un HashMap pour les paramètres d'entrée
            Map<String, Object> inParams = new HashMap<>();

            inParams.put("P_USER", demandePerso.getPUser());
            inParams.put("P_ORIG", demandePerso.getPOrig());
            inParams.put("P_EMET_IDEN", demandePerso.getPEmetIden());
            inParams.put("P_ACTI_IDEN", demandePerso.getPActiIden());
            inParams.put("P_TITU_NUME", demandePerso.getPTituNume());
            inParams.put("P_FLAG_DENOMINATION", demandePerso.getPFlagDenomination());
            inParams.put("P_TITU_QUAL", demandePerso.getPTituQual());
            inParams.put("P_TITU_TITR", demandePerso.getPTituTitr());
            inParams.put("P_TITU_NOM", null);
            inParams.put("P_TITU_PREN", null);
            inParams.put("P_TITU_NOM_JF", null);
            inParams.put("P_FLAG_ADRESSE_POSTALE", demandePerso.getPFlagAdressePostale());
            inParams.put("P_ADRE_INFO_BATI", demandePerso.getPAdreInfoBati());
            inParams.put("P_ADRE_INFO_RUE", demandePerso.getPAdreInfoRue());
            inParams.put("P_ADRE_COMP", demandePerso.getPAdreComp());
            inParams.put("P_ADRE_CODP", demandePerso.getPAdreCodp());
            inParams.put("P_ADRE_NOM_COMU", demandePerso.getPAdreNomComu());
            inParams.put("P_ADRE_PAYS_IDEN", demandePerso.getPAdrePaysIden());
            inParams.put("P_ADRE_INDI_BLOQ", demandePerso.getPAdreIndiBloq());
            inParams.put("P_FLAG_ADRESSE_FISCALE", demandePerso.getPFlagAdressePostale());
            inParams.put("P_ADRE_FISC_INFO_BATI", demandePerso.getPAdreFiscInfoBati());
            inParams.put("P_ADRE_FISC_INFO_RUE", demandePerso.getPAdreFiscInfoRue());
            inParams.put("P_ADRE_FISC_COMP", demandePerso.getPAdreFiscComp());
            inParams.put("P_ADRE_FISC_CODP", demandePerso.getPAdreCodp());
            inParams.put("P_ADRE_FISC_NOM_COMU", demandePerso.getPAdreFiscNomComu());
            inParams.put("P_ADRE_FISC_PAYS_IDEN", demandePerso.getPAdrePaysIden());
            inParams.put("P_ADRE_FISC_INDI_BLOQ", demandePerso.getPAdreIndiBloq());
            inParams.put("P_FLAG_NAISSANCE", null);
            inParams.put("P_TITU_DATE_NAIS", null);
            inParams.put("P_TITU_COMU_NAIS", null);
            inParams.put("P_TITU_DEPT_NAIS", null);
            inParams.put("P_PAYS_NAIS_IDEN", null);
            inParams.put("P_TITU_COMU_NAIS_CODE", null);
            inParams.put("P_FLAG_CSP", demandePerso.getPFlagCsp());
            inParams.put("P_TITU_CSP", demandePerso.getPTituCsp());
            inParams.put("P_FLAG_E_MAIL", demandePerso.getPFlagEMail());
            inParams.put("P_TITU_E_MAIL", demandePerso.getPTituEMail());
            inParams.put("P_FLAG_E_MAIL2", demandePerso.getPFlagEMail2());
            inParams.put("P_TITU_E_MAIL2", demandePerso.getPTituEMail2());
            inParams.put("P_FLAG_NUME_TEL", demandePerso.getPFlagNumeTel());
            inParams.put("P_TITU_NUME_TEL", demandePerso.getPTituNumeTel());
            inParams.put("P_FLAG_NUME_TEL2", demandePerso.getPFlagNumeTel2());
            inParams.put("P_TITU_NUME_TEL2", demandePerso.getPTituNumeTel2());
            inParams.put("P_FLAG_NUM_MOBILE_PRO", demandePerso.getPFlagNumMobilePro());
            inParams.put("P_TITU_NUM_MOBILE_PRO", demandePerso.getPTituNumMobilePro());
            inParams.put("P_FLAG_NUM_MOBILE_PERSO", demandePerso.getPFlagNumMobilePerso());
            inParams.put("P_TITU_NUM_MOBILE_PERSO", demandePerso.getPTituNumMobilePerso());
            inParams.put("P_FLAG_NUM_FAX_PRO", demandePerso.getPFlagNumFaxPro());
            inParams.put("P_TITU_NUM_FAX_PRO", demandePerso.getPTituNumFaxPro());
            inParams.put("P_FLAG_NUM_FAX_PERSO", demandePerso.getPFlagNumFaxPerso());
            inParams.put("P_TITU_NUM_FAX_PERSO", demandePerso.getPTituNumFaxPerso());

            Map<String, Object> outParams = jdbcCall.execute(inParams);
            logger.info(" success " + demandePerso);

            return demandePerso;

        } catch (DataAccessException e) {
            Map<String, Object> contextParams = new HashMap<>();
            // Gérez l'erreur SQL
            Throwable rootCause = e.getRootCause();
            if (rootCause != null) {
                contextParams.put("P_USER", demandePerso.getPUser());
                contextParams.put("P_EMET_IDEN", demandePerso.getPEmetIden());
                throw new FunctionnalException("SDX", rootCause.getMessage(), contextParams);
            }
        }
        return demandePerso;
    }

}


