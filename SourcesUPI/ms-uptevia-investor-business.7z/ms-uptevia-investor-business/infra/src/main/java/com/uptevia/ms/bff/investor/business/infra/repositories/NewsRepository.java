package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.NewsDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.INewsRepository;
import com.uptevia.ms.bff.investor.business.infra.mapper.NewsRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

@Repository
public class NewsRepository implements INewsRepository {


    public static final String ID_EMET = "idEmet";
    public static final String ID_ACTI = "idActi";
    public static final String TITU_NUM = "pTituNume";

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    Logger logger = Logger.getLogger(NewsRepository.class.getName());
    private final JdbcTemplate jdbcTemplate;


    public NewsRepository(@Qualifier("jdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    //@Cacheable("News")
    public NewsDTO getNews(int idEmet, int idActi, int pTituNume) throws FunctionnalException {

        logger.log(Level.INFO, "Beginning get News... ");


        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("UPI_TITU_GET_FIL_ACTU")
                .returningResultSet("PS_CUR",
                        new NewsRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(ID_EMET, idEmet)
                .addValue(ID_ACTI, idActi)
                .addValue(TITU_NUM, pTituNume);


        Map<String, Object> out = jdbcCall.execute(in);

        List<NewsDTO> result = (List<NewsDTO>) out.get("PS_CUR");

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put(ID_EMET, idEmet);
            contextParams.put(ID_ACTI, idActi);
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        if (result.size() > 1) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put(ID_EMET, idEmet);
            contextParams.put(ID_ACTI, idActi);
            throw new FunctionnalException("MDX", "Multi_Data_Exception", contextParams);
        }

        return result.get(0);

    }
}
