package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.caceis.stc.jdbc.sql.ProcStockHelper;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.service.impl.AbstractBusinessService;
import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import com.uptevia.ms.bff.investor.business.domain.model.LigneAvoirsDTO;
import com.uptevia.ms.bff.investor.business.domain.model.OrdreBourseDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.IOperationRepository;
import com.uptevia.ms.bff.investor.business.infra.mapper.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.sql.Types;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



@Repository
public class OperationRepository implements IOperationRepository {

    private static final String REQUEST_INSERT_AVOIR_A_VENDRE = "INSERT INTO ORDRE_VENTE_LIGNE_AVOIR(C_ID_DEMANDE, L_VALE_IDEN, L_RUB_COMPTA, " +
            "SOAA_DATE, AVOA_NUME, NB_ACTION_A_VENDRE, C_REST_JURI, C_UT_CREATION, D_CREATION, C_UT_MAJ, D_MAJ, N_PRIORITE, D_VOTE_DOUBLE, D_DETENTION,D_CESS_FISCALE, D_DISPO) " +
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final JdbcTemplate jdbcTemplate;

    public OperationRepository(@Qualifier("jdbcTemplate3") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @PostConstruct
    public void init() {
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }


    @Override
    public List<LocalDate> getClosedDays(LocalDate dateDebut, LocalDate dateFin) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.PROC_JOURS_FERMES)
                .returningResultSet(Constantes.PS_CUR,
                        new ClosedDaysRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("DATE_DEBUT", AbstractBusinessService.formatDateForProc(dateDebut))
                .addValue("DATE_FIN", AbstractBusinessService.formatDateForProc(dateFin));


        Map<String, Object> out = jdbcCall.execute(in);

        List<LocalDate> result = (List<LocalDate>) out.get(Constantes.PS_CUR);
        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return result;
    }



    @Override
    public OrdreBourseDTO insertDemandeOlis(OrdreBourseDTO ordreBourse) throws FunctionnalException {
        String today = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH).format(LocalDateTime.now());

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("INSERT_DEMANDE_OLIS")
                .declareParameters(
                        new SqlParameter("PARAM_ID_DEMANDE", Types.NUMERIC),
                        new SqlParameter("PARAM_ID_DEMANDE_RATT", Types.NUMERIC),
                        new SqlParameter("PARAM_ID_TYPE_CANAL", Types.NUMERIC),
                        new SqlParameter("PARAM_ID_OPERATEUR", Types.NUMERIC),
                        new SqlParameter("PARAM_ID_NATURE_DEMANDE", Types.NUMERIC),
                        new SqlParameter("PARAM_ID_EMET", Types.VARCHAR),
                        new SqlParameter("PARAM_ID_CCN", Types.VARCHAR),
                        new SqlParameter("PARAM_ID_ACT_INCONNU", Types.NUMERIC),
                        new SqlParameter("PARAM_NUM_RANG", Types.NUMERIC),
                        new SqlParameter("PARAM_REF_CANAL", Types.VARCHAR),
                        new SqlParameter("PARAM_COMMENTAIRE", Types.VARCHAR),
                        new SqlParameter("PARAM_TITU_QUAL", Types.VARCHAR),
                        new SqlParameter("PARAM_NOM_TITU", Types.VARCHAR),
                        new SqlParameter("PARAM_PNOM_TITU", Types.VARCHAR),
                        new SqlParameter("PARAM_MAIL_TITU", Types.VARCHAR),
                        new SqlParameter("PARAM_DATE_NAISSANCE", Types.DATE),
                        new SqlParameter("PARAM_LIBELLE_EMET", Types.VARCHAR),
                        new SqlParameter("PARAM_DATE_DEMANDE", Types.DATE),
                        new SqlParameter("PARAM_DATE_TRANSMISSION", Types.TIMESTAMP),
                        new SqlParameter("PARAM_DATE_CLOTURE", Types.DATE),
                        new SqlParameter("PARAM_PJ_FOURNIES", Types.VARCHAR),
                        new SqlParameter("PARAM_RETENUE_SRC", Types.VARCHAR),
                        new SqlParameter("PARAM_USERCREA", Types.VARCHAR),
                        new SqlParameter("PARAM_DEMANDEVALIDE", Types.VARCHAR),
                        new SqlOutParameter(Constantes.PS_CUR, Types.REF_CURSOR)
                )
                .returningResultSet(Constantes.PS_CUR,
                        new DemandeOrdreRowMapper()
                );

        Map<String, Object> inParams = new HashMap<>();
        inParams.put("PARAM_ID_DEMANDE", null);
        inParams.put("PARAM_ID_DEMANDE_RATT", null);
        inParams.put("PARAM_ID_TYPE_CANAL", Constantes.PARAM_ID_TYPE_CANAL);
        inParams.put("PARAM_ID_OPERATEUR", 9999);
        inParams.put("PARAM_ID_NATURE_DEMANDE", ordreBourse.getNatureDemande());
        inParams.put("PARAM_ID_EMET", ordreBourse.getEmetIden());
        inParams.put("PARAM_LIBELLE_EMET", ordreBourse.getEmetLibelle());
        inParams.put("PARAM_ID_CCN", ordreBourse.getActiIden());
        inParams.put("PARAM_ID_ACT_INCONNU", null);
        inParams.put("PARAM_NUM_RANG", ordreBourse.getTituNume());
        inParams.put("PARAM_REF_CANAL", null);
        inParams.put("PARAM_COMMENTAIRE", null);
        inParams.put("PARAM_TITU_QUAL", ordreBourse.getTituQualite());
        inParams.put("PARAM_NOM_TITU", ordreBourse.getTituNom());
        inParams.put("PARAM_PNOM_TITU", ordreBourse.getTituPrenom());
        inParams.put("PARAM_MAIL_TITU", ordreBourse.getTituEmail());
        inParams.put("PARAM_DATE_NAISSANCE", java.sql.Date.valueOf(ordreBourse.getTituDateNais()));
        inParams.put("PARAM_DATE_DEMANDE", java.sql.Date.valueOf(today));
        inParams.put("PARAM_DATE_TRANSMISSION", java.sql.Timestamp.valueOf(LocalDateTime.now()));
        inParams.put("PARAM_DATE_CLOTURE", null);
        inParams.put("PARAM_PJ_FOURNIES", "O");
        inParams.put("PARAM_RETENUE_SRC", null);
        inParams.put("PARAM_USERCREA", ordreBourse.getLogin());
        inParams.put("PARAM_DEMANDEVALIDE", "O");


        Map<String, Object> outParams = jdbcCall.execute(inParams);

        List<OrdreBourseDTO> result = (List<OrdreBourseDTO>) outParams.get("PS_CUR");
        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return result.get(0);
    }

    @Override
    public Long insertOrdreBourse(OrdreBourseDTO ordreBourse) throws FunctionnalException {
        logger.info("Inserting Ordre Bourse in Olis ...");

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("INSERT_ORDRE_BOURSE_OLIS");

        SqlParameter[] declaredParameters = {
                new SqlParameter("PARAM_ID_DEMANDE", java.sql.Types.NUMERIC),
                new SqlParameter("PARAM_ID_TYPE_VENTE", java.sql.Types.NUMERIC),
                new SqlParameter("PARAM_VALE_DEFI_IDEN", java.sql.Types.VARCHAR),
                new SqlParameter("PARAM_NB_ACTIONS_A_VENDRE", java.sql.Types.NUMERIC),
                new SqlParameter("PARAM_COURS_LIMITE", java.sql.Types.NUMERIC),
                new SqlParameter("PARAM_DATE_FIN_VALIDITE", java.sql.Types.DATE),
                new SqlParameter("PARAM_ORDRE_SOIGNANT", java.sql.Types.VARCHAR),
                new SqlParameter("PARAM_ORDRE_SPECIFIQUE", java.sql.Types.VARCHAR),
                new SqlParameter("PARAM_REF_PATIO", java.sql.Types.VARCHAR),
                new SqlParameter("PARAM_MARCHE", java.sql.Types.NUMERIC),
                new SqlParameter("PARAM_RUB_COMPTA", java.sql.Types.NUMERIC),
                new SqlParameter("PARAM_ACTIONS_DISPO", java.sql.Types.NUMERIC),
                new SqlParameter("PARAM_TYPE_DATE_VALIDITE", java.sql.Types.VARCHAR),
                new SqlParameter("PARAM_COURS_NON_COTE", java.sql.Types.NUMERIC),
                new SqlParameter("PARAM_CCN_ACHETEUR", java.sql.Types.VARCHAR),
                new SqlParameter("PARAM_INDI_TTF", java.sql.Types.VARCHAR),
                new SqlParameter("PARAM_TTF_EXO_IDEN", java.sql.Types.NUMERIC),
                new SqlParameter("CPLACECOTATION", java.sql.Types.VARCHAR),
                new SqlParameter("CDEVISECOTATION", java.sql.Types.VARCHAR),
                new SqlParameter("CIDINTMARKETS", java.sql.Types.VARCHAR),
                new SqlParameter("CIDEXTMARKETS", java.sql.Types.VARCHAR),
                new SqlParameter("CIDMARKETI", java.sql.Types.NUMERIC),
                new SqlParameter("USERCREA", java.sql.Types.VARCHAR),
                new SqlOutParameter("PS_CUR", Types.REF_CURSOR)
        };

        Map<String, Object> inParams = new HashMap<>();
        inParams.put("PARAM_ID_DEMANDE", ordreBourse.getIdDemande());
        inParams.put("PARAM_ID_TYPE_VENTE", ordreBourse.getTypeVente());
        inParams.put("PARAM_VALE_DEFI_IDEN", ordreBourse.getValeIden());
        inParams.put("PARAM_NB_ACTIONS_A_VENDRE", ordreBourse.getNbActions());
        inParams.put("PARAM_COURS_LIMITE", ordreBourse.getCoursLimite() != 0 ? ordreBourse.getCoursLimite() : null);
        inParams.put("PARAM_DATE_FIN_VALIDITE", java.sql.Date.valueOf(ordreBourse.getDateFinValidite()));
        inParams.put("PARAM_ORDRE_SOIGNANT", null);
        inParams.put("PARAM_ORDRE_SPECIFIQUE", null);
        inParams.put("PARAM_REF_PATIO", null);
        inParams.put("PARAM_MARCHE", 0);
        inParams.put("PARAM_RUB_COMPTA", null);
        inParams.put("PARAM_ACTIONS_DISPO", null);
        inParams.put("PARAM_TYPE_DATE_VALIDITE", "AUTRE");
        inParams.put("PARAM_COURS_NON_COTE", null);
        inParams.put("PARAM_CCN_ACHETEUR", null);
        inParams.put("PARAM_INDI_TTF", "N");
        inParams.put("PARAM_TTF_EXO_IDEN", 1);
        inParams.put("CPLACECOTATION", null);
        inParams.put("CDEVISECOTATION", null);
        inParams.put("CIDINTMARKETS", null);
        inParams.put("CIDEXTMARKETS", null);
        inParams.put("CIDMARKETI", null);
        inParams.put("USERCREA", ordreBourse.getLogin());

        jdbcCall.declareParameters(declaredParameters);
        jdbcCall.returningResultSet(Constantes.PS_CUR,
                new OrdreBourseRowMapper()
        );


        Map<String, Object> outParams = jdbcCall.execute(inParams);

        List<Long> result = (List<Long>) outParams.get("PS_CUR");
        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return result.get(0);
    }


    @Override
    public int insertReglement(OrdreBourseDTO ordreBourse) throws FunctionnalException {
        logger.info("Inserting Reglementin Olis ...");

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("INSERT_REGLEMENT");

        SqlParameter[] declaredParameters = {
                new SqlParameter("ID_DEMANDE", java.sql.Types.NUMERIC),
                new SqlParameter("REGLT_ATTENDU", java.sql.Types.NUMERIC),
                new SqlParameter("REGLT_VERSE", java.sql.Types.NUMERIC),
                new SqlParameter("MODE_REGLT", java.sql.Types.NUMERIC),
                new SqlParameter("ISO_DEVISE_VERSE", java.sql.Types.VARCHAR),
                new SqlParameter("DATE_RGLT_RECU", java.sql.Types.DATE),
                new SqlParameter("DATE_RGLT_VERSE", java.sql.Types.DATE),
                new SqlParameter("CODE_BANQUE", java.sql.Types.VARCHAR),
                new SqlParameter("CODE_AGENCE", java.sql.Types.VARCHAR),
                new SqlParameter("NUM_COMPTE", java.sql.Types.VARCHAR),
                new SqlParameter("CLE_RIB", java.sql.Types.VARCHAR),
                new SqlParameter("DOMICILIATION", java.sql.Types.VARCHAR),
                new SqlParameter("NUMERO_CHEQUE", java.sql.Types.NUMERIC),
                new SqlParameter("USERCREA", java.sql.Types.VARCHAR),
        };

        Map<String, Object> inParams = new HashMap<>();
        inParams.put("ID_DEMANDE", ordreBourse.getIdDemande());
        inParams.put("REGLT_ATTENDU", ordreBourse.getRegltAttendu());
        inParams.put("REGLT_VERSE", null);
        inParams.put("MODE_REGLT", ordreBourse.getModeReglt());
        inParams.put("ISO_DEVISE_VERSE", "EUR");
        inParams.put("DATE_RGLT_RECU", null);
        inParams.put("DATE_RGLT_VERSE", null);
        inParams.put("CODE_BANQUE", null);
        inParams.put("CODE_AGENCE", null);
        inParams.put("NUM_COMPTE", null);
        inParams.put("CLE_RIB", null);
        inParams.put("DOMICILIATION", null);
        inParams.put("NUMERO_CHEQUE", null);
        inParams.put("USERCREA", ordreBourse.getLogin());

        jdbcCall.declareParameters(declaredParameters);
        jdbcCall.returningResultSet(Constantes.PS_CUR,
                new ReglementRowMapper()
        );


        Map<String, Object> outParams = jdbcCall.execute(inParams);

        List<Long> result = (List<Long>) outParams.get(Constantes.PS_CUR);
        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return Math.toIntExact(result.get(0));

    }

    @Override
    public int insertAvoirsAVendre(OrdreBourseDTO demande) {
        List<LigneAvoirsDTO> lesAvoirs = demande.getTitres();
        jdbcTemplate.batchUpdate(REQUEST_INSERT_AVOIR_A_VENDRE, lesAvoirs, lesAvoirs.size(),
                (ps, avoirAVendre) -> {
                    int pos = 1;
                    ps.setInt(pos++, demande.getIdDemande());
                    ps.setString(pos++, demande.getValeIden());
                    ps.setString(pos++, avoirAVendre.getRubCompta());
                    ps.setDate(pos++, java.sql.Date.valueOf(avoirAVendre.getDateSoaa()));
                    ps.setInt(pos++, avoirAVendre.getNumAvoa() == null ? 0 : avoirAVendre.getNumAvoa());
                    ps.setInt(pos++, avoirAVendre.getNbActionAVendre());
                    ps.setString(pos++, avoirAVendre.getRestrictionJuridique());
                    ps.setString(pos++, demande.getLogin());
                    ps.setTimestamp(pos++, new Timestamp(System.currentTimeMillis()));
                    ps.setString(pos++, demande.getLogin());
                    ps.setTimestamp(pos++, new Timestamp(System.currentTimeMillis()));
                    ps.setInt(pos++, avoirAVendre.getPriorite() == null ? 1 : avoirAVendre.getPriorite());
                    // System.out.println("Priorite de la ligne : " + avoirAVendre.getPriorite());
                    ps.setDate(pos++, avoirAVendre.getDateVoteDoubleBrut() == null ? null : java.sql.Date.valueOf(avoirAVendre.getDateVoteDoubleBrut()));
                    ps.setDate(pos++, avoirAVendre.getDateDetentionBrut() == null ? null : java.sql.Date.valueOf(avoirAVendre.getDateDetentionBrut()));
                    ps.setDate(pos++, avoirAVendre.getDateCessFiscale() == null ? null : java.sql.Date.valueOf(avoirAVendre.getDateCessFiscale()));
                    ps.setDate(pos, avoirAVendre.getDateDispo() == null ? null : java.sql.Date.valueOf(avoirAVendre.getDateDispo()));

                });

        return lesAvoirs.size();
    }

    @Override
    public int confirmTransactionCB(OrdreBourseDTO demande) throws Exception {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("PARAM_LOGIN", demande.getLogin());
        params.put("PARAM_APPLICATION", Constantes.APPLICATION);
        params.put("PARAM_ID_TRANSACTION", demande.getOcbIdTransaction());
        params.put("PARAM_ID_DEMANDE", demande.getIdDemande());

        BigDecimal retour = ProcStockHelper.callFunctionOnOlis(Constantes.GET_CONFIRM_TRANSACTION, params);

        return (retour == null ? 0 : retour.intValue());
    }

}
