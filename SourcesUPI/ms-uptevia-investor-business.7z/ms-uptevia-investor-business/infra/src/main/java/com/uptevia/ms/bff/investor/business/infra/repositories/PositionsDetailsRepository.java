package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;

import com.uptevia.ms.bff.investor.business.domain.model.PositionsDetailsDTO;

import com.uptevia.ms.bff.investor.business.domain.repository.IPositionsDetailsRepository;

import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import com.uptevia.ms.bff.investor.business.infra.mapper.PositionsDetailsRowMapper;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

@Repository
public class PositionsDetailsRepository implements IPositionsDetailsRepository {



    Logger logger = Logger.getLogger(PositionsDetailsRepository.class.getName());
    private final JdbcTemplate jdbcTemplate;


    public PositionsDetailsRepository(@Qualifier("jdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }
    @Override
    public List<PositionsDetailsDTO> getAllPositionsDetails(int idEmet, int idActi) throws FunctionnalException {

        logger.log(Level.INFO, "Beginning get Details Positions with id emet : {0} ", idEmet);


        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.PROC_RECAP_SOLDE)
                .returningResultSet("PS_CUR",
                        new PositionsDetailsRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_EMET_IDEN", idEmet)
                .addValue("P_ACTI_IDEN", idActi);


        Map<String, Object> out = jdbcCall.execute(in);

        List<PositionsDetailsDTO> result = (List<PositionsDetailsDTO>) out.get("PS_CUR");

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return result;

    }


}
