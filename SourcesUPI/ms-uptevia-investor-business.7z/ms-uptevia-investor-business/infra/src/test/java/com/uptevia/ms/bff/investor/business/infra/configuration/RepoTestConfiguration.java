package com.uptevia.ms.bff.investor.business.infra.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.uptevia.ms.bff.investor.infra.repositories"})
public class RepoTestConfiguration {
}
