# ms-uptevia-investor-ext

micro service uptevia investor externe