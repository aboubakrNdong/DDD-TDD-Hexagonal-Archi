package com.uptevia.ms.bff.investor.ext.app.configuration;


public class CachingConfig {


}

