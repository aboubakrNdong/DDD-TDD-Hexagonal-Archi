package com.uptevia.ms.bff.investor.ext.app.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.uptevia.ms.bff.investor.ext.api.PaiementApi;
import com.uptevia.ms.bff.investor.ext.api.model.*;
import com.uptevia.ms.bff.investor.ext.app.mapper.PaiementCbUrlDTOMapper;
import com.uptevia.ms.bff.investor.ext.domain.model.PaiementCBUrlRequestDTO;
import com.uptevia.ms.bff.investor.ext.domain.service.PaiementService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class PaiementController implements PaiementApi {
    private final PaiementService paiementService;

    public PaiementController(final PaiementService paiementService) {
        this.paiementService = paiementService;
    }

    @Override
    public ResponseEntity<PaiementCBUrlJson> generateUrlSsoTransaction(PaiementCBUrlRequestJson paiementCBUrlRequestJson) {

        PaiementCBUrlRequestDTO cbUrlRequest = PaiementCbUrlDTOMapper.INSTANCE.JsonToDto(paiementCBUrlRequestJson);
        String url;
        try {
            url = paiementService.generateUrlSsoTransaction(cbUrlRequest);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new ResponseEntity<>(
                new PaiementCBUrlJson().urlPaiement(url)
                , HttpStatus.OK);
    }

    @Override
    public ResponseEntity<PaiementCBRetourJson> decryptParamRetour(String d1) {
        JsonNode jsonDecrypt;
        try {
            jsonDecrypt = paiementService.decryptParamRetour(d1);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new ResponseEntity<>(
                new PaiementCBRetourJson().params(jsonDecrypt)
                , HttpStatus.OK);
    }

}