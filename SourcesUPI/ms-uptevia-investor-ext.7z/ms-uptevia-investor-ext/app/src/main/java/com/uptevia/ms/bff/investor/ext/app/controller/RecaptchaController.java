package com.uptevia.ms.bff.investor.ext.app.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.uptevia.ms.bff.investor.ext.api.RecaptchaApi;
import com.uptevia.ms.bff.investor.ext.api.model.RecaptchaVerifyJson;
import com.uptevia.ms.bff.investor.ext.app.mapper.RecaptchaVerifyDTOMapper;
import com.uptevia.ms.bff.investor.ext.domain.model.RecaptchaVerifyDTO;
import com.uptevia.ms.bff.investor.ext.domain.service.RecaptchaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class RecaptchaController implements RecaptchaApi {
    private final RecaptchaService recaptchaService ;

    public RecaptchaController(final RecaptchaService recaptchaService) {
        this.recaptchaService = recaptchaService ;
    }

    /**
     * @param recaptchaVerifyJson (required)
     * @return
     */
    @Override
    public ResponseEntity<Object> verifyRecaptcha(RecaptchaVerifyJson recaptchaVerifyJson) {
        RecaptchaVerifyDTO captchaVerifyDTO = RecaptchaVerifyDTOMapper.INSTANCE.jsonToDto(recaptchaVerifyJson);
        JsonNode dto = null;
        try {

            dto = recaptchaService.verifyRecaptcha(captchaVerifyDTO);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new ResponseEntity<>(dto
                , HttpStatus.OK);
    }
}