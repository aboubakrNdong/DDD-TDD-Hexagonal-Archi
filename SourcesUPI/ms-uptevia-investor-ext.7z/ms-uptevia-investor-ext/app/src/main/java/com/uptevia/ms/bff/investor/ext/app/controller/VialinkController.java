package com.uptevia.ms.bff.investor.ext.app.controller;

import com.uptevia.ms.bff.investor.ext.api.VialinkApi;
import com.uptevia.ms.bff.investor.ext.domain.service.VialinkService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


@RestController
@RequestMapping("/api/v1")
public class VialinkController implements VialinkApi {
    private final VialinkService vialinkService;

    public VialinkController(VialinkService vialinkService) {
        this.vialinkService = vialinkService;
    }


    /**
     * @param controlId (optional)
     * @param type      (optional)
     * @param file      (optional)
     * @param file2     (optional)
     * @return
     */
    @Override
    public ResponseEntity<Object> addDocument(String controlId, String type, MultipartFile file, MultipartFile file2) {
        String result;
        try {
            result = vialinkService.addDocument(controlId, type, file, file2);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>(result
                , HttpStatus.CREATED);
    }


    /**
     * @param login login utilisateur UPI (required)
     * @return
     */
    @Override
    public ResponseEntity<Object> createControl(String login) {
        String resultCtrl;
        try {
            resultCtrl = vialinkService.newControl(login);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>(resultCtrl
                , HttpStatus.CREATED);
    }


    /**
     * @param controlId Identifiant du dossier (required)
     * @return
     */
    @Override
    public ResponseEntity<Void> submitControl(String controlId) {
        String result;
        try {
            result = vialinkService.submitControl(controlId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>(
                HttpStatus.ACCEPTED);
    }

    /**
     * @param controlId Identifiant du dossier (required)
     * @return
     */
    @Override
    public ResponseEntity<Object> getControlStatus(String controlId) {
        String result;
        try {
            result = vialinkService.getControlStatus(controlId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>(result
                , HttpStatus.OK);
    }



    /**
     * @param controlId Identifiant du dossier (required)
     * @return
     */
    @Override
    public ResponseEntity<Object> getControlDocuments(String controlId) {
        String result;
        try {
            result = vialinkService.getControlDocuments(controlId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>(result
                , HttpStatus.OK);
    }


    /**
     * @param controlId Identifiant du dossier (required)
     * @return
     */
    @Override
    public ResponseEntity<Object> getControlResult(String controlId) {
        String result;
        try {
            result = vialinkService.getControlResult(controlId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>(result
                , HttpStatus.OK);
    }


    @Override
    public ResponseEntity<Void> sendMailResultToGrc(String login, String controlId, String score) {
        try {
            vialinkService.sendMaiToGrc(login, controlId, score);
        } catch (Exception e) {
            throw new RuntimeException(e);

            //return new ResponseEntity<>(HttpStatus.REQUEST_TIMEOUT);
        }
        return new ResponseEntity<>(HttpStatus.CREATED);
    }


}
