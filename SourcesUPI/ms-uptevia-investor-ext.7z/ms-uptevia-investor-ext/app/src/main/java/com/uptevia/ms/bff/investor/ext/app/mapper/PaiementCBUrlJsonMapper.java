package com.uptevia.ms.bff.investor.ext.app.mapper;

import com.uptevia.ms.bff.investor.ext.api.model.PaiementCBUrlJson;
import com.uptevia.ms.bff.investor.ext.domain.model.PaiementResponseDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PaiementCBUrlJsonMapper {

    PaiementCBUrlJsonMapper INSTANCE = Mappers.getMapper(PaiementCBUrlJsonMapper.class);
    PaiementCBUrlJson dtoToJson(PaiementResponseDTO paiementResponseDTO);
}