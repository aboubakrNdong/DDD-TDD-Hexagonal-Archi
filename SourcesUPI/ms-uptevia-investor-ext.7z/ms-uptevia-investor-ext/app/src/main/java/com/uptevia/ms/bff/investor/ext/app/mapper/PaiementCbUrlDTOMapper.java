package com.uptevia.ms.bff.investor.ext.app.mapper;

import com.uptevia.ms.bff.investor.ext.api.model.PaiementCBUrlRequestJson;
import com.uptevia.ms.bff.investor.ext.domain.model.PaiementCBUrlRequestDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PaiementCbUrlDTOMapper {
    PaiementCbUrlDTOMapper INSTANCE = Mappers.getMapper(PaiementCbUrlDTOMapper.class);
    PaiementCBUrlRequestDTO JsonToDto(PaiementCBUrlRequestJson paiementCBUrlRequestJson);
}
