package com.uptevia.ms.bff.investor.ext.app.mapper;

import com.uptevia.ms.bff.investor.ext.api.model.RecaptchaVerifyJson;
import com.uptevia.ms.bff.investor.ext.domain.model.RecaptchaVerifyDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RecaptchaVerifyDTOMapper {
    RecaptchaVerifyDTOMapper INSTANCE = Mappers.getMapper(RecaptchaVerifyDTOMapper.class);
    RecaptchaVerifyDTO jsonToDto(RecaptchaVerifyJson requestJson);
}
