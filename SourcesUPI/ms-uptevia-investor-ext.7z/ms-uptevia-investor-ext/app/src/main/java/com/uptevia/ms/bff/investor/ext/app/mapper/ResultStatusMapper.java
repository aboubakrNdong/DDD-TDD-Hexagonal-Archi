package com.uptevia.ms.bff.investor.ext.app.mapper;

import com.uptevia.ms.bff.investor.ext.api.model.ResultStatusJson;
import com.uptevia.ms.bff.investor.ext.domain.model.ResultStatusDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ResultStatusMapper {
    ResultStatusMapper INSTANCE = Mappers.getMapper(ResultStatusMapper.class);

    ResultStatusJson dtoToJson(ResultStatusDTO resultStatusDTO);
}
