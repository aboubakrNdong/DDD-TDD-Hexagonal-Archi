package com.uptevia.ms.bff.investor.ext.app.mapper;

import com.uptevia.ms.bff.investor.ext.api.model.SubscriberVlkJson;
import com.uptevia.ms.bff.investor.ext.domain.model.SubscriberVlkDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SubscriberVlkDTOMapper {
    SubscriberVlkDTOMapper INSTANCE = Mappers.getMapper(SubscriberVlkDTOMapper.class);
    SubscriberVlkDTO jsonToDto(SubscriberVlkJson json);
}
