package com.uptevia.ms.bff.investor.ext.domain.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;
import java.util.List;

@Builder
@Getter
@Setter
public class RecaptchaRetourDTO {
    private boolean success;
    private String hostname;
    private String action;
    private float score;
    private OffsetDateTime challengeTs;
    private List<String> errorCodes = null;

    // Constructeur par défaut
    public RecaptchaRetourDTO() {
    }

    @JsonCreator
    public RecaptchaRetourDTO(
            @JsonProperty("success") boolean success,
            @JsonProperty("hostname") String hostname,
            @JsonProperty("action") String action,
            @JsonProperty("score") float score,
            @JsonProperty("challengeTs") OffsetDateTime challengeTs,
            @JsonProperty("errorCodes") List<String> errorCodes) {
        this.success = success;
        this.hostname = hostname;
        this.action = action;
        this.score = score;
        this.challengeTs = challengeTs;
        this.errorCodes = errorCodes;
    }

}
