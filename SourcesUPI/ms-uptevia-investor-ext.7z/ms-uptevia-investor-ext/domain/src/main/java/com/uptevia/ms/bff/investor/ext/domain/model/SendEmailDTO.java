package com.uptevia.ms.bff.investor.ext.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@Builder
public class SendEmailDTO {

    private String from;
    private String textBody;
    private String htmlBody;
    private String subject;
    private String typeMail;
    private List<String> recipients = null;
    private List<AttachmentsDTO> attachments = null;

}