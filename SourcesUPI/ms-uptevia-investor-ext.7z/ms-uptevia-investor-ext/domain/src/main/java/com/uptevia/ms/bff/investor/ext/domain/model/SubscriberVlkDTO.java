package com.uptevia.ms.bff.investor.ext.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class SubscriberVlkDTO {

    private String firstName;

    private String lastName;

    private String phoneNumber;

    private String email;

    private String birthday;

    private String address;

    private String city;

    private String zipCode;
}
