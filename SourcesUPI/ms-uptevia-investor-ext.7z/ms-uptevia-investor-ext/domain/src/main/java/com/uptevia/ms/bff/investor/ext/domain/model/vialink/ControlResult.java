package com.uptevia.ms.bff.investor.ext.domain.model.vialink;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;

public class ControlResult {
    @JsonProperty("status")
    private String status;

    @JsonProperty("score")
    private int score;

    @JsonProperty("checkResults")
    private List<Object> checkResults;

    @JsonProperty("nbPerformedChecks")
    private int nbPerformedChecks;

    @JsonProperty("nbConfiguredChecks")
    private int nbConfiguredChecks;

    @JsonProperty("scores")
    private Map<String, Integer> scores;

    @JsonProperty("scoresPerDocument")
    private Map<String, Object> scoresPerDocument;

}
