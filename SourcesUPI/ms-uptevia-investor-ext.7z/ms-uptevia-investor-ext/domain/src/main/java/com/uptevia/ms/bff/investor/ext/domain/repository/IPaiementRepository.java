package com.uptevia.ms.bff.investor.ext.domain.repository;

import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.model.PaiementCBUrlRequestDTO;

import java.io.IOException;

public interface IPaiementRepository {
    String getPaiementCBUrl(PaiementCBUrlRequestDTO cbUrlRequest) throws FunctionnalException;

    String decryptParamRetour(String chaine) throws IOException;
}