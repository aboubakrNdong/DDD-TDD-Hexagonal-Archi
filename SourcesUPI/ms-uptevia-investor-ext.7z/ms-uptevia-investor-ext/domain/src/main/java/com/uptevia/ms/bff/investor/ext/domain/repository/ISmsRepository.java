package com.uptevia.ms.bff.investor.ext.domain.repository;

import java.util.List;

public interface ISmsRepository {    String sendOneSMStoOneByRetarus(List<String> mobilePhones, String textSMS);
}
