package com.uptevia.ms.bff.investor.ext.domain.repository;

import java.io.File;

public interface IVialinkRepository {

    String newControl(String login);

    String uploadDocument(String controlId, File file, File file2, String type);

    String submitControl(String controlId);

    String getControlStatus(String controlId);

    String getControlDocuments(String controlId);

    String getControlReport(String controlId);

    String getControlResult(String controlId);


    boolean sendMaiToGrc(String login, String controlId, String scoreVialink);
}
