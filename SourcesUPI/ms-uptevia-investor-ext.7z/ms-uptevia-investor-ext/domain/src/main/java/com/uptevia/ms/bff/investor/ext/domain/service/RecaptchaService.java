package com.uptevia.ms.bff.investor.ext.domain.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.uptevia.ms.bff.investor.ext.domain.model.RecaptchaVerifyDTO;

import java.io.IOException;

public interface RecaptchaService {
    JsonNode verifyRecaptcha(RecaptchaVerifyDTO captchaVerifyDTO) throws IOException;
}
