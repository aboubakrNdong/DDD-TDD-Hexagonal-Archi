package com.uptevia.ms.bff.investor.ext.domain.service;

import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface VialinkService {
    String newControl(String login) throws FunctionnalException;

    String addDocument(String controlId, String type, MultipartFile file, MultipartFile file2) throws FunctionnalException, IOException;

    String submitControl(String controlId) throws FunctionnalException;

    String getControlStatus(String controlId) throws FunctionnalException;

    String getControlDocuments(String controlId) throws FunctionnalException;

    String getControlReport(String controlId) throws FunctionnalException;

    String getControlResult(String controlId) throws FunctionnalException;

    boolean sendMaiToGrc(String login, String controlId, String score) throws FunctionnalException;
}
