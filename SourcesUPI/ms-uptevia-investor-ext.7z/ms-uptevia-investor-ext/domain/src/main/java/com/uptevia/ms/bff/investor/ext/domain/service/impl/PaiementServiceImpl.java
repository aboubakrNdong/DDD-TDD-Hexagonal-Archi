package com.uptevia.ms.bff.investor.ext.domain.service.impl;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.model.PaiementCBUrlRequestDTO;
import com.uptevia.ms.bff.investor.ext.domain.repository.IPaiementRepository;
import com.uptevia.ms.bff.investor.ext.domain.service.PaiementService;

import java.io.IOException;


public class PaiementServiceImpl implements PaiementService {
    private final IPaiementRepository paiementRepository;

    public PaiementServiceImpl(IPaiementRepository paiementRepository) {
        this.paiementRepository = paiementRepository;
    }

    @Override
    public String generateUrlSsoTransaction(PaiementCBUrlRequestDTO cbUrlRequest) throws FunctionnalException {
        return paiementRepository.getPaiementCBUrl(cbUrlRequest);
    }

    @Override
    public JsonNode decryptParamRetour(String d1) throws IOException {

        ObjectMapper mapper = new ObjectMapper();
        JsonFactory factory = mapper.getJsonFactory();

        String decrypt = paiementRepository.decryptParamRetour(d1);
        JsonParser parser = factory.createJsonParser(decrypt);
        return mapper.readTree(parser);
    }
}