package com.uptevia.ms.bff.investor.ext.domain.service.impl;

import com.fasterxml.jackson.databind.JsonNode;
import com.uptevia.ms.bff.investor.ext.domain.model.RecaptchaVerifyDTO;
import com.uptevia.ms.bff.investor.ext.domain.repository.IRecaptchaRepository;
import com.uptevia.ms.bff.investor.ext.domain.service.RecaptchaService;

import java.io.IOException;

public class RecaptchaServiceImpl implements RecaptchaService {
    private final IRecaptchaRepository repository ;

    public RecaptchaServiceImpl(IRecaptchaRepository repository) {
        this.repository = repository;
    }

    @Override
    public JsonNode verifyRecaptcha(RecaptchaVerifyDTO captchaVerifyDTO) throws IOException {
        return AbstractService.stringToJson(repository.sendgRecaptchatoServer(captchaVerifyDTO));
    }
}
