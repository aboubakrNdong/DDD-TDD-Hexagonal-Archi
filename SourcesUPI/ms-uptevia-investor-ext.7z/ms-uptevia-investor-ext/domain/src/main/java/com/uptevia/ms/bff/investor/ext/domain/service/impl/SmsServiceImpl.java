package com.uptevia.ms.bff.investor.ext.domain.service.impl;

import com.uptevia.ms.bff.investor.ext.domain.repository.ISmsRepository;
import com.uptevia.ms.bff.investor.ext.domain.service.SmsService;

import java.util.List;

public class SmsServiceImpl implements SmsService {
    private final ISmsRepository smsRepository;

    public SmsServiceImpl(ISmsRepository smsRepository) {
        this.smsRepository = smsRepository;
    }

    /**
     * @param textSMS
     * @param nums
     * @return
     */
    @Override
    public String sendOneSMStoOne(String textSMS, List<String> nums) {
        return smsRepository.sendOneSMStoOneByRetarus(nums, textSMS);
    }
}
