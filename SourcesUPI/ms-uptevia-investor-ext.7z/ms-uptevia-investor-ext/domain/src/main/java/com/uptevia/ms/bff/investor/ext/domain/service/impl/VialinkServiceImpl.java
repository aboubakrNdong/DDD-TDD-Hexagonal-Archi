package com.uptevia.ms.bff.investor.ext.domain.service.impl;

import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.repository.IVialinkRepository;
import com.uptevia.ms.bff.investor.ext.domain.service.VialinkService;
import org.springframework.web.multipart.MultipartFile;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class VialinkServiceImpl implements VialinkService {
    private final IVialinkRepository vialinkRepository;

    public VialinkServiceImpl(IVialinkRepository repo) {
        this.vialinkRepository = repo;
    }

    /**
     * @param login
     * @return
     * @throws FunctionnalException
     */
    @Override
    public String newControl(String login) throws FunctionnalException {
        return vialinkRepository.newControl(login);
    }

    /**
     * @param controlId
     * @param type
     * @param file
     * @param file2
     * @return
     * @throws FunctionnalException
     */
    @Override
    public String addDocument(String controlId, String type, MultipartFile file, MultipartFile file2) throws FunctionnalException, IOException {
        return vialinkRepository.uploadDocument(controlId, convertMultipartFileToFile(file), convertMultipartFileToFile(file2), type );
    }

    /**
     * @param controlId
     * @return
     * @throws FunctionnalException
     */
    @Override
    public String submitControl(String controlId) throws FunctionnalException {
        return vialinkRepository.submitControl(controlId);
    }

    /**
     * @param controlId
     * @return
     * @throws FunctionnalException
     */
    @Override
    public String getControlStatus(String controlId) throws FunctionnalException {
        return vialinkRepository.getControlStatus(controlId);
    }

    @Override
    public String getControlDocuments(String controlId) throws FunctionnalException {
        return vialinkRepository.getControlDocuments(controlId);
    }

    @Override
    public String getControlReport(String controlId) throws FunctionnalException {
        return vialinkRepository.getControlReport(controlId);
    }

    @Override
    public String getControlResult(String controlId) throws FunctionnalException {
        return vialinkRepository.getControlResult(controlId);
    }

    @Override
    public boolean sendMaiToGrc(String login, String controlId, String score) throws FunctionnalException {
        return vialinkRepository.sendMaiToGrc(login, controlId, score);
    }

    private File convertMultipartFileToFile(MultipartFile multipartFile) throws IOException {

        if (multipartFile == null) {
            return null;
        }

        File file = new File(multipartFile.getOriginalFilename());
        try {
            Path filePath = file.toPath();
            Files.copy(multipartFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            // Gérer l'exception selon vos besoins
            throw new IOException("Erreur lors de la conversion de MultipartFile en File", e);
        }
        return file;
    }


}
