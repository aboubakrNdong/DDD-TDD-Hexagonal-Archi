package com.uptevia.ms.bff.investor.ext.domain.service.impl;

import com.uptevia.ms.bff.investor.ext.domain.model.PaiementCBUrlRequestDTO;
import com.uptevia.ms.bff.investor.ext.domain.repository.IPaiementRepository;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class PaiementServiceImplTest {

    private static final String APPLICATION = "TEST_UNITAIRE";
    private static final String MODULE = "TU";
    private static final String THEME = "test";
    @InjectMocks
    PaiementServiceImpl paiementService;


    @Mock
    private IPaiementRepository paiementRepository;

    private EasyRandom easyRandom = new EasyRandom();

    private final PaiementCBUrlRequestDTO urlRequestDTO = PaiementCBUrlRequestDTO.builder()
            .login("92605493")
            .emetIden(484)
            .actiIden(193)
            .langue("FRA")
            .module("ACHAT")
            .theme("UPTEVIA")
            .coursLimite(BigDecimal.valueOf(100.2))
            .dateValidite(LocalDate.parse("2023-12-01"))
            .typeValidite("JOUR")
            .modalite(3)
            .quantite(1)
            .isDirect(true)
            .isMontantReel(true)
            .moisValiditeMax(1)
            .build();


    @Test
    public void should_return_null_url_for_bad_request() {
        String testUrl;
        try {
            PaiementCBUrlRequestDTO paiementCBUrlRequestDTO = easyRandom.nextObject(PaiementCBUrlRequestDTO.class);
            testUrl = paiementService.generateUrlSsoTransaction(paiementCBUrlRequestDTO);
            assertNull(testUrl);
        } catch (Exception e) {
            fail("Exeception e : " + e.getMessage());
        }
    }

}