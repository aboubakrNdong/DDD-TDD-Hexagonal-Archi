package com.uptevia.ms.bff.investor.ext.infra.consumers;


import com.uptevia.ms.bff.investor.ext.domain.util.Constantes;
import com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels.Control;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import java.io.File;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.time.Instant;
import java.util.*;

@Configuration
@EnableCaching
public class ClientVialink {

    private final String baseUrl = "https://app.vialink.biz/";
    private final String clientId = "UPTEVIA_RECETTE";
    private final String clientSecret = Constantes.VIALINK_CLIENT_SECRET;
    private String accessToken;
    private RestTemplate restTemplate;
    private Instant tokenExpiration;

    @Value("${proxy.host}")
    private String proxyHost;

    private static final Logger logger = LoggerFactory.getLogger(ClientVialink.class);

    public ClientVialink() {

        try {
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(Constantes.PROXY_SERVER_HOST_PROD, Constantes.PROXY_SERVER_PORT));
            SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
            requestFactory.setProxy(proxy);

            this.restTemplate = new RestTemplate();
            requestFactory.setBufferRequestBody(false);
            this.restTemplate.setRequestFactory(requestFactory);
            this.restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());

            this.accessToken = obtainAccessToken().getAccess_token();
        } catch (Exception e) {
            logger.warn("Avertissement lors de l'initialisation de ClientVialink", e);
        }

    }

    @Cacheable("accessTokenCache")
    public String getAccessToken() {
        // Vérifiez si le token est expiré avant de le retourner
        if (tokenExpiration == null || tokenExpiration.isBefore(Instant.now().plusSeconds(30))) {
            renewAccessToken();
        }
        return accessToken;
    }

    @CacheEvict("accessTokenCache")
    private void renewAccessToken() {
        ConnectResult connectResult = obtainAccessToken();
        this.accessToken = connectResult.getAccess_token();
        this.tokenExpiration = Instant.now().plusSeconds(connectResult.getApi_key_info().getExpiresIn());
    }

    private ConnectResult obtainAccessToken() {
        String urlConnect = baseUrl + "connect/api/auth/oauth/token";

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("grant_type", "client_credentials");
        params.add("scope", "kyc-requester");
        HttpHeaders headers = new HttpHeaders();
        String basicAuth = Base64.getEncoder().encodeToString((clientId + ":" + clientSecret).getBytes());
        headers.set("Authorization", "Basic " + basicAuth);

        HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(params, headers);


        ResponseEntity<ConnectResult> responseEntity = restTemplate.exchange(
                urlConnect,
                HttpMethod.POST,
                requestEntity,
                ConnectResult.class
        );


        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            return responseEntity.getBody();
        } else {
            throw new RuntimeException("Failed to obtain access token");
        }
    }


    public String createControle(Control reqControl) {
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + getAccessToken());

        HttpEntity<Control> requestEntity = new HttpEntity<>(reqControl, headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(
                baseUrl + "kyc/api/requester/v1/controls",
                HttpMethod.POST,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();

    }

    public String uploadDocument(String controlId, File file, File file2, String type) {

        String apiUrl = baseUrl + "kyc/api/requester/v1/controls/" + controlId + "/documents.multipart?type=" + type;

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.set("Authorization", "Bearer " + getAccessToken());

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", new FileSystemResource(file));

        if (file2 != null) {
            body.add("file2", new FileSystemResource(file2));
        }

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.POST,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();
    }

    public String submitControl(String controlId) {

        String apiUrl = baseUrl + "kyc/api/requester/v1/controls/" + controlId + "/submit";
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + getAccessToken());

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.POST,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : "{ok}";
    }

    public String getControlStatus(String controlId) {

        String apiUrl = baseUrl + "kyc/api/requester/v1/controls/" + controlId;
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + getAccessToken());

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.GET,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();
    }

    public String getControlResult(String controlId) {

        String apiUrl = baseUrl + "kyc/api/requester/v1/controls/" + controlId + "/result?addNonApplicable=true";
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + getAccessToken());

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.GET,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();
    }

    public String getControlDocuments(String controlId) {

        String apiUrl = baseUrl + "kyc/api/requester/v1/controls/" + controlId + "/documents";
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + getAccessToken());

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.GET,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();
    }

    public String getControlReport(String controlId) {

        String apiUrl = baseUrl + "kyc/api/requester/v1/controls/" + controlId + "/report";
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + getAccessToken());

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.GET,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();
    }

}

