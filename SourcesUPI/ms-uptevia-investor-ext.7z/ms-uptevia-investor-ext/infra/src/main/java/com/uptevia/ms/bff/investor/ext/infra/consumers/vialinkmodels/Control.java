package com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
public class Control {
    @JsonProperty("spaceId")
    private String spaceId;

    @JsonProperty("controlProfileId")
    private String controlProfileId;

    @JsonProperty("subscriber")
    private Subscriber subscriber;

    @JsonProperty("metadata")
    private List<Metadata> metadata;

}
