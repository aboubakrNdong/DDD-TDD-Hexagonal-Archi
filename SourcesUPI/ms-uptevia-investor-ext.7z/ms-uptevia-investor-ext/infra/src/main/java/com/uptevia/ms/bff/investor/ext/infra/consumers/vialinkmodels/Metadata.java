package com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Metadata {
    @JsonProperty("key")
    private String key;

    @JsonProperty("value")
    private String value;

}
