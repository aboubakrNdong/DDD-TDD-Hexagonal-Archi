package com.uptevia.ms.bff.investor.ext.infra.repositories;


import com.uptevia.ms.bff.investor.ext.domain.model.AttachmentsDTO;
import com.uptevia.ms.bff.investor.ext.domain.model.PsSelDetailTituDTO;

import com.uptevia.ms.bff.investor.ext.domain.model.SendEmailDTO;
import com.uptevia.ms.bff.investor.ext.domain.util.Constantes;
import com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels.*;
import com.uptevia.ms.bff.investor.ext.domain.repository.IVialinkRepository;
import com.uptevia.ms.bff.investor.ext.infra.consumers.ClientVialink;
import com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels.Address;
import com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels.Control;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;


import java.io.File;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;


@Repository
public class VialinkRepository implements IVialinkRepository {

    private static final Logger LOG = LoggerFactory.getLogger(VialinkRepository.class);

    java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VialinkRepository.class.getName());

    @Value("${base.business.url}")
    private String baseBusinessUrl;


    public PsSelDetailTituDTO getTitulaire(String login) {

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseBusinessUrl + "titulaire")
                .queryParam("login", login);

        String apiUrl = builder.toUriString();

        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<PsSelDetailTituDTO> response = restTemplate.getForEntity(apiUrl, PsSelDetailTituDTO.class);

        PsSelDetailTituDTO titulaire = null;
        if (response.getStatusCode().is2xxSuccessful()) {
            titulaire = response.getBody();
        } else {
            logger.warning("Erreur lors de l'appel HTTP. Statut : " + response.getStatusCode());
        }

        return titulaire;
    }


    /**
     * @param login
     * @return
     */
    @Override
    public String newControl(String login) {

        ClientVialink clientVLK = new ClientVialink();
        Control reqControl = makeControl(login);
        return clientVLK.createControle(reqControl);

    }

    @Override
    public String uploadDocument(String controlId, File file, File file2, String type) {

        ClientVialink client = new ClientVialink();
        return client.uploadDocument(controlId, file, file2, type);

    }

    /**
     * @param controlId
     * @return
     */
    @Override
    public String submitControl(String controlId) {
        ClientVialink client = new ClientVialink();
        return client.submitControl(controlId);
    }

    /**
     * @param controlId
     * @return
     */
    @Override
    public String getControlStatus(String controlId) {
        ClientVialink client = new ClientVialink();
        return client.getControlStatus(controlId);
    }

    @Override
    public String getControlDocuments(String controlId) {
        ClientVialink client = new ClientVialink();
        return client.getControlDocuments(controlId);
    }

    @Override
    public String getControlReport(String controlId) {
        ClientVialink client = new ClientVialink();
        return client.getControlReport(controlId);
    }

    @Override
    public String getControlResult(String controlId) {
        ClientVialink client = new ClientVialink();
        return client.getControlResult(controlId);
    }

    @Override
    public boolean sendMaiToGrc(String login, String controlId, String scoreVialink) {

        PsSelDetailTituDTO titulaire = getTitulaire(login);

        List<String> recipient = List.of(Constantes.GRC_MAIL);


        final AttachmentsDTO attachDoc = AttachmentsDTO.builder()
                .fileName("nofile")
                .file("")
                .build();
        List<AttachmentsDTO> attachmentsList = Arrays.asList(attachDoc);

        final SendEmailDTO thesendEmailDTO = SendEmailDTO.builder()
                .from("no-reply@uptevia.com")
                .textBody(
                        buildMessage(titulaire.getNom(), titulaire.getPrenom(), login, titulaire.getEmetIden().toString(), titulaire.getActiIden().toString(),
                                titulaire.getActiTypeCpte(), "1", controlId, scoreVialink))
                .htmlBody("")
                .subject("Problème connexion site investisseur")
                .typeMail("string")
                .recipients(recipient)
                .attachments(attachmentsList)
                .build();


        if (sendEmail(thesendEmailDTO)) {
            return true;
        } else {
            throw new RuntimeException("Failed to send email");
        }


    }

    String buildMessage(String nom, String prenom, String identifiant, String codeEmetteur,
                        String ccn, String typeCompte, String numeroTitulaire, String controlId, String scoreVialink) {

        return String.format("Bonjour,\n\n"
                        + "Je n'arrive pas à me connecter sur le mon espace investisseur.\n"
                        + "Pouvez-vous s'il vous plaît me connecter sur mon espace, s'il vous plaît.\n\n"
                        + "Ci-joint mes identifiants :\n\n"
                        + "Category: Gestion des accès\n"
                        + "Subcategory: Problèmes accès au site\n"
                        + "Nom: %s\n"
                        + "Prénom: %s\n"
                        + "Identifiant: %s\n"
                        + "Code émetteur: %s\n"
                        + "CCN: %s\n"
                        + "Type de compte: %s\n"
                        + "Numéro du titulaire: %s\n\n"
                        + "Score Vialink : %s\n"
                        + "Numéro du Dossier Vialink: %s\n\n"
                        + "En vous remerciant d'avance pour votre aide.\n\n"
                        + "Cordialement,\n\n"
                        + "%s %s",
                nom, prenom, identifiant, codeEmetteur, ccn, typeCompte, numeroTitulaire, controlId, scoreVialink, prenom, nom);
    }

    public boolean sendEmail(SendEmailDTO sendEmailDTO) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseBusinessUrl + "sendMail")
                .queryParam("from", sendEmailDTO.getFrom())
                .queryParam("textBody", sendEmailDTO.getTextBody())
                .queryParam("htmlBody", sendEmailDTO.getHtmlBody())
                .queryParam("subject", sendEmailDTO.getSubject())
                .queryParam("typeMail", sendEmailDTO.getTypeMail())
                .queryParam("recipients", sendEmailDTO.getRecipients())
                .queryParam("attachments", sendEmailDTO.getAttachments());

        String apiUrl = builder.toUriString();

        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<SendEmailDTO> response = restTemplate.postForEntity(apiUrl, sendEmailDTO, SendEmailDTO.class);

        return response.getStatusCode().is2xxSuccessful();
    }

    public Subscriber createSubscriber(String login) {

        PsSelDetailTituDTO titulaire = getTitulaire(login);

        Address ad = Address.builder()
                .address(titulaire.getAdreFiscInfoRue())
                .city(titulaire.getAdreFiscNomCommune())
                .zipCode(titulaire.getAdreFiscCodp())
                .build();

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        return Subscriber.builder()
                .firstName(titulaire.getPrenom())
                .lastName(titulaire.getNom())
                .email(titulaire.getEmailPro())
                .birthday(fmt.format(titulaire.getTituNaisDate()))
                .phoneNumber(titulaire.getNumMobilePro())
                .type("PERSON")
                .address(ad)
                .build();
    }

    public Control makeControl(String login) {
        return Control.builder()
                .controlProfileId("c62ca746-c91f-4ac4-904a-b51f77a58fe3")
                .spaceId("99802e26-8e40-4b81-b655-020e99c54814")
                .subscriber(createSubscriber(login))
                .build();

    }
}
