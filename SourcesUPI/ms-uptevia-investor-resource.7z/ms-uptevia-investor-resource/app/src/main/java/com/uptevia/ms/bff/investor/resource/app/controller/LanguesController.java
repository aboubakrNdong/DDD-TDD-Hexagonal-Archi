package com.uptevia.ms.bff.investor.resource.app.controller;

import com.uptevia.ms.bff.investor.resource.api.LanguesApi;
import com.uptevia.ms.bff.investor.resource.api.model.LanguesJson;
import com.uptevia.ms.bff.investor.resource.app.mapper.LanguesJsonMapper;
import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.LanguesDTO;
import com.uptevia.ms.bff.investor.resource.domain.service.LanguesService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/api/v1")
public class LanguesController implements LanguesApi {

    Logger logger = Logger.getLogger(LanguesController.class.getName());

    private final LanguesService languesService;

    private static final String MESSAGE = "with the param : ";

    public LanguesController(final LanguesService languesService) {
        this.languesService = languesService;
    }

    /**
     * GET /langues
     * Affiche les Langues de communication de UPI
     *
     * @param codeLangue langues (optional)
     * @return langues trouvées pour ces parametres (status code 200)
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     * or langues non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */

    @Override
    public ResponseEntity<List<LanguesJson>> getLangues(String codeLangue) {

        List<LanguesDTO> languesDTO = null;

        try {
            languesDTO = languesService.getLangues(codeLangue);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(languesDTO.stream()
                .map(LanguesJsonMapper.INSTANCE::dtoToJson).toList(), HttpStatus.OK);

    }
}
