package com.uptevia.ms.bff.investor.resource.app.controller;

import com.uptevia.ms.bff.investor.resource.api.LogoApi;
import com.uptevia.ms.bff.investor.resource.api.model.LogoJson;
import com.uptevia.ms.bff.investor.resource.app.mapper.LogoJsonMapper;
import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.LogoDTO;
import com.uptevia.ms.bff.investor.resource.domain.service.LogoService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.logging.Logger;

@RestController
@RequestMapping("/api/v1")
public class LogoController implements LogoApi {

    Logger logger = Logger.getLogger(LogoController.class.getName());

    private final LogoService logoService;

    public LogoController(final LogoService logoService) {
        this.logoService = logoService;
    }


    /**
     * GET /logo/{emetIden}
     * get logo image, l&#39;url et le display (rediriger vers le site emetteur en cliquant le logo)
     *
     * @param emetIden Code emetteur (required)
     * @return Un logo a été trouvé pour ces parametres (status code 200)
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     * or Logo non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */
    @Override
    public ResponseEntity<LogoJson> getLogo(Integer emetIden) {
        LogoDTO logoDTO = null;
        try {
            logoDTO = logoService.getLogo(emetIden);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(
                LogoJsonMapper.INSTANCE.DtoToJson(
                        logoDTO
                ), HttpStatus.OK);


    }
}
