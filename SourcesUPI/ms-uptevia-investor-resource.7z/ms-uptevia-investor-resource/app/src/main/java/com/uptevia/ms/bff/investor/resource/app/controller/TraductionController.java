package com.uptevia.ms.bff.investor.resource.app.controller;

import com.uptevia.ms.bff.investor.resource.api.TraductionApi;
import com.uptevia.ms.bff.investor.resource.api.model.TraductionJson;
import com.uptevia.ms.bff.investor.resource.app.mapper.TraductionJsonMapper;
import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.TraductionDTO;
import com.uptevia.ms.bff.investor.resource.domain.service.TraductionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/api/v1")
public class TraductionController implements TraductionApi {

    Logger logger = Logger.getLogger(TraductionController.class.getName());

    private final TraductionService traductionService;

    public TraductionController(final TraductionService traductionService) {
        this.traductionService = traductionService;
    }


    /**
     * GET /traduction/{lang}/{themeId}
     * get langue traduction
     *
     * @param lang    langue (required)
     * @param themeId theme id (required)
     * @return une liste de clé et valeur ont été trouvé pour ces parametres (status code 200)
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     * or Logo non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */
    @Override
    public ResponseEntity<List<TraductionJson>> getLangue(String lang, Integer themeId) {


        List<TraductionDTO> traductions = null;
        try {
            traductions = traductionService.getTrads(lang, themeId);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(traductions
                        .stream()
                        .map(TraductionJsonMapper.INSTANCE::dtoToJson)
                        .toList(), HttpStatus.OK);

    }
}
