package com.uptevia.ms.bff.investor.resource.app.dto;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

@Getter
@Setter
@Builder
public class UserDTO {
    private String login;
    private String password;
    private String email;
    private OffsetDateTime dateAccess;
    private int nbAcces;
    private int nbEssais;
    private int nbTotalEssais;
    private OffsetDateTime dateValiditeDEB;
    private OffsetDateTime dateValiditeFin;
    private OffsetDateTime dateMajPsw;
    private boolean indiCompteBloque;
    private boolean indiPwdExpire;
    private boolean indiWillBePwdExpired;
    private String origine;
    private String passwordV1;
    private String sltPassword;

    private int idQuestionSecurite1;
    private String reponseQuestionSecurite1;
    private int idQuestionSecurite2;
    private String reponseQuestionSecurite2;
    private String token;

}
