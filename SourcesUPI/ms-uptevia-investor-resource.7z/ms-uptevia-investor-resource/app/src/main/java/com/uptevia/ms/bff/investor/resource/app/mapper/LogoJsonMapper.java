package com.uptevia.ms.bff.investor.resource.app.mapper;

import com.uptevia.ms.bff.investor.resource.api.model.LogoJson;
import com.uptevia.ms.bff.investor.resource.domain.model.LogoDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface LogoJsonMapper {

    LogoJsonMapper INSTANCE = Mappers.getMapper(LogoJsonMapper.class);
    LogoJson DtoToJson(LogoDTO logoDTO);

}
