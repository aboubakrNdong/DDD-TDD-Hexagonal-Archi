package com.uptevia.ms.bff.investor.resource.app.mapper;

import com.uptevia.ms.bff.investor.resource.api.model.ParametrageJson;
import com.uptevia.ms.bff.investor.resource.domain.model.ParametrageDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ParametrageJsonMapper {

    ParametrageJsonMapper INSTANCE = Mappers.getMapper(ParametrageJsonMapper.class);
    ParametrageJson dtoToJson(ParametrageDTO parametrageDTO);
}
