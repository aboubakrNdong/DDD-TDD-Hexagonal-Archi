package com.uptevia.ms.bff.investor.resource.app.security.jwt;



import com.uptevia.ms.bff.investor.resource.app.dto.UserDTO;
import com.uptevia.ms.bff.investor.resource.domain.util.Constants;
import io.jsonwebtoken.*;
import io.jsonwebtoken.Jwts;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class JwtUtils {

    @Value("${resource.app.jwtExpirationMs}")
    private int jwtExpirationMs;
    @Value("${resource.app.jwtSecret}")
    private String secretKey;

    private static final SignatureAlgorithm algorithm = SignatureAlgorithm.HS256;

    public String generateJwtToken(final UserDTO userDTO) {

        Map<String, Object> claims = new HashMap<>();
        claims.put("subject", userDTO.getLogin());

        //Build Token signed with HS256 signature
        String token = Jwts.builder()
                .claims(claims)
                .setSubject(userDTO.getLogin())
                .setIssuedAt(new Date())
                .setExpiration(new Date((new Date()).getTime() + jwtExpirationMs))
                .signWith(key(), algorithm)
                .compact();
        return token;
    }

    //generate secure key from java.security to sign jwt token
    private Key key() {
        return new SecretKeySpec(secretKey.getBytes(), algorithm.getJcaName());
    }

    //Extract subject as username  from JWT  token
    public String getUserNameFromJwtToken(final String token) {
        return Jwts.parser().setSigningKey(key()).build()
                .parseClaimsJws(token).getBody().getSubject();
    }

    public boolean validateJwtToken(final String authToken) {
        try {
            Jwts.parser().setSigningKey(key()).build().parse(authToken);
            return true;
        } catch (MalformedJwtException e) {
            log.error("Invalid JWT token: {}", e.getMessage());
        } catch (ExpiredJwtException e) {
            log.error("JWT token is expired: {}", e.getMessage());
        } catch (UnsupportedJwtException e) {
            log.error("JWT token is unsupported: {}", e.getMessage());
        } catch (IllegalArgumentException e) {
            log.error("JWT claims string is empty: {}", e.getMessage());
        }

        return false;
    }


    public String resolveToken(final HttpServletRequest req) {

        String bearerToken = req.getHeader(Constants.AUTHORIZATION);
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7, bearerToken.length());
        }
        if (bearerToken != null) {
            return bearerToken;
        }
        return null;
    }
}
