package com.uptevia.ms.bff.investor.resource.app.controller;


import com.uptevia.ms.bff.investor.resource.app.dto.UserDTO;
import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.ModuleDTO;
import com.uptevia.ms.bff.investor.resource.domain.service.ModuleService;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@ExtendWith(SpringExtension.class)
@WebMvcTest(value = ModuleController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
class ModuleControllerTest {

    private static String URL_GET_MODULE_LINKS = "/api/v1/modules";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ModuleService moduleService;


    private EasyRandom easyRandom = new EasyRandom();

    @Test
    void should_return_get_modules_ok() throws Exception {
        //Given
        List<ModuleDTO> modules = easyRandom.objects(ModuleDTO.class, 1)
                .collect(Collectors.toList());
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        // When
        Mockito.when(moduleService.getModule(99963514, 1, 1, "")).thenReturn(modules);

        //Then
        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_MODULE_LINKS)
                        .header("Authorization", "Bearer ", userDTO.getToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "1")
                        .queryParam("tituNume", "1")
                        .queryParam("typeCpte", "")
                        .characterEncoding("UTF-8"))
                .andExpect(jsonPath("$.*").isArray())
                .andExpect(jsonPath("$.[0].sousModule").exists());
    }

    @Test
    void should_return_get_modules_and_return_500() throws Exception {
        //Given
        ModuleDTO moduleDto = easyRandom.nextObject(ModuleDTO.class);
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        // When
        Mockito.when(moduleService.getModule(99963514, 1, 1, "")).thenThrow(NullPointerException.class);

        //Then
        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_MODULE_LINKS)
                        .header("Authorization", "Bearer ", userDTO.getToken())
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "1")
                        .queryParam("tituNume", "1")
                        .queryParam("typeCpte", "")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void should_return_get_modules_and_return_404() throws Exception {

        // When
        Mockito.when(moduleService.getModule(99963514, 1, 1, "")).thenThrow(new FunctionnalException("code", "message"));
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        //Then
        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_MODULE_LINKS)
                        .header("Authorization", "Bearer ", userDTO.getToken())
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "1")
                        .queryParam("tituNume", "1")
                        .queryParam("typeCpte", "")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());
    }

}
