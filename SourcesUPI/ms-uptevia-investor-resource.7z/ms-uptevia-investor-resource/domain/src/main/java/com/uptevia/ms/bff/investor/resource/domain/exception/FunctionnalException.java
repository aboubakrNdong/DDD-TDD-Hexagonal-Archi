package com.uptevia.ms.bff.investor.resource.domain.exception;

import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;
@Setter
@Getter
public class FunctionnalException extends Exception {

    private final String code;

    private final String message;

    private final Map<String, Object> contextParams = new HashMap<>();


    public FunctionnalException(String code, String message) {
        super(message);
        this.code = code;
        this.message = message;
    }

    public FunctionnalException(String code, String message, Map<String, Object> contextParams) {
        super(message);
        this.code = code;
        this.message = message;
        this.contextParams.putAll(contextParams);
    }
}
