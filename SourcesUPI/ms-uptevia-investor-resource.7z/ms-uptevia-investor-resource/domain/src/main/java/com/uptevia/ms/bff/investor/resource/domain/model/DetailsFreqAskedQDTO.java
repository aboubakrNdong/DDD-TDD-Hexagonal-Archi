package com.uptevia.ms.bff.investor.resource.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class DetailsFreqAskedQDTO {

    private String keyFaqCategory;

    private String logoNameFaqCategory;

    private String faqQuestionKey;

    private String faqAnswerKey;
}
