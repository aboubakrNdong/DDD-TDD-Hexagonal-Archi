package com.uptevia.ms.bff.investor.resource.domain.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class FaqsDTO {

    private String category;

    private String logoNameCategory;

    private List<DetailsFreqAskedQDTO> qresponses = null;

}
