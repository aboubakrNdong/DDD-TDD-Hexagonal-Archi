package com.uptevia.ms.bff.investor.resource.domain.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LogoDTO {

    private Integer idLogo;

    private Integer emetIden;

    private String type;

    private boolean display;

    private String url;

    private byte[] file;

    private String format;
}
