package com.uptevia.ms.bff.investor.resource.domain.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ModuleDTO {

    private String groupeNom;

    private String groupeUrl;

    private int groupeOrdre;
    private boolean showMenu;

    private String groupeImgName;


    private List<SousModuleDTO> sousModule = null;

}
