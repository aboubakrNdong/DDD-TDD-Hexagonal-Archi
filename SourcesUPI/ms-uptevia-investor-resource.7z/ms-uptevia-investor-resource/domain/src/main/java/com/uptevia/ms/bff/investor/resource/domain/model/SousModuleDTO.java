package com.uptevia.ms.bff.investor.resource.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;


@Getter
@Builder
@Setter

public class SousModuleDTO {

    private String moduleGroupeNom;

    private String moduleGroupeUrl;

    private int moduleGroupeOrdre;

    private String moduleGroupeImgName;

    private String moduleNom;

    private String moduleUrl;

    private int moduleOrdre;

    private String moduleImgName;

    private String moduleIndicateurMenu;

    private String moduleGroupeIndicateurMenu;

    private boolean habiliteEmet;
    private boolean habiliteActi;
    private List<String> motifsBlocage ;

}
