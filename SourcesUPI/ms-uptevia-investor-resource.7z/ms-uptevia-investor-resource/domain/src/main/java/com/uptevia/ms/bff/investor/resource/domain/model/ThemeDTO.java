package com.uptevia.ms.bff.investor.resource.domain.model;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
@Getter
@Setter
public class ThemeDTO implements Serializable {

    private int idTheme;

    private String libelle;

    private String path;

    private long loadOrder;

    private String url;
}
