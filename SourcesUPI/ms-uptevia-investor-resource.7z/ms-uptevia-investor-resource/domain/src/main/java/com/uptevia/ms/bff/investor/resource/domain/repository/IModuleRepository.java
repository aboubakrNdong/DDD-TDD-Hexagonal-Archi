package com.uptevia.ms.bff.investor.resource.domain.repository;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.SousModuleDTO;

import java.util.List;

public interface IModuleRepository {
    List<SousModuleDTO> getModule(final int idEmet, final int idActi, final int pTituNume, final String typeCpte) throws FunctionnalException;

}
