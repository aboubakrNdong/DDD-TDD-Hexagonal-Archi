package com.uptevia.ms.bff.investor.resource.domain.repository;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.TraductionDTO;

import java.util.List;

public interface ITraductionRepository {


    List<TraductionDTO> getAllTrads() throws FunctionnalException;
}
