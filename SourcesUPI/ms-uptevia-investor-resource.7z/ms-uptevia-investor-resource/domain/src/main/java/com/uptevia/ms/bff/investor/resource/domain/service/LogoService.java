package com.uptevia.ms.bff.investor.resource.domain.service;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.LogoDTO;

public interface LogoService {

    LogoDTO getLogo(final int idEmet) throws FunctionnalException;
}
