package com.uptevia.ms.bff.investor.resource.domain.service;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.TraductionDTO;

import java.util.List;

public interface TraductionService {

    public List<TraductionDTO> getTrads(String lang, Integer themeId) throws FunctionnalException;
}
