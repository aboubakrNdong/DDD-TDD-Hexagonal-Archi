package com.uptevia.ms.bff.investor.resource.domain.service.impl;


public abstract class AbstractService {
    /**
     * method to convert "O" or "o" is True
     * @param string
     * @return
     */
    public static boolean toBooleanStrict(String string) {
        if (string.equalsIgnoreCase("o")) {
            return true;
        } else  {
            return false;
        }
    }

}
