package com.uptevia.ms.bff.investor.resource.domain.service.impl;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.DetailsFreqAskedQDTO;
import com.uptevia.ms.bff.investor.resource.domain.model.FaqsDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.IFaqsRepository;
import com.uptevia.ms.bff.investor.resource.domain.service.FaqService;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.List;

public class FaqServiceImpl implements FaqService {

    private final IFaqsRepository iFaqsRepository;

    public FaqServiceImpl(final IFaqsRepository iFaqsRepository) {
        this.iFaqsRepository = iFaqsRepository;
    }

    @Override
    public List<FaqsDTO> getFaqs(String piLoggedFaq) throws FunctionnalException {

        List<FaqsDTO> faqsDTOs = new ArrayList<>();
        List<DetailsFreqAskedQDTO> result = iFaqsRepository.getFaqs(piLoggedFaq);

        for(DetailsFreqAskedQDTO detailsFreqAskedQDTO : result) {
            FaqsDTO object = new FaqsDTO();
            object.setCategory(detailsFreqAskedQDTO.getKeyFaqCategory());
            object.setLogoNameCategory(detailsFreqAskedQDTO.getLogoNameFaqCategory());
            object.setQresponses(addOjects(result, detailsFreqAskedQDTO.getKeyFaqCategory()));
            faqsDTOs.add(object);
        }
        //Delete duplicate elements in our list faqsDtos
        return faqsDTOs.stream().filter(distinctByKey(FaqsDTO::getCategory)).toList();
    }

    private List<DetailsFreqAskedQDTO> addOjects(final List<DetailsFreqAskedQDTO> source, final String criterea) {
        List<DetailsFreqAskedQDTO> result = new ArrayList<>();
        for (int i = 0; i<source.size(); i++) {
            if(criterea.equals(source.get(i).getKeyFaqCategory())) {
                result.add(source.get(i));
            }
        }
        return result;
    }

    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }
}