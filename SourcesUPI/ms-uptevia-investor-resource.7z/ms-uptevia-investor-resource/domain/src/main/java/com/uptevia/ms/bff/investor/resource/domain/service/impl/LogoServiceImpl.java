package com.uptevia.ms.bff.investor.resource.domain.service.impl;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.LogoDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.ILogoRepository;
import com.uptevia.ms.bff.investor.resource.domain.service.LogoService;

public class LogoServiceImpl implements LogoService {

    private final ILogoRepository logoRepository;

    public LogoServiceImpl(final ILogoRepository logoRepository) {
        this.logoRepository = logoRepository;
    }

    @Override
    public LogoDTO getLogo(int idEmet) throws FunctionnalException {
        return logoRepository.getLogo(idEmet);
    }
}
