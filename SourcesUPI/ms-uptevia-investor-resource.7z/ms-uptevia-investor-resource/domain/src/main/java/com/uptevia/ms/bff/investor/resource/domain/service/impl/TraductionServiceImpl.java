package com.uptevia.ms.bff.investor.resource.domain.service.impl;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.TraductionDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.ITraductionRepository;
import com.uptevia.ms.bff.investor.resource.domain.service.TraductionService;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

public class TraductionServiceImpl implements TraductionService {

    private final ITraductionRepository traductionRepository;

    public TraductionServiceImpl(final ITraductionRepository traductionRepository) {
        this.traductionRepository = traductionRepository;
    }

    @Override
    public List<TraductionDTO> getTrads(String lang, Integer themeId) throws FunctionnalException {

        return traductionRepository.getAllTrads()
                .stream()
                .filter(traductionDTO ->
                    StringUtils.equalsIgnoreCase(traductionDTO.getCodeLangue(), lang) &&
                            traductionDTO.getThemeId() == themeId
                ).toList();
    }
}
