package com.uptevia.ms.bff.investor.resource.domain.service.impl;

import com.uptevia.ms.bff.investor.resource.domain.model.LogoDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.ILogoRepository;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.logging.Logger;

@ExtendWith(MockitoExtension.class)
public class LogoServiceImplTest {

    Logger logger = Logger.getLogger(LogoServiceImplTest.class.getName());

    @Mock
    private ILogoRepository logoRepository;

    @InjectMocks
    LogoServiceImpl logoService;

    private EasyRandom easyRandom = new EasyRandom();


    @Test
    void should_return_get_logo_ok() throws Exception {

        LogoDTO logoDTO = easyRandom.nextObject(LogoDTO.class);

        Mockito.when(logoRepository.getLogo(99963514)).thenReturn(logoDTO);

        Assertions.assertThat(logoService.getLogo(99963514).getEmetIden()).isEqualTo(logoDTO.getEmetIden());

    }
}
