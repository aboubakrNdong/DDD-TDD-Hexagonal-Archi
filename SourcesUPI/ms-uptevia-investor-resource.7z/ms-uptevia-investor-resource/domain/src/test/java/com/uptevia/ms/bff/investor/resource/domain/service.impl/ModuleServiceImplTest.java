package com.uptevia.ms.bff.investor.resource.domain.service.impl;

import com.uptevia.ms.bff.investor.resource.domain.model.SousModuleDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.IModuleRepository;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.stream.Collectors;

@ExtendWith(MockitoExtension.class)
class ModuleServiceImplTest {


    @Mock
    private IModuleRepository moduleRepository;
    @InjectMocks
    ModuleServiceImpl moduleService;
    private final EasyRandom easyRandom = new EasyRandom();
    @Test
    void should_return_menu_ok() throws Exception {

        int idEmet = 99963514;
        int idActi = 1;
        int pTituNume = 1;
        String typeCpte = "PP";

        List<SousModuleDTO> allSousModuleDto = easyRandom.objects(SousModuleDTO.class,5)
                .collect(Collectors.toList());

        allSousModuleDto.forEach(e -> {
            e.setModuleGroupeNom("PORTEFEUILLE");
            e.setModuleNom("TITRES");
        });

        Mockito.when(moduleRepository.getModule(idEmet, idActi, pTituNume, typeCpte)).thenReturn(allSousModuleDto);

        Assertions.assertThat(moduleService.getModule(idEmet, idActi, pTituNume, typeCpte).size()).isEqualTo(1);
    }

    @Test
    void should_return_dashboard_ok() throws Exception {

        int idEmet = 99963514;
        int idActi = 1;
        int pTituNume = 1;
        String typeCpte = "PP";

        List<SousModuleDTO> allSousModuleDto = easyRandom.objects(SousModuleDTO.class,3)
                .collect(Collectors.toList());

        allSousModuleDto.forEach(e -> {
            e.setModuleGroupeNom("DASHBOARD");
            e.setModuleGroupeOrdre(1);
        });

        Mockito.when(moduleRepository.getModule(idEmet, idActi, pTituNume, typeCpte)).thenReturn(allSousModuleDto);

        Assertions.assertThat(moduleService.getModule(idEmet, idActi, pTituNume, typeCpte).size()).isEqualTo(1);
    }
}

