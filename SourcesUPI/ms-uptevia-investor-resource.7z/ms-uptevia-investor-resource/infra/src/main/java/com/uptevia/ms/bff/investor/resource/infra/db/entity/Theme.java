package com.uptevia.ms.bff.investor.resource.infra.db.entity;

import java.io.Serializable;

import javax.persistence.*;


/**
 * Entity implementation class for Entity: Theme
 *
 */
@NamedStoredProcedureQueries({
		@NamedStoredProcedureQuery(
				name = Theme.NamedQuery_PS_SEL_THEME,
				procedureName = "PS_SEL_THEME_LI",
				resultClasses = Theme.class,
				parameters = {
						@StoredProcedureParameter(
								type = String.class,
								mode = ParameterMode.IN
						),
						@StoredProcedureParameter(
								type = void.class,
								mode = ParameterMode.REF_CURSOR
						)
				}
		)
})
@Entity
@Table(name="THEME", schema="ORAOAEC01")
public class Theme implements Serializable {
	
	private static final long serialVersionUID = 3015621713020992780L;

	public static final String NamedQuery_PS_SEL_THEME  = "fetchFromTheme";

	@Id
	@Column(name="ID_THEME")
	private int idTheme;

	@Column(name="LIBELLE")
	private String libelle;

	@Column(name="PATH")
	private String path;
	
	@Column(name="LOAD_ORDER")
	private long loadOrder;

	@Column(name="URL")
	private String url;
	
	public Theme() {
	}

	public int getIdTheme() {
		return idTheme;
	}

	public void setIdTheme(int idTheme) {
		this.idTheme = idTheme;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public long getLoadOrder() {
		return loadOrder;
	}

	public void setLoadOrder(long loadOrder) {
		this.loadOrder = loadOrder;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
