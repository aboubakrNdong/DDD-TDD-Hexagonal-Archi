package com.uptevia.ms.bff.investor.resource.infra.mapper;

import com.uptevia.ms.bff.investor.resource.domain.model.DetailsFreqAskedQDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class FaqDetailsRowMapper implements RowMapper<DetailsFreqAskedQDTO> {
    @Override
    public DetailsFreqAskedQDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        return DetailsFreqAskedQDTO.builder()
                .faqQuestionKey(rs.getString("faq_question_key"))
                .faqAnswerKey(rs.getString("faq_answer_key"))
                .keyFaqCategory(rs.getString("key_faq_category"))
                .logoNameFaqCategory(rs.getString("logo_name_faq_category"))
                .build();
    }
}
