package com.uptevia.ms.bff.investor.resource.infra.mapper;

import com.uptevia.ms.bff.investor.resource.domain.model.LanguesDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;


public class LanguesRowMapper implements RowMapper<LanguesDTO> {

    @Override
    public LanguesDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        return LanguesDTO.builder()
                .paysIden(rs.getString("PAYS_IDEN"))
                .paysIso2(rs.getString("PAYS_ISO2"))
                .build();
    }
}
