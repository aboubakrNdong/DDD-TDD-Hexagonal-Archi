package com.uptevia.ms.bff.investor.resource.infra.mapper;

import com.uptevia.ms.bff.investor.resource.domain.model.LogoDTO;

import org.springframework.jdbc.core.RowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.commons.lang3.StringUtils;

public class LogoRowMapper implements RowMapper<LogoDTO> {

    @Override
    public LogoDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        LogoDTO logoDTO = new LogoDTO();

        logoDTO.setIdLogo(rs.getInt("LOGO_ID"));
        logoDTO.setEmetIden(rs.getInt("EMET_IDEN"));
        logoDTO.setType(rs.getString("LOGO_TYPE"));
        logoDTO.setFormat(rs.getString("LOGO_FORMAT"));
        logoDTO.setFile(rs.getBytes("LOGO_FILE"));
        logoDTO.setDisplay(StringUtils.endsWithIgnoreCase(rs.getString("LOGO_DISPLAY"), "1"));
        logoDTO.setUrl(rs.getString("LIEN_SITE_CLE"));

        return logoDTO;
    }
}
