package com.uptevia.ms.bff.investor.resource.infra.mapper;

import com.uptevia.ms.bff.investor.resource.domain.model.ParametrageDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ParametrageRowMapper implements RowMapper<ParametrageDTO> {
    @Override
    public ParametrageDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        List<String> paramValue = new ArrayList<>();
        ParametrageDTO result = new ParametrageDTO();
        String[] splited = rs.getString("PARAM_VALUE").split(";");
        for(String s : splited){
            paramValue.add(s);
        }
        result.setEmetIden(Integer.valueOf(rs.getString("EMET_IDEN")));
        result.setParamValue(paramValue);
        result.setParamName(rs.getString("PARAM_NAME"));
        return result;
    }
}
