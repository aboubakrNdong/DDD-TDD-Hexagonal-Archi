package com.uptevia.ms.bff.investor.resource.infra.repositories;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.LanguesDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.ILanguesRepository;
import com.uptevia.ms.bff.investor.resource.domain.util.Constants;
import com.uptevia.ms.bff.investor.resource.infra.mapper.LanguesRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class LanguesRepository implements ILanguesRepository {

    private static final String PS_CUR = "PS_CUR";


    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;


    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public List<LanguesDTO> getLangues(String codeLangue) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constants.SITE_GET_LANGUES)
                .returningResultSet(PS_CUR,
                        new LanguesRowMapper());

        SqlParameterSource in = new MapSqlParameterSource();
        Map<String, Object> out = jdbcCall.execute(in);

        List<LanguesDTO> result = (List<LanguesDTO>) out.get(PS_CUR);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return result;
    }
}
