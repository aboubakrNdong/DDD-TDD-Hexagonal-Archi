package com.uptevia.ms.bff.investor.resource.infra.repositories;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.LogoDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.ILogoRepository;
import com.uptevia.ms.bff.investor.resource.domain.util.Constants;
import com.uptevia.ms.bff.investor.resource.infra.mapper.LogoRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

@Repository
public class LogoRepository implements ILogoRepository {


    public static final String ID_EMET = "idEmet";

    Logger logger = Logger.getLogger(LogoRepository.class.getName());
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    @Cacheable("logos")
    public LogoDTO getLogo(int idEmet) throws FunctionnalException {

        logger.log(Level.INFO, "Beginning get logo with identifier ");


        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("UPI_EMET_GET_CONFIG")
                .returningResultSet("PS_CUR",
                        new LogoRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(ID_EMET, idEmet);


        Map<String, Object> out = jdbcCall.execute(in);

        List<LogoDTO> result = (List<LogoDTO>) out.get("PS_CUR");

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put(ID_EMET, idEmet);
            throw new FunctionnalException(Constants.LOGIN_TEXT_BAD_CREDENTIALS, Constants.LOGIN_TEXT_BAD_CREDENTIALS, contextParams);
        }

        if (result.size() > 1) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put(ID_EMET, idEmet);
            throw new FunctionnalException("MDX", "Multi_Data_Exception", contextParams);
        }

        return result.get(0);

    }
}
