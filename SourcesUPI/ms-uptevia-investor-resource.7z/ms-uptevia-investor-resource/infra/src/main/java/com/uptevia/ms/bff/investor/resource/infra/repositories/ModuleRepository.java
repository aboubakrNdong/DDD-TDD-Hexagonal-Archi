package com.uptevia.ms.bff.investor.resource.infra.repositories;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.SousModuleDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.IModuleRepository;
import com.uptevia.ms.bff.investor.resource.infra.mapper.SousModuleRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Repository
public class ModuleRepository implements IModuleRepository {

    Logger logger = Logger.getLogger(ModuleRepository.class.getName());


    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;


    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public List<SousModuleDTO> getModule(int idEmet, int idActi, int pTituNume, String typeCpte) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("TITU_GET_MODULES")
                .returningResultSet("PS_CUR",
                        new SousModuleRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_EMET_IDEN", idEmet)
                .addValue("PARAM_ACTI_IDEN", idActi)
                .addValue("PARAM_TITU_NUME", pTituNume)
                .addValue("PARAM_TYPE_CPTE", typeCpte);


        Map<String, Object> out = jdbcCall.execute(in);

        List<SousModuleDTO> result = (List<SousModuleDTO>) out.get("PS_CUR");

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("PARAM_EMET_IDEN", idEmet);
            contextParams.put("PARAM_ACTI_IDEN", idActi);
            contextParams.put("PARAM_TITU_NUME", pTituNume);
            contextParams.put("PARAM_TYPE_CPTE", typeCpte);
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }
        return result;
    }
}
