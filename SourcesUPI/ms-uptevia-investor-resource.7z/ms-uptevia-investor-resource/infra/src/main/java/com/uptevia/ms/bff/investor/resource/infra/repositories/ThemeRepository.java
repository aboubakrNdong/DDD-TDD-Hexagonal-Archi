package com.uptevia.ms.bff.investor.resource.infra.repositories;

import com.uptevia.ms.bff.investor.resource.domain.model.ThemeDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.IThemeRepository;
import com.uptevia.ms.bff.investor.resource.infra.db.dao.ThemeDao;
import com.uptevia.ms.bff.investor.resource.infra.mapper.ThemeDTOMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class ThemeRepository implements IThemeRepository {

    private ThemeDao themeDao;


    public ThemeRepository(final ThemeDao themeDao) {

    }

        @Override
    public List<ThemeDTO> findThemes() {
        return themeDao.findAll().stream()
                .map(ThemeDTOMapper.INSTANCE::themeToThemeDTO)
                .toList();
    }
}
