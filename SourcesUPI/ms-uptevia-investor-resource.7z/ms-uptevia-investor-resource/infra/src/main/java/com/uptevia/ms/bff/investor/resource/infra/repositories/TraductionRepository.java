package com.uptevia.ms.bff.investor.resource.infra.repositories;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.TraductionDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.ITraductionRepository;
import com.uptevia.ms.bff.investor.resource.infra.mapper.TraductionRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

@Repository
public class TraductionRepository implements ITraductionRepository {

    public static final String NAME_OF_PROC_TRADUCTION = "UPI_SITE_GET_TRADUCTION";

    Logger logger = Logger.getLogger(TraductionRepository.class.getName());
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${jdbc.fetch.size.traduction}")
    private int fetchSize;

    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }
    @Override
    @Cacheable("traductions")
    public List<TraductionDTO> getAllTrads() throws FunctionnalException {

        logger.log(Level.INFO, "Beginning get AllTrads with fetch size {0}", jdbcTemplate.getFetchSize());

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(NAME_OF_PROC_TRADUCTION)
                .returningResultSet("PS_CUR",
                new TraductionRowMapper());


        Map<String, Object> out = jdbcCall.execute();

        List<TraductionDTO> result = (List<TraductionDTO>) out.get("PS_CUR");

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        logger.log(Level.INFO, "END get AllTrads");

        return result;

    }
}
