package com.uptevia.ms.bff.investor.resource.infra.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.uptevia.ms.bff.investor.resource.infra.repositories"})
public class RepoTestConfiguration {
}
