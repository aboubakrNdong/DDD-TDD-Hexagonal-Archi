package com.uptevia.ms.bff.investor.auth.app.controller;


import com.uptevia.ms.bff.investor.auth.api.AccountApi;
import com.uptevia.ms.bff.investor.auth.api.model.DetailConnexionJson;
import com.uptevia.ms.bff.investor.auth.api.model.ResultStatusJson;
import com.uptevia.ms.bff.investor.auth.app.enums.EnumStatus;
import com.uptevia.ms.bff.investor.auth.app.exception.CustomResponseStatusException;
import com.uptevia.ms.bff.investor.auth.app.mapper.DetailConnexionMapper;
import com.uptevia.ms.bff.investor.auth.app.mapper.ResultStatusMapper;
import com.uptevia.ms.bff.investor.auth.domain.utils.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.DetailConnexionDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.ResultStatusDTO;
import com.uptevia.ms.bff.investor.auth.domain.service.UpdatePasswordService;
import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;


@RestController
@RequestMapping("/api/v1")
@Slf4j
public class AccountController implements AccountApi {
    private final UpdatePasswordService updatePasswordService;

    @Autowired
    private JwtUtils jwtUtils;

    public AccountController(final UpdatePasswordService updatePasswordService) {
        this.updatePasswordService = updatePasswordService;
    }


    /**
     * @param detailConnexionJson       login details related to user want to change password (required)
     * @return password changed successfully (status code 200)
     * or Bad request. Password not changed (status code 400)
     * or User not authorized, incorrect JWT token (status code 401)
     * or Access error to query or to database (status code 500)
     */

    @Override
    public ResponseEntity<ResultStatusJson> updatePassword(final DetailConnexionJson detailConnexionJson) {
        ResultStatusDTO resultStatusDTO = new ResultStatusDTO();
        DetailConnexionDTO detailConnexionDTO = DetailConnexionMapper.INSTANCE.jsonToDto(detailConnexionJson);
        try {
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));
            detailConnexionDTO.setLogin(claims.getSubject());
            updatePasswordService.updatePassword(detailConnexionDTO);
            resultStatusDTO.setStatus(EnumStatus.STATUS_OK.getStatus());
        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ex.getCode(), ex.getContextParams());
        }

        return new ResponseEntity<>(ResultStatusMapper.INSTANCE.DtoToJson(resultStatusDTO), HttpStatus.OK);
    }


}
