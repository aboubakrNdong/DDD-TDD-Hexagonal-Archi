package com.uptevia.ms.bff.investor.auth.app.controller;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.uptevia.ms.bff.investor.auth.api.AuthenticateApi;
import com.uptevia.ms.bff.investor.auth.api.model.EabonnementJson;
import com.uptevia.ms.bff.investor.auth.api.model.LogOutRequestJson;
import com.uptevia.ms.bff.investor.auth.api.model.LoginRequestJson;
import com.uptevia.ms.bff.investor.auth.api.model.PlanetShareRequestJson;
import com.uptevia.ms.bff.investor.auth.api.model.ResultStatusJson;
import com.uptevia.ms.bff.investor.auth.api.model.SsoUrlJson;
import com.uptevia.ms.bff.investor.auth.api.model.UserJson;
import com.uptevia.ms.bff.investor.auth.api.model.UserPlanetShareJson;
import com.uptevia.ms.bff.investor.auth.app.exception.CustomResponseStatusException;
import com.uptevia.ms.bff.investor.auth.app.mapper.EabonnementMapper;
import com.uptevia.ms.bff.investor.auth.app.mapper.LogOutRequestMapper;
import com.uptevia.ms.bff.investor.auth.app.mapper.LoginRequestMapper;
import com.uptevia.ms.bff.investor.auth.app.mapper.PlanetShareRequestMapper;
import com.uptevia.ms.bff.investor.auth.app.mapper.ResultStatusMapper;
import com.uptevia.ms.bff.investor.auth.app.mapper.SsoUrlDTOMapper;
import com.uptevia.ms.bff.investor.auth.app.mapper.UserJsonMapper;
import com.uptevia.ms.bff.investor.auth.app.mapper.UserPlanetShareJsonMapper;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.EabonnementDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.LogOutRequestDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.LoginRequestDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.PlanetShareRequestDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.ResultStatusDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.SsoInfoDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.SsoUrlDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserPlanetShareDTO;
import com.uptevia.ms.bff.investor.auth.domain.service.AuthService;
import com.uptevia.ms.bff.investor.auth.domain.service.SsoService;
import com.uptevia.ms.bff.investor.auth.domain.service.UtilsService;
import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;
import com.uptevia.ms.bff.investor.auth.domain.util.ToolsManager;
import com.uptevia.ms.bff.investor.auth.domain.utils.jwt.JwtUtils;

import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;


@RestController
@RequestMapping("/api/v1")
@Slf4j
public class AuthController implements AuthenticateApi {


    private static final String AUTHORIZATION = "Authorization";
    @Autowired
    JwtUtils jwtUtils;

    private final AuthService authService;
    private final SsoService ssoService;
    private final UtilsService utilsService;

    private final static long LOGOUT_TIMEOUT = 185L;

    public AuthController(final AuthService authService, final SsoService ssoService, final UtilsService utilsService) {
        this.authService = authService;
        this.ssoService = ssoService;
        this.utilsService = utilsService;
    }


    private static final String MESSAGE = "with the param : ";


    /**
     * GET /authenticate
     * Recherche si actionnaire existe dans la table Acti
     *
     * @param loginRequestJson login (required)
     * @return Un actionnaire a été trouvé pour ces parametres (status code 200)
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     * or Actionnaire non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */

    @Override
    public ResponseEntity<ResultStatusJson> authenticate(final LoginRequestJson loginRequestJson) {

        ResultStatusDTO resultStatusDTO;
        try {
            LoginRequestDTO loginRequest = LoginRequestMapper.INSTANCE.jsonToDto(loginRequestJson);
            resultStatusDTO = authService.authenticate(loginRequest);
        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, ex.getCode(), ex.getContextParams());
        }

        return new ResponseEntity<>(ResultStatusMapper.INSTANCE.DtoToJson(resultStatusDTO), HttpStatus.OK);
    }



    @Override
    public ResponseEntity<UserJson> validateOtpCode(String otpCode, String X_UPI_AUTH) {

        UserDTO userDTO = null;
        Map<String, Object> contextParams = new HashMap<>();
        try {
            String encrytedLogin = X_UPI_AUTH.trim();

            String decryptedLogin = ToolsManager.decryptFromFront(encrytedLogin);
            if (decryptedLogin == null) {
                contextParams.put("login ", encrytedLogin);
                throw new FunctionnalException("DECRYPTION_ERROR", "DECRYPTION_ERROR", contextParams);
            }

            userDTO = authService.validateOtpCode(decryptedLogin, otpCode);

            if (Objects.isNull(userDTO) || userDTO.getError() == null) {
                contextParams.put("login ", encrytedLogin);
                throw new FunctionnalException("INVALID_PARAMS_ERROR", "INVALID_PARAMS_ERROR", contextParams);
            }

            // Généger et ratacher le token au user ici uniquement si getError == OK
            if(userDTO.getError().equalsIgnoreCase("OK")){
                userDTO.setToken(jwtUtils.generateJwtToken(userDTO));
            }

        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, ex.getCode(), ex.getContextParams());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return ResponseEntity.ok().body(UserJsonMapper.INSTANCE.DtoToJson(userDTO));
    }


    @Override
    public ResponseEntity<List<UserJson>> ancientOlisAccount(final LoginRequestJson loginRequestJson) {
        List<UserDTO> userDTOs = null;
        LoginRequestDTO loginRequestDTO = LoginRequestMapper.INSTANCE.jsonToDto(loginRequestJson);
        try {
            userDTOs = authService.ancientOlisAccount(loginRequestDTO);

        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, ex.getCode(), ex.getContextParams());
        }

        return new ResponseEntity<>(userDTOs.stream()
                .map(UserJsonMapper.INSTANCE::DtoToJson).toList(), HttpStatus.OK);
    }

    /**
     * @param planetShareRequestJson Emitter code (required)
     * @return list des anciens user planetshare
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Actionnaire non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     * @author FBOUCHNAK
     */
    @Override
    public ResponseEntity<List<UserPlanetShareJson>> ancientPlanetShare(final PlanetShareRequestJson planetShareRequestJson) {

        List<UserPlanetShareDTO> userPlanetShareDTOS = new ArrayList<>();
        PlanetShareRequestDTO planetShareRequestDTO = PlanetShareRequestMapper.INSTANCE.jsonToDto(planetShareRequestJson);
        try {
            userPlanetShareDTOS = authService.ancientPlanetShare(planetShareRequestDTO.getEmetIden(),
                    planetShareRequestDTO.getAccessCode(), planetShareRequestDTO.getPassword());
            // verify status onBoarding


        } catch (final FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, ex.getCode(), ex.getContextParams());
        }
        return new ResponseEntity<>(userPlanetShareDTOS.stream()
                .map(UserPlanetShareJsonMapper.INSTANCE::DtoToJson).toList(), HttpStatus.OK);
    }


    /**
     * @param eabonnementJson (optional)
     * @return void
     * @author FBOUCHNAK
     */
    @Override
    public ResponseEntity<Void> acceptCgu(final EabonnementJson eabonnementJson) {

        EabonnementDTO eabonnementDTO = EabonnementMapper.INSTANCE.jsonToDto(eabonnementJson);
        try {
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));
            eabonnementDTO.setLogin(claims.getSubject());
            eabonnementDTO.setEmetIden(claims.get("emetIden").toString());
            eabonnementDTO.setActiIden(claims.get("actiIden").toString());
            eabonnementDTO.setTituNume(Integer.valueOf(claims.get("titunume").toString()));
            authService.acceptCgu(eabonnementDTO);
        } catch (final FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ex.getCode(), ex.getContextParams());
        }
        return new ResponseEntity<>(HttpStatus.CREATED);
    }


    @Override
    public ResponseEntity<List<LogOutRequestJson>> updateLoggedOutUsers() {
        List<LogOutRequestDTO> result = this.updateLoggedOutUsers(LOGOUT_TIMEOUT);
        return new ResponseEntity<>(result.stream()
                .map(LogOutRequestMapper.LOG_OUT_REQUEST_MAPPER::dtoTojson).toList(), HttpStatus.OK);
    }

    protected List<LogOutRequestDTO> updateLoggedOutUsers(final long timeout) {

        final List<LogOutRequestDTO> revokedTokens = new ArrayList<>(this.authService.findAllRevokedTokens());

        System.out.println(revokedTokens.size());
        return revokedTokens.stream()
                .filter(myRevokedToken -> myRevokedToken.getRevokeDate() != null
                        && !myRevokedToken.getValidityEndDate().isBefore(OffsetDateTime.now()))
                .toList();
    }

    @Override
    public ResponseEntity<SsoUrlJson> generateUrlSso(@NotNull @Valid String idOperateur,
            @NotNull @Valid String loginActionnaire) {
        log.info("Begin genenrateUrlSso");
        try {
            if(utilsService.isLoginUpiNotExist(loginActionnaire)){
                throw new FunctionnalException(HttpStatus.NOT_FOUND.toString(), "User not found");
            }
            SsoUrlDTO ssoUrlDTO = ssoService.generateSsoUrlDTO(idOperateur, loginActionnaire);
            SsoUrlJson result = SsoUrlDTOMapper.INSTANCE.DtoToJson(ssoUrlDTO);
            return ResponseEntity.ok().body(result);
        } catch (FunctionnalException e) {
            log.error(e.getMessage(), e);
            System.out.println(e.getMessage());
            e.printStackTrace();
            throw new CustomResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e.getContextParams());
        } finally {
            log.info("End genenrateUrlSso success");
        }
    }

    @Override
    public ResponseEntity<UserJson> setupSso(@NotNull @Valid String token) {
        log.info("Begin setupSso");
        try {
            String login = jwtUtils.getUserNameFromJwtToken(token);
            if(utilsService.isLoginUpiNotExist(login)){
                throw new FunctionnalException(HttpStatus.NOT_FOUND.toString(), "User not found");
            }
            UserDTO userDTO = ssoService.getInfosForSsoConnection(login);
            userDTO.setSso(true);
            userDTO.setToken(token);
            UserJson json = UserJsonMapper.INSTANCE.DtoToJson(userDTO);
            return ResponseEntity.ok().body(json);
        } catch (FunctionnalException e) {
            log.error(e.getMessage(), e);
            throw new CustomResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage(), e.getContextParams());
        } finally {
            log.info("End setupSso");
        }
    }

}
