package com.uptevia.ms.bff.investor.auth.app.controller;


import com.uptevia.ms.bff.investor.auth.api.ForgotApi;
import com.uptevia.ms.bff.investor.auth.api.model.NewIdentifiantJson;
import com.uptevia.ms.bff.investor.auth.api.model.UserLightJson;
import com.uptevia.ms.bff.investor.auth.api.model.UserVerifiedJson;
import com.uptevia.ms.bff.investor.auth.app.exception.CustomResponseStatusException;
import com.uptevia.ms.bff.investor.auth.app.mapper.*;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.service.ForgotIdentifiantService;
import com.uptevia.ms.bff.investor.auth.domain.util.ToolsManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/v1")
@Slf4j
public class ForgotController implements ForgotApi {


    private final ForgotIdentifiantService forgotIdentifiantService;

    public ForgotController(ForgotIdentifiantService forgotIdentifiantService) {
        this.forgotIdentifiantService = forgotIdentifiantService;
    }


    @Override
    public ResponseEntity<Boolean> sendResetToken(String login, String buttonChoice, String lang) {

        try {
            String l = lang == null ? "fr" : lang;
            forgotIdentifiantService.sendTokenByEmail(login, buttonChoice, l);
        } catch (FunctionnalException ex) {
            //Ne pas throw l'exception dans la réponse pour ne pas donner d'indication mais le mettre dans un future système de log
            System.out.println("FunctionnalException = " + ex.getCode() + "--" + ex.getContextParams());
        }
        return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
    }



    /**
     * POST /forgot/forgot-identifiant
     * Renvoyer l&#39;identifiant d&#39;un actionnaire en cas d&#39;oubli de sa part
     *
     * @param newIdentifiantJson (optional)
     * @return les données saisies matchent bien avec l&#39;identifiant utilisé (status code 200)
     * or Identifiant non trouvé pour ces données (status code 404)
     */

    @Override
    public ResponseEntity<UserVerifiedJson> verifyIdentifiant(NewIdentifiantJson newIdentifiantJson) {


        UserVerifiedDTO userVerified;
        NewIdentifiantDTO newIdentifiantDTO = ForgotMapper.instance.jsonToDto(newIdentifiantJson);

        try {
            userVerified = forgotIdentifiantService.verifyIdentifiant(newIdentifiantDTO);
        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.NOT_FOUND, ex.getCode(), ex.getContextParams());
        }

        return ResponseEntity.ok().body(UserVerifiedJsonMapper.INSTANCE.dtoToJson(userVerified));

    }



    /**
     * @param sd La chaine cryptee (required)
     * @return
     */
    @Override
    public ResponseEntity<UserLightJson> verifyToken(String sd) {


        UserDTO userDTO;
        try {
            userDTO = forgotIdentifiantService.verifyResetToken(sd);
        } catch (Exception e) {

            throw new RuntimeException(e);
        }

        //TODO: A refacto
        if(ObjectUtils.isEmpty(userDTO)){
            return new ResponseEntity<>(new UserLightJson().email(null).login(null).error("connexion.token.msg.generic"), HttpStatus.OK);
        }

        if(!ToolsManager.isDateOneDayAhead(userDTO.getDateMajPsw())){
            return new ResponseEntity<>(new UserLightJson().email(null).login(null).error("login.error.maj.psw.24h"), HttpStatus.OK);
        }else{
            return new ResponseEntity<>(new UserLightJson().email(userDTO.getEmail()).login(userDTO.getLogin()).error(null), HttpStatus.OK);

        }
    }


}
