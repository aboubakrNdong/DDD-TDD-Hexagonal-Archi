package com.uptevia.ms.bff.investor.auth.app.controller;

import com.uptevia.ms.bff.investor.auth.api.LogoutApi;
import com.uptevia.ms.bff.investor.auth.api.model.LogOutPayloadJson;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.LogOutRequestDTO;
import com.uptevia.ms.bff.investor.auth.domain.service.AuthService;
import com.uptevia.ms.bff.investor.auth.domain.utils.jwt.JwtUtils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.*;


@RestController
@RequestMapping("/api/v1")
@Slf4j
public class LogoutController implements LogoutApi {

    @Autowired
    private JwtUtils jwtUtils;

    private final AuthService authService;

    public LogoutController(AuthService authService) {
        this.authService = authService;
    }

    /**
     * This api is for log out the current authenticated user
     * and blacklist the JWT token to be not usable
     * @param LogOutPayloadJson  (optional)
     * @return
     */
    @Override
    public ResponseEntity<Boolean> logout(final LogOutPayloadJson logOutRequestJson) {

        log.info("begin logging out from session ...");
        boolean logout = false;
        try {
            if (jwtUtils.validateJwtToken(logOutRequestJson.getToken())){
                final LogOutRequestDTO logOutRequestDTO = this.handleRequest(logOutRequestJson.getToken());
                logout = authService.logout(logOutRequestDTO);
            }
        } catch (FunctionnalException ex) {
            log.error("Exception occurred while revoking token : {}", ex.getMessage());
        }

        return new ResponseEntity<>(logout, HttpStatus.OK);
    }

    private LogOutRequestDTO handleRequest(final String token) {
        ZoneOffset zoneOffset = OffsetDateTime.now().getOffset();
        return LogOutRequestDTO.builder()
                .validityEndDate(jwtUtils.getTokenExpiryFromJWT(token).toInstant().atOffset(zoneOffset))
                .token(token)
                .username(jwtUtils.getUserNameFromJwtToken(token))
                .build();
    }

}
