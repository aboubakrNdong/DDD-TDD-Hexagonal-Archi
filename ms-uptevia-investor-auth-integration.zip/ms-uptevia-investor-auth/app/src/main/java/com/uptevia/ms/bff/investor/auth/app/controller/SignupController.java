package com.uptevia.ms.bff.investor.auth.app.controller;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uptevia.ms.bff.investor.auth.api.SignupApi;
import com.uptevia.ms.bff.investor.auth.api.model.*;
import com.uptevia.ms.bff.investor.auth.app.exception.CustomResponseStatusException;
import com.uptevia.ms.bff.investor.auth.app.mapper.*;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.service.SignupService;
import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;
import com.uptevia.ms.bff.investor.auth.domain.util.ToolsManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
@Slf4j
public class SignupController implements SignupApi {


    private final SignupService signupService;

    public SignupController(SignupService signupService) {
        this.signupService = signupService;
    }


    /**
     * vérifier si les données saisies par le user sont bons
     *
     * @param emetteurDetailsJson (optional)
     * @return boolean
     */
    @Override
    public ResponseEntity<Boolean> verifyIdentity(final EmetteurDetailsJson emetteurDetailsJson) {

        boolean verify;
        EmetteurDetailsDTO emetteurDetailsDTO = SignupMapper.instance.jsonToDto(emetteurDetailsJson);

        try {
            verify = signupService.verifyIdentity(emetteurDetailsDTO);
        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.NOT_FOUND, ex.getCode(), ex.getContextParams());
        }
        return new ResponseEntity<>(verify, HttpStatus.OK);
    }


    /**
     * POST /signup/check-questions-answers
     * Vérifier si les questions et réponses matchent bien avec celles entrées
     *
     * @param questionnaireJson (optional)
     * @return les questions et les réponses saisies matchent bien  (status code 200)
     * or les questions et les réponses sont différentes (status code 404)
     */

    @Override
    public ResponseEntity<Boolean> checkQuestionsAnswers(final QuestionnaireJson questionnaireJson) {

        boolean check;
        QuestionnaireDTO questionnaireDTO = QuestionnaireMapper.QUESTIONNAIRE_MAPPER.jsonToDto(questionnaireJson);

        try {
            check = signupService.checkQuestionsAnswers(questionnaireDTO);
        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.NOT_FOUND, ex.getCode(), ex.getContextParams());
        }
        return new ResponseEntity<>(check, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Boolean> savePassword(PayloadJson payloadJson) {

        String decryptedData = ToolsManager.decryptFromFront(payloadJson.getPayload());
        if (decryptedData == null) {
            log.warn("Erreur de dechiffrement");
            return new ResponseEntity<>(Boolean.FALSE, HttpStatus.OK);
        }

        //System.out.println("le Payload en clair est : " + decryptedData);

        DetailConnexionDTO detailConnexionDTO = makeDtoFromPayload(decryptedData);

        if (detailConnexionDTO == null) {
            log.warn("Erreur de creation de DetailConnexionDTO");
            return new ResponseEntity<>(Boolean.FALSE, HttpStatus.OK);
        }
        try {
            signupService.savePassword(detailConnexionDTO);
        } catch (FunctionnalException ex) {

            if(ex.getMessage().equals(String.valueOf(Constantes.STATUS_400))){
                throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, ex.getCode(), ex.getContextParams());
            }
            throw new CustomResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, ex.getCode(), ex.getContextParams());
        }
        return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Boolean> saveSecretQuestions(PayloadJson payloadJson) {
        String decryptedData = ToolsManager.decryptFromFront(payloadJson.getPayload());
        if (decryptedData == null) {
            log.warn("Erreur de dechiffrement");
            return new ResponseEntity<>(Boolean.FALSE, HttpStatus.OK);
        }

        System.out.println("le Payload en clair est : " + decryptedData);

        QuestionnaireDTO questionnaireDTO  = makeQuestionnaireDTOFromPayload(decryptedData);


        try {
            signupService.saveSecretQuestions(questionnaireDTO);
        } catch (FunctionnalException e) {
            log.info(e.getMessage());
            return new ResponseEntity<>(Boolean.FALSE, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
    }



    /**
     * charger la liste de question secrets à répondre lors du création du compte
     *
     * @return SecretQuestionsJson
     */
    @Override
    public ResponseEntity<List<SecretQuestionsJson>> secretQuestions(final String idListe, final Integer emetIden) {

        List<SecretQuestionsDTO> secretQuestionsDTOS;

        try {
            secretQuestionsDTOS = signupService.secretQuestions(idListe, emetIden);
        } catch (FunctionnalException e) {
            log.info(e.getMessage());
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(secretQuestionsDTOS.stream()
                .map(SecretQuestionsJsonMapper.SECRET_QUESTIONS_JSON_MAPPER::dtoToJson).toList(), HttpStatus.OK);
    }



    private DetailConnexionDTO makeDtoFromPayload(String decryptedData) {
        try {
            JsonNode jObj;
            ObjectMapper mapper = new ObjectMapper();
            JsonFactory factory = mapper.getJsonFactory();

            JsonParser parser = factory.createJsonParser(decryptedData);
            jObj = mapper.readTree(parser);

            return DetailConnexionDTO.builder()
                    .login(jObj.get("login").asText())
                    .newPassword(jObj.get("newPassword").asText())
                    .build();
        } catch (Exception e) {
            log.info(e.getMessage());
            return null;
        }
    }

    private QuestionnaireDTO makeQuestionnaireDTOFromPayload(String decryptedData) {
        try {
            JsonNode jObj;
            ObjectMapper mapper = new ObjectMapper();
            JsonFactory factory = mapper.getJsonFactory();

            JsonParser parser = factory.createJsonParser(decryptedData);
            jObj = mapper.readTree(parser);

            return QuestionnaireDTO.builder()
                    .login(jObj.get("login").asText())
                    .firstAnswer(jObj.get("firstAnswer").asText())
                    .firstQuestion(jObj.get("firstQuestion").asInt())
                    .secondAnswer(jObj.get("secondAnswer").asText())
                    .secondQuestion(jObj.get("secondQuestion").asInt())
                    .buttonChoice(jObj.get("buttonChoice").asText())
                    .lang(jObj.get("lang").asText())
                    .build();
        } catch (Exception e) {
            log.info(e.getMessage());
            return null;
        }
    }

}
