package com.uptevia.ms.bff.investor.auth.app.exception;

import com.uptevia.ms.bff.investor.auth.api.model.MSExceptionDTOJson;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;



@RestControllerAdvice
public class ControllerExceptionHandler {


    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @ExceptionHandler(value = {CustomResponseStatusException.class})
    public ResponseEntity<MSExceptionDTOJson> resourceNotFoundException(CustomResponseStatusException ex, WebRequest request) {
        MSExceptionDTOJson msExceptionDTOJson = new MSExceptionDTOJson()
                .errorCode(ex.getReason())
                .contextParams(ex.getContextParams())
                .message(ex.getMessage());

        LOGGER.info("Error found: " + ex.getMessage());

        return new ResponseEntity<>(msExceptionDTOJson,ex.getStatus());
    }

    @ExceptionHandler(value = {RuntimeException.class})
    public ResponseEntity<MSExceptionDTOJson> resourceRuntimeException(RuntimeException ex, WebRequest request) {
        MSExceptionDTOJson message = new MSExceptionDTOJson()
                .message(ex.getMessage());

        ex.printStackTrace();

        return new ResponseEntity<>(message, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
