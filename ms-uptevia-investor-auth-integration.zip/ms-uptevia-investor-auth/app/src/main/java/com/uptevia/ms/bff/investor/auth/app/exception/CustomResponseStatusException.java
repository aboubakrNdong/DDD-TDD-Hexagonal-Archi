package com.uptevia.ms.bff.investor.auth.app.exception;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

@Setter
@Getter
public class CustomResponseStatusException extends ResponseStatusException {

    private final Map<String, Object> contextParams;

    public CustomResponseStatusException(HttpStatus status, String reason, Map<String, Object> contextParams)  {

        super(status, reason);
        this.contextParams = contextParams;
    }
}
