package com.uptevia.ms.bff.investor.auth.app.mapper;

import com.uptevia.ms.bff.investor.auth.api.model.ApiResponseJson;
import com.uptevia.ms.bff.investor.auth.domain.model.ApiResponseDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ApiResponseMapper {

    ApiResponseMapper INSTANCE = Mappers.getMapper(ApiResponseMapper.class);
    ApiResponseJson dtoToJson (ApiResponseDTO responseDTO);
}
