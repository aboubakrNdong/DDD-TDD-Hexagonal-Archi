package com.uptevia.ms.bff.investor.auth.app.mapper;

import com.uptevia.ms.bff.investor.auth.api.model.DetailConnexionJson;
import com.uptevia.ms.bff.investor.auth.domain.model.DetailConnexionDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DetailConnexionMapper {

    DetailConnexionMapper INSTANCE = Mappers.getMapper(DetailConnexionMapper.class);

    DetailConnexionDTO jsonToDto (DetailConnexionJson detailConnexionJson);
}
