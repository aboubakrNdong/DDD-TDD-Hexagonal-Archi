package com.uptevia.ms.bff.investor.auth.app.mapper;

import com.uptevia.ms.bff.investor.auth.api.model.LogOutRequestJson;
import com.uptevia.ms.bff.investor.auth.domain.model.LogOutRequestDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface LogOutRequestMapper {

    LogOutRequestMapper LOG_OUT_REQUEST_MAPPER = Mappers.getMapper(LogOutRequestMapper.class);

    LogOutRequestDTO jsonToDto (LogOutRequestJson logOutRequestJson);

    LogOutRequestJson dtoTojson(LogOutRequestDTO logOutRequestDTO);
}
