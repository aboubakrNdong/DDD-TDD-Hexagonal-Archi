package com.uptevia.ms.bff.investor.auth.app.mapper;

import com.uptevia.ms.bff.investor.auth.api.model.LoginRequestJson;
import com.uptevia.ms.bff.investor.auth.domain.model.LoginRequestDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface LoginRequestMapper {

    LoginRequestMapper INSTANCE = Mappers.getMapper(LoginRequestMapper.class);

    LoginRequestDTO jsonToDto (LoginRequestJson loginRequestJson);
}
