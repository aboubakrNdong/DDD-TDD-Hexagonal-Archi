/*package com.uptevia.ms.bff.investor.auth.app.mapper;


import com.uptevia.ms.bff.investor.auth.api.model.RequestOtpJson;
import com.uptevia.ms.bff.investor.auth.domain.model.RequestOtpDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RequestOtpJsonMapper {

    RequestOtpJsonMapper instance = Mappers.getMapper(RequestOtpJsonMapper.class);
    RequestOtpDTO jsonToDto(RequestOtpJson redJson);
}
*/