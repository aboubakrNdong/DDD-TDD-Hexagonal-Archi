package com.uptevia.ms.bff.investor.auth.app.mapper;

import com.uptevia.ms.bff.investor.auth.api.model.EmetteurDetailsJson;
import com.uptevia.ms.bff.investor.auth.domain.model.EmetteurDetailsDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SignupMapper {

    SignupMapper instance = Mappers.getMapper(SignupMapper.class);

    EmetteurDetailsDTO jsonToDto (EmetteurDetailsJson emetteurDetailsJson);
}
