package com.uptevia.ms.bff.investor.auth.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.uptevia.ms.bff.investor.auth.api.model.SsoUrlJson;
import com.uptevia.ms.bff.investor.auth.domain.model.SsoUrlDTO;

@Mapper
public interface SsoUrlDTOMapper {
    
    public SsoUrlDTOMapper INSTANCE = Mappers.getMapper(SsoUrlDTOMapper.class);

    public SsoUrlJson DtoToJson(SsoUrlDTO ssoUrlDTO);
}
