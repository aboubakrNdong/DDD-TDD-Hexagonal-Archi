package com.uptevia.ms.bff.investor.auth.app.mapper;

import com.uptevia.ms.bff.investor.auth.api.model.UserVerifiedJson;
import com.uptevia.ms.bff.investor.auth.domain.model.UserVerifiedDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface UserVerifiedJsonMapper {

    UserVerifiedJsonMapper INSTANCE = Mappers.getMapper(UserVerifiedJsonMapper.class);

    UserVerifiedJson dtoToJson(UserVerifiedDTO detailTituDTO);

}