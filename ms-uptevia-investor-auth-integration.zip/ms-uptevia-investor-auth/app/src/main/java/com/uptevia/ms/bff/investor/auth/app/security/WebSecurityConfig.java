package com.uptevia.ms.bff.investor.auth.app.security;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import lombok.extern.slf4j.Slf4j;

//@Configuration
//@EnableWebSecurity
@Slf4j
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    private static final String[] AUTH_WHITELIST = {
            // -- Swagger UI v3 (OpenAPI)
            "/v3/api-docs/**",
            "/ms-investor-auth.v1.json",
            "/swagger-ui.html",
            "/swagger-ui/**",
            "/**/authenticate/**",
            "/**/set-password/**",
            "/**/forgot/**",
            "/**/actuator/**",
            "/**/ancient-planetshare/**",
            "/**/secret-questions/**",
            "/**/save-password/**",
            "/**/save-secret-questions/**",
            "/**/check-questions-answers/**",
            "/**/authenticate/validate-otp/**",
            "/**/authenticate/setup-sso/**",
            "/**/authenticate/generate-url-sso/**",
            "/**/mail-phone/**",
            "/**/logout/**",
            "/**/updateLoggedOutUsers/**"
    };

    /*@Autowired
    private JwtUtils jwtUtils;

    @Bean
    public AuthTokenFilter authenticationJwtTokenFilter() {
        return new AuthTokenFilter(jwtUtils);
    }*/


    @Override
    protected void configure(final HttpSecurity http) throws Exception {

        log.info("Begin auth secure context ... ");
        // Disable CSRF (cross site request forgery)
        http
                .csrf().disable()
                .authorizeRequests().anyRequest().authenticated()
                .and()
                .httpBasic();

        // Apply JWT
        //http.addFilterAfter(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);

    }


    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth)
            throws Exception
    {
        auth.inMemoryAuthentication()
                .withUser("shareholder")
                .password("{noop}Uptevia@2027")
                .roles("USER");
    }
}
