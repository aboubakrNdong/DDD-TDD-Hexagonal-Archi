package com.uptevia.ms.bff.investor.auth.app.mapper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.uptevia.ms.bff.investor.auth.api.model.SsoUrlJson;
import com.uptevia.ms.bff.investor.auth.domain.model.SsoUrlDTO;

public class SsoUrlDTOMapperTest {
    
    String url = "test";
    private SsoUrlDTO ssoUrlDTO = new SsoUrlDTO(url);

    @Test
    public void shouldMapDTOToJSON() {
        //GIVEN
        //WHEN
        SsoUrlJson json = SsoUrlDTOMapper.INSTANCE.DtoToJson(ssoUrlDTO);
        //THEN
        assertNotNull(json);
        assertEquals(json.getUrl(), this.url);
    }
}
