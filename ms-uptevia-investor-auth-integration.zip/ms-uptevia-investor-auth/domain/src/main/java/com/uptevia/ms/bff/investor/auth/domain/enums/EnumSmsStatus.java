package com.uptevia.ms.bff.investor.auth.domain.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
@Getter
@AllArgsConstructor
public enum EnumSmsStatus {

    STATUS_OK ("OK"),
    STATUS_OTP_REQUEST_ERROR ("OTP_REQUEST_ERROR"), // Ce statut  indiquetout autre erreur imprevu
    STATUS_SERVER_ERROR("SMS_SERVER_ERROR"), // Ce statut  indique un incidentretarus
    STATUS_BLOCKED ("BLOCKED"); // Ce statut  indique le blocage de génération OTP

    private final String status;


}