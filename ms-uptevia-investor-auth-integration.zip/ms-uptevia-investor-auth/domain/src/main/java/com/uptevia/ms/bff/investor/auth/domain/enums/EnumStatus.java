package com.uptevia.ms.bff.investor.auth.domain.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EnumStatus {

    STATUS_OK ("OK"),
    STATUS_NOT_FOUND ("Not Found"),
    STATUS_NOT_ALLOWED ("NOT_ALLOWED"), // Ce statut masque le not found. pour ne pas indiquer qu'un login n'existe pas par exemple
    ONBOARDING_STEP_PSW ("ONBOARDING_STEP_PSW"),
    ONBOARDING_STEP_QUESTION ("ONBOARDING_STEP_QUESTION"),
    ONBOARDING_STEP_OTP ("ONBOARDING_STEP_OTP"),
    ONBOARDING_STEP_UPLOAD_DOC ("ONBOARDING_STEP_OTP"),
    ONBOARDING_COMPLETED ("ONBOARDING_COMPLETED");

    private final String status;

}