package com.uptevia.ms.bff.investor.auth.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter
public class AttachmentsDTO {

    private String fileName;
    private String file;

}