package com.uptevia.ms.bff.investor.auth.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@Builder
public class EmetteurDetailsDTO {

    private String identifiant;

    private String nomFamille;

    private String prenom;

    private LocalDate dateNaissance;

    private String telephone;

    private String email;

    private String emetFirstname;

    private String numCpte;

    private String buttonChoice;

}
