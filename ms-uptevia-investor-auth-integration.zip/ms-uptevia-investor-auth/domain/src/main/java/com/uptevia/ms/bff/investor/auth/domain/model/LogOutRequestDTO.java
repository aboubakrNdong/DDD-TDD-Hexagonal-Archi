package com.uptevia.ms.bff.investor.auth.domain.model;

import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;

@Data
@Builder
public class LogOutRequestDTO {

    private String username;

    private String token;

    private OffsetDateTime revokeDate;

    private OffsetDateTime validityEndDate;

    public LogOutRequestDTO(String username, String token, OffsetDateTime revokeDate, OffsetDateTime validityEndDate) {
        this.username = username;
        this.token = token;
        this.revokeDate = revokeDate;
        this.validityEndDate = validityEndDate;
    }

    @Override
    public String toString() {
        return "revokeDate: " + this.revokeDate +
                ", validityEndDate: " + this.validityEndDate;
    }
}
