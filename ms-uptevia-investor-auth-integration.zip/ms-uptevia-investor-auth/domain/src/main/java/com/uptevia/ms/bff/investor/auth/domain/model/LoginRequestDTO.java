package com.uptevia.ms.bff.investor.auth.domain.model;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class LoginRequestDTO {

    private String login;

    private String password;

    private String email;

    private boolean operation;

    private String lang;



}
