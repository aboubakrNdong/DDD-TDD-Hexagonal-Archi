package com.uptevia.ms.bff.investor.auth.domain.model;

import lombok.*;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MailTraductionDTO {

    private String key;

    private String libelle;

}
