package com.uptevia.ms.bff.investor.auth.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@Builder
public class NewIdentifiantDTO {

    private String pEmetIden;

    private String pActiIden;

    private String pNom;

    private String pPrenom;

    private LocalDate pDateNais;

}
