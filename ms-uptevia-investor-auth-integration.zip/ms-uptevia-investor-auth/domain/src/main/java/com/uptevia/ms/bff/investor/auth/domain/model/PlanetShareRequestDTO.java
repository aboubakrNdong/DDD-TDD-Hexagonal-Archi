package com.uptevia.ms.bff.investor.auth.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter
public class PlanetShareRequestDTO {

    private Integer emetIden;

    private String accessCode;

    private String password;

}
