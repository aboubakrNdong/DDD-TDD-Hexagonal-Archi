package com.uptevia.ms.bff.investor.auth.domain.model;

import lombok.Getter;
import lombok.Setter;

import java.time.OffsetDateTime;

@Getter
@Setter
public class PsSelDetailTituDTO {
    private Integer emetIden;

    private Integer actiIden;

    private String nom;

    private String prenom;

    private String qualite;

    private OffsetDateTime dateDerniereConnexion;

    private String nomJF;

    private String emailPerso;

    private String emailPro;

    private String numFixePerso;

    private String numFixePro;

    private String numMobilePerso;

    private String numMobilePro;

    private String tituLanguage;

    private String adreFiscInfoBati;

    private String adreFiscInfoRue;

    private String adreFiscComp;

    private String adreFiscCodp;

    private String adreFiscDept;

    private String adreFiscNomCommune;

    private String adreFiscCodeCommune;

    private String adreFiscPaysIden;

    /** Adresse postale */
    private String adreInfoBati; /** batiment */

    private String adreInfoRue; /** rue */

    private String adreComplement; /** complément */

    private String adreCodp; /** code postal */

    private String adreNomCommune; /** commune */

    private String adrePaysIden; /** pays */
    /** Fin Adresse postale */

    /** Infos de naissance */
    private OffsetDateTime tituNaisDate; /** date de naissance */

    private String tituNaisComu;

    private String tituNaisComuCode;

    private String tituNaisDept;

    private String tituNaisPaysIden;
    /** Fin Infos de naissance */

    /**  Données bancaires */
    private String tituModeReglement;

    private String tituDevise; /** devise */

    private String regrReglIden;

    private String ribBank; /** code banque (si pays FRA) */

    private String ribAgen; /** code agence (si pays FRA) */

    private String ribCompte;

    private String ribCle;

    private String ribDomi;

    private String ribIban; /** iban */

    private String ribeBic; /** code bic */

    private String ribeBicInte; /** code bic */

    private String ribeBankNom;  /** nom de la banque */

    private String ribeBankAdre; /** adresse de la banque */

    private String ribePaysIden; /** pays de la banque */

    private String ribeAgence; /** code agence (si pays <> FRA) */

    private String ribeCtrlInte; /** contrôle intermédiaire */

    private String ribeCpte1; /** réf compte 1 */

    private String ribeCpte2; /** réf compte 2 */

    private String ribeCtrlFinal; /** contrôle final */

    private String ribeBic2; /** code bic */

    private String ribePic2;

    private String ribeBankCode; /** code banque (si pays <> FRA) */

    private String tituBene; /** bénéficiaire */

    private String actiRefeScte; /** type to verify */

    private String actiRefeSala; /** code salarié */

    private String actiTypeCpte; /** nature de compte */

    private OffsetDateTime actiConvDateEnvoi; /** date d'envoi de la convetion de compte */

    private OffsetDateTime actiConvDateRecept; /** date de réception de la convention de compte */

    private OffsetDateTime actiConvDateRelance;

    private String actiMifClass; /** classification MIF */

    private boolean actiConvIndiExclu; /** indicateur de non prise en compte de la convention de compte */

    private boolean actiConvIndiIncomp; /** indicateur de non complétude de la convetion de compte */

    private String emetLibelle; /** libellé émetteur */

    private String drhRattachement; /** coordonnées RH */

    private String natioIso3;

    private String idNatioType;

    private String idNatioMifid;

    private String pjType;

    private String pjNume;

    private OffsetDateTime pjDateExpir;

    private OffsetDateTime pjDateDeliv;

    private String pjTypeLib;

    private String idNatioTypeLib;
}
