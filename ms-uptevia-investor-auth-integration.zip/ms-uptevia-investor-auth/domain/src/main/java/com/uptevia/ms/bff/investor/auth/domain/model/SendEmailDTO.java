package com.uptevia.ms.bff.investor.auth.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@Builder
public class SendEmailDTO {

    private String from = "no-reply@uptevia.com";
    private String textBody;
    //private String htmlBody;
    private String subject;
    //private String typeMail;
    private String recipients = null;
    private List<AttachmentsDTO> attachments = null;

}