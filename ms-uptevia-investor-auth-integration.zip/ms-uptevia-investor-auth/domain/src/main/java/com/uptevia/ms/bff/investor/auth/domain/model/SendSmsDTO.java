package com.uptevia.ms.bff.investor.auth.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@Builder
public class SendSmsDTO {

    private String text;

    private List<String> mobileNumbers;

    public SendSmsDTO (String text, List<String> mobileNumbers) {
        this.text = text;
        this.mobileNumbers = mobileNumbers;
    }
    public SendSmsDTO() {
    }

}