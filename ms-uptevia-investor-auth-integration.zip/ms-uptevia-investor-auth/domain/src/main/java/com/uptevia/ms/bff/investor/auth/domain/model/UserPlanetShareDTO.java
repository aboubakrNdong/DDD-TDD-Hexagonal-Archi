package com.uptevia.ms.bff.investor.auth.domain.model;


import lombok.*;

@Getter
@Setter
@Builder
public class UserPlanetShareDTO {

    private String password;
    private String saltPassword;
    private String emetIden;
    private String actiIden;
    private String tituNume;
    private String loginUpi;
    private String email;
    private String numMobile;
    private String onBoardingStatus;

    // Util method to reset all the attributes of your instance
    public void reset(){
        password = "";
        saltPassword = "";
        emetIden = "";
        actiIden = "";
        tituNume = "";
        loginUpi = "";
        email = "";
        numMobile = "";
    }
}
