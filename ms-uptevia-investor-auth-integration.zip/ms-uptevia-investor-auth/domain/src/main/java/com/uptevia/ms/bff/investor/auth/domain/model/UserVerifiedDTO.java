package com.uptevia.ms.bff.investor.auth.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class UserVerifiedDTO {
    private String login;
    private String email;
    private String numTel;
    private String onBoardingStatus;
    private String verificationKey;
}
