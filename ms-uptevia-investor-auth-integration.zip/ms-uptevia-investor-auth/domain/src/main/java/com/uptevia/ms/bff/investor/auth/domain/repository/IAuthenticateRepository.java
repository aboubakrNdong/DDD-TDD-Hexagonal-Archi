package com.uptevia.ms.bff.investor.auth.domain.repository;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface IAuthenticateRepository {

    UserDTO authenticate(final String login, final String password) throws FunctionnalException;

    Long updateNbAcces(final String login) throws FunctionnalException;

    Long updateNbEssai(final String login,final int number) throws FunctionnalException;

    List<UserDTO> ancientOlisAccount(final String login) throws FunctionnalException;

    List<UserPlanetShareDTO> ancientPlanetShare(final Integer emetIden, final String accessCode) throws FunctionnalException;

    UserDTO getUpiUtilUser(String login);

    Long updateDateMajOtp(String login) throws FunctionnalException;
    void acceptCgu(final EabonnementDTO eabonnementDTO);


    String validateToken(String login, String token, String useCase);

    BigDecimal requestToken(String login, String token, String useCase);

    List<String> getWhitelist(String typeWhitelist) throws FunctionnalException;

    String validateOtpCode(String login, String otpCode);
    String requestOtp (String login, String lang) throws FunctionnalException;

    Map<String, String> sendSms(SendSmsDTO  sendSmsDTO);

    long logout(final LogOutRequestDTO logOutRequestDTO);

    List<LogOutRequestDTO> findAllRevokedTokens();

}

