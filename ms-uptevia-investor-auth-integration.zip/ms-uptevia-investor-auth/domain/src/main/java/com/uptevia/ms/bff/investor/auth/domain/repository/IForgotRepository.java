package com.uptevia.ms.bff.investor.auth.domain.repository;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.EmailBodyDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.ForgotIdentifiantDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.MailTraductionDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.SendEmailDTO;

import java.time.LocalDate;
import java.util.List;

public interface IForgotRepository {

    ForgotIdentifiantDTO getIdentifiant(String pEmetIden, String pActiIden, String pNom, String pPrenom, LocalDate pDateNais) throws FunctionnalException;

    String getFrontUrl();

    boolean sendEmail(SendEmailDTO sendEmailDTO, final EmailBodyDTO emailBodyDTO);

    List<MailTraductionDTO> getAllKeyAndLibelle(String language, String key, int themeId ) throws FunctionnalException;
}