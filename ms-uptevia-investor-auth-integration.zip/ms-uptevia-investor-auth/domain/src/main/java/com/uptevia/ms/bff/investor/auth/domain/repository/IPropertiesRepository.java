package com.uptevia.ms.bff.investor.auth.domain.repository;

public interface IPropertiesRepository {
    public String getFrontUrl();
    public int getJwtExpirationMs();
    public String getSecretKey();
}
