package com.uptevia.ms.bff.investor.auth.domain.repository;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;

public interface IUpdatePasswordRepository {

    long updatePassword(final String login, final String newPassword) throws FunctionnalException;

    Integer getHistoricPasswords(final String login, final String newPassword, final long nbrFois) throws FunctionnalException;
}
