package com.uptevia.ms.bff.investor.auth.domain.service;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;

import java.util.List;

public interface AuthService {

    ResultStatusDTO authenticate(final LoginRequestDTO loginRequestDTO) throws FunctionnalException;

    List<UserDTO> ancientOlisAccount(final LoginRequestDTO loginRequestDTO)throws FunctionnalException;

    List<UserPlanetShareDTO> ancientPlanetShare(final Integer emetIden, final String accessCode, final String password) throws FunctionnalException;

    ResultStatusDTO getOnboardingStatus(String login);

    void acceptCgu(final EabonnementDTO eabonnementDTO) throws FunctionnalException;

    UserDTO validateOtpCode(String login, String otpCode) throws FunctionnalException;


    boolean logout(final LogOutRequestDTO logOutRequestDTO) throws FunctionnalException;

    List<LogOutRequestDTO> findAllRevokedTokens();
}
