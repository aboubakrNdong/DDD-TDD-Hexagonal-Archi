package com.uptevia.ms.bff.investor.auth.domain.service;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;

public interface ForgotIdentifiantService {

    UserVerifiedDTO verifyIdentifiant(final NewIdentifiantDTO newIdentifiantDTO) throws FunctionnalException;
    UserDTO verifyResetToken(String chaine) throws Exception;

    void sendTokenByEmail(String login, String buttonChoice, String lang) throws FunctionnalException;
}
