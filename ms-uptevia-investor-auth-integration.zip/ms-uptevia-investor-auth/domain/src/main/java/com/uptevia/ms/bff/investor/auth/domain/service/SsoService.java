package com.uptevia.ms.bff.investor.auth.domain.service;

import com.uptevia.ms.bff.investor.auth.domain.model.SsoUrlDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;

public interface SsoService {
    public SsoUrlDTO generateSsoUrlDTO(String idOperateur, String loginActionnaire); 
    public UserDTO getInfosForSsoConnection(String loginActionnaire);
}