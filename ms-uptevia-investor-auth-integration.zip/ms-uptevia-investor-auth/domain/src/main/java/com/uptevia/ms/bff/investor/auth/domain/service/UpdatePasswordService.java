package com.uptevia.ms.bff.investor.auth.domain.service;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.DetailConnexionDTO;

public interface UpdatePasswordService {

    void updatePassword(final DetailConnexionDTO detailConnexionDTO) throws FunctionnalException;
}
