package com.uptevia.ms.bff.investor.auth.domain.service;

public interface UtilsService {
    public boolean isLoginUpiNotExist(String login);
}
