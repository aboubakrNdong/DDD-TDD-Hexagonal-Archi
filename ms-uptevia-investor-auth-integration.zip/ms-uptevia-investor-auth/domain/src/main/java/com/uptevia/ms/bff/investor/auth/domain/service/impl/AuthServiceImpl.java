package com.uptevia.ms.bff.investor.auth.domain.service.impl;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.service.AuthService;
import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;
import com.uptevia.ms.bff.investor.auth.domain.enums.EnumStatus;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Slf4j
public class AuthServiceImpl extends AbstractAuthService implements AuthService {

    private final IAuthenticateRepository iAuthenticateRepository;

    private int nbAccess = 0;

    public AuthServiceImpl(final IAuthenticateRepository iAuthenticateRepository) {
        this.iAuthenticateRepository = iAuthenticateRepository;
    }

    @Override
    public ResultStatusDTO authenticate(final LoginRequestDTO loginRequestDTO) throws FunctionnalException {
        ResultStatusDTO resultStatusDTO = new ResultStatusDTO();

        ZoneOffset offset = OffsetDateTime.now().getOffset();

        UserDTO userDTO = iAuthenticateRepository.authenticate(loginRequestDTO.getLogin(), loginRequestDTO.getPassword());

        //* generates the Salt value to be used to crypt password. *//*
        String hashedSaltedPwd = DigestUtils.sha256Hex(loginRequestDTO.getPassword() + userDTO.getSltPassword());

        // octane 32001 cas3
        if (StringUtils.isEmpty(userDTO.getPassword())) {
            throw new FunctionnalException(Constantes.LOGIN_ERROR_WITHOUT_PASSWORD, Constantes.LOGIN_ERROR_WITHOUT_PASSWORD);
        }

        // octane 32001 cas5
        this.checkBadCredentials(userDTO, loginRequestDTO, hashedSaltedPwd);

        if (userDTO.isIndiCompteBloque()) {
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BLOCKING, Constantes.LOGIN_TEXT_BLOCKING);
        }

        /*
         * Handle case: When user change password and then try to authenticate
         * and enter 3 times an error password, we should block him
         */
        this.checkAccessDate(userDTO, offset, loginRequestDTO, hashedSaltedPwd);

        // octane 32001 cas6
        if (userDTO.isIndiPwdExpire()) {
            throw new FunctionnalException(Constantes.LOGIN_ERROR_PASSWORD_EXPIRED, Constantes.LOGIN_ERROR_PASSWORD_EXPIRED);
        }

        // octane 32001 cas9
        this.checkDateValidity(userDTO, offset);

        //octane 10003: For password buy/sell operation validation
        if (!StringUtils.equals(hashedSaltedPwd, userDTO.getPassword()) && loginRequestDTO.isOperation()) {
            iAuthenticateRepository.updateNbEssai(loginRequestDTO.getLogin(), 1);
            throw new FunctionnalException(Constantes.BAD_OPERATIONS_PASSWORD, Constantes.BAD_OPERATIONS_PASSWORD);
        }


        nbAccess = 0;
        iAuthenticateRepository.updateNbAcces(loginRequestDTO.getLogin());
        iAuthenticateRepository.updateNbEssai(loginRequestDTO.getLogin(), 0);

        //Si donc Authen ok et qu'il ne sagit pas d'un parcours d'achat et vente, on demande l'OTP
        if (!loginRequestDTO.isOperation()) {
            resultStatusDTO.setStatus(iAuthenticateRepository.requestOtp(loginRequestDTO.getLogin(), loginRequestDTO.getLang()));
        }

        return resultStatusDTO;
    }

    private void checkDateValidity(final UserDTO userDTO, final ZoneOffset offset) throws FunctionnalException {
        if (userDTO.getDateValiditeFin() != null) {
            LocalDateTime dateTimeAccess = LocalDateTime.now();
            if (userDTO.getDateValiditeFin().isBefore(dateTimeAccess.atOffset(offset))) {
                throw new FunctionnalException(Constantes.LOGIN_ERROR_DATE_VALIDITY_END, Constantes.LOGIN_ERROR_DATE_VALIDITY_END);
            }
        }
    }

    private void checkAccessDate(final UserDTO userDTO, final ZoneOffset offset, final LoginRequestDTO loginRequestDTO,
                                 final String hashedSaltedPwd) throws FunctionnalException {
        if (userDTO.getDateMajPsw() != null) {
            LocalDateTime now = LocalDateTime.now();
            OffsetDateTime dateTimeAccess24h = userDTO.getDateMajPsw().plusDays(1);
            if (now.atOffset(offset).isBefore(dateTimeAccess24h)
                    && !(StringUtils.equals(hashedSaltedPwd, userDTO.getPassword()) || loginRequestDTO.isOperation())) {
                if (nbAccess < 3 && !userDTO.isIndiCompteBloque()) {
                    iAuthenticateRepository.updateNbEssai(loginRequestDTO.getLogin(), 1);
                    nbAccess++;
                    throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_CREDENTIALS, Constantes.LOGIN_TEXT_BAD_CREDENTIALS);
                } else {
                    nbAccess = 0;
                    iAuthenticateRepository.updateNbEssai(loginRequestDTO.getLogin(), 1);
                    throw new FunctionnalException(Constantes.LOGIN_ERROR_MAJ_PSW_24H, Constantes.LOGIN_ERROR_MAJ_PSW_24H);
                }
            }
        }
    }

    private void checkBadCredentials(final UserDTO userDTO, final LoginRequestDTO loginRequestDTO,
                                     final String hashedSaltedPwd) throws FunctionnalException {

        // octane 32001 cas5
        if (!(StringUtils.equals(hashedSaltedPwd, userDTO.getPassword()) || loginRequestDTO.isOperation())) {

            if (nbAccess < 3 && !userDTO.isIndiCompteBloque()) {
                iAuthenticateRepository.updateNbEssai(loginRequestDTO.getLogin(), 1);
                nbAccess++;
                throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_CREDENTIALS, Constantes.LOGIN_TEXT_BAD_CREDENTIALS);
            } else {
                nbAccess = 0;
                iAuthenticateRepository.updateNbEssai(loginRequestDTO.getLogin(), 1);
                throw new FunctionnalException(Constantes.LOGIN_TEXT_BLOCKING, Constantes.LOGIN_TEXT_BLOCKING);
            }
        }
    }

    @Override
    public List<UserDTO> ancientOlisAccount(final LoginRequestDTO loginRequestDTO) throws FunctionnalException {

        log.info("begin authentication and validation for this login request !!");

        ZoneOffset offset = OffsetDateTime.now().getOffset();

        log.info("Getting the user details from old OLIS database");
        List<UserDTO> userDTOs = iAuthenticateRepository.ancientOlisAccount(loginRequestDTO.getLogin());


        if (userDTOs != null && !userDTOs.isEmpty()) {
            UserDTO userDTO = userDTOs.get(0);

            log.info("Create the hashed password to be compared to the entered password for verification");
            String pwsHex = DigestUtils.sha256Hex(loginRequestDTO.getLogin() + StringUtils.lowerCase(StringUtils.defaultIfBlank(userDTO.getEmail(), "")) + loginRequestDTO.getPassword());

            // octane 22002 cas4
            if (userDTO.isIndiCompteBloque()) {
                log.warn("current account is blocked.");
                throw new FunctionnalException(Constantes.LOGIN_TEXT_BLOCKING, Constantes.LOGIN_TEXT_BLOCKING);
            }

            // octane 22002 cas3
            if (StringUtils.isEmpty(userDTO.getPassword())) {
                log.warn("current account has not a password in database !!");
                throw new FunctionnalException(Constantes.LOGIN_ERROR_WITHOUT_PASSWORD, Constantes.LOGIN_ERROR_WITHOUT_PASSWORD);
            }

            // octane 22002 cas5
            if (!StringUtils.equals(pwsHex, userDTO.getPassword())) {
                log.warn("You have entered a wrong password. Please verify your parameters.");
                iAuthenticateRepository.updateNbEssai(loginRequestDTO.getLogin(), 1);
                throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_CREDENTIALS, Constantes.LOGIN_TEXT_BAD_CREDENTIALS);
            }

            // octane 22002 cas9
            if (userDTO.getDateValiditeFin() != null) {
                log.warn("current account has not a validity expired date !!");
                LocalDateTime dateTimeAccess = LocalDateTime.now();
                if (userDTO.getDateValiditeFin().isBefore(dateTimeAccess.atOffset(offset))) {
                    throw new FunctionnalException(Constantes.LOGIN_ERROR_DATE_VALIDITY_END, Constantes.LOGIN_ERROR_DATE_VALIDITY_END);
                }
            }
        }

        log.info("Updating access number for connected user");
        iAuthenticateRepository.updateNbAcces(loginRequestDTO.getLogin());
        log.info("Update tries number for connected user");
        iAuthenticateRepository.updateNbEssai(loginRequestDTO.getLogin(), 0);

        return userDTOs;
    }

    @Override
    public List<UserPlanetShareDTO> ancientPlanetShare(final Integer emetIden, final String accessCode,
                                                       final String password) throws FunctionnalException {

        log.info("Getting the planetshare user details from database ...");
        List<UserPlanetShareDTO> userPlanetShareDTOS = iAuthenticateRepository.ancientPlanetShare(emetIden, accessCode);

        if (userPlanetShareDTOS != null && !userPlanetShareDTOS.isEmpty()) {
            UserPlanetShareDTO first = userPlanetShareDTOS.get(0);

            String onBoardingStatus = getOnboardingStatus(userPlanetShareDTOS.get(0).getLoginUpi()).getStatus();
            first.setOnBoardingStatus(onBoardingStatus);

            String hashedSaltedPwd = DigestUtils.sha256Hex(StringUtils.defaultIfBlank(first.getSaltPassword(), "") + password);

            if (!StringUtils.equals(hashedSaltedPwd, StringUtils.lowerCase(first.getPassword()))) {
                throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_CREDENTIALS, Constantes.LOGIN_TEXT_BAD_CREDENTIALS);
            }

            if (StringUtils.equals(onBoardingStatus, EnumStatus.ONBOARDING_COMPLETED.getStatus())) {
                first.reset();
            }
        }

        return userPlanetShareDTOS;
    }

    @Override
    public ResultStatusDTO getOnboardingStatus(String login) {
        UserDTO userDTO = iAuthenticateRepository.getUpiUtilUser(login);
        ResultStatusDTO resultStatusDTO = new ResultStatusDTO();


        if (userDTO == null) {
            resultStatusDTO.setStatus(EnumStatus.STATUS_NOT_ALLOWED.getStatus());
        } else {
            boolean hasCompletedOnboarding = ObjectUtils.allNotNull(userDTO.getReponseQuestionSecurite1(),
                    userDTO.getReponseQuestionSecurite2(),
                    userDTO.getPassword());
            if (hasCompletedOnboarding) {
                resultStatusDTO.setStatus(EnumStatus.ONBOARDING_COMPLETED.getStatus());
                return resultStatusDTO;
            }

            //un nouveau
            if (StringUtils.isEmpty(userDTO.getPassword())) {
                resultStatusDTO.setStatus(EnumStatus.STATUS_OK.getStatus());
                return resultStatusDTO;
            }

            if (StringUtils.isEmpty(userDTO.getReponseQuestionSecurite1()) || StringUtils.isEmpty(userDTO.getReponseQuestionSecurite2())) {
                resultStatusDTO.setStatus(EnumStatus.ONBOARDING_STEP_QUESTION.getStatus());
                return resultStatusDTO;
            }

            resultStatusDTO.setStatus(EnumStatus.STATUS_OK.getStatus());

        }
        return resultStatusDTO;
    }

    @Override
    public void acceptCgu(final EabonnementDTO eabonnementDTO) throws FunctionnalException {
        iAuthenticateRepository.acceptCgu(eabonnementDTO);
    }

    @Override
    public UserDTO validateOtpCode(String login, String otpCode) throws FunctionnalException {

        String retourCheckOtp;
        UserDTO userDTO = null;

        retourCheckOtp = iAuthenticateRepository.validateOtpCode(login, otpCode);

        if (StringUtils.equals(retourCheckOtp, "OK")) {
            userDTO = iAuthenticateRepository.getUpiUtilUser(login);
            userDTO.setError(retourCheckOtp);
            //Indicateur indiStepQuestion : true si au moins une question manque
            if (StringUtils.isEmpty(userDTO.getReponseQuestionSecurite1()) || StringUtils.isEmpty(userDTO.getReponseQuestionSecurite2())) {
                userDTO.setIndiStepQuestion(true);
            }
        } else {
            //Echec Validation OTP. Pas de user à retourner mais des erreurs
            userDTO = UserDTO.builder()
                    .error(retourCheckOtp)
                    .build();
        }
        return userDTO;
    }

    @Override
    public boolean logout(final LogOutRequestDTO logOutRequestDTO) throws FunctionnalException {
        log.info("saving token to database to be revoked and anymore used");
        long revoked = iAuthenticateRepository.logout(logOutRequestDTO);
        return revoked > 0;
    }

    @Override
    public List<LogOutRequestDTO> findAllRevokedTokens() {
        return iAuthenticateRepository.findAllRevokedTokens();
    }
}
