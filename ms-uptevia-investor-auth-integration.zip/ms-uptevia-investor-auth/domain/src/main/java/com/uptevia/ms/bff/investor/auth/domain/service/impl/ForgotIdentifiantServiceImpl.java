package com.uptevia.ms.bff.investor.auth.domain.service.impl;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.IForgotRepository;
import com.uptevia.ms.bff.investor.auth.domain.service.ForgotIdentifiantService;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;

import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;
import com.uptevia.ms.bff.investor.auth.domain.enums.EnumStatus;
import com.uptevia.ms.bff.investor.auth.domain.util.ToolsManager;
import com.uptevia.ms.bff.investor.auth.domain.util.Traduction;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import static com.uptevia.ms.bff.investor.auth.domain.util.Constantes.LOGIN_TEXT_BAD_CREDENTIALS;
import static com.uptevia.ms.bff.investor.auth.domain.util.Constantes.MANDATORY_FIELD;

public class ForgotIdentifiantServiceImpl implements ForgotIdentifiantService {
    //TODO implements logs

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final IForgotRepository iForgotRepository;

    private final IAuthenticateRepository iAuthenticateRepository;

    public static final String buttonForgotPassword = "forgotpassword";

    public static final String buttonFirstConnexion = "firstconnexion";

    public static final String buttonOldOlis = "oldolis";


    public static final String buttonOldPls = "oldpls";


    public static final String buttonForgotIdentifiant = "forgotidentifiant";


    public String mailTextBody = "";

    public String mailSubject = "";

    public static String userEmail = "";


    public ForgotIdentifiantServiceImpl(IForgotRepository iForgotRepository, IAuthenticateRepository iAuthenticateRepository) {
        this.iForgotRepository = iForgotRepository;
        this.iAuthenticateRepository = iAuthenticateRepository;
    }


    @Override
    public UserVerifiedDTO verifyIdentifiant(final NewIdentifiantDTO newIdentifiantDTO) throws FunctionnalException {

        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("pActiIden", newIdentifiantDTO.getPActiIden());

        //if nom or prenom are null throws exception
        if (StringUtils.isBlank(newIdentifiantDTO.getPNom())
                || StringUtils.isBlank(newIdentifiantDTO.getPPrenom())
                || StringUtils.isBlank(newIdentifiantDTO.getPActiIden())
                || StringUtils.isBlank(newIdentifiantDTO.getPActiIden())
                || ObjectUtils.isEmpty(newIdentifiantDTO.getPDateNais())) {
            logger.warn(MANDATORY_FIELD);
            return  UserVerifiedDTO.builder().onBoardingStatus(EnumStatus.STATUS_NOT_ALLOWED.getStatus()).build();
            // throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);

        }

        ForgotIdentifiantDTO forgotIdentifiantDTO = iForgotRepository.getIdentifiant(newIdentifiantDTO.getPEmetIden(), newIdentifiantDTO.getPActiIden(), newIdentifiantDTO.getPNom(), newIdentifiantDTO.getPPrenom(), newIdentifiantDTO.getPDateNais());
        String login = null;
        login = forgotIdentifiantDTO.getLoginUpi();
        if (StringUtils.isBlank(login)) {
            contextParams.put("Inputs ", newIdentifiantDTO.toString());
            logger.warn(LOGIN_TEXT_BAD_CREDENTIALS);
            return  UserVerifiedDTO.builder().onBoardingStatus(EnumStatus.STATUS_NOT_ALLOWED.getStatus()).build();
            // throw new FunctionnalException(LOGIN_TEXT_BAD_CREDENTIALS, LOGIN_TEXT_BAD_CREDENTIALS, contextParams);
        }


        UserDTO userVerified = iAuthenticateRepository.getUpiUtilUser(login);

        //Générer un Token notamment pour le parcours vialink

        String token = createToken(userVerified.getLogin(), "VIALINK");
        System.out.println("verificationKey pour " + login + ": "+ token);

        //Insérer le verificationKey en base
        if (iAuthenticateRepository.requestToken(login, token, "VIALINK") == BigDecimal.valueOf(-1)) {
            contextParams.put("login ", login);
            contextParams.put("useCase ", "VIALINK");
            logger.warn("TOKEN_VIALINK_ERROR");
            return  UserVerifiedDTO.builder().onBoardingStatus(EnumStatus.STATUS_NOT_ALLOWED.getStatus()).build();
            //throw new FunctionnalException("TOKEN_VIALINK_ERROR", "TOKEN_VIALINK_ERROR", contextParams);
        }

        return UserVerifiedDTO.builder()
                .email(userVerified.getEmail())
                .numTel(userVerified.getNumTel())
                .login(userVerified.getLogin())
                .onBoardingStatus(getOnboardingStatus(userVerified))
                .verificationKey(token)
                .build();
    }

    private String getOnboardingStatus(UserDTO userDTO) {
        if(!StringUtils.isEmpty(userDTO.getReponseQuestionSecurite1()) &&
                !StringUtils.isEmpty(userDTO.getReponseQuestionSecurite2()) &&
                !StringUtils.isEmpty(userDTO.getPassword())) return EnumStatus.ONBOARDING_COMPLETED.getStatus();

        if (StringUtils.isEmpty(userDTO.getPassword())) {
            return EnumStatus.STATUS_OK.getStatus();

        }

        if (StringUtils.isEmpty(userDTO.getReponseQuestionSecurite1()) || StringUtils.isEmpty(userDTO.getReponseQuestionSecurite2())) {
            return EnumStatus.ONBOARDING_STEP_QUESTION.getStatus();

        }
        return EnumStatus.STATUS_OK.getStatus();
    }

    private String createToken(String login, String useCase) {
        ObjectMapper objectMap = new ObjectMapper();
        ObjectNode json = objectMap.createObjectNode();
        json.put(Constantes.JSON_PARAM_TIME, new Date().getTime());
        json.put(Constantes.JSON_PARAM_ACTION, useCase);
        json.put(Constantes.JSON_PARAM_LOGIN, login);
        return ToolsManager.asHex(ToolsManager.encryptJSONStringToBytes(ToolsManager.SECRET_KEY, ToolsManager.IV_PARAMETER_SPEC, json.toString()));

    }


    /**
     * @param chaine
     * @return
     * @throws IOException
     */
    @Override
    public UserDTO verifyResetToken(final String chaine) throws IOException, FunctionnalException {

        JsonNode jObj;
        UserDTO userDTO = null;
        Map<String, Object> contextParams = new HashMap<>();
        try {
            if (StringUtils.isBlank(chaine)) {
                return null;
            }

            byte[] bSd = ToolsManager.hexToByteArray(chaine);
            bSd = ToolsManager.decryptAes(bSd);
            String decrypt = new String(bSd);

            ObjectMapper mapper = new ObjectMapper();
            JsonFactory factory = mapper.getJsonFactory();

            JsonParser parser = factory.createJsonParser(decrypt);
            jObj = mapper.readTree(parser);

            String login = jObj.get("lg").asText();
            //System.out.println("login: " + login);

            if (!StringUtils.isBlank(login)) {
                userDTO = iAuthenticateRepository.authenticate(login, "");

                // On check la validité de ce token en base
                String checking = iAuthenticateRepository.validateToken(login, chaine, "MAIL_MDP_PERDU");
                //System.out.println("checking: " + checking);
                if (!"OK".equalsIgnoreCase(checking)) {
                    contextParams.put("login ", login);
                    contextParams.put("motifEchec  ", checking);
                    throw new FunctionnalException("TOKEN_VERIFICATION_ERROR", "TOKEN_VERIFICATION_ERROR", contextParams);
                }

            }

        } catch (Exception e1) {
            logger.warn("Exception" + e1);
            return null;
        }
        return userDTO;
    }

    @Override
    public void sendTokenByEmail(String login, String buttonChoice, String lang) throws FunctionnalException {

        Map<String, Object> contextParams = new HashMap<>();

        if (!StringUtils.isBlank(login)) {
            UserDTO psSelDetailTituDTO = iAuthenticateRepository.authenticate(login, "");
            this.userEmail = psSelDetailTituDTO.getEmail();
        }

         List<String> WHITE_LIST_MAIL = iAuthenticateRepository.getWhitelist("MAIL");
       if(!WHITE_LIST_MAIL.stream().anyMatch(userEmail::equalsIgnoreCase)){
            contextParams.put("userEmail ", userEmail);
            throw new FunctionnalException("MailNotInWhiteList", userEmail, contextParams);
        }

        //TODO enhance mapping lang Front and Back

        String convertLang = Traduction.getLangue(lang);

        if (convertLang == null) {
            logger.info("langue not in DB null");
            throw new FunctionnalException("EDX", "Empty_Data_Exception");
        }


        if (StringUtils.equals(buttonChoice, buttonForgotIdentifiant)) {

            this.mailSubject = getLibelle("mail.text.forgotidentifiant.subject", convertLang);

            this.mailTextBody = getLibelle("mail.text.forgotidentifiant.textbody", convertLang)+ "<br /> <br /> <br />" + login +
                    "<br /> <br /> <br />" + getLibelle("mail.text.forgotidentifiant.footer", convertLang);
        }

        if (StringUtils.equals(buttonChoice, buttonForgotPassword)) {

            this.mailSubject = getLibelle("mail.text.forgotpassword.subject", convertLang);

            this.mailTextBody = getLibelle("mail.text.forgotpassword.textbody", convertLang)+ "<br /> <br /> <br />" +
                    createURLToken(login, userEmail, "sd") + "<br /> <br /> <br />" +
                    getLibelle("mail.text.forgotpassword.footer", convertLang);
        }

        if (StringUtils.equals(buttonChoice, buttonFirstConnexion)) {

            this.mailSubject = getLibelle("mail.text.firstconnexion.subject", convertLang);

            this.mailTextBody = getLibelle("mail.text.firstconnexion.textbody", convertLang)  + "<br /> <br /> <br />" +
                    createURLToken(login, userEmail, "dt") + "<br /> <br /> <br />" +
                    getLibelle("mail.text.firstconnexion.footer", convertLang) ;

        }

        if (StringUtils.equals(buttonChoice, buttonOldOlis)) {

            this.mailSubject = getLibelle("mail.text.oldOlis.subject", convertLang);

            this.mailTextBody = getLibelle("mail.text.oldOlis.textbody", convertLang) + "<br /> <br /> <br />" +
                    createURLToken(login, userEmail, "ol") + "<br /> <br /> <br />" +
                    getLibelle("mail.text.oldOlis.footer", convertLang);

        }
        if (StringUtils.equals(buttonChoice, buttonOldPls)) {

            this.mailSubject = getLibelle("mail.text.oldPls.subject", convertLang);

            this.mailTextBody = getLibelle("mail.text.oldPls.textbody", convertLang) + "<br /> <br /> <br />" +
                    createURLToken(login, userEmail, "pl")  + "<br /> <br /> <br />" +
                    getLibelle("mail.text.oldPls.footer", convertLang);

        }
        EmailBodyDTO emailBodyDTO = EmailBodyDTO.builder()
                .textBody(mailTextBody)
                .securityLib(getLibelle("footer.item.securite", convertLang))
                .cguLib(getLibelle("footer.item.cgu", convertLang))
                .rgpdLib(getLibelle("footer.item.rgpd", convertLang))
                .accessibilityLib(getLibelle("footer.item.accessibilite", convertLang))
                .conformLib(getLibelle("footer.item.conformite", convertLang))
                .build();


        iForgotRepository.sendEmail(SendEmailDTO.builder()
                .textBody(mailTextBody)
                .subject(mailSubject)
                .recipients(userEmail)
                .build(), emailBodyDTO);

    }

    private String getLibelle(String keyTrad, String lang) throws FunctionnalException {

        List<MailTraductionDTO> allLibelle = iForgotRepository.getAllKeyAndLibelle(lang, keyTrad, 1);

        if (allLibelle.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            logger.info("error in getting all trad from DB ");
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return Traduction.iTerateOverTrad(allLibelle, keyTrad);
    }

    private String createURLToken(final String login, final String destEmail, final String useCase) throws FunctionnalException {
        Map<String, Object> contextParams = new HashMap<>();

        ObjectMapper objectMap = new ObjectMapper();
        ObjectNode json = objectMap.createObjectNode();

        json.put(Constantes.JSON_PARAM_EMAIL, destEmail);
        json.put(Constantes.JSON_PARAM_TIME, new Date().getTime());
        json.put(Constantes.JSON_PARAM_ACTION, useCase);
        json.put(Constantes.JSON_PARAM_LOGIN, login);

        String encrypted = ToolsManager.asHex(ToolsManager.encryptJSONStringToBytes(ToolsManager.SECRET_KEY, ToolsManager.IV_PARAMETER_SPEC, json.toString()));

        //Insérer le token en base pour le vérifier plus tard
        if (iAuthenticateRepository.requestToken(login, encrypted, "MAIL_MDP_PERDU") == BigDecimal.valueOf(-1)) {
            contextParams.put("login ", login);
            contextParams.put("useCase ", useCase);
            throw new FunctionnalException("TOKEN_INSERTION_ERROR", "TOKEN_INSERTION_ERROR", contextParams);
        }

        return iForgotRepository.getFrontUrl() + "#/setpassword?"+useCase+"=" + encrypted;

    }

}
