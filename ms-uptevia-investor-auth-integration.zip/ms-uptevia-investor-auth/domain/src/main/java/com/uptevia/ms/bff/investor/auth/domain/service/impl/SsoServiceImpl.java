package com.uptevia.ms.bff.investor.auth.domain.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.uptevia.ms.bff.investor.auth.domain.model.SsoInfoDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.SsoUrlDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.IPropertiesRepository;
import com.uptevia.ms.bff.investor.auth.domain.service.SsoService;
import com.uptevia.ms.bff.investor.auth.domain.utils.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.auth.domain.utils.sso.SsoUrlGenerator;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SsoServiceImpl implements SsoService{

    IAuthenticateRepository iAuthenticateRepository;
    IPropertiesRepository iPropertiesRepository;

    JwtUtils jwtUtils;

    public SsoServiceImpl(final IAuthenticateRepository iAuthenticateRepository, final IPropertiesRepository iPropertiesRepository){
        this.iAuthenticateRepository = iAuthenticateRepository;
        this.iPropertiesRepository = iPropertiesRepository;
        this.jwtUtils = new JwtUtils(iPropertiesRepository);
    }

    @Override
    public SsoUrlDTO generateSsoUrlDTO(String idOperateur, String loginActionnaire) {
        log.trace("Begin generate Sso Url for idOperateur :" + idOperateur);
        SsoInfoDTO infosSso = SsoInfoDTO.builder().idOperateur(idOperateur).build();
        UserDTO userDTO = iAuthenticateRepository.getUpiUtilUser(loginActionnaire);
        userDTO.setSso(true);
        userDTO.setInfosSso(infosSso);
        userDTO.setToken(jwtUtils.generateJwtToken(userDTO));

        SsoUrlGenerator generator = new SsoUrlGenerator(userDTO);
        String url = iPropertiesRepository.getFrontUrl() + generator.generateUrl();
        
        SsoUrlDTO result = new SsoUrlDTO(url);
        log.trace("Sso Url for idOperateur :" + idOperateur + " has been created");
        return result;
    }

    @Override
    public UserDTO getInfosForSsoConnection(String loginActionnaire) {
        log.trace("Begin fetching info of user for sso connexion");
        UserDTO userDTO = iAuthenticateRepository.getUpiUtilUser(loginActionnaire);
        userDTO.setSso(true);
        log.trace("End fetching info of user for sso connexion");
        return userDTO;
    }
    
}
