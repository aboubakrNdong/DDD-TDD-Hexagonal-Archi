package com.uptevia.ms.bff.investor.auth.domain.service.impl;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.DetailConnexionDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.IUpdatePasswordRepository;
import com.uptevia.ms.bff.investor.auth.domain.service.UpdatePasswordService;
import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;
import com.uptevia.ms.bff.investor.auth.domain.util.ToolsManager;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Map;


public class UpdatePasswordServiceImpl extends AbstractAuthService implements UpdatePasswordService {
    private final IUpdatePasswordRepository iUpdatePasswordRepository;

    private final IAuthenticateRepository iAuthenticateRepository;

    private static final String NEW_PASSWORD = "newPassword";

    public UpdatePasswordServiceImpl(final IUpdatePasswordRepository iUpdatePasswordRepository,
                                     final IAuthenticateRepository iAuthenticateRepository) {
        this.iUpdatePasswordRepository = iUpdatePasswordRepository;
        this.iAuthenticateRepository = iAuthenticateRepository;
    }


    @Override
    public void updatePassword(final DetailConnexionDTO detailConnexionDTO) throws FunctionnalException {

        ZoneOffset offset = OffsetDateTime.now().getOffset();
        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("login", detailConnexionDTO.getLogin());
        /*
         * Ajout de régles de validation du nouveau mot de passe
         */

        UserDTO userDTO = iAuthenticateRepository.authenticate(detailConnexionDTO.getLogin(), detailConnexionDTO.getOldPassword());
        /*
         * Hachage et cryptage du nouveau mot de passe
         */
        /* generates the Salt value to be used to crypt password. */
        String oldHashedSaltedPwd = DigestUtils.sha256Hex(detailConnexionDTO.getOldPassword() + userDTO.getSltPassword());

        /* generates an encrypted and polluted password. It can be stored in a database.*/
        String encryptedPassword = DigestUtils.sha256Hex(detailConnexionDTO.getNewPassword() + userDTO.getSltPassword());

        /*
         * Tester si le oldPassword c'est bien le mot de passe actuel
         * @Todo à vérifier le login est bien même celui de (JWT)
         */
        if (ObjectUtils.allNotNull(detailConnexionDTO.getOldPassword(), userDTO.getPassword()) &&
                !StringUtils.equals(oldHashedSaltedPwd, userDTO.getPassword())) {
            contextParams.put("oldPassword", detailConnexionDTO.getOldPassword());
            throw new FunctionnalException(Constantes.MAJ_TEXT_BAD_PASSWORD, Constantes.MAJ_TEXT_BAD_PASSWORD, contextParams);
        }

        /*
         * Vérifier si le mot de passe a été changé dans les derniers 24 heures
         */
        if (userDTO.getDateMajPsw() != null) {
            LocalDateTime now = LocalDateTime.now();
            OffsetDateTime dateTimeAccess24h = userDTO.getDateMajPsw().plusDays(1);
            if (now.atOffset(offset).isBefore(dateTimeAccess24h)) {
                throw new FunctionnalException(Constantes.LOGIN_ERROR_MAJ_PSW_24H, Constantes.LOGIN_ERROR_MAJ_PSW_24H, contextParams);
            }
        }

        /*
         * nouveau mot de passe doit contenir au moins un caractére spécial
         */
        if (hasSpecialCharacter(detailConnexionDTO.getNewPassword())) {
            contextParams.put(NEW_PASSWORD, detailConnexionDTO.getNewPassword());
            throw new FunctionnalException(Constantes.MAJ_TEXT_CHAR_SPECIAL, Constantes.MAJ_TEXT_CHAR_SPECIAL, contextParams);
        }
        /*
         * nouveau mot de passe doit contenir au moins un digit
         */
        if (!hasNumber(detailConnexionDTO.getNewPassword())) {
            contextParams.put(NEW_PASSWORD, detailConnexionDTO.getNewPassword());
            throw new FunctionnalException(Constantes.MAJ_TEXT_NUMBER, Constantes.MAJ_TEXT_NUMBER, contextParams);
        }

        /*
         * nouveau mot de passe doit contenir au moins une lettre en majuscule
         */
        if (!containsUpperCase(detailConnexionDTO.getNewPassword())) {
            contextParams.put(NEW_PASSWORD, detailConnexionDTO.getNewPassword());
            throw new FunctionnalException(Constantes.MAJ_TEXT_UPPER_CASE, Constantes.MAJ_TEXT_UPPER_CASE, contextParams);
        }

        /*
         * nouveau mot de passe doit contenir au moins une lettre en miniscule
         */
        if (!containsLowerCase(detailConnexionDTO.getNewPassword())) {
            contextParams.put(NEW_PASSWORD, detailConnexionDTO.getNewPassword());
            throw new FunctionnalException(Constantes.MAJ_TEXT_LOWER_CASE, Constantes.MAJ_TEXT_LOWER_CASE, contextParams);
        }

        /*
         * nouveau mot de passe doit etre entre 12 et 16 de longueur
         */
        if (detailConnexionDTO.getNewPassword().length() < 12 || detailConnexionDTO.getNewPassword().length() > 16) {
            contextParams.put(NEW_PASSWORD, detailConnexionDTO.getNewPassword());
            throw new FunctionnalException(Constantes.MAJ_TEXT_LENGTH, Constantes.MAJ_TEXT_LENGTH, contextParams);
        }

        if (detailConnexionDTO.getNewPassword().contains(detailConnexionDTO.getLogin())
                || containsSequence(detailConnexionDTO.getNewPassword())) {
            throw new FunctionnalException(Constantes.MAJ_PASSWORD_WEAK, Constantes.MAJ_PASSWORD_WEAK, contextParams);
        }



        /*
         * Recuperer les trois derniers mot de passe utilisés
         * Appel au fontion stockée: UPI_UTIL_IS_LAST_PWD
         */
        if (iUpdatePasswordRepository.getHistoricPasswords(detailConnexionDTO.getLogin(), encryptedPassword, 3) > 0) {
            contextParams.put(NEW_PASSWORD, detailConnexionDTO.getNewPassword());
            throw new FunctionnalException(Constantes.MAJ_TEXT_USED, Constantes.MAJ_TEXT_USED, contextParams);
        }

        iAuthenticateRepository.updateNbAcces(detailConnexionDTO.getLogin());
        iAuthenticateRepository.updateNbEssai(detailConnexionDTO.getLogin(), 0);

        /*
         * If all thing goes well then proceed to
         * updating password with the new one hached and crypted: newPassword
         */
        iUpdatePasswordRepository.updatePassword(detailConnexionDTO.getLogin(), encryptedPassword);
    }


}
