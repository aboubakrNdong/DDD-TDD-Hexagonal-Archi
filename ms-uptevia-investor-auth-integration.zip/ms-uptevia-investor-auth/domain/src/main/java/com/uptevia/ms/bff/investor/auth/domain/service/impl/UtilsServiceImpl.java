package com.uptevia.ms.bff.investor.auth.domain.service.impl;

import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.service.UtilsService;

public class UtilsServiceImpl implements UtilsService{

    private IAuthenticateRepository iAuthenticateRepository;

    public UtilsServiceImpl(final IAuthenticateRepository iAuthenticateRepository) {
        this.iAuthenticateRepository = iAuthenticateRepository;
    }
    
    @Override
    public boolean isLoginUpiNotExist(String login) {
        UserDTO userDTO = iAuthenticateRepository.getUpiUtilUser(login);
        return userDTO == null;
    }
    
}
