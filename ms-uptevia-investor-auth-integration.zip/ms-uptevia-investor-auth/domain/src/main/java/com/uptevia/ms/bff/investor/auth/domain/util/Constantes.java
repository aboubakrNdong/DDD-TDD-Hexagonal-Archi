package com.uptevia.ms.bff.investor.auth.domain.util;


/**
 * <b>Description : Classe utilitaire contenant des constantes utilisees frequemment</b>
 *
 * @author Farhat Bouchnak
 */
public class Constantes {

    private Constantes() {

    }


    public static final String OTP_NEW_GENERATION = "OTP_NEW_GENERATION";

    public static final String ERROR_IN_SMS_REQUEST = "ERROR_IN_SMS_REQUEST";

    public static final String X_UPI_AUTH = "X-UPI-AUTH";

    public static final int STATUS_400 = 400;

    public static final String MANDATORY_FIELD = "form.field.validator.mandatory";

    public static final Integer NOMBRE_ESSAI = 3;

    public static final String SECRET_QUESTION_BAD_ANSWER1 = "secret.text.BadAnswer1";


    public static final String SECRET_QUESTION_BAD_ANSWER2 = "secret.text.BadAnswer2";

    public static final String SECRET_QUESTION_BAD_QUESTION1 = "secret.text.BadQuestion1";

    public static final String SECRET_QUESTION_BAD_QUESTION2 = "secret.text.BadQuestion2";

    public static final String LOGIN_TEXT_BAD_SURNAME = "login.text.BadSurname";

    public static final String LOGIN_TEXT_BAD_FIRSTNAME = "login.text.BadFirstName";

    public static final String LOGIN_TEXT_BAD_DOB = "login.text.Baddob";

    public static final String LOGIN_TEXT_BAD_PHONE = "login.text.BadPhone";

    public static final String LOGIN_TEXT_BAD_EMAIL = "login.text.BadEmail";

    public static final String LOGIN_TEXT_BAD_EMETNAME = "login.text.BadEmetname";

    public static final String LOGIN_TEXT_BAD_NUMCOMPTE = "login.text.BadNumcompte";


    public static final String LOGIN_ERROR_WITHOUT_PASSWORD = "login.error.without.password";

    public static final String LOGIN_TEXT_BAD_CREDENTIALS = "login.text.BadCredentials";

    public static final String LOGIN_ERROR_MAJ_PSW_24H = "login.error.maj.psw.24h";

    public static final String LOGIN_ERROR_MAJ_PSW_24H_SECURITY = "login.error.maj.psw.24h.security";

    public static final String LOGIN_TEXT_BLOCKING = "login.text.blocking";

    public static final String LOGIN_ERROR_PASSWORD_EXPIRED = "login.error.password.expired";

    public static final String LOGIN_ERROR_DATE_VALIDITY_END = "login.error.date.validite.fin";

    public static final String EMPTY_DATA_EXCEPTION = "Empty_Data_Exception";

    public static final String MULTI_DATA_EXCEPTION = "Multi_Data_Exception";

    public static final String UPI_UTIL_GET_BY_LOGIN = "UPI_UTIL_GET_BY_LOGIN";
    public static final String UPI_UTIL_UPDATE_NB_ACCES = "UPI_UTIL_UPDATE_NB_ACCES";

    public static final String UPI_UTIL_UPDATE_NB_ESSAI = "UPI_UTIL_UPDATE_NB_ESSAI";

    public static final String UPI_UTIL_UPDATE_DATE_MAJ_OTP = "UPI_UTIL_UPDATE_DATE_MAJ_OTP";

    public static final String PARAM_LOGIN = "PARAM_LOGIN";

    public static final String PARAM_PASSWORD = "PARAM_PASSWORD";
    public static final String PARAM_USER_MAJ = "PARAM_USER_MAJ";

    public static final String UPI_UTIL_GET_BY_LOGIN_OLIS = "UPI_UTIL_GET_BY_LOGIN_OLIS";

    public static final String PS_CUR = "PS_CUR";

    public static final String BAD_OPERATIONS_PASSWORD = "operation.text.wrong.password";

    public static final String TRY_PARAM = "essai";

    public static final String MAJ_TEXT_BAD_PASSWORD = "majpassword.text.badPassword";
    public static final String MAJ_PASSWORD_WEAK = "password.text.weak";
    public static final String MAJ_TEXT_CHAR_SPECIAL = "majpassword.text.charspecial";

    public static final String MAJ_TEXT_NUMBER = "majpassword.text.number";

    public static final String MAJ_TEXT_UPPER_CASE = "majpassword.text.upperCase";

    public static final String MAJ_TEXT_LOWER_CASE = "majpassword.text.lowerCase";

    public static final String MAJ_TEXT_LENGTH = "majpassword.text.length";

    public static final String MAJ_TEXT_USED = "majpassword.text.used";

    public static final String MAIL_MDP_PERDU = "MAIL_MDP_PERDU";

    public static final String SECRET_QUESTIONS = "SECRET_QUESTIONS";

    public static final String JSON_PARAM_EMAIL = "em";
    public static final String JSON_PARAM_LOGIN = "lg";
    public static final String JSON_PARAM_ACTION = "action";
    public static final String JSON_PARAM_TIME = "time";
    public static final long DELAY = 1440; // exprimé en minutes
    public static final String UPI_UTIL_GET_BY_LOGIN_PLANETSHARES = "UPI_UTIL_GET_BY_LOGIN_PLANETSHARES";

    public static final String AUTHORIZATION = "Authorization";
    public static final String MAIL_NOT_IN_WHITELIST = "form.field.validator.mailwhitelist";

    public static final String PHONE_NOT_IN_WHITELIST = "form.field.validator.phonewhitelist";
    public static final String PHONE_NOT_FOUND = "form.field.validator.noPhone";


    public static final String UPI_UTIL_CPTE_UPDATE_CGU = "UPI_UTIL_CPTE_UPDATE_CGU";

    public static final String UPI_REVOKED_TOKEN_GET_ALL = "UPI_REVOKED_TOKEN_GET_ALL";
}
