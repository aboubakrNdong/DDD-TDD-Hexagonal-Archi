package com.uptevia.ms.bff.investor.auth.domain.util;
/*
 * Cette classe a pour objectif de fournir des outils de cryptage et hashage des mot
 * de passes, des questions secrètes ou tout autre outil utilisé pour
 * sécuriser les comptes d'un utilisateur
 *
 */


import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;


public class ToolsManager {



    /* Declaration of variables */
    private static final String CHARACTERS = "$#0123456789@%&ABCDEFabcdefGHIJKLMghijklmNOPQRSTUVWXYZnopqrstuvwxyz";
    private static final int ITERATIONS = 10000;
    private static final int  KEY_LENGTH = 256;

    private static final String RSA = "RSA/ECB/OAEPWITHSHA-256ANDMGF1PADDING";

    public static final String IV_PARAMETER_SPEC 	= "P8PoFEsef548Uhet"; 	//vector
    public static final String SECRET_KEY 			= "srjcaplg8e354dg0";


    public static final String SECRET_KEY_FRONT  = "MbE+H56GBRxflJ8="; // Use the same secret key you used for encryption

    private static final String ALGORITHM = "AES";
    private static final String MODE_PADDING = "AES/ECB/PKCS5Padding";

    private static final Logger LOG = LoggerFactory.getLogger("ToolsManager");

    /*
     * private constructor for  utility classes
     */
    private ToolsManager(){

    }


    /* Method to generate the salt value. */
    public static String getSaltValue(final int length, final String pwdReversed)
    {
        StringBuilder saltValue = new StringBuilder(length);

        for (int i = 1; i <= length; i++)
        {
            if(pwdReversed.length() > i){
                saltValue.append(CHARACTERS.charAt(pwdReversed.length() - i));
            }
        }

        return new String(saltValue);
    }

    /* Method to generate the hash value */
    public static byte[] hash(final char[] password, final byte[] salt)
    {
        PBEKeySpec spec = new PBEKeySpec(password, salt, ITERATIONS, KEY_LENGTH);
        Arrays.fill(password, Character.MIN_VALUE);
        try
        {
            SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            return skf.generateSecret(spec).getEncoded();
        }
        catch (NoSuchAlgorithmException | InvalidKeySpecException e)
        {
            throw new AssertionError("Error while hashing a password: " + e.getMessage(), e);
        }
        finally
        {
            spec.clearPassword();
        }
    }

    /* Method to encrypt the password using the original password and salt value. */
    public static String generateSecurePassword(final String password, final String salt)
    {
        String securedPassword;

        byte[] securePassword = hash(password.toCharArray(), salt.getBytes());

        securedPassword = Base64.getEncoder().encodeToString(securePassword);

        return securedPassword;
    }

    /* Method to verify if both password matches or not */
    public static boolean verifyUserPassword(final String providedPassword, final String securedPassword, final String salt)
    {
        boolean verify;

        /* Generate New secure password with the same salt */
        String newSecurePassword = generateSecurePassword(providedPassword, salt);
        /* Check if two passwords are equal */
        verify = newSecurePassword.equalsIgnoreCase(securedPassword);

        return verify;
    }


    public static String encrypt(final String strClearText, final String strKey) {

        String encryption = "";

        try {
            SecretKeySpec sKeySpec = new SecretKeySpec(strKey.getBytes(), RSA);
            Cipher cipher = Cipher.getInstance(RSA);
            cipher.init(Cipher.ENCRYPT_MODE, sKeySpec);
            byte[] encrypted = cipher.doFinal(strClearText.getBytes());
            encryption = new String(encrypted);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return encryption;
    }

    public static String decrypt(final String strEncrypted, final String strKey) {

        String decryption = "";

        try {
            SecretKeySpec sKeySpec=new SecretKeySpec(strKey.getBytes(), RSA);
            Cipher cipher = Cipher.getInstance(RSA);
            cipher.init(Cipher.DECRYPT_MODE, sKeySpec);
            byte[] decrypted = cipher.doFinal(strEncrypted.getBytes());
            decryption = new String(decrypted);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return decryption;
    }


    // Méthode copiée de EncryptUtils de com.caceis.olis2.util
    public static String asHex(byte buf[]) {
        StringBuffer strbuf = new StringBuffer(buf.length * 2);
        for (int index = 0; index < buf.length; index++) {
            if (((int) buf[index] & 0xff) < 0x10) {
                strbuf.append("0");
            }
            strbuf.append(Long.toString((int) buf[index] & 0xff, 16));
        }
        return strbuf.toString();
    }

    // Méthode copiée de EncryptUtils de com.caceis.olis2.util
    public static byte[] encryptJSONStringToBytes(String pSecretKey, String vector, String pJsonString) {
        byte[] result = null;
        if (StringUtils.isNoneBlank(pSecretKey, pJsonString )) {
            try {
                byte[] keyData = pSecretKey.getBytes();
                SecretKey key = new SecretKeySpec(keyData, "AES");
                IvParameterSpec ivSpec = new IvParameterSpec(vector.getBytes());
                Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
                cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);
                // The String is padded with the good size.
                String chaineToEncryp = new String(pJsonString);
                int blocksize = cipher.getBlockSize();
                int remainder = chaineToEncryp.length() % blocksize;
                if (remainder > 0) {
                    chaineToEncryp = org.apache.commons.lang3.StringUtils.rightPad(chaineToEncryp, chaineToEncryp.length() - remainder + blocksize);
                }
                result = cipher.doFinal(chaineToEncryp.getBytes());
            } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalStateException |
                     IllegalBlockSizeException | BadPaddingException | InvalidAlgorithmParameterException e) {
                LOG.error("*Erreur", e);
            }

        }
        return result;
    }


    // Méthode copiée de EncryptUtils de com.caceis.olis2.util
    public static byte[] decryptAes(byte[] cipherText) {
        SecretKey key = new SecretKeySpec(SECRET_KEY.getBytes(), "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(IV_PARAMETER_SPEC.getBytes());
        Cipher cipher;
        byte[] clearText = null;
        try {
            cipher = Cipher.getInstance("AES/CBC/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key, ivSpec);
            clearText = cipher.doFinal(cipherText);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
            LOG.error("*Erreur lors du décrytage AES", e);
        }

        return clearText;
    }

    public static String decryptSecretAnswer(String stringToDecrypt) throws IOException {

        String stringDecrypted = "";
        try {
            if (StringUtils.isBlank(stringToDecrypt)) {
                return null;
            }
            byte[] bSd = ToolsManager.hexToByteArray(stringToDecrypt);
            bSd = ToolsManager.decryptAes(bSd);
            stringDecrypted = new String(bSd);

        } catch (Exception e1) {
            return null;
        }


        return stringDecrypted.trim();
    }



    // Méthode copiée de EncryptUtils de com.caceis.olis2.util
    public static byte[] hexToByteArray(String s) {

        byte data[] = new byte[s.length()/2];
        for (int i = 0; i < data.length; i++) {
            data[i] = Integer.decode("#"+s.charAt(i*2)+s.charAt(i*2+1)).byteValue();
        }
        return data;
    }

    public static boolean isDateOneDayAhead(OffsetDateTime givenDate) {
        if(givenDate == null)
            return true;
        OffsetDateTime currentDate = OffsetDateTime.now();
        return currentDate.isAfter(givenDate.plus(1, ChronoUnit.DAYS));
    }


    public static byte[] decryptAesForFront(byte[] cipherText) {
        SecretKey key = new SecretKeySpec(SECRET_KEY_FRONT.getBytes(), "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(IV_PARAMETER_SPEC.getBytes());
        Cipher cipher;
        byte[] clearText = null;
        try {
            cipher = Cipher.getInstance("AES/CBC/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key, ivSpec);
            clearText = cipher.doFinal(cipherText);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
            LOG.error("*Erreur lors du décrytage AES", e);
        }

        return clearText;
    }

    public static String decryptForFront(String chaine){
        byte[] bSd = ToolsManager.hexToByteArray(chaine);
        bSd = ToolsManager.decryptAesForFront(bSd);
        String decrypt = new String(bSd);
        return decrypt.trim();
    }

    public static String decryptFrontParam(String encryptedPayload) throws Exception {
        byte[] encryptedBytes = Base64.getDecoder().decode(encryptedPayload);
        byte[] keyBytes = SECRET_KEY.getBytes("UTF-8");
        SecretKeySpec secretKeySpec = new SecretKeySpec(keyBytes, "AES");

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        byte[] ivBytes = new byte[16]; // You’ll need the initialization vector used during encryption
        IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);

        cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivSpec);
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

        String  cle = String.valueOf(generateKey(32));

        return new String(decryptedBytes, "UTF-8");
    }

    public static SecretKey generateKey(int n) throws NoSuchAlgorithmException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(n);
        SecretKey key = keyGenerator.generateKey();
        return key;
    }


    public static String decryptFromFront(String encryptedText) {
        try {
            SecretKeySpec key = new SecretKeySpec(SECRET_KEY_FRONT.getBytes(), ALGORITHM);
            Cipher cipher = Cipher.getInstance(MODE_PADDING);
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedText));
            return new String(decryptedBytes);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null; //Si rien de décryté
    }


}
