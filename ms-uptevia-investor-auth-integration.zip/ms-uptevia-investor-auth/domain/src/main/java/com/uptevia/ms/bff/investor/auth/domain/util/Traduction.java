package com.uptevia.ms.bff.investor.auth.domain.util;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.MailTraductionDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.TraductionDTO;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.IForgotRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
// import org.apache.commons.text.StringSubstitutor;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Traduction {
    private Traduction(){

    }

    private final Logger logger = LoggerFactory.getLogger(this.getClass());


/*    public static String getTexte(String key, String lang) {

        String  url = baseRessource + "/api/v1/traduction/" + key + "/" + lang+ "/";
        return "Réinitialisation de votre mot de passe";

        TraductionDTO[] traductions = restTemplate.getForObject(url, TraductionDTO[].class);

        if (traductions != null && traductions.length > 0) {
            return traductions[0].getLibelle();
        } else{
            return key;
        }
    }*/

  /*  public static String getTextInLang(String keyText, String lang,  Map<String, String> parameters) {
        //TODO mettre clé de trad
        String baseString = "Votre code Uptevia se trouve ci-aprés : ${1}. Pas à l'origine de la demande, contactez-nous via les accès habituels. Il expirera dans 10 minutes.";

        StringSubstitutor substitutor = new StringSubstitutor(parameters);
        return   substitutor.replace(baseString);
    }*/

    //TODO enhance mapping lang Front and Back
    public static String getLangue(String lang){

        Map<String, String> mapLangue = new HashMap<>();

        mapLangue.put("en", "ENG");
        mapLangue.put("fr", "FRA");
        mapLangue.put("de", "DEU");
        mapLangue.put("es", "ESP");
        mapLangue.put("pt", "PRT");
        mapLangue.put("it", "ITA");
        mapLangue.put("nl", "NLD");

        return mapLangue.get(lang);
    }

    //TODO enhance getLibelle: save all trad in cache, and use Cacheable

    public static String iTerateOverTrad(List<MailTraductionDTO> listLibelle, String keyTrad) {

        String libelleFromDb = "";

        //Iterate over all key to get Libelle
        Iterator<MailTraductionDTO> iterator = listLibelle.iterator();

        while ((iterator.hasNext())) {
            MailTraductionDTO allTrads = iterator.next();
            if (allTrads.getKey().toString().equals(keyTrad)) {
                libelleFromDb = allTrads.getLibelle();
                System.out.println("the trad is"+ libelleFromDb);
                return libelleFromDb;
            }
        }

        if(libelleFromDb.isEmpty()){
            System.out.println("the trad do not exist in DB");
            return keyTrad;
        } else {
            return libelleFromDb;
        }
    }
}
