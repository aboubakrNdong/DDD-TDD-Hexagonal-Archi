package com.uptevia.ms.bff.investor.auth.domain.utils.jwt;


import java.security.Key;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.LogOutRequestDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.auth.domain.repository.IPropertiesRepository;
import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.UnsupportedJwtException;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JwtUtils {

    private int jwtExpirationMs;
    private String secretKey;

    public JwtUtils(IPropertiesRepository propertiesRepository) {
        this.jwtExpirationMs = propertiesRepository.getJwtExpirationMs();
        this.secretKey = propertiesRepository.getSecretKey();
    }

    private final List<Object> loggedOutUsers = new CopyOnWriteArrayList<>();

    private static final SignatureAlgorithm algorithm = SignatureAlgorithm.HS256;

    public String generateJwtToken(final UserDTO userDTO) {

        Map<String, Object> claims = new HashMap<>();
        claims.put("subject", userDTO.getLogin());
        claims.put("emetIden", userDTO.getEmetIden());
        claims.put("actiIden", userDTO.getActiIden());
        claims.put("titunume", userDTO.getTituNume());

        //Build Token signed with HS256 signature
        return Jwts.builder()
                .claims(claims)
                .setSubject(userDTO.getLogin())
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date((new Date()).getTime() + jwtExpirationMs))
                .signWith(key(), algorithm)
                .compact();
    }

    //generate secure key from java.security to sign jwt token
    private Key key() {
        return new SecretKeySpec(secretKey.getBytes(), algorithm.getJcaName());
    }

    //Extract subject as username  from JWT  token
    public String getUserNameFromJwtToken(final String token) {
        return Jwts.parser().setSigningKey(key()).build()
                .parseClaimsJws(token).getBody().getSubject();
    }

    public boolean validateJwtToken(final String authToken) {
        try {
            log.info("Begin parsing JWT token ...");
            Jwts.parser().setSigningKey(key()).build().parse(authToken);
            return true;
        } catch (MalformedJwtException e) {
            log.error("Invalid JWT token: {}", e.getMessage());
        } catch (ExpiredJwtException e) {
            log.error("JWT token is expired: {}", e.getMessage());
        } catch (UnsupportedJwtException e) {
            log.error("JWT token is unsupported: {}", e.getMessage());
        } catch (IllegalArgumentException e) {
            log.error("JWT claims string is empty: {}", e.getMessage());
        }
        log.error("Begin parsing jwt token");
        return false;
    }

    public String resolveToken(final HttpServletRequest req) {
        String bearerToken = req.getHeader(Constantes.AUTHORIZATION);
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7, bearerToken.length());
        }
        if (bearerToken != null) {
            return bearerToken;
        }
        return null;
    }

    public Claims getAllClaimsFromToken(String bearerToken) {
        if (bearerToken != null && bearerToken.startsWith("Bearer "))
            bearerToken = bearerToken.substring(7, bearerToken.length());
        return Jwts.parser().verifyWith((SecretKey) key()).build().parseSignedClaims(bearerToken).getPayload();
    }

    /**
     * get the expiration date from the JWT token
     *
     * @param token
     * @return Date
     */
    public Date getTokenExpiryFromJWT(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(key())
                .build()
                .parseSignedClaims(token)
                .getBody();

        return claims.getExpiration();
    }


    /**
     * update the logged-out user's list every some minutes
     *
     * @param revokedTokens
     */

    public void updateLoggedOutUsers(List<LogOutRequestDTO> revokedTokens) {
        this.loggedOutUsers.clear();
        this.loggedOutUsers.addAll(revokedTokens.stream()
                .map(myRevokedToken -> new LogOutRequestDTO(myRevokedToken.getUsername(), myRevokedToken.getToken(), OffsetDateTime.now(),
                        this.getTokenExpiryFromJWT(myRevokedToken.getToken()).toInstant()
                        .atOffset(ZoneOffset.UTC))).toList());
    }

    /**
     * add a check to validate a JWT Token to perform an extra check to see if the incoming token is present in the blacklist or not
     * @param authToken
     */

    private void validateTokenIsNotForALoggedOutDevice(final String authToken) throws FunctionnalException {

        if (authToken != null && this.loggedOutUsers.stream().noneMatch(auToken -> auToken.equals(authToken))) {
            String errorMessage = String.format("Token corresponds to an already logged out user [%s]. Please login again", this.getUserNameFromJwtToken(authToken));
            throw new FunctionnalException("JWT", errorMessage);
        }
    }

}
