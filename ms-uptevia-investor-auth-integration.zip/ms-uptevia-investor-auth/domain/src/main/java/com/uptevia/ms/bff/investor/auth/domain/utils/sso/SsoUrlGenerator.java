package com.uptevia.ms.bff.investor.auth.domain.utils.sso;

import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;

public class SsoUrlGenerator {
    public static String SSO_ROUTE_NAME = "#/sso/";
    private UserDTO userDTO;

    public SsoUrlGenerator(UserDTO userDTO) {
        this.userDTO = userDTO;
    }

    public String generateUrl() {
        String url = SSO_ROUTE_NAME + userDTO.getToken();
        return url;
    }
}
