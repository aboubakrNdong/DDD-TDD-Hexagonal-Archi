package com.uptevia.ms.bff.investor.auth.domain.configuration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ActiveProfiles;

import com.uptevia.ms.bff.investor.auth.domain.repository.AuthenticateRepositoryTest;
import com.uptevia.ms.bff.investor.auth.domain.repository.IPropertiesRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.TestPropertiesRepository;
import com.uptevia.ms.bff.investor.auth.domain.service.SsoService;
import com.uptevia.ms.bff.investor.auth.domain.service.impl.SsoServiceImpl;
import com.uptevia.ms.bff.investor.auth.domain.utils.jwt.JwtUtils;

@Configuration
@ActiveProfiles("test")
public class TestConfiguration {
    
    @Bean
    SsoService getSsoService(AuthenticateRepositoryTest authenticateRepository, TestPropertiesRepository propertiesRepository) {
        return new SsoServiceImpl(authenticateRepository, propertiesRepository);
    }

    @Bean
    JwtUtils getJwtUtils(TestPropertiesRepository propertiesRepository) {
        return new JwtUtils(propertiesRepository);
    }
}

