package com.uptevia.ms.bff.investor.auth.domain.other;

public class TestData {
    public static String TEST_LOGIN = "99970827";
    public static String TEST_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJzdWJqZWN0IjoiOTk5NzA4MjciLCJzdWIiOiI5OTk3MDgyNyIsImlhdCI6MTcxMjkwODE3NCwiZXhwIjoxNzEyOTA4MTc1fQ.6rIcO_0Uz4pfmqehWK1mkKda-XhHE5uJJ0SvYTwoO4A";
}
