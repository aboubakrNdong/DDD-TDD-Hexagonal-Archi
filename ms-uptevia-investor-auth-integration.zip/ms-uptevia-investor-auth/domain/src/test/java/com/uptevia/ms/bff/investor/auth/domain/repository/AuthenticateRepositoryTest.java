package com.uptevia.ms.bff.investor.auth.domain.repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.EabonnementDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.LogOutRequestDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.SendSmsDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserPlanetShareDTO;

public class AuthenticateRepositoryTest implements IAuthenticateRepository{

    @Override
    public UserDTO authenticate(String login, String password) throws FunctionnalException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'authenticate'");
    }

    @Override
    public Long updateNbAcces(String login) throws FunctionnalException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateNbAcces'");
    }

    @Override
    public Long updateNbEssai(String login, int number) throws FunctionnalException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateNbEssai'");
    }

    @Override
    public List<UserDTO> ancientOlisAccount(String login) throws FunctionnalException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'ancientOlisAccount'");
    }

    @Override
    public List<UserPlanetShareDTO> ancientPlanetShare(Integer emetIden, String accessCode)
            throws FunctionnalException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'ancientPlanetShare'");
    }

    @Override
    public UserDTO getUpiUtilUser(String login) {
        UserDTO user = UserDTO.builder()
            .login(login)
            .build();
        return user;
    }

    @Override
    public Long updateDateMajOtp(String login) throws FunctionnalException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateDateMajOtp'");
    }

    @Override
    public void acceptCgu(EabonnementDTO eabonnementDTO) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'acceptCgu'");
    }

    @Override
    public String validateToken(String login, String token, String useCase) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'validateToken'");
    }

    @Override
    public BigDecimal requestToken(String login, String token, String useCase) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'requestToken'");
    }

    @Override
    public List<String> getWhitelist(String typeWhitelist) throws FunctionnalException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getWhitelist'");
    }

    @Override
    public String validateOtpCode(String login, String otpCode) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'validateOtpCode'");
    }

    @Override
    public String requestOtp(String login, String lang) throws FunctionnalException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'requestOtp'");
    }

    @Override
    public Map<String, String> sendSms(SendSmsDTO sendSmsDTO) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'sendSms'");
    }

    @Override
    public long logout(LogOutRequestDTO logOutRequestDTO) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'logout'");
    }

    @Override
    public List<LogOutRequestDTO> findAllRevokedTokens() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAllRevokedTokens'");
    }
    
}
