package com.uptevia.ms.bff.investor.auth.domain.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Qualifier("test")
public class TestPropertiesRepository implements IPropertiesRepository{

    private String frontUrl = "www.test-upi.com";
    private int jwtExpirationMs = 1000;
    private String secretKey = "my-test-secret-key-is-so-secret-that-no-one-will-find-it";

    @Override
    public String getFrontUrl() {return frontUrl;}
    @Override
    public int getJwtExpirationMs() {return jwtExpirationMs;}
    @Override
    public String getSecretKey() {return secretKey;}

    @Test
    public void shouldGetFrontUrl() {
        //GIVEN
        //WHEN
        String url = this.getFrontUrl();
        //THEN
        assertEquals(url, this.frontUrl);
    }

    @Test
    void shouldGetJwtExpirationMs(){
        //GIVEN
        //WHEN
        int jwtExpirationMs = this.getJwtExpirationMs();    
        //THEN
        assertEquals(jwtExpirationMs, this.jwtExpirationMs);
    }

    @Test
    public void shouldGetSecretKey() {
        //GIVEN
        //WHEN
        String key = this.getSecretKey();
        //THEN
        assertEquals(key, this.secretKey);
    }
}
