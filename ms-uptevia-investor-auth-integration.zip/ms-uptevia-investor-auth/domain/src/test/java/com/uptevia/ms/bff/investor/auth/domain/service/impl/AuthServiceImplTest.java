package com.uptevia.ms.bff.investor.auth.domain.service.impl;


import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.LoginRequestDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.SecretQuestionsDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserPlanetShareDTO;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class AuthServiceImplTest {

    @Mock
    private IAuthenticateRepository iAuthenticateRepository;

    @InjectMocks
    AuthServiceImpl authService;

    private final EasyRandom easyRandom = new EasyRandom();

    private final LoginRequestDTO loginRequestDTO = LoginRequestDTO.builder()
            .login("99963514")
            .password("1")
            .build();

    @BeforeEach
    public void setUp() {
        authService = new AuthServiceImpl(iAuthenticateRepository);
    }


    // TODO : adapt
    /*@Test
    void should_return_authenticate_ok() throws Exception {

        ZoneOffset offset = OffsetDateTime.now().getOffset();
        LocalDateTime dateTimeAccess = LocalDateTime.now();
        String login = "99963514";
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        String hashedSaltedPwd = DigestUtils.sha256Hex(loginRequestDTO.getPassword() + userDTO.getSltPassword());
        userDTO.setIndiCompteBloque(false);
        userDTO.setDateMajPsw(dateTimeAccess.minusDays(3).atOffset(offset));
        userDTO.setIndiWillBePwdExpired(false);
        userDTO.setDateValiditeFin(null);
        userDTO.setPassword(hashedSaltedPwd);
        Mockito.when(iAuthenticateRepository.authenticate(login, loginRequestDTO.getPassword())).thenReturn(userDTO);
        Mockito.when(iAuthenticateRepository.updateNbEssai(login, 0)).thenReturn(1L);
        Mockito.when(iAuthenticateRepository.updateNbAcces(login)).thenReturn(1L);

        Assertions.assertThat(authService.authenticate(loginRequestDTO)).isEqualTo(userDTO);
    }*/

    @Test
    void should_throws_login_error_without_password() throws Exception {

        String login = "99963514";
        String psw = "1";

        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        userDTO.setPassword(null);

        Mockito.when(iAuthenticateRepository.authenticate(login, psw)).thenReturn(userDTO);

        FunctionnalException exception = assertThrows(FunctionnalException.class, () ->
                authService.authenticate(loginRequestDTO));

        assertEquals("login.error.without.password", exception.getCode());

    }

    @Test
    void should_throws_login_text_bad_credentials() throws Exception {

        String login = "99963514";
        ZoneOffset offset = OffsetDateTime.now().getOffset();
        LocalDateTime dateTimeAccess = LocalDateTime.now();
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        loginRequestDTO.setPassword(userDTO.getPassword());
        userDTO.setPassword("faux-pwd");
        userDTO.setDateMajPsw(dateTimeAccess.minusDays(3).atOffset(offset));
        userDTO.setIndiCompteBloque(false);
        Mockito.when(iAuthenticateRepository.authenticate(login, loginRequestDTO.getPassword())).thenReturn(userDTO);
        Mockito.when(iAuthenticateRepository.updateNbEssai(login, 1)).thenReturn(1L);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () ->
                authService.authenticate(loginRequestDTO));

        assertEquals("login.text.BadCredentials", exception.getCode());
    }

    @Test
    void should_throws_login_text_blocking() throws Exception {

        String login = "99963514";
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        //authService.setNbAccess(3);
        loginRequestDTO.setPassword(userDTO.getPassword());
        userDTO.setPassword("faux-pwd");
        userDTO.setIndiCompteBloque(true);
        userDTO.setIndiWillBePwdExpired(false);
        userDTO.setDateValiditeFin(null);
        OffsetDateTime now = OffsetDateTime.now().minusDays(10);
        userDTO.setDateMajPsw(now);
        Mockito.when(iAuthenticateRepository.authenticate(login, loginRequestDTO.getPassword())).thenReturn(userDTO);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () ->
                authService.authenticate(loginRequestDTO));
        assertEquals("login.text.blocking", exception.getCode());

    }

    @Test
    void should_throws_login_error_password_expired() throws Exception {

        String login = "99963514";
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        userDTO.setIndiCompteBloque(false);
        userDTO.setIndiPwdExpire(true);
        userDTO.setDateValiditeFin(null);
        loginRequestDTO.setPassword(userDTO.getPassword());
        String encryptedPassword = DigestUtils.sha256Hex(loginRequestDTO.getPassword() + userDTO.getSltPassword());
        userDTO.setPassword(encryptedPassword);
        OffsetDateTime now = OffsetDateTime.now().minusDays(10);
        userDTO.setDateMajPsw(now);
        Mockito.when(iAuthenticateRepository.authenticate(login, loginRequestDTO.getPassword())).thenReturn(userDTO);

        FunctionnalException exception = assertThrows(FunctionnalException.class, () ->
                authService.authenticate(loginRequestDTO));

        assertEquals("login.error.password.expired", exception.getCode());

    }

    @Test
    void should_throws_login_error_validity_end_date() throws Exception {

        ZoneOffset offset = OffsetDateTime.now().getOffset();
        LocalDateTime dateTimeAcces = LocalDateTime.now();
        String login = "99963514";
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        userDTO.setIndiCompteBloque(false);
        userDTO.setIndiPwdExpire(false);
        // set date yesterday
        userDTO.setDateValiditeFin(dateTimeAcces.minusDays(1).atOffset(offset));
        loginRequestDTO.setPassword(userDTO.getPassword());
        String encryptedPassword = DigestUtils.sha256Hex(loginRequestDTO.getPassword() + userDTO.getSltPassword());
        userDTO.setPassword(encryptedPassword);
        OffsetDateTime now = OffsetDateTime.now().minusDays(10);
        userDTO.setDateMajPsw(now);
        Mockito.when(iAuthenticateRepository.authenticate(login, loginRequestDTO.getPassword())).thenReturn(userDTO);

        FunctionnalException exception = assertThrows(FunctionnalException.class, () ->
                authService.authenticate(loginRequestDTO));

        assertEquals("login.error.date.validite.fin", exception.getCode());

    }


    @Test
    void should_return_authenticate_olis_ok() throws Exception {

        ZoneOffset offset = OffsetDateTime.now().getOffset();
        LocalDateTime dateTimeAccess = LocalDateTime.now();
        String login = "99963514";
        List<UserDTO> userDTOS = easyRandom.objects(UserDTO.class, 3)
                .collect(Collectors.toList());
        UserDTO userDTO = userDTOS.get(0);
        String hashedSaltedPwd = DigestUtils.sha256Hex(loginRequestDTO.getLogin() + StringUtils.lowerCase(StringUtils.defaultIfBlank(userDTO.getEmail(), "")) + loginRequestDTO.getPassword());
                //DigestUtils.sha256Hex(loginRequestDTO.getPassword() + userDTO.getSltPassword());
        userDTO.setIndiCompteBloque(false);
        userDTO.setDateMajPsw(dateTimeAccess.minusDays(3).atOffset(offset));
        userDTO.setIndiWillBePwdExpired(false);
        userDTO.setDateValiditeFin(null);
        userDTO.setPassword(hashedSaltedPwd);
        Mockito.when(iAuthenticateRepository.ancientOlisAccount(login)).thenReturn(userDTOS);
        Mockito.when(iAuthenticateRepository.updateNbEssai(login, 0)).thenReturn(1L);
        Mockito.when(iAuthenticateRepository.updateNbAcces(login)).thenReturn(1L);

        Assertions.assertThat(authService.ancientOlisAccount(loginRequestDTO)).isEqualTo(userDTOS);
    }

    @Test
    void should_olis_throws_login_error_without_password() throws Exception {

        String login = "99963514";

        List<UserDTO> userDTOS = easyRandom.objects(UserDTO.class, 3).collect(Collectors.toList());
        Mockito.when(iAuthenticateRepository.ancientOlisAccount(login)).thenReturn(userDTOS);
        UserDTO userDTO = userDTOS.get(0);
        userDTO.setPassword(null);
        userDTO.setIndiCompteBloque(Boolean.FALSE);

        FunctionnalException exception = assertThrows(FunctionnalException.class, () ->
                authService.ancientOlisAccount(loginRequestDTO));

        assertEquals("login.error.without.password", exception.getCode());
    }

    @Test
    void should_olis_throws_login_text_bad_credentials() throws Exception {

        String login = "99963514";
        ZoneOffset offset = OffsetDateTime.now().getOffset();
        List<UserDTO> userDTOS = easyRandom.objects(UserDTO.class, 3).collect(Collectors.toList());
        LocalDateTime dateTimeAccess = LocalDateTime.now();
        UserDTO userDTO = userDTOS.get(0);
        loginRequestDTO.setPassword(userDTO.getPassword());
        userDTO.setPassword("faux-pwd");
        userDTO.setDateMajPsw(dateTimeAccess.minusDays(3).atOffset(offset));
        userDTO.setIndiCompteBloque(false);
        Mockito.when(iAuthenticateRepository.ancientOlisAccount(login)).thenReturn(userDTOS);
        Mockito.when(iAuthenticateRepository.updateNbEssai(login, 1)).thenReturn(1L);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () ->
                authService.ancientOlisAccount(loginRequestDTO));

        assertEquals("login.text.BadCredentials", exception.getCode());
    }

    @Test
    void should_olis_throws_login_text_blocking() throws Exception {

        String login = "99963514";
        List<UserDTO> userDTOS = easyRandom.objects(UserDTO.class, 3).collect(Collectors.toList());
        UserDTO userDTO = userDTOS.get(0);
        //authService.setNbAccess(3);
        loginRequestDTO.setPassword(userDTO.getPassword());
        userDTO.setIndiCompteBloque(true);
        Mockito.when(iAuthenticateRepository.ancientOlisAccount(login)).thenReturn(userDTOS);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () ->
                authService.ancientOlisAccount(loginRequestDTO));
        assertEquals("login.text.blocking", exception.getCode());
    }

    @Test
    void should_olis_throws_login_error_password_expired() throws Exception {

        String login = "99963514";
        List<UserDTO> userDTOS = easyRandom.objects(UserDTO.class, 3).collect(Collectors.toList());
        UserDTO userDTO = userDTOS.get(0);
        userDTO.setIndiCompteBloque(false);
        userDTO.setIndiPwdExpire(true);
        userDTO.setDateValiditeFin(null);
        loginRequestDTO.setPassword(userDTO.getPassword());
        String encryptedPassword = DigestUtils.sha256Hex(loginRequestDTO.getLogin() + StringUtils.lowerCase(StringUtils.defaultIfBlank(userDTO.getEmail(), "")) + loginRequestDTO.getPassword());
        userDTO.setPassword(encryptedPassword);
        OffsetDateTime now = OffsetDateTime.now().minusDays(10);
        userDTO.setDateValiditeFin(now);
        Mockito.when(iAuthenticateRepository.ancientOlisAccount(loginRequestDTO.getLogin())).thenReturn(userDTOS);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () ->
                authService.ancientOlisAccount(loginRequestDTO));

        assertEquals("login.error.date.validite.fin", exception.getCode());
    }


    @Test
    void should_planetShare_throws_login_text_bad_credentials() throws Exception {

        String login = "99963514";
        ZoneOffset offset = OffsetDateTime.now().getOffset();
        List<UserPlanetShareDTO> userPlanetShareDTOS = easyRandom.objects(UserPlanetShareDTO.class, 3).collect(Collectors.toList());
        LocalDateTime dateTimeAccess = LocalDateTime.now();
        UserPlanetShareDTO userPlanetShareDTO = userPlanetShareDTOS.get(0);
        loginRequestDTO.setPassword(userPlanetShareDTO.getPassword());
        userPlanetShareDTO.setPassword("faux-pwd");
        Mockito.when(iAuthenticateRepository.ancientPlanetShare(1234, "testtest")).thenReturn(userPlanetShareDTOS);
        FunctionnalException exception = assertThrows(FunctionnalException.class, () ->
                authService.ancientPlanetShare(1234, "testtest", "password"));

        assertEquals("login.text.BadCredentials", exception.getCode());
    }
}
