package com.uptevia.ms.bff.investor.auth.domain.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;

import com.uptevia.ms.bff.investor.auth.domain.model.SsoUrlDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.auth.domain.other.TestData;
import com.uptevia.ms.bff.investor.auth.domain.repository.AuthenticateRepositoryTest;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.IPropertiesRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.TestPropertiesRepository;
import com.uptevia.ms.bff.investor.auth.domain.utils.sso.SsoUrlGenerator;

public class SsoServiceImplTest {

    IAuthenticateRepository authenticateRepository = new AuthenticateRepositoryTest();
    IPropertiesRepository propertiesRepository = new TestPropertiesRepository();

    private SsoServiceImpl service = new SsoServiceImpl(authenticateRepository, propertiesRepository);

    private UserDTO userDTO;

    @BeforeEach
    public void setUp() {
        userDTO = UserDTO.builder().token(TestData.TEST_TOKEN).build();
    }

    @Test
    public void shouldInstanciateTheService() {
        assertNotNull(service);
    }

    @Test
    public void shouldGenerateSsoUrlDTO() {
        // GIVEN
        String idOperateur = "rguenoun";
        // WHEN
        SsoUrlDTO urlDTO = service.generateSsoUrlDTO(idOperateur, TestData.TEST_LOGIN);

        //THEN
        assertNotNull(urlDTO);
        assertNotNull(urlDTO.getUrl());        
    }

    @Test
    public void shouldGenerateUserDTOFromTheGivenLogin() {
        //GIVEN
        //WHEN
        UserDTO userDTO = service.getInfosForSsoConnection(TestData.TEST_LOGIN);
        //THEN
        assertNotNull(userDTO);
        assertTrue(userDTO.isSso());
    }
}
