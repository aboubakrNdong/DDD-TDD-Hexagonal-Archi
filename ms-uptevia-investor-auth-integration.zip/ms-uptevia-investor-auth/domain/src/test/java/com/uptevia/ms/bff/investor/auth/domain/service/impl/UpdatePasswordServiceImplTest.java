package com.uptevia.ms.bff.investor.auth.domain.service.impl;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.DetailConnexionDTO;
import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.repository.IUpdatePasswordRepository;
import org.apache.commons.codec.digest.DigestUtils;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UpdatePasswordServiceImplTest {

    private static final String LOGIN = "99963514";
    private static final String PASSWORD = "test@198Ht@L0vaS";
    private static final String OLD_PASSWORD = "test@198Ht@L0vaS";
    private static final String EMAIL = "test@test.com";
    @Mock
    private IUpdatePasswordRepository iUpdatePasswordRepository = mock(IUpdatePasswordRepository.class);

    @Mock
    private IAuthenticateRepository iAuthenticateRepository = mock(IAuthenticateRepository.class);

    private UpdatePasswordServiceImpl updatePasswordService;

    private final EasyRandom easyRandom = new EasyRandom();

    private final DetailConnexionDTO detailConnexionDTO = DetailConnexionDTO.builder()
            .login(LOGIN)
            .newPassword(PASSWORD)
            .oldPassword(OLD_PASSWORD)
            .email(EMAIL)
            .build();


    @BeforeEach
    public void setUp() {
        updatePasswordService = new UpdatePasswordServiceImpl(iUpdatePasswordRepository, iAuthenticateRepository);
    }

    @Test
    void should_return_update_pws_ok() throws Exception {

        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        ZoneOffset offset = OffsetDateTime.now().getOffset();
        LocalDateTime dateTimeAccess = LocalDateTime.now();
        userDTO.setIndiCompteBloque(false);
        userDTO.setDateMajPsw(dateTimeAccess.minusDays(3).atOffset(offset));
        String hashedSaltedPwd = DigestUtils.sha256Hex(PASSWORD + userDTO.getSltPassword());
        userDTO.setPassword(hashedSaltedPwd);
        detailConnexionDTO.setOldPassword(PASSWORD);
        Mockito.when(iAuthenticateRepository.authenticate(LOGIN, PASSWORD)).thenReturn(userDTO);
        Mockito.when(iAuthenticateRepository.updateNbEssai(LOGIN, 0)).thenReturn(1L);
        Mockito.when(iAuthenticateRepository.updateNbAcces(LOGIN)).thenReturn(1L);

        updatePasswordService.updatePassword(detailConnexionDTO);
        ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);

        verify(iUpdatePasswordRepository, times(1)).updatePassword(captor.capture(), captor.capture());

    }

    @Test
    void when_old_Pwd_Not_Match_should_return_update_pws_KO() {

        FunctionnalException exception =  assertThrows(FunctionnalException.class, this::execute);
        assertEquals("majpassword.text.badPassword", exception.getCode());
    }

    private void execute() throws FunctionnalException {

        String other_Old_Pwd = "test@198Ht@L0vaS";

        detailConnexionDTO.setOldPassword(other_Old_Pwd);

        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);

        Mockito.when(iAuthenticateRepository.authenticate(LOGIN, PASSWORD)).thenReturn(userDTO);

        updatePasswordService.updatePassword(detailConnexionDTO);
    }


    @Test
    void when_psw_contains_No_Special_character_should_return_update_pws_KO() throws FunctionnalException {
        ZoneOffset offset = OffsetDateTime.now().getOffset();
        LocalDateTime dateTimeAccess = LocalDateTime.parse("2018-12-30T19:34:50.63");
        String psw_without_Special_Char = "test198HtL0vaS";
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(iAuthenticateRepository.authenticate(LOGIN, psw_without_Special_Char)).thenReturn(userDTO);
        detailConnexionDTO.setNewPassword(psw_without_Special_Char);
        detailConnexionDTO.setOldPassword(psw_without_Special_Char);
        String hashedSaltedPwd = DigestUtils.sha256Hex(psw_without_Special_Char + userDTO.getSltPassword());
        userDTO.setPassword(hashedSaltedPwd);
        userDTO.setDateMajPsw(dateTimeAccess.minusHours(2).atOffset(offset));
        FunctionnalException exception =  assertThrows(FunctionnalException.class, () ->
            updatePasswordService.updatePassword(detailConnexionDTO)
        );
        assertEquals("majpassword.text.charspecial", exception.getCode());
    }

    @Test
    void when_psw_contains_No_Numbers_should_return_update_pws_KO() throws FunctionnalException {
        ZoneOffset offset = OffsetDateTime.now().getOffset();
        LocalDateTime dateTimeAccess = LocalDateTime.parse("2018-12-30T19:34:50.63");
        String psw_without_Numbers = "test@Ht@LovaS";
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(iAuthenticateRepository.authenticate(LOGIN, psw_without_Numbers)).thenReturn(userDTO);
        detailConnexionDTO.setNewPassword(psw_without_Numbers);
        detailConnexionDTO.setOldPassword(psw_without_Numbers);
        String hashedSaltedPwd = DigestUtils.sha256Hex(psw_without_Numbers + userDTO.getSltPassword());
        userDTO.setPassword(hashedSaltedPwd);
        userDTO.setDateMajPsw(dateTimeAccess.minusHours(2).atOffset(offset));
        FunctionnalException exception =  assertThrows(FunctionnalException.class, () ->
            updatePasswordService.updatePassword(detailConnexionDTO)
        );
        assertEquals("majpassword.text.number", exception.getCode());
    }

    @Test
    void when_psw_contains_No_UpperCase_should_return_update_pws_KO() throws FunctionnalException {
        ZoneOffset offset = OffsetDateTime.now().getOffset();
        LocalDateTime dateTimeAccess = LocalDateTime.parse("2018-12-30T19:34:50.63");
        String psw_without_Upper_Case = "test@ht@lovas1";
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(iAuthenticateRepository.authenticate(LOGIN, psw_without_Upper_Case)).thenReturn(userDTO);
        detailConnexionDTO.setNewPassword(psw_without_Upper_Case);
        detailConnexionDTO.setOldPassword(psw_without_Upper_Case);
        String hashedSaltedPwd = DigestUtils.sha256Hex(psw_without_Upper_Case + userDTO.getSltPassword());
        userDTO.setPassword(hashedSaltedPwd);
        userDTO.setDateMajPsw(dateTimeAccess.minusHours(2).atOffset(offset));
        FunctionnalException exception =  assertThrows(FunctionnalException.class, () ->
            updatePasswordService.updatePassword(detailConnexionDTO)
        );
        assertEquals("majpassword.text.upperCase", exception.getCode());
    }

    @Test
    void when_psw_contains_No_LowerCase_should_return_update_pws_KO() throws FunctionnalException {
        ZoneOffset offset = OffsetDateTime.now().getOffset();
        LocalDateTime dateTimeAccess = LocalDateTime.parse("2018-12-30T19:34:50.63");
        String psw_without_Lower_Case = "TEST@KT@LOVAS/1";
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(iAuthenticateRepository.authenticate(LOGIN, psw_without_Lower_Case)).thenReturn(userDTO);
        detailConnexionDTO.setNewPassword(psw_without_Lower_Case);
        detailConnexionDTO.setOldPassword(psw_without_Lower_Case);
        String hashedSaltedPwd = DigestUtils.sha256Hex(psw_without_Lower_Case + userDTO.getSltPassword());
        userDTO.setPassword(hashedSaltedPwd);
        userDTO.setDateMajPsw(dateTimeAccess.minusHours(2).atOffset(offset));
        FunctionnalException exception =  assertThrows(FunctionnalException.class, () ->
            updatePasswordService.updatePassword(detailConnexionDTO)
        );
        assertEquals("majpassword.text.lowerCase", exception.getCode());
    }

    @Test
    void when_psw_Less_12_should_return_update_pws_KO() throws FunctionnalException {
        ZoneOffset offset = OffsetDateTime.now().getOffset();
        LocalDateTime dateTimeAccess = LocalDateTime.parse("2018-12-30T19:34:50.63");
        String psw_Less_Then_12 = "test@KT@L1";
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(iAuthenticateRepository.authenticate(LOGIN, psw_Less_Then_12)).thenReturn(userDTO);
        detailConnexionDTO.setNewPassword(psw_Less_Then_12);
        detailConnexionDTO.setOldPassword(psw_Less_Then_12);
        String hashedSaltedPwd = DigestUtils.sha256Hex(psw_Less_Then_12 + userDTO.getSltPassword());
        userDTO.setPassword(hashedSaltedPwd);
        userDTO.setDateMajPsw(dateTimeAccess.minusHours(2).atOffset(offset));
        FunctionnalException exception =  assertThrows(FunctionnalException.class, () ->
            updatePasswordService.updatePassword(detailConnexionDTO)
        );
        assertEquals("majpassword.text.length", exception.getCode());
    }

    @Test
    void when_psw_Greater_16_should_return_update_pws_KO() throws FunctionnalException {
        ZoneOffset offset = OffsetDateTime.now().getOffset();
        LocalDateTime dateTimeAccess = LocalDateTime.parse("2018-12-30T19:34:50.63");
        String psw_Less_Greater_then_16 = "test@KT@L1@Ht09CxSWP";
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(iAuthenticateRepository.authenticate(LOGIN, psw_Less_Greater_then_16)).thenReturn(userDTO);
        String hashedSaltedPwd = DigestUtils.sha256Hex(psw_Less_Greater_then_16 + userDTO.getSltPassword());
        userDTO.setPassword(hashedSaltedPwd);
        userDTO.setDateMajPsw(dateTimeAccess.minusHours(2).atOffset(offset));
        detailConnexionDTO.setNewPassword(psw_Less_Greater_then_16);
        detailConnexionDTO.setOldPassword(psw_Less_Greater_then_16);
        FunctionnalException exception =  assertThrows(FunctionnalException.class, () ->
            updatePasswordService.updatePassword(detailConnexionDTO)
        );

        assertEquals("majpassword.text.length", exception.getCode());
    }

    @Test
    void when_psw_maj_less_then_24h_should_return_update_pws_KO() throws FunctionnalException {

        ZoneOffset offset = OffsetDateTime.now().getOffset();
        LocalDateTime dateTimeAccess = LocalDateTime.now();
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        // set 2 hours before
        Mockito.when(iAuthenticateRepository.authenticate(LOGIN, PASSWORD)).thenReturn(userDTO);
        userDTO.setDateMajPsw(dateTimeAccess.minusHours(2).atOffset(offset));
        String hashedSaltedPwd = DigestUtils.sha256Hex(PASSWORD + userDTO.getSltPassword());
        userDTO.setPassword(hashedSaltedPwd);
        detailConnexionDTO.setNewPassword(PASSWORD);
        detailConnexionDTO.setOldPassword(PASSWORD);
        FunctionnalException exception =  assertThrows(FunctionnalException.class, () ->
                updatePasswordService.updatePassword(detailConnexionDTO)
        );
        assertEquals("login.error.maj.psw.24h", exception.getCode());
    }

}
