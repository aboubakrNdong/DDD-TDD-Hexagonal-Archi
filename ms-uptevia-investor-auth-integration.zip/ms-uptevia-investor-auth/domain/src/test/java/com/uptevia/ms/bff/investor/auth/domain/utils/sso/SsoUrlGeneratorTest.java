package com.uptevia.ms.bff.investor.auth.domain.utils.sso;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;

public class SsoUrlGeneratorTest {
    @Test
    public void givenTokeShouldGenerateUrl() {
        //GIVEN
        String token = "test-token";
        UserDTO user = UserDTO.builder().token(token).build();
        SsoUrlGenerator generator = new SsoUrlGenerator(user);
        String expectedUrl = SsoUrlGenerator.SSO_ROUTE_NAME + user.getToken();
        //WHEN
        String url = generator.generateUrl();
        //THEN
        assertEquals(url, expectedUrl);
    }

}
