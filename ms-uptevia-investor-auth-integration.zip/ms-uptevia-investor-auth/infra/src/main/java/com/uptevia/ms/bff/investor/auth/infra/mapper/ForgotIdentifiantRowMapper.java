package com.uptevia.ms.bff.investor.auth.infra.mapper;

import com.uptevia.ms.bff.investor.auth.domain.model.ForgotIdentifiantDTO;
import org.springframework.jdbc.core.RowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ForgotIdentifiantRowMapper implements RowMapper<ForgotIdentifiantDTO> {
    @Override
        public ForgotIdentifiantDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
            return ForgotIdentifiantDTO.builder()
                    .loginUpi(rs.getString("LOGIN_UPI"))
                    .build();
        }
    }
