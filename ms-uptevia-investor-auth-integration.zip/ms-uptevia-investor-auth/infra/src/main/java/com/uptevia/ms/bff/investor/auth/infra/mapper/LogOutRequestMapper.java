package com.uptevia.ms.bff.investor.auth.infra.mapper;

import com.uptevia.ms.bff.investor.auth.domain.model.LogOutRequestDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.*;

public class LogOutRequestMapper implements RowMapper<LogOutRequestDTO> {
    @Override
    public LogOutRequestDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        String username = rs.getString("LOGIN");
        String token = rs.getString("TOKEN");
        ZoneId zoneId = ZoneId.systemDefault();
        OffsetDateTime revokedOffsetDateTime = null;
        if (rs.getDate("REVOCATION_DATE") != null) {
            LocalDateTime revokedDate =  rs.getTimestamp("REVOCATION_DATE").toLocalDateTime();
            revokedOffsetDateTime = revokedDate.atZone(zoneId).toOffsetDateTime();
        }
        OffsetDateTime validityEndOffsetDateTime = null;
        if (rs.getDate("VALIDITY_END_DATE") != null) {
            LocalDateTime validityEndDate = rs.getTimestamp("VALIDITY_END_DATE").toLocalDateTime();
            validityEndOffsetDateTime = validityEndDate.atZone(zoneId).toOffsetDateTime();
        }

        return new LogOutRequestDTO(username, token, revokedOffsetDateTime, validityEndOffsetDateTime);
    }
}
