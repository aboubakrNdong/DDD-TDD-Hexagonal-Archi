package com.uptevia.ms.bff.investor.auth.infra.mapper;

import com.uptevia.ms.bff.investor.auth.domain.model.TitulaireCompteDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class TituCompteRowMapper implements RowMapper<TitulaireCompteDTO> {
    @Override
    public TitulaireCompteDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        TitulaireCompteDTO titulaireCompteDTO = TitulaireCompteDTO.builder()
                .idenTifiant(rs.getInt("EMET_IDEN"))
                .nom(rs.getString("NOM"))
                .prenom(rs.getString("PRENOM"))
                .numCpte(rs.getString("ACTI_IDEN"))
                .telephone(rs.getString("TELEPHONE"))
                .email(rs.getString("EMAIL"))
                .emetFirstname(rs.getString("EMET_LIBE"))
                .build();


        if (rs.getDate("DATE_NAISSANCE") != null) {
            LocalDateTime dateNaissance = rs.getTimestamp("DATE_NAISSANCE").toLocalDateTime();
            titulaireCompteDTO.setDateNaissance(dateNaissance.toLocalDate());
        }

        return titulaireCompteDTO;
    }
}
