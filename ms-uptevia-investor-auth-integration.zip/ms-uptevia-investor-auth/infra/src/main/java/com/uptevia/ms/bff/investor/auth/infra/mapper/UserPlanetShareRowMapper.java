package com.uptevia.ms.bff.investor.auth.infra.mapper;

import com.uptevia.ms.bff.investor.auth.domain.model.UserPlanetShareDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class UserPlanetShareRowMapper implements RowMapper<UserPlanetShareDTO> {
    @Override
    public UserPlanetShareDTO mapRow(final ResultSet rs, final int rowNum) throws SQLException {

        return UserPlanetShareDTO.builder()
                .password(rs.getString("MDP"))
                .saltPassword(rs.getString("MDP_SALT"))
                .emetIden(rs.getString("EMET_IDEN"))
                .actiIden(rs.getString("ACTI_IDEN"))
                .tituNume(rs.getString("TITU_NUME"))
                .loginUpi(rs.getString("LOGIN_UPI"))
                .email(rs.getString("EMAIL"))
                .numMobile(rs.getString("NUM_MOBILE"))
                .build();
    }
}
