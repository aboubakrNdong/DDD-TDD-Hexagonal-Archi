package com.uptevia.ms.bff.investor.auth.infra.mapper;


import com.uptevia.ms.bff.investor.auth.domain.model.UserDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.*;

public class UserRowMapper implements RowMapper<UserDTO> {

    @Override
    public UserDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        UserDTO userDTO = UserDTO.builder()
                .email(rs.getString("EMAIL"))
                .numTel(rs.getString("NUM_TEL"))
                .login(rs.getString("LOGIN_UPI"))
                .password(rs.getString("PASSWORD"))
                .nbAcces(rs.getInt("NB_ACCES"))
                .nbEssais(rs.getInt("NB_ESSAIS"))
                .nbTotalEssais(rs.getInt("NB_TOTAL_ESSAIS"))
                .indiCompteBloque(!StringUtils.equals(rs.getString("INDI_COMPTE_BLOQUE"), "N"))
                .indiPwdExpire(!StringUtils.equals(rs.getString("INDI_PWD_EXPIRE"), "N"))
                .sltPassword(rs.getString("SLT_PASSWORD"))
                .idQuestionSecurite1(rs.getInt("ID_QUESTION_SECURITE_1"))
                .reponseQuestionSecurite1(rs.getString(("REPONSE_QUESTION_SECURITE_1")))
                .idQuestionSecurite2(rs.getInt("ID_QUESTION_SECURITE_2"))
                .reponseQuestionSecurite2(rs.getString(("REPONSE_QUESTION_SECURITE_2")))
                .actiIden(rs.getString("ACTI_IDEN"))
                .emetIden(rs.getString("EMET_IDEN"))
                .tituNume(rs.getString("TITU_NUME"))
                .build();


        ZoneOffset offset = ZoneOffset.UTC;

        if (rs.getDate("DATE_ACCES") != null) {
            LocalDateTime dateTimeAcces = rs.getTimestamp("DATE_ACCES").toLocalDateTime();
            userDTO.setDateAccess(dateTimeAcces.atOffset(offset));
        }

        if (rs.getDate("DATE_MAJ_OTP") != null) {
            LocalDateTime dateMajOtp = rs.getTimestamp("DATE_MAJ_OTP").toLocalDateTime();
            userDTO.setOtpValidatedDate(dateMajOtp.atOffset(offset));
            userDTO.setOtpValidated(true);
        }

        if (rs.getDate("DATE_VALIDITE_DEB") != null) {
            LocalDateTime dateDeb = rs.getTimestamp("DATE_VALIDITE_DEB").toLocalDateTime();
            userDTO.setDateValiditeDEB(dateDeb.atOffset(offset));
        }

        if (rs.getDate("DATE_VALIDITE_FIN") != null) {
            LocalDateTime dateFin = rs.getTimestamp("DATE_VALIDITE_FIN").toLocalDateTime();
            userDTO.setDateValiditeFin(dateFin.atOffset(offset));
        }

        if (rs.getDate("DATE_MAJ_PWD") != null) {
            LocalDateTime dateMaj = rs.getTimestamp("DATE_MAJ_PWD").toLocalDateTime();
            userDTO.setDateMajPsw(dateMaj.atOffset(offset));

            //JIRA 32001, cas 1
            LocalDateTime now = LocalDateTime
                    .now();

            LocalDateTime dateTimeBegin = dateMaj
                    .plusDays(365);

            LocalDateTime dateTimeEnd = dateMaj
                    .plusDays(456);

            if (now.isAfter(dateTimeBegin) && now.isBefore(dateTimeEnd)) {
                userDTO.setIndiWillBePwdExpired(true);
            }

        }

        String indBlocage = rs.getString("INDI_BLOCAGE");
        if(StringUtils.isNotEmpty(indBlocage) && indBlocage.equals("O"))
            userDTO.setIndicOtpBlocage(true);

        return userDTO;
    }
}
