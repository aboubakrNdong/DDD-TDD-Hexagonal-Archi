package com.uptevia.ms.bff.investor.auth.infra.repositories;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.MailTraductionDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AbstractTraductionRepository {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${base.resource.url}")
    private String baseResourceUrl;

    public List<MailTraductionDTO> getAllKeyAndLibelle(String language, String key, int themeId) throws FunctionnalException {

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseResourceUrl + "traduction/"+ language + "/" + themeId)
                .queryParam("lang", language )
                .queryParam("themeId", themeId);

        String apiUrl = builder.toUriString();

        RestTemplate restTemplate = new RestTemplate();

        List<MailTraductionDTO> response = List.of(restTemplate.getForObject(apiUrl, MailTraductionDTO[].class));

        if (response.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            logger.info("error in getting all trad from DB ");

            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return response ;
    }
}
