package com.uptevia.ms.bff.investor.auth.infra.repositories;


import com.uptevia.ms.bff.investor.auth.domain.enums.EnumSmsStatus;
import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.repository.IAuthenticateRepository;
import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;
import com.uptevia.ms.bff.investor.auth.domain.util.Traduction;
import com.uptevia.ms.bff.investor.auth.infra.mapper.*;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Repository
public class AuthenticateRepository extends AbstractTraductionRepository implements IAuthenticateRepository {


    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private JdbcTemplate jdbcTemplate;

    private static final String UPI_TITU_GET_BY_CRITERIA = "UPI_TITU_GET_BY_CRITERIA";

    private static final String PS_CUR = "PS_CUR";

    @Value("${base.ext.url}")
    private String baseExtUrl;


    @Value("${base.business.url}")
    private String baseBusinessUrl;


    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public UserDTO authenticate(final String login, final String password) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.UPI_UTIL_GET_BY_LOGIN)
                .returningResultSet(Constantes.PS_CUR,
                        new UserRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login)
                .addValue(Constantes.PARAM_PASSWORD, "");


        Map<String, Object> out = jdbcCall.execute(in);

        List<UserDTO> result = (List<UserDTO>) out.get(Constantes.PS_CUR);

        if (result.isEmpty()) {
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_CREDENTIALS, Constantes.LOGIN_TEXT_BAD_CREDENTIALS);
        }

        return result.get(0);

    }

    @Override
    public Long updateNbAcces(final String login) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName(Constantes.UPI_UTIL_UPDATE_NB_ACCES); //function name

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login)
                .addValue(Constantes.PARAM_USER_MAJ, login);

        return jdbcCall.executeFunction(BigDecimal.class, in).longValue();

    }

    @Override
    public Long updateNbEssai(final String login, final int number) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName(Constantes.UPI_UTIL_UPDATE_NB_ESSAI); //function name

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login)
                .addValue(Constantes.PARAM_USER_MAJ, login)
                .addValue("PARAM_NB_ESSAIS", number);
        return jdbcCall.executeFunction(BigDecimal.class, in).longValue();
    }

    @Override
    public List<UserDTO> ancientOlisAccount(final String login) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.UPI_UTIL_GET_BY_LOGIN_OLIS)
                .returningResultSet("PS_CUR",
                        new UserOlisRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login);

        Map<String, Object> out = jdbcCall.execute(in);

        List<UserDTO> result = (List<UserDTO>) out.get("PS_CUR");

        if (result.isEmpty()) {
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_CREDENTIALS, Constantes.EMPTY_DATA_EXCEPTION);
        }

        return result;
    }


    @Override
    public List<UserPlanetShareDTO> ancientPlanetShare(final Integer emetIden, final String accessCode) throws FunctionnalException {

        logger.info("Begin getting data for planetshare user...");
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.UPI_UTIL_GET_BY_LOGIN_PLANETSHARES)
                .returningResultSet(Constantes.PS_CUR,
                        new UserPlanetShareRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_EMET_IDEN", StringUtils.leftPad(String.valueOf(emetIden), 5, "0"))
                .addValue("P_CDE_UTIL", accessCode);

        Map<String, Object> out = jdbcCall.execute(in);

        List<UserPlanetShareDTO> result = (List<UserPlanetShareDTO>) out.get(Constantes.PS_CUR);

        if (result.isEmpty()) {
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_CREDENTIALS, Constantes.EMPTY_DATA_EXCEPTION);
        }

        return result;
    }

    @Override
    public UserDTO getUpiUtilUser(String login) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.UPI_UTIL_GET_BY_LOGIN)
                .returningResultSet(Constantes.PS_CUR,
                        new UserRowMapper());
        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login)
                .addValue(Constantes.PARAM_PASSWORD, "");

        Map<String, Object> out = jdbcCall.execute(in);
        List<UserDTO> result = (List<UserDTO>) out.get(Constantes.PS_CUR);

        if (result.isEmpty()) {
            return null;
        }
        return result.get(0);
    }

    @Override
    public Long updateDateMajOtp(final String login) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName(Constantes.UPI_UTIL_UPDATE_DATE_MAJ_OTP);

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login)
                .addValue(Constantes.PARAM_USER_MAJ, login);

        return jdbcCall.executeFunction(BigDecimal.class, in).longValue();

    }

    public void acceptCgu(final EabonnementDTO eabonnementDTO) {

        String compteKey = buildCompteKey(eabonnementDTO.getEmetIden(), eabonnementDTO.getActiIden(),
                String.valueOf(eabonnementDTO.getTituNume()), "", "", "");
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName(Constantes.UPI_UTIL_CPTE_UPDATE_CGU); //function name

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_COMPTE_KEY", compteKey)
                .addValue(Constantes.PARAM_USER_MAJ, eabonnementDTO.getLogin());

        jdbcCall.executeFunction(BigDecimal.class, in);
    }

    @Override
    public String validateOtpCode(String login, String otpCode) {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName("OTP_CHECK_CODE");

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_LOGIN", login)
                .addValue("P_OTP_CODE", otpCode);

        return jdbcCall.executeFunction(String.class, in);

    }


    @Override
    public String validateToken(String login, String token, String useCase) {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName("TOKEN_CHECK_VALIDITY");

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_LOGIN", login)
                .addValue("P_TOKEN_TYPE", useCase)
                .addValue("P_TOKEN", token);
        return jdbcCall.executeFunction(String.class, in);

    }

    @Override
    public BigDecimal requestToken(String login, String token, String useCase) {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName("TOKEN_NEW_GENERATION");

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_LOGIN", login)
                .addValue("P_USER_CREA", login)
                .addValue("P_TOKEN_TYPE", useCase)
                .addValue("P_TOKEN", token);

        return jdbcCall.executeFunction(BigDecimal.class, in);

    }


    @Override
    public List<String> getWhitelist(String typeWhitelist) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("UPI_GET_WL")
                .returningResultSet(PS_CUR,
                        new WhitelistRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_TYPE_WL", typeWhitelist);

        Map<String, Object> out = jdbcCall.execute(in);

        List<String> result = (List<String>) out.get(PS_CUR);

        return result;
    }

    @Override
    public String requestOtp(String login, String lang) throws FunctionnalException {

        //retrieve number from login
        UserDTO userDTO = getUpiUtilUser(login);

        if (userDTO.isIndicOtpBlocage()) {
            return EnumSmsStatus.STATUS_BLOCKED.getStatus();
        }

        //check if number not null
        List<String> isInWhitelist = getWhitelist("MOBILE");
        if (ObjectUtils.isEmpty(userDTO.getNumTel()) ) {
            throw new FunctionnalException(Constantes.PHONE_NOT_FOUND, Constantes.PHONE_NOT_FOUND);
        }

        String numMobile = userDTO.getNumTel().trim().replaceAll("\\s+", "");

       if (!isInWhitelist.contains(numMobile)) {
            throw new FunctionnalException(Constantes.PHONE_NOT_IN_WHITELIST, Constantes.PHONE_NOT_IN_WHITELIST);
        }

        String convertLang = Traduction.getLangue(lang);

        String codeGenerated = getRandomNumberString();
        SendSmsDTO sendSmsDTO = new SendSmsDTO();

        String baseString = getLibelle("connexion.sms.otp", convertLang);

        String smsText = String.format(baseString, codeGenerated);
        logger.info("smsText is" + smsText);

        sendSmsDTO.setText(smsText);
        sendSmsDTO.setMobileNumbers(Collections.singletonList(numMobile));

        try {
            //send sms
            Map<String, String> smsResult = sendSms(sendSmsDTO);

            if (!StringUtils.equals(smsResult.get("status"), "OK")) {
                //Souci de communication avec API send SMS
                logger.warn(Constantes.ERROR_IN_SMS_REQUEST + " Status : " + smsResult.get("status") + " for user: " + login);
                return EnumSmsStatus.STATUS_SERVER_ERROR.getStatus();
            }

            String saveResult = saveSmsDataInDb(codeGenerated, login, smsResult.get("body"));
            if (saveResult.isEmpty()) {
                throw new FunctionnalException(Constantes.ERROR_IN_SMS_REQUEST, Constantes.ERROR_IN_SMS_REQUEST);
            } else {
                return EnumSmsStatus.STATUS_OK.getStatus();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return EnumSmsStatus.STATUS_OTP_REQUEST_ERROR.getStatus();
    }


    private String getLibelle(String keyTrad, String lang) throws FunctionnalException {

        List<MailTraductionDTO> allLibelle = getAllKeyAndLibelle(lang, keyTrad, 1);

        if (allLibelle.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            logger.info("error in getting all trad from DB ");
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return Traduction.iTerateOverTrad(allLibelle, keyTrad);
    }


    @Override
    public Map<String, String> sendSms(SendSmsDTO sendSmsDTO) {
        Map<String, String> sendSmsResult = new HashMap<>();


        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseExtUrl + "restricted/sms/send")
                .queryParam("text", sendSmsDTO.getText())
                .queryParam("mobileNumbers", sendSmsDTO.getMobileNumbers());

        String apiUrl = builder.toUriString();

        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<SendSmsDTO> response = restTemplate.postForEntity(apiUrl, sendSmsDTO, SendSmsDTO.class);

        if (response.getStatusCode().is2xxSuccessful()) {
            sendSmsResult.put("status", "OK");
        } else {
            sendSmsResult.put("status", String.valueOf(response.getStatusCode()));
        }

        sendSmsResult.put("body", String.valueOf(response.getBody()));

        return sendSmsResult;
    }


    private String saveSmsDataInDb(String codeOtp, String loginUpi, String jobIdRetarus) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName(Constantes.OTP_NEW_GENERATION); //function name

        String dateAndTime = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).format(LocalDateTime.now());

        Timestamp timestamp = Timestamp.valueOf(LocalDateTime.parse(dateAndTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));


        //TODO save in DB,  P_OTP_DATA the result of retarus in json

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_LOGIN", loginUpi)
                .addValue("P_OTP_CODE", codeOtp)
                .addValue("P_OTP_DATE_ENVOI", timestamp)
                .addValue("P_OTP_DATA", jobIdRetarus)
                .addValue("P_USER_CREA", loginUpi);

        Timestamp resultProc = jdbcCall.executeFunction(Timestamp.class, in);
        String resultValue = resultProc.toString();
        return resultValue;
    }


    //generate Code OTP
    public static String getRandomNumberString() {
        // It will generate 6 digit random Number.
        Random rnd = new Random();
        int number = rnd.nextInt(999999);
        return String.format("%06d", number);
    }


    public static String buildCompteKey(String emetIden, String actiIden, String tituNume, String titrIdCat, String titrCreelia, String idAutre) {
        return StringUtils.leftPad(StringUtils.defaultIfBlank(emetIden, "0"), 8, "0")
                + "-" + StringUtils.leftPad(StringUtils.defaultIfBlank(actiIden, "0"), 7, "0")
                + "-" + StringUtils.leftPad(StringUtils.defaultIfBlank(tituNume, "0"), 2, "0")
                + "-" + StringUtils.defaultIfBlank(titrCreelia, "0")
                + "-" + StringUtils.defaultIfBlank(titrIdCat, "0")
                + "-" + StringUtils.defaultIfBlank(idAutre, "0");
    }


    @Override
    public long logout(final LogOutRequestDTO logOutRequestDTO) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName("REVOKED_JWT_TOKEN_INSERT");
        String dateAndTime = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now());
        Timestamp revokeDate = Timestamp.valueOf(LocalDateTime.parse(dateAndTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_LOGIN", logOutRequestDTO.getUsername())
                .addValue("P_TOKEN_REVOKE_DATE", revokeDate)
                .addValue("P_TOKEN_VALIDITY_END_DATE", logOutRequestDTO.getValidityEndDate())
                .addValue("P_TOKEN", logOutRequestDTO.getToken());

        return jdbcCall.executeFunction(BigDecimal.class, in).longValue();
    }

    @Override
    public List<LogOutRequestDTO> findAllRevokedTokens() {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.UPI_REVOKED_TOKEN_GET_ALL)
                .returningResultSet(Constantes.PS_CUR, new LogOutRequestMapper());
        SqlParameterSource in = new MapSqlParameterSource();
        Map<String, Object> out = jdbcCall.execute(in);
        List<LogOutRequestDTO> result = (List<LogOutRequestDTO>) out.get(Constantes.PS_CUR);
        logger.info("We have {} revoked tokens from database", result.size());
        return result;
    }

}
