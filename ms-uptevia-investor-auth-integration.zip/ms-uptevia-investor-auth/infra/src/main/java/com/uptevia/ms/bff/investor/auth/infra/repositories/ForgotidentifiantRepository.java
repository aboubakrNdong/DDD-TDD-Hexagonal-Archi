package com.uptevia.ms.bff.investor.auth.infra.repositories;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.repository.IForgotRepository;
import com.uptevia.ms.bff.investor.auth.infra.mapper.ForgotIdentifiantRowMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.PostConstruct;
import java.util.*;
import java.time.LocalDate;
import java.util.function.Function;
import java.util.stream.Collectors;


@Repository
@SuppressWarnings("unchecked")
public class ForgotidentifiantRepository implements IForgotRepository {

    private static final String UPI_TITU_GET_BY_CRITERIA = "UPI_TITU_GET_BY_CRITERIA";

    private static final String PS_CUR = "PS_CUR";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());


    @Value("${base.business.url}")
    private String baseBusinessUrl;

    @Value("${base.front.url}")
    private String baseFrontUrl;

    @Value("${base.resource.url}")
    private String baseResourceUrl;

    public static Map<String, TraductionDTO> traductions = new HashMap<>();

    @Autowired
    private JdbcTemplate jdbcTemplate;


    public ForgotidentifiantRepository(@Qualifier("jdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public String getFrontUrl() {
        return baseFrontUrl;
    }

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    @PostConstruct
    public void init() {
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public ForgotIdentifiantDTO getIdentifiant(String pEmetIden, String pActiIden, String pNom, String pPrenom, LocalDate pDateNais) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(UPI_TITU_GET_BY_CRITERIA)
                .returningResultSet(PS_CUR,
                        new ForgotIdentifiantRowMapper());


        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_EMET_IDEN", pEmetIden)
                .addValue("P_ACTI_IDEN", pActiIden)
                .addValue("P_NOM", pNom)
                .addValue("P_PRENOM", pPrenom)
                .addValue("P_EMAIL", null)
                .addValue("P_DATE_NAIS", pDateNais)
                .addValue("P_NUM_TEL", null)
                .addValue("P_LOGIN", null);

        Map<String, Object> out = jdbcCall.execute(in);

        List<ForgotIdentifiantDTO> result = (List<ForgotIdentifiantDTO>) out.get(PS_CUR);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }
        logger.info("the login UPI is : " + result.get(0).getLoginUpi());

        return result.get(0);

    }


    @Override
    public boolean sendEmail(SendEmailDTO sendEmailDTO, final EmailBodyDTO emailBodyDTO) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();

        body.add("from", sendEmailDTO.getFrom());
        body.add("textBody", emailBodyDTO);
        body.add("subject", sendEmailDTO.getSubject());
        body.add("recipients", sendEmailDTO.getRecipients());

        RestTemplate restTemplate = new RestTemplate();
        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);

        ResponseEntity<Boolean> responseEntity = restTemplate.exchange(baseBusinessUrl + "restricted/sendMail",
                HttpMethod.POST,
                requestEntity,
                Boolean.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST;

    }


    //TODO delete this and use function in AbstractTraductionRepo
    public List<MailTraductionDTO> getAllKeyAndLibelle(String language, String key, int themeId) throws FunctionnalException {

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseResourceUrl + "traduction/" + language + "/" + themeId)
                .queryParam("lang", language)
                .queryParam("themeId", themeId);

        String apiUrl = builder.toUriString();

        RestTemplate restTemplate = new RestTemplate();

        List<MailTraductionDTO> response = List.of(restTemplate.getForObject(apiUrl, MailTraductionDTO[].class));

        if (response.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            logger.info("error in getting all trad from DB ");

            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return response;
    }


    private String getText(final String key) {
        var libelle = "";
        if (traductions != null && !traductions.entrySet().isEmpty()) {
            libelle = traductions.get(key).getLibelle();
        }
        return libelle;
    }

    private static String getLangue(final String lang) {

        Map<String, String> mapLangue = new HashMap<>();

        mapLangue.put("en", "ENG");
        mapLangue.put("fr", "FRA");
        mapLangue.put("de", "DEU");
        mapLangue.put("es", "ESP");
        mapLangue.put("pt", "PRT");
        mapLangue.put("it", "ITA");
        mapLangue.put("nl", "NLD");

        return mapLangue.get(lang);
    }
}
