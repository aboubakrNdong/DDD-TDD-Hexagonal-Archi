package com.uptevia.ms.bff.investor.auth.infra.repositories;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.uptevia.ms.bff.investor.auth.domain.repository.IPropertiesRepository;

@Repository
public class PropertiesRepository implements IPropertiesRepository {

    @Value("${base.front.url}")
    private String frontUrl;
    @Value("${auth.app.jwtExpirationMs}")
    private int jwtExpirationMs;
    @Value("${auth.app.jwtSecret}")
    private String secretKey;

    @Override
    public String getFrontUrl() { return frontUrl;}

    @Override
    public int getJwtExpirationMs() {return jwtExpirationMs;}

    @Override
    public String getSecretKey() {return secretKey;}
    
}
