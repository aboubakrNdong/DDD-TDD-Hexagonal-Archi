package com.uptevia.ms.bff.investor.auth.infra.repositories;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.model.*;
import com.uptevia.ms.bff.investor.auth.domain.repository.ISignUpRepository;
import com.uptevia.ms.bff.investor.auth.domain.util.Constantes;
import com.uptevia.ms.bff.investor.auth.infra.mapper.SecretQuestionsRowMapper;
import com.uptevia.ms.bff.investor.auth.infra.mapper.TituCompteRowMapper;
import com.uptevia.ms.bff.investor.auth.infra.mapper.UserRowMapper;
import com.uptevia.ms.bff.investor.auth.infra.mapper.WhitelistRowMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Repository
@SuppressWarnings("unchecked")
public class SignUpRepository implements ISignUpRepository {

    private static final String UPI_UTIL_GET_COMPTES = "UPI_UTIL_GET_COMPTES";

    private static final String UPI_GET_ELEMENTS_LISTE = "UPI_GET_ELEMENTS_LISTE";

    private static final String UPI_UPDATE_SECRETS_QUESTIONS = "upi_util_update_questions_securite";

    private static final String PS_CUR = "PS_CUR";

    private final Logger logger = LoggerFactory.getLogger(this.getClass());


    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${base.business.url}")
    private String baseBusinessUrl;

    public SignUpRepository(@Qualifier("jdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    @PostConstruct
    public void init() {
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }


    @Override
    public TitulaireCompteDTO getTitulareComptes(final String login) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(UPI_UTIL_GET_COMPTES)
                .returningResultSet(PS_CUR,
                        new TituCompteRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_LOGIN", login);


        Map<String, Object> out = jdbcCall.execute(in);

        List<TitulaireCompteDTO> result = (List<TitulaireCompteDTO>) out.get(PS_CUR);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("login", login);
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }
        return result.get(0);
    }

    @Override
    public List<SecretQuestionsDTO> secretQuestions(final String idListe, final Integer emetIden) throws FunctionnalException{

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(UPI_GET_ELEMENTS_LISTE)
                .returningResultSet(PS_CUR,
                        new SecretQuestionsRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_ID_LISTE", idListe)
                .addValue("P_EMET_IDEN", emetIden);

        Map<String, Object> out = jdbcCall.execute(in);

        List<SecretQuestionsDTO> result = (List<SecretQuestionsDTO>) out.get(PS_CUR);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }
        return result;
    }

    @Override
    public void saveSecretQuestions(final QuestionnaireDTO questionnaireDTO) {

        try {
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                    .withFunctionName(UPI_UPDATE_SECRETS_QUESTIONS); //function name

            //Add parameters needed to execute the SQL function
            SqlParameterSource in = new MapSqlParameterSource()
                    .addValue("PARAM_LOGIN", questionnaireDTO.getLogin())
                    .addValue("PARAM_QUESTION_1", questionnaireDTO.getFirstQuestion())
                    .addValue("PARAM_REPONSE_1", questionnaireDTO.getFirstAnswer())
                    .addValue("PARAM_SEL_1", questionnaireDTO.getEncryptionkeyFirstAnswer())
                    .addValue("PARAM_QUESTION_2", questionnaireDTO.getSecondQuestion())
                    .addValue("PARAM_REPONSE_2", questionnaireDTO.getSecondAnswer())
                    .addValue("PARAM_SEL_2", questionnaireDTO.getEncryptionKeySecondAnswer());

            jdbcCall.executeFunction(BigDecimal.class, in);
        }
        catch (DataAccessException e){
            e.printStackTrace();
        }
    }



    @Override
    public UserDTO questionsAnswerCheck(final String login, final String password) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.UPI_UTIL_GET_BY_LOGIN)
                .returningResultSet(Constantes.PS_CUR,
                        new UserRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.PARAM_LOGIN, login)
                .addValue(Constantes.PARAM_PASSWORD, "");


        Map<String, Object> out = jdbcCall.execute(in);

        List<UserDTO> result = (List<UserDTO>) out.get(Constantes.PS_CUR);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("emetIden", login);
            logger.error("Empty_Data_Exception : {}", login);
            throw new FunctionnalException(Constantes.EMPTY_DATA_EXCEPTION, Constantes.EMPTY_DATA_EXCEPTION, contextParams);
        }

        if (result.size() > 1) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("emetIden", login);
            logger.error("Multi_Data_Exception : {}", login);
            throw new FunctionnalException(Constantes.LOGIN_TEXT_BAD_CREDENTIALS, Constantes.MULTI_DATA_EXCEPTION, contextParams);
        }

        return result.get(0);


    }

    @Override
    public boolean sendTheEmailURL(SendEmailDTO sendEmailDTO) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseBusinessUrl + "sendMail")
                .queryParam("from", sendEmailDTO.getFrom())
                .queryParam("textBody", sendEmailDTO.getTextBody())
                .queryParam("subject", sendEmailDTO.getSubject())
                .queryParam("recipients", sendEmailDTO.getRecipients())
                .queryParam("attachments", sendEmailDTO.getAttachments());

        String apiUrl = builder.toUriString();

        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<SendEmailDTO> response = restTemplate.postForEntity(apiUrl, sendEmailDTO, SendEmailDTO.class);

        return response.getStatusCode().is2xxSuccessful();
    }


}
