package com.uptevia.ms.bff.investor.auth.infra.repositories;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.domain.repository.IUpdatePasswordRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;

@Repository
@Slf4j
public class UpdatePasswordRepository implements IUpdatePasswordRepository {

    private static final String UPI_UTIL_UPDATE_PWD = "UPI_UTIL_UPDATE_PWD";

    private static final String UPI_UTIL_IS_LAST_PWD = "UPI_UTIL_IS_LAST_PWD";

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;


    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public long updatePassword(final String login, final String newPassword) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName(UPI_UTIL_UPDATE_PWD); //function name

        //Add parameters needed to execute the SQL function
        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_LOGIN", login)
                .addValue("PARAM_PWD", newPassword)
                .addValue("PARAM_USER_MAJ", login);

       return jdbcCall.executeFunction(BigDecimal.class, in).longValue();
    }

    @Override
    public Integer getHistoricPasswords(final String login, final String newPassword, final long nbrFois) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName(UPI_UTIL_IS_LAST_PWD); //function name

        //Add parameters needed to execute the SQL function
        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_LOGIN", login)
                .addValue("PARAM_PWD", newPassword)
                .addValue("PARAM_NB_LAST_PWD", nbrFois);

        return jdbcCall.executeFunction(BigDecimal.class, in).intValue();
    }
}
