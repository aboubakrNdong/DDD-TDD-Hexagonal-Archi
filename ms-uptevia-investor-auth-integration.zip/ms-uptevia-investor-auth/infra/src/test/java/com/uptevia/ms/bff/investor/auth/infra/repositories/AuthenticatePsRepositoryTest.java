package com.uptevia.ms.bff.investor.auth.infra.repositories;

import com.uptevia.ms.bff.investor.auth.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.auth.infra.configuration.DbTestConfiguration;
import com.uptevia.ms.bff.investor.auth.infra.configuration.RepoTestConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ContextConfiguration;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ContextConfiguration(classes = { DbTestConfiguration.class, RepoTestConfiguration.class })
@DataJpaTest
public class AuthenticatePsRepositoryTest {

    @Autowired
    private AuthenticateRepository authenticateRepository;

    //@Test
    public void should_get_actionnaire_by_id_emet_and_id_acti() throws FunctionnalException {



    }
}