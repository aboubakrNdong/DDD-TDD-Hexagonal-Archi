package com.uptevia.ms.bff.investor.business.app.configuration;

import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableFeignClients(basePackages = "com.uptevia.ms.bff.investor.business")
public class FeignConfiguration {

}
