package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.api.model.*;
import com.uptevia.ms.bff.investor.business.app.exception.CustomResponseStatusException;
import com.uptevia.ms.bff.investor.business.app.mapper.*;
import com.uptevia.ms.bff.investor.business.api.ActionnaireApi;
import com.uptevia.ms.bff.investor.business.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.service.ActionnaireService;
import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@RestController
@RequestMapping("/api/v1")
public class ActionnaireController implements ActionnaireApi {
    Logger logger = Logger.getLogger(ActionnaireController.class.getName());
    private static final String MESSAGE = "with the param : ";
    private final ActionnaireService actionnaireService;

    @Autowired
    private JwtUtils jwtUtils;

    public ActionnaireController(final ActionnaireService actionnaireService) {
        this.actionnaireService = actionnaireService;
    }


    /**
     * GET /actionnaire
     * Recherche si actionnaire existe dans la table Acti
     *
     * @param emetIden Code emetteur (required)
     * @param actiIden CCN (required)
     * @param tituNume Rang du titulaire (required)
     * @return Un actionnaire a été trouvé pour ces parametres (status code 200)
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     * or Actionnaire non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */
    @Override
    public ResponseEntity<TitulaireJson> checkActionnaire(Integer emetIden, Integer actiIden, Integer tituNume) {
        PsSelDetailTituDTO detailTituDTO = null;
        try {
            detailTituDTO = actionnaireService.getActionnaire(emetIden, actiIden, tituNume);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
                return new ResponseEntity<>(
                        HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(
                TitulaireJsonMapper.INSTANCE.DtoToJson(
                        detailTituDTO
                ), HttpStatus.OK);
    }

    /**
     * GET /comptes
     * Recherche si compte existe dans la table compte
     *
     * @param login login (required)
     * @return Un comptes a été trouvé pour ces parametres (status code 200)
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     * or Comptes non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */
    @Override
    public ResponseEntity<List<ComptesJson>> getComptes(String login) {
        List<CompteDTO> comptes = null;
        try {
            comptes = actionnaireService.getComptes(login);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE+ e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(comptes
                .stream()
                .map(CompteJsonMapper.INSTANCE::dtoToJson)
                .toList(), HttpStatus.OK);

    }

    /**
     * GET /paysSepa
     * return la liste des pays autorisé a modifié leur données bancaire
     *
     * @param emetIden Code Emetteur  (required)
     * @param paramName nom du parameter (required)
     * @return une liste des pays a été trouvé pour ce emetteur (status code 200)
     *         or Retour de la procédure stockée incorrect (status code 400)
     *         or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     *         or parametrage non trouvé pour ces parametres (status code 404)
     *         or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */

      @Override
    public ResponseEntity<PaysSefaJson> getPaysSepa(Integer emetIden, String paramName) {
        PaysSepaDTO paysSepaDTO = null;

        try {
            paysSepaDTO = actionnaireService.getPaysSepa(emetIden, paramName);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE+ e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(PaysSepaJsonMapper.INSTANCE.dtoToJson(paysSepaDTO),
                HttpStatus.OK);
    }

    /**
     * @param login login (required)
     * @return titulaire as JSON
     */
    @Override
    public ResponseEntity<TitulaireJson> getTitulaire(String login) {
        PsSelDetailTituDTO detailTituDTO = null;
        try {
            detailTituDTO = actionnaireService.getFirstActionnaireByLogin(login);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(
                TitulaireJsonMapper.INSTANCE.DtoToJson(
                        detailTituDTO
                ), HttpStatus.OK);
    }

    /**
     *
     * @param login login (required)
     * @return titulaire
     * this function has the same logic as getTitulaire(login)
     * but it needs a jwt
     */
    public ResponseEntity<TitulaireJson> getTitulaireWithToken() {
        PsSelDetailTituDTO detailTituDTO = null;
        try {
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));
            detailTituDTO = actionnaireService.getFirstActionnaireByLogin(claims.getSubject());
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(
                TitulaireJsonMapper.INSTANCE.DtoToJson(
                        detailTituDTO
                ), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Codeiso2Json> getCodeiso2(String paysIden, String codeLangue) {
        CodeIso2DTO codeIso2DTO = null;

        try {
            codeIso2DTO = actionnaireService.getCodeIso2(paysIden, codeLangue);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(CodeIso2JsonMapper.INSTANCE.dtoToJson(codeIso2DTO),
                HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Boolean> updateMailPhone(ReqUpdateMailPhoneJson reqUpdateMailPhoneJson) {
        ReqUpdateMailPhone req = ReqUpdateMailPhoneJsonMapper.INSTANCE.jsonToDto(reqUpdateMailPhoneJson);

        try {
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));

            req.setLogin(claims.getSubject());
            req.setMail(reqUpdateMailPhoneJson.getMail());
            req.setTelephone(reqUpdateMailPhoneJson.getTelephone());

         actionnaireService.updateMailPhone(req);

        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(true, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Boolean> updateMifid(MifidNatMajJson mifidNatMajJson) {

        MifidNatMajDTO req = MifidNatMajDTOMapper.INSTANCE.jsonToDto(mifidNatMajJson);
        try {

            if(actionnaireService.updateMifid(req)){
                return new ResponseEntity<>(Boolean.TRUE, HttpStatus.OK);
            } else{
                return new ResponseEntity<>(Boolean.FALSE, HttpStatus.CONFLICT);
            }
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

    }


    @Override
    public ResponseEntity<Boolean> chekTitulaireKyc(String login) {
        boolean result;
        try {
            result = actionnaireService.chekTitulaireKyc(login);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @Override
    public ResponseEntity<ResultStatusJson> updateCspLanguage(ReqUpdateCspLanguageJson reqUpdateCspLanguageJson) {

        String serverResponse;
        ReqUpdateCspLanguageDto req = ReqUpdateCspLanguageJsonMapper.INSTANCE.jsonToDto(reqUpdateCspLanguageJson);

        try {

            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));

                req.setActiIden(claims.get("actiIden").toString());
                req.setEmetIden(claims.get("emetIden").toString());
                req.setTituNum(claims.get("titunume").toString());

                serverResponse = actionnaireService.updateCspLanguage(req);

        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            throw new RuntimeException(e);
        }
        return new ResponseEntity<>(new ResultStatusJson().status(serverResponse)
                , HttpStatus.OK);

    }

    @Override
    public ResponseEntity<ResultStatusJson> updateBancaireTitu(ReqUpdateBancaireTituJson reqUpdateBancaireTituJson) {

        String serverResponse;
        ReqUpdateBancaireTituDto req = ReqUpdateBancaireTituJsonMapper.INSTANCE.jsonToDto(reqUpdateBancaireTituJson);

        try {

            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));

            req.setActiIden(claims.get("actiIden").toString());
            req.setEmetIden(claims.get("emetIden").toString());
            req.setTituNum(claims.get("titunume").toString());

            serverResponse =  actionnaireService.updateBancaireTitu(req);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            throw new RuntimeException(e);
        }
        return new ResponseEntity<>(new ResultStatusJson().status(serverResponse)
                , HttpStatus.OK);
    }

    /**
     * POST /update/adresse-titu
     * Create a request to update adresse postale and fiscale in Registrar
     *
     * @param reqUpdateAdresseTituJson  (optional)
     * @return Mise à jour effectuée. (status code 200)
     *         or Bad request. Mise à jour non effectuée. (status code 400)
     *         or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     *         or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */

    //TODO code below to uncomment after mvp

    /*

    @Override
    public ResponseEntity<ResultStatusJson> updateAdresseTitu(ReqUpdateAdresseTituJson reqUpdateAdresseTituJson) {

        String serverResponse;
        ReqUpdateAdresseTituDto reqUpdateAdresseTitu = ReqUpdateAdresseTituJsonMapper.instance.jsonToDto(reqUpdateAdresseTituJson);
        try {
            serverResponse =  actionnaireService.updateAdresseTitu(reqUpdateAdresseTitu);
        } catch (FunctionnalException ex) {
            logger.info(ex.getMessage() + MESSAGE + ex.getContextParams().toString());
            throw new RuntimeException(ex);
        }

        return new ResponseEntity<>(new ResultStatusJson().status(serverResponse)
                , HttpStatus.OK);

    }

    @Override
    public ResponseEntity<ResultStatusJson> updateContactTitu(ReqUpdateContactTituJson reqUpdateContactTituJson) {

        String serverResponse;
        ReqUpdateContactTituDto req = ReqUpdateContactTituJsonMapper.INSTANCE.jsonToDto(reqUpdateContactTituJson);

        try {
            serverResponse =  actionnaireService.updateContactTitu(req);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + MESSAGE + e.getContextParams().toString());
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>(new ResultStatusJson().status(serverResponse)
                , HttpStatus.OK);

    }*/
}
