package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.api.DocumentationApi;
import com.uptevia.ms.bff.investor.business.api.model.FileJson;
import com.uptevia.ms.bff.investor.business.api.model.FileParamsJson;
import com.uptevia.ms.bff.investor.business.api.model.TypeDocumentsJson;
import com.uptevia.ms.bff.investor.business.app.exception.CustomResponseStatusException;
import com.uptevia.ms.bff.investor.business.app.mapper.FileJsonMapper;
import com.uptevia.ms.bff.investor.business.app.mapper.TypeDocumentJsonMapper;
import com.uptevia.ms.bff.investor.business.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.FileDTO;
import com.uptevia.ms.bff.investor.business.domain.model.TypeDocumentDTO;
import com.uptevia.ms.bff.investor.business.domain.service.DocumentationService;
import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import io.jsonwebtoken.Claims;
import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class DocumentationController implements DocumentationApi {

    Logger logger = LoggerFactory.getLogger(DocumentationController.class.getName());

    private final DocumentationService documentationService;
    @Autowired
    private JwtUtils jwtUtils;

    public DocumentationController(final DocumentationService documentationService) {
        this.documentationService = documentationService;
    }

    /**
     * GET /documentation
     * Affiche le type du document et les details
     *
     * @return informations trouvées pour ces parametres (status code 200)
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     * or Fichiers non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */
    @Override
    public ResponseEntity<List<TypeDocumentsJson>> getTypeDocument() {
        List<TypeDocumentDTO> typeDocumentDTO = new ArrayList<>();
        try {
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));
            if (claims != null)
                typeDocumentDTO = documentationService.getTypeDocuments(Integer.valueOf(claims.get("emetIden").toString()),
                        Integer.valueOf(claims.get("actiIden").toString()),
                        Integer.valueOf(claims.get("titunume").toString()));
        } catch (FunctionnalException ex) {
            throw new CustomResponseStatusException(HttpStatus.NO_CONTENT, ex.getCode(), ex.getContextParams());
        }
        return new ResponseEntity<>(typeDocumentDTO.stream()
                .map(TypeDocumentJsonMapper.INSTANCE::dtoToJson).toList(), HttpStatus.OK);
    }


    @Override
    public ResponseEntity<List<FileJson>> getFiles(Integer docId, String codeLangue) {

        List<FileDTO> files = null;
        try {
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));
            if (claims != null)
                files = documentationService.getFiles(Integer.valueOf(claims.get("emetIden").toString()),
                        Integer.valueOf(claims.get("actiIden").toString()),
                        Integer.valueOf(claims.get("titunume").toString()),
                        docId,
                        codeLangue);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }


        return new ResponseEntity<>(files
                .stream().map(FileJsonMapper.INSTANCE::dtoToJson).toList(), HttpStatus.OK);
    }



}