package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.api.EabonnementApi;
import com.uptevia.ms.bff.investor.business.api.model.*;
import com.uptevia.ms.bff.investor.business.app.mapper.*;
import com.uptevia.ms.bff.investor.business.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.service.EabonnementService;
import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;


@RestController
@RequestMapping("/api/v1")
@Slf4j
public class EabonnementController implements EabonnementApi {

    private static final String MESSAGE = "with the param : ";
    private final EabonnementService eabonnementService;

    @Autowired
    private JwtUtils jwtUtils;

    public EabonnementController(final EabonnementService eabonnementService) {
        this.eabonnementService = eabonnementService;
    }


    /**
     * POST /insert/Eabonnement
     * requete pour insérer le module d&#39;abonnement aux e-services
     *
     * @param eabonnementJson  (optional)
     * @return mise à jour effectuée avec succés  (status code 201)
     *         or Bad request. Mise à jour non effectuée. (status code 400)
     *         or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     *         or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */

    @Override
    public ResponseEntity<Void> insertEabonnement(final EabonnementJson eabonnementJson) {
        EabonnementDTO eabonnement = EabonnementDTOMapper.INSTANCE.JsonToDto(eabonnementJson);
        try {
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));
            eabonnement.setParamLogin(claims.getSubject());
            eabonnement.setParamEmetIden(Integer.valueOf(claims.get("emetIden").toString()));
            eabonnement.setParamActiIden(Integer.valueOf(claims.get("actiIden").toString()));
            eabonnement.setParamTituNume(Integer.valueOf(claims.get("titunume").toString()));
            eabonnementService.insertEabonnement(eabonnement);
        } catch (FunctionnalException ex) {
            log.error("Exception occurred while inserting data ", ex);
        }
        return new ResponseEntity<>(HttpStatus.CREATED);
    }



}
