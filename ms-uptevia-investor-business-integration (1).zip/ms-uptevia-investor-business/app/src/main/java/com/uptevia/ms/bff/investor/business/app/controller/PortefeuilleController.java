package com.uptevia.ms.bff.investor.business.app.controller;

import com.uptevia.ms.bff.investor.business.api.PortefeuilleApi;
import com.uptevia.ms.bff.investor.business.api.model.*;
import com.uptevia.ms.bff.investor.business.app.mapper.*;
import com.uptevia.ms.bff.investor.business.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.service.ActionnaireService;
import com.uptevia.ms.bff.investor.business.domain.service.PortefeuilleService;
import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import io.jsonwebtoken.Claims;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class PortefeuilleController implements PortefeuilleApi {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final PortefeuilleService portefeuilleService;
    private final ActionnaireService actionnaireService;
    @Autowired
    private JwtUtils jwtUtils;

    public PortefeuilleController(final PortefeuilleService portefeuilleService, ActionnaireService actionnaireService) {
        this.portefeuilleService = portefeuilleService;
        this.actionnaireService = actionnaireService;
    }

    @Override
    public ResponseEntity<PortefeuilleTitreJson> getPortefeuilleTitres() {

        List<CompteDTO> comptes = null;
        PortefeuilleTitreDTO portefeuilleTitre = null;
        try {
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));
            comptes = actionnaireService.getComptes(claims.getSubject());
            portefeuilleTitre = portefeuilleService.getPortefeuilleTitres(comptes.get(0).getEmetIden(), comptes.get(0).getActiIden());

        } catch (FunctionnalException e) {
            logger.info(String.format("{0} with the param : ", e.getMessage() , e.getContextParams().toString()));
            return new ResponseEntity<>(
                    HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<>(
                PortefeuilleTitreJsonMapper.INSTANCE.dtoToJson(
                        portefeuilleTitre
                ), HttpStatus.OK);
    }
}