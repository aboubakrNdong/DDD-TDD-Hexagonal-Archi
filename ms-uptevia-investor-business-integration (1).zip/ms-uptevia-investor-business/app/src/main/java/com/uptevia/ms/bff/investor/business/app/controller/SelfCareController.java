package com.uptevia.ms.bff.investor.business.app.controller;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uptevia.ms.bff.investor.business.api.SelfcareApi;
import com.uptevia.ms.bff.investor.business.api.model.CategoriesJson;
import com.uptevia.ms.bff.investor.business.api.model.DemandeJson;
import com.uptevia.ms.bff.investor.business.api.model.PayloadJson;
import com.uptevia.ms.bff.investor.business.app.mapper.CategoriesJsonMapper;
import com.uptevia.ms.bff.investor.business.app.mapper.DemandeDTOMapper;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.CategoriesDTO;
import com.uptevia.ms.bff.investor.business.domain.model.DemandeDTO;
import com.uptevia.ms.bff.investor.business.domain.service.ParamsService;
import com.uptevia.ms.bff.investor.business.domain.service.SelfCareService;
import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import com.uptevia.ms.bff.investor.business.domain.util.ToolsManager;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Payload;
import java.util.List;
import java.util.logging.Logger;
import com.uptevia.ms.bff.investor.business.app.security.jwt.JwtUtils;


@RestController
@RequestMapping("/api/v1")
@Slf4j
public class SelfCareController implements SelfcareApi {


    @Autowired
    private JwtUtils jwtUtils;

    private final SelfCareService selfCareService;
    private final ParamsService paramsService;

    public SelfCareController(final SelfCareService selfCareService, ParamsService paramsService) {
        this.selfCareService = selfCareService;
        this.paramsService = paramsService;
    }

    /**
     * GET /categories
     * get categories and sous categories for Faq Forms
     *
     * @param pIndiLogged connecté / non connecté (required)
     * @return une liste des categories et sous categories a été trouvé pour ces parametres (status code 200)
     *         or Retour de la procédure stockée incorrect (status code 400)
     *         or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     *         or Categories non trouvé pour ces parametres (status code 404)
     *         or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */

    @Override
    public ResponseEntity<List<CategoriesJson>> getCategories(String pIndiLogged) {
        List<CategoriesDTO> categoriesDTOS = null;

        try {
            categoriesDTOS = selfCareService.getCategories(pIndiLogged);
        } catch (FunctionnalException ex) {
            log.error("Exception occurred while getting files ", ex);
        }

        return new ResponseEntity<>(categoriesDTOS.stream()
                .map(CategoriesJsonMapper.INSTANCE::dtoToJson).toList(), HttpStatus.OK);
    }

    @Override
    public ResponseEntity<Void> createSelfCare(PayloadJson payload) {

        boolean isConnected = false;
        String decryptedData = ToolsManager.decryptFromFront(payload.getPayload());
        if (decryptedData == null) {
            log.warn("Erreur de dechiffrement");
            return new ResponseEntity<>( HttpStatus.BAD_REQUEST);
        }

        DemandeDTO demandeTosave  = makeDemandeDTOFromPayload(decryptedData);

        try {
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            if(currentRequest.getHeader(Constantes.AUTHORIZATION) != null){
                isConnected = true;
            }
            String grcMail = paramsService.getParamValueByName("GRC_MAIL");
            selfCareService.createSelfCare(demandeTosave, grcMail, isConnected);
        } catch (FunctionnalException ex) {
            log.error("Exception occurred while creating Demand or getting grcMail ", ex);
        }
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    private DemandeDTO makeDemandeDTOFromPayload(String decryptedData) {
        try {
            JsonNode jObj;
            ObjectMapper mapper = new ObjectMapper();
            JsonFactory factory = mapper.getJsonFactory();

            JsonParser parser = factory.createJsonParser(decryptedData);
            jObj = mapper.readTree(parser);

            return DemandeDTO.builder()
                    .identifier(jObj.get("identifiant").asText())
                    .actiIden(jObj.get("actiIden").asText())
                    .emetIden(jObj.get("emetIden").asText())
                    .tituNume(jObj.get("tituNume").asText())
                    .category(jObj.get("category").asText())
                    .subCategory(jObj.get("subCategory").asText())
                    .firstName(jObj.get("firstName").asText())
                    .lastName(jObj.get("lastName").asText())
                    .telephone(jObj.get("telephone").asText())
                    .selectphone(jObj.get("selectphone").asText())
                    .email(jObj.get(("email")).asText())
                    .pays(jObj.get("pays").asText())
                    .dob(jObj.get("dob").asText())
                    .message(jObj.get("message").asText())
                    .lang(jObj.get("lang").asText())
                    .build();
        } catch (Exception e) {
            log.info(e.getMessage());
            return null;
        }
    }

}
