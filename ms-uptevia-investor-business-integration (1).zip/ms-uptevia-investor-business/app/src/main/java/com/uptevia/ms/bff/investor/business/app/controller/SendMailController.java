package com.uptevia.ms.bff.investor.business.app.controller;



import com.uptevia.ms.bff.investor.business.api.SendMailApi;
import com.uptevia.ms.bff.investor.business.api.model.EmailBodyJson;
import com.uptevia.ms.bff.investor.business.app.mapper.EmailBodyDTOMapper;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.service.EmailService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.logging.Logger;

@RestController
@RequestMapping("/api/v1")
@Slf4j
public class SendMailController implements SendMailApi {

    Logger logger = Logger.getLogger(SendMailController.class.getName());
    private final EmailService emailService;

    public SendMailController(EmailService emailService) {
        this.emailService = emailService;
    }

    @Override
    public ResponseEntity<Boolean> sendMail(String  recipients, EmailBodyJson emailBody, String htmlBody, String subject, String typeMail, List<MultipartFile> attachments ) {

        try {
            emailService.sendMail(recipients, EmailBodyDTOMapper.INSTANCE.JsonToDto(emailBody), htmlBody, subject, typeMail, attachments);
        } catch (FunctionnalException exception) {
            log.error("Exception occurred while sending mail", exception);
        }
        return new ResponseEntity<>(true, HttpStatus.OK);
    }



}