package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.AvoirTitreJson;

import com.uptevia.ms.bff.investor.business.domain.model.AvoirTitreDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AvoirTitreJsonMapper {


    AvoirTitreJsonMapper INSTANCE = Mappers.getMapper(AvoirTitreJsonMapper.class);

    AvoirTitreJson dtoToJson(AvoirTitreDTO ligneAvoirsDTO);
}
