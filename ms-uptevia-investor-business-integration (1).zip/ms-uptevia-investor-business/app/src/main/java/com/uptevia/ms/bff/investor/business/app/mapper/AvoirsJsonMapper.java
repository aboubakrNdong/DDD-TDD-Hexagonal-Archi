package com.uptevia.ms.bff.investor.business.app.mapper;



import com.uptevia.ms.bff.investor.business.api.model.AvoirsJson;
import com.uptevia.ms.bff.investor.business.domain.model.AvoirsDTO;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AvoirsJsonMapper {

    AvoirsJsonMapper INSTANCE = Mappers.getMapper(AvoirsJsonMapper.class);
    AvoirsJson dtoToJson(AvoirsDTO avoirsDTO);

}
