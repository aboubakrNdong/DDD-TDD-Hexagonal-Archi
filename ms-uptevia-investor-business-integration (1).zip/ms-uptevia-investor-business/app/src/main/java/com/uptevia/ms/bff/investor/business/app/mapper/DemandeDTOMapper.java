package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.DemandeJson;
import com.uptevia.ms.bff.investor.business.domain.model.DemandeDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DemandeDTOMapper {

    DemandeDTOMapper INSTANCE = Mappers.getMapper(DemandeDTOMapper.class);

    DemandeDTO JsonToDto(DemandeJson emetteurJson);
}
