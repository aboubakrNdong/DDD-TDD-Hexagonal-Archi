package com.uptevia.ms.bff.investor.business.app.mapper;


import com.uptevia.ms.bff.investor.business.api.model.EmailBodyJson;
import com.uptevia.ms.bff.investor.business.domain.model.EmailBodyDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface EmailBodyDTOMapper {


        EmailBodyDTOMapper INSTANCE = Mappers.getMapper(EmailBodyDTOMapper.class);

        EmailBodyDTO JsonToDto(EmailBodyJson emailBodyJson);

}
