package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.GroupeTitreJson;
import com.uptevia.ms.bff.investor.business.domain.model.GroupeTitreDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface GroupeTitreJsonMapper {

    GroupeTitreJsonMapper INSTANCE = Mappers.getMapper(GroupeTitreJsonMapper.class);

    GroupeTitreJson dtoToJson(GroupeTitreDTO dto);
}
