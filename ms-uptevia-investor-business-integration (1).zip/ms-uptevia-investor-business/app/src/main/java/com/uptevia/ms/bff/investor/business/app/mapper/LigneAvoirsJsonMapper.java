package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.LigneAvoirsJson;

import com.uptevia.ms.bff.investor.business.domain.model.LigneAvoirsDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface LigneAvoirsJsonMapper {


    LigneAvoirsJsonMapper INSTANCE = Mappers.getMapper(LigneAvoirsJsonMapper.class);

    LigneAvoirsJson dtoToJson(LigneAvoirsDTO ligneAvoirsDTO);
}
