package com.uptevia.ms.bff.investor.business.app.mapper;


import com.uptevia.ms.bff.investor.business.api.model.MifidNatMajJson;
import com.uptevia.ms.bff.investor.business.domain.model.MifidNatMajDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface MifidNatMajDTOMapper {

    MifidNatMajDTOMapper INSTANCE = Mappers.getMapper(MifidNatMajDTOMapper.class);

    MifidNatMajDTO jsonToDto(MifidNatMajJson emetteurJson);
}
