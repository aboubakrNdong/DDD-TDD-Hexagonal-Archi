package com.uptevia.ms.bff.investor.business.app.mapper;


import com.uptevia.ms.bff.investor.business.api.model.OperationPrerequisResponseJson;

import com.uptevia.ms.bff.investor.business.domain.model.OperationPrerequisDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface OperationPrerequisResponseJsonMapper {

    OperationPrerequisResponseJsonMapper INSTANCE = Mappers.getMapper(OperationPrerequisResponseJsonMapper.class);
    OperationPrerequisResponseJson dtoToJson(OperationPrerequisDTO operationPrerequisDTO);

}
