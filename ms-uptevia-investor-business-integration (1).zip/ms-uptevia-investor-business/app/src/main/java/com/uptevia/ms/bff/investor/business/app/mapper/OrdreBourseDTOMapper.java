package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.OrdreBourseJson;
import com.uptevia.ms.bff.investor.business.domain.model.OrdreBourseDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface OrdreBourseDTOMapper {

    OrdreBourseDTOMapper INSTANCE = Mappers.getMapper(OrdreBourseDTOMapper.class);

    OrdreBourseDTO jsonToDto(OrdreBourseJson ordreBourseJson);
}
