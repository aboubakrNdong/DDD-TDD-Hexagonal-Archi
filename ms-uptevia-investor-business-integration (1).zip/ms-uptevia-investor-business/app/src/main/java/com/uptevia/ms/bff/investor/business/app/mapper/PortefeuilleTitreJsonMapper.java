package com.uptevia.ms.bff.investor.business.app.mapper;


import com.uptevia.ms.bff.investor.business.api.model.PortefeuilleTitreJson;
import com.uptevia.ms.bff.investor.business.domain.model.PortefeuilleTitreDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
@Mapper
public interface PortefeuilleTitreJsonMapper {

    PortefeuilleTitreJsonMapper INSTANCE = Mappers.getMapper(PortefeuilleTitreJsonMapper.class);

    PortefeuilleTitreJson dtoToJson(PortefeuilleTitreDTO dto);
}
