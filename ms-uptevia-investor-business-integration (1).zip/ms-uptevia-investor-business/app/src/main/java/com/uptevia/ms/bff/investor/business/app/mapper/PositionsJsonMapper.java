package com.uptevia.ms.bff.investor.business.app.mapper;


import com.uptevia.ms.bff.investor.business.api.model.PositionsJson;
import com.uptevia.ms.bff.investor.business.domain.model.PositionsDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PositionsJsonMapper {

    PositionsJsonMapper INSTANCE = Mappers.getMapper(PositionsJsonMapper.class);
    PositionsJson dtoToJson(PositionsDTO positionsDTO);

}
