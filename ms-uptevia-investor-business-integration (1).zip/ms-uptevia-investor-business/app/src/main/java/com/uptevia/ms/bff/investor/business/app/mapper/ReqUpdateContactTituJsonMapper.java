package com.uptevia.ms.bff.investor.business.app.mapper;


import com.uptevia.ms.bff.investor.business.api.model.ReqUpdateAdresseTituJson;
import com.uptevia.ms.bff.investor.business.api.model.ReqUpdateContactTituJson;
import com.uptevia.ms.bff.investor.business.domain.model.ReqUpdateAdresseTituDto;
import com.uptevia.ms.bff.investor.business.domain.model.ReqUpdateContactTituDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ReqUpdateContactTituJsonMapper {
    ReqUpdateContactTituJsonMapper INSTANCE = Mappers.getMapper(ReqUpdateContactTituJsonMapper.class);
    ReqUpdateContactTituDto jsonToDto(ReqUpdateContactTituJson redJson);

}
