package com.uptevia.ms.bff.investor.business.app.mapper;


import com.uptevia.ms.bff.investor.business.api.model.ReqUpdateCspLanguageJson;
import com.uptevia.ms.bff.investor.business.domain.model.ReqUpdateCspLanguageDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ReqUpdateCspLanguageJsonMapper {
    ReqUpdateCspLanguageJsonMapper INSTANCE = Mappers.getMapper(ReqUpdateCspLanguageJsonMapper.class);
    ReqUpdateCspLanguageDto jsonToDto(ReqUpdateCspLanguageJson redJson);

}
