package com.uptevia.ms.bff.investor.business.app.mapper;


import com.uptevia.ms.bff.investor.business.api.model.ReqUpdateMailPhoneJson;
import com.uptevia.ms.bff.investor.business.domain.model.ReqUpdateMailPhone;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ReqUpdateMailPhoneJsonMapper {
    ReqUpdateMailPhoneJsonMapper INSTANCE = Mappers.getMapper(ReqUpdateMailPhoneJsonMapper.class);
    ReqUpdateMailPhone jsonToDto(ReqUpdateMailPhoneJson redJson);
}
