package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.ResultStatusJson;
import com.uptevia.ms.bff.investor.business.domain.model.ResultStatusDTO;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ResultStatusMapper {

    ResultStatusMapper INSTANCE = Mappers.getMapper(ResultStatusMapper.class);
    ResultStatusJson dtoToJson(ResultStatusDTO resultStatusDTO);
}