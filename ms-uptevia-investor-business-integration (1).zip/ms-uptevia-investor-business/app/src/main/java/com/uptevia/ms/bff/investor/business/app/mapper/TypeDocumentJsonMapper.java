package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.TypeDocumentsJson;
import com.uptevia.ms.bff.investor.business.domain.model.TypeDocumentDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TypeDocumentJsonMapper {

    TypeDocumentJsonMapper INSTANCE = Mappers.getMapper(TypeDocumentJsonMapper.class);
    TypeDocumentsJson dtoToJson(TypeDocumentDTO typeDocumentDTO);

}
