package com.uptevia.ms.bff.investor.business.app.mapper;

import com.uptevia.ms.bff.investor.business.api.model.ValeurDetailJson;
import com.uptevia.ms.bff.investor.business.domain.model.ValeurDetailDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ValeurDetailJsonMapper {

    ValeurDetailJsonMapper INSTANCE = Mappers.getMapper(ValeurDetailJsonMapper.class);

    ValeurDetailJson dtoToJson(ValeurDetailDTO valeurDetailDTO);
}