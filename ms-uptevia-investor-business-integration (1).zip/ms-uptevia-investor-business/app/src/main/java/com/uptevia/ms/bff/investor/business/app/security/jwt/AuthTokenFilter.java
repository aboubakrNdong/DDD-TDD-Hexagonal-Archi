package com.uptevia.ms.bff.investor.business.app.security.jwt;

import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Slf4j
public class AuthTokenFilter extends OncePerRequestFilter {


    private final JwtUtils jwtUtils;
    public AuthTokenFilter(final JwtUtils jwtUtils) {
        this.jwtUtils = jwtUtils;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

        try {

            String jwtToken = jwtUtils.resolveToken(httpServletRequest);
            log.info("Begin business token validation ...");
            if (jwtToken != null && jwtUtils.validateJwtToken(jwtToken)) {
                log.info("Getting username from token .... ");
                String username = jwtUtils.getUserNameFromJwtToken(jwtToken);

                UsernamePasswordAuthenticationToken authentication =
                        new UsernamePasswordAuthenticationToken(username, null,
                                null);

                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(httpServletRequest));
                log.info("creating security context for connected user... ");
                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
        } catch (Exception e) {
            logger.error("Cannot set user authentication: {}", e);
        }

        logger.info("processing request filter ...");
        filterChain.doFilter(httpServletRequest, response);
    }

}
