package com.uptevia.ms.bff.investor.business.app.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.uptevia.ms.bff.investor.business.api.model.FileParamsJson;

import com.uptevia.ms.bff.investor.business.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.FileDTO;
import com.uptevia.ms.bff.investor.business.domain.model.TypeDocumentDTO;
import com.uptevia.ms.bff.investor.business.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.business.domain.service.DocumentationService;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.List;
import java.util.stream.Collectors;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = DocumentationController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
class DocumentationControllerTest {

    private static String URL_GET_TYPEDOCUMENT_LINKS = "/api/v1/typeDocument";
    private static String URL_GET_FILES_LINKS = "/api/v1/files";
    @MockBean
    private JwtUtils jwtUtils;
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    private DocumentationService documentationService;
    private static EasyRandom easyRandom = new EasyRandom();

    @Test
    void should_return_get_typeDocument_ok() throws Exception {

        int idEmet = 99963514;
        int idActi = 2;
        int pTituNume = 1;

        List<TypeDocumentDTO> typeDocument = easyRandom.objects(TypeDocumentDTO.class, 1)
                .collect(Collectors.toList());
        typeDocument.forEach(e -> {
            e.setDocumentTypeId(1);
            e.setDocumentTypeTraductionKey("document.type.caceis.guides.pratiques");
        });
        Mockito.when(documentationService.getTypeDocuments(idEmet, idActi, pTituNume)).thenReturn(typeDocument);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_TYPEDOCUMENT_LINKS)
                        //.header("Authorization", "Bearer ", userDTO.getToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isOk());
    }

    @Test
    void should_return_get_typeDocument_and_return_404() throws Exception {
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        int idEmet = 99963514;
        int idActi = 2;
        int pTituNume = 1;

        Mockito.when(documentationService.getTypeDocuments(idEmet, idActi, pTituNume)).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.get("/api/typeDocument")
                        .header("Authorization", "Bearer ", userDTO.getToken())
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isNotFound());
    }

    @Test
    void should_return_get_typedocument_and_return_400() throws Exception {
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(documentationService.getTypeDocuments(anyInt(), anyInt(), anyInt())).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_TYPEDOCUMENT_LINKS)
                .header("Authorization", "Bearer ", userDTO.getToken()))
                .andExpect(status().isOk())
                .andExpect(forwardedUrl(null));
    }
   /* @Test
    void should_return_get_files_ok() throws Exception {

        int idEmet = 99963514;
        int idActi = 2;
        int pTituNume = 1;
        int pDocId = 1;
        String pCodeLangue = "FRA";
        FileParamsJson fileParamsJson = new FileParamsJson();
        fileParamsJson.setActiIden(idActi);
        fileParamsJson.setEmetIden(idEmet);
        fileParamsJson.setCodeLangue("FRA");
        fileParamsJson.setDocId(1);
        List<FileDTO> files = easyRandom.objects(FileDTO.class, 1)
                .collect(Collectors.toList());
        files.forEach(e -> {
            e.setDocumentId(1);
            e.setDocumentContentType("application/pdf");
        });
        Mockito.when(documentationService.getFiles(idEmet, idActi,pTituNume,pDocId, pCodeLangue)).thenReturn(files);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_FILES_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(fileParamsJson.toString())
                        .characterEncoding("UTF-8"))
                .andExpect(jsonPath("$.*").isArray());
    }*/


   @Test
    void should_return_get_files_and_return_500() throws Exception {

        Mockito.when(documentationService.getFiles(99963514, 2, 1, 1, "FRA")).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_FILES_LINKS)
                        .queryParam("emetIden", "99963514")
                        .queryParam("actiIden", "2")
                        .queryParam("tituNume", "1")
                        .queryParam("docId", "1")
                        .queryParam("codeLangue", "FRA")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void should_return_get_files_and_return_404() throws Exception {

        FileParamsJson fileParamsJson = new FileParamsJson();
        /*fileParamsJson.setActiIden(2);
        fileParamsJson.setEmetIden(99963514);
        fileParamsJson.setTituNume(1);*/
        fileParamsJson.setCodeLangue("FRA");
        fileParamsJson.setDocId(1);
        Mockito.when(documentationService.getFiles(99963514, 2, 1, 1, "FRA")).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.get("/api/files")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(fileParamsJson))
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());
    }

    public static String asJsonString(final Object obj) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
