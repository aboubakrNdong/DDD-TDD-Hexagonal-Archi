package com.uptevia.ms.bff.investor.business.app.controller;



import com.uptevia.ms.bff.investor.business.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.NewsDTO;

import com.uptevia.ms.bff.investor.business.domain.model.UserDTO;
import com.uptevia.ms.bff.investor.business.domain.service.NewsService;
import org.jeasy.random.EasyRandom;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.mockito.ArgumentMatchers.anyInt;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = NewsController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
class NewsControllerTest {

    private static String URL_API_GET = "/api/v1/news";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private NewsService newsService;

    @MockBean
    private JwtUtils jwtUtils;

    private EasyRandom easyRandom = new EasyRandom();

    @Test
    void should_return_get_news_ok() throws Exception {
        //Given
        NewsDTO newsDTO = easyRandom.nextObject(NewsDTO.class);
        int idEmet = 99963514;
        int idActi = 1;
        int pTituNume = 1;

        // When
        Mockito.when(newsService.getNews(idEmet, idActi, pTituNume)).thenReturn(newsDTO);

        //Then
        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_API_GET))
                .andExpect(status().isOk())
                .andDo(print());

    }

    @Test
    void should_return_get_news_and_return_400() throws Exception {
        //Given
        NewsDTO newsDTO = easyRandom.nextObject(NewsDTO.class);
        int idEmet = 99963514;
        int idActi = 1;
        int pTituNume = 1;
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        // When
        Mockito.when(newsService.getNews(anyInt(), anyInt(), anyInt())).thenThrow(new FunctionnalException("code", "message"));

        //Then
        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_API_GET))
                .andExpect(status().isOk())
                .andExpect(forwardedUrl(null));

    }


    @Test
    void should_return_get_news_and_return_404() throws Exception {

        // When
        Mockito.when(newsService.getNews(anyInt(), anyInt(), anyInt())).thenThrow(new FunctionnalException("code", "message"));

        //Then
        this.mockMvc.perform(MockMvcRequestBuilders.get("/api/news"))
                .andExpect(status().isNotFound());

    }


}