package com.uptevia.ms.bff.investor.business.domain.model;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Builder
@Getter
@Setter
public class AvoirTitreDTO {
    private Boolean disponible;
    private Integer quantite;
    private String natureJuridique;
    private String valeIden;
    private String valeLibe;
    private String devise;
    private double prixAcquisition;
    private double prixSouscription;
    private double coursAcquisition;
    private double coursLevee;
    private double dernierCours;
    private String categorie;
    private double valorisation;
    private String restriction;
    private LocalDate dateDispo;
    private LocalDate dateLevee;
    private LocalDate dateAcquisition;
    private LocalDate dateSouscription;
    private LocalDate dateSoaa;
    private LocalDate dateVoteDoubleBrut;
    private LocalDate dateVoteDouble;
    private LocalDate dateDetentionBrut;
    private LocalDate dateCessFiscale;
    private String admiIden;
    private String typeDetention;
    private String qualificatif;
    private String valeIdenPlan;
    private String cpteIden;
    private Long voix;
}
