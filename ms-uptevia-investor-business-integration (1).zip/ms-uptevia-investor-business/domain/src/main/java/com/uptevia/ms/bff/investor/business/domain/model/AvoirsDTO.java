package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;
@Getter
@Setter
public class AvoirsDTO {

    private String codeLibelle;

    private Integer qteTotale;

    private BigDecimal valorisationTotale;

    private String devise;

    private List<AvoirsDetailsDTO> details ;
}
