package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;


@Builder
@Getter
@Setter
public class BaremeDTO {
    private String idextBarcomms;
    private Integer emetIden;
    private String baremeWeb;
    private double amount0D;
    private double amount1D;
    private double amount2D;
    private double amount3D;
    private double amount4D;
    private double amount5D;
    private double amount6D;
    private double amount7D;
    private double amount8D;
    private double amount9D;
    private double percent0D;
    private double percent1D;
    private double percent2D;
    private double percent3D;
    private double percent4D;
    private double percent5D;
    private double percent6D;
    private double percent7D;
    private double percent8D;
    private double percent9D;
    private double mtMinD;
    private double mtMaxD;

}


