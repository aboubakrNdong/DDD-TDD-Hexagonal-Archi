package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CategoriesDTO {

    private int typoId;

    private String typoTraductionKey;

    private int typoOrdre;

    private List<SousCategoriesDTO> sousCategories = null;

}
