package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter


public class CodeIso2DTO {

    private String libelle;

    private String paysIso2;

    private String paysIndiSepa;

    private String paysIso2Bic;

    private Integer paysIbanLong;

}
