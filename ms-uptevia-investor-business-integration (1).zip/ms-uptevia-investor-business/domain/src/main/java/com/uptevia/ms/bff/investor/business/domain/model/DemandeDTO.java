package com.uptevia.ms.bff.investor.business.domain.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.ExtensionMethod;

import java.time.LocalDate;

@Getter
@Setter
@Builder
@ExtensionMethod({
        DemandeDTO.class
})
public class DemandeDTO {

    private  String identifier;

    private String pIndiLogged;

    private String actiIden;

    private String emetIden;

    private String tituNume;

    private String category;

    private String subCategory;

    private String firstName;

    private String lastName;

    private String telephone;

    private String selectphone;

    private String email;

    private String pays;

    private String dob;

    private String message;

    private String lang;


    public static <T> String toJson(T source) {
        //Creating the ObjectMapper object
        ObjectMapper mapper = new ObjectMapper();
        String jsonStr = "";
        try {
            // Getting source object as a json string
           jsonStr = mapper.writeValueAsString(source);
        }
        catch (JsonProcessingException e){
            e.printStackTrace();
        }
        return jsonStr;
    }
}
