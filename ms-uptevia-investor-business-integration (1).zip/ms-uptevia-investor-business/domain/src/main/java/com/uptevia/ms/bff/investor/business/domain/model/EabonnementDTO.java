package com.uptevia.ms.bff.investor.business.domain.model;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Builder
public class EabonnementDTO {

    private String paramLogin;

    private Integer paramEmetIden;

    private Integer paramActiIden;

    private Integer paramTituNume;

    private String paramChoix;

    private Date paramDateChoix;

}

