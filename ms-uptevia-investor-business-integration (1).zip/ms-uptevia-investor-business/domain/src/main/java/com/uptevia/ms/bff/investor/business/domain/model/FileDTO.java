package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter


public class FileDTO {

    private int documentId;

    private String documentFileName;

    private String documentContentType;

    private byte [] documentContent;

}
