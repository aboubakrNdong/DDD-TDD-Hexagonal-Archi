package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Builder
@Getter
@Setter
public class LigneAvoirsDTO {

    private String natureJuridique;
    private String libePlan;
    private String valeIdenPlan;
    private Integer regptAvoir;
    private String rubCompta;
    private Integer nbActionDispo;
    private String categorie;
    private double prixAcquisition;
    private String qualificatif;
    private LocalDate dateDispo;
    private LocalDate dateLevee;
    private LocalDate dateSouscription;
    private String restrictionJuridique;
    private Integer numAvoa;
    private Integer nbActionAVendre;
    private Integer priorite;
    private LocalDate dateSoaa;

    private LocalDate dateVoteDoubleBrut;
    private LocalDate dateDetentionBrut;
    private LocalDate dateCessFiscale;
}
