package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class MifidNatMajDTO {
    private Integer emetIden;

    private Integer actiIden;

    private Integer tituNume;

    private String natioIso3;

    private String idNatioType;

    private String idNatioMifid;

    private String pjType;

    private String pjNume;
    private String pjGed;

    private LocalDate pjDateExpir;

    private LocalDate pjDateDeliv;
    private String origine;
}
