package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class NewsDTO  implements Serializable {

    private List<ActusDTO> actus;

}
