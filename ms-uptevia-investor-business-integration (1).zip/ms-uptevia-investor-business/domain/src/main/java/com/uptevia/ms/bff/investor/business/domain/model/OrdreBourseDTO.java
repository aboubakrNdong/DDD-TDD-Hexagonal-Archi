package com.uptevia.ms.bff.investor.business.domain.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.ExtensionMethod;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@Builder
@ExtensionMethod({
        OrdreBourseDTO.class
})
public class OrdreBourseDTO {
    // Info Actionnaire à prendre en Front
    private Integer emetIden;
    private Integer actiIden;
    private Integer tituNume;
    private String login;


    // Info Actionnaire à prendre en Back
    private String emetLibelle;
    private String tituNom;
    private String tituPrenom;
    private String tituQualite;
    private LocalDate tituDateNais;
    private String tituEmail;


    // Info Achat
    private Integer idDemande; // Ce qui est réutilisé entre les proc
    private String numDemandeCurrval; // Ce qui est envoyer comme reference au front

    private Integer natureDemande;

    private Integer typeVente;

    private String valeIden;

    private Integer nbActions;

    private double coursLimite;

    private LocalDate dateFinValidite;

    private Long ocbIdTransaction;

    //Info Reglement
    private double regltAttendu;
    private Integer modeReglt;
    private LocalDate dateRgltRecu;


    // Info Titres
    private List<LigneAvoirsDTO> titres;

    public static <T> String toJson(T source) {
        //Creating the ObjectMapper object
        ObjectMapper mapper = new ObjectMapper();
        String jsonStr = "";
        try {
            // Getting source object as a json string
            jsonStr = mapper.writeValueAsString(source);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return jsonStr;
    }
}
