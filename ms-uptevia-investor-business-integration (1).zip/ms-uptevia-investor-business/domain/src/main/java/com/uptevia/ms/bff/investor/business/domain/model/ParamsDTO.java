package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@Builder
public class ParamsDTO {
    private String paramName;
    private String paramValue;
    private String paramCategory;
}