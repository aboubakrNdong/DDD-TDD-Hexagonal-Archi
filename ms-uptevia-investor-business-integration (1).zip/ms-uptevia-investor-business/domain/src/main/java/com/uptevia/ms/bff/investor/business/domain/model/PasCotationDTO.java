package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Getter;
import lombok.Setter;
import lombok.Builder;

@Builder
@Getter
@Setter
public class PasCotationDTO {
    private Integer tickSize;
    private double tranMin;
    private double tranMax;
    private double eche;
}
