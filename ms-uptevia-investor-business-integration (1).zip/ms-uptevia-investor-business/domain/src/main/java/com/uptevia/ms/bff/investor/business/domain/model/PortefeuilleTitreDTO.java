package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Builder
@Getter
@Setter
public class PortefeuilleTitreDTO {

    private double valorisationTotal;
    private String devise ;
    private Integer titresTotal;
    private Long droitsVote;
    private Integer titresDispo;
    private Integer titresIndispo;
    private List<GroupeTitreDTO> groupeTitres = null;
}
