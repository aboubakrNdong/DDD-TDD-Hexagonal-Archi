package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter
public class ReqUpdateAdresseTituDto {

    private String emetIden;
    private String actiIden;
    private String tituNum;
    private String typeAdre;
    private String adreInfoRue;
    private String adreComp;
    private String adreCodp;
    private String adreNomComu;
    private String adrePaysIden;
    private String adreBati;
    private String adreFiscDept;
    private String adreFiscCodeComu;

}