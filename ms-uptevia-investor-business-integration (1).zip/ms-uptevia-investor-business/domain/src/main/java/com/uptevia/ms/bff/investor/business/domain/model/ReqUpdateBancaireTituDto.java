package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter
public class ReqUpdateBancaireTituDto {

    private String emetIden;
    private String actiIden;
    private String tituNum;
    private String type;
    private String sCodePaysReglement;
    private String sDevise;
    private String sModeReglement;
    private String sAgence;
    private String sBanque;
    private String sCle;
    private String sCompte;
    private String sDomiciliation;
    private String sBeneficiaire;
    private String sRibeBankCode;
    private String sRibeAgen;
    private String sRibCtrlInte;
    private String sRibCpt1;
    private String sRibCpt2;

    private String sRibCtrlFin;

    private String sRibBic;

    private String sRibBankNom;

    private String sRibBankAdress;

    private String sRibIban;
    private String sRibBicIntermediaire;
    private String sRibBicCouverture;
    private String sRibBankIntermediaireNom;
    private String sRibBankIntermediaireNomAdress;
    private String sRibeCptBankBenefChezBankIntermediaire;
    private String sRibeBankCouvertureNom;
    private String sRibeBankCouvertureNomAdre;
    private String sRibeCptBankInterChezBankCouverture;

}