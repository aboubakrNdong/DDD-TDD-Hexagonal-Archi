package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter
public class ReqUpdateContactTituDto {

    private String emetIden;
    private String actiIden;
    private String tituNum;
    private String tituEmail;
    private String tituEmail2;
    private String tituNumMobilePerso;
    private String tituNumMobilePersoIndiPays;
    private String tituNumMobilePro;
    private String tituNumMobileProIndiPays;
    private String tituNumTel;
    private String tituNumTelIndiPays;
    private String tituNumTel2;
    private String tituNumTel2IndiPays;
    private String typecontact;
    private String typeCoord;
    private String numFaxPro;
    private String numFaxProIndiPays;
    private String numFaxPerso;
    private String numFaxPersoIndiPays;

}