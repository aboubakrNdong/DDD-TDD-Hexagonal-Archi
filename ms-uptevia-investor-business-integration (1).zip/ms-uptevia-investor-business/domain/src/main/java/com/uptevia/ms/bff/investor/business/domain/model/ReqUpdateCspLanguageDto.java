package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter
public class ReqUpdateCspLanguageDto {

    private String emetIden;
    private String actiIden;
    private String tituNum;
    private String csp;
    private String language;

}