package com.uptevia.ms.bff.investor.business.domain.model;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter

public class SousCategoriesDTO {

    private int cateTypoId;

    private String cateTypoTraductionKey;

    private int cateTypoOrdre;

    private int sousTypoId;

    private String sousTypoTraductionKey;

    private String sousTypoIndiPjObligatoire;

    private int sousTypoOrdre;
}
