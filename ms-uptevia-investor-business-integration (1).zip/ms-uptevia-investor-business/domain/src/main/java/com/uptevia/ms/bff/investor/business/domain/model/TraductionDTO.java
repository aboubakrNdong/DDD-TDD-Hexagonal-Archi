package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class TraductionDTO {

    private String key;

    private String libelle;

    private int themeId;

    private String codeLangue;

}
