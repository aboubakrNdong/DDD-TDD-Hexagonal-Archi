package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Getter;
import lombok.Setter;
import lombok.Builder;

@Builder
@Getter
@Setter
public class ValeurDTO {

    private Boolean isValeurPrincipale;
    private String valeIden;
    private String valeGestIden;
    private String valeLibe;
    private String valeLibe2;
    private String valeNatu;
    private String valeDepo;
    private String valeNego;
    private String valeCate;
    private Integer valeScale;
    private String deviseNego;
    private String codePlace;
    private String libelleCodePlace;
    private String iCodePrime;
    private Integer iPromesse;
    private String valeurPatio;
    private double tauxTtf;
    private double tauxFraisBancaires;
    private double minFrais;
    private double tauxImpotBourse;
    private Integer isValeurEtrangere;
    private Integer isValEtrAutorisee;
    private Integer displayTutoSpe;
    private Integer valeurAffichableVente;
    private Integer valeurVendableOlis;
    private Integer valeurAffichableAchat;
    private Integer valeurAchetableOlis;
    private double dernierCours;
    private double dernierCoursEuro;
    private String deviseCours;
    private double coursOuverture;
    private String coursDate;
    private boolean possedeTitres;
    private Long solde;
    private Long repartie ;
    private Long disponible ;
    private Long indisponible ;
    private Long derogation ;

}
