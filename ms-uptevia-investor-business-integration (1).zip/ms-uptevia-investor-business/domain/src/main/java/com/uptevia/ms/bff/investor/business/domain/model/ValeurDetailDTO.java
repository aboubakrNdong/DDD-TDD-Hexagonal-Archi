package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class ValeurDetailDTO {
    private List<PasCotationDTO> pasCotation;
    private BaremeDTO bareme;
    public ValeurDetailDTO(List<PasCotationDTO> pasCotation, BaremeDTO bareme) {
        this.pasCotation = pasCotation;
        this.bareme = bareme;
    }
    public ValeurDetailDTO() {

    }
}

