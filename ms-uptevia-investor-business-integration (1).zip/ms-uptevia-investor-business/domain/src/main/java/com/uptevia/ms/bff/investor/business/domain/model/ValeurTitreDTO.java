package com.uptevia.ms.bff.investor.business.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Builder
@Getter
@Setter
public class ValeurTitreDTO {

    private String valeIden;
    private String valeLibe;
    private double dernierCours;

    private List<OrigineTitreDTO> listOrigines = null;
}
