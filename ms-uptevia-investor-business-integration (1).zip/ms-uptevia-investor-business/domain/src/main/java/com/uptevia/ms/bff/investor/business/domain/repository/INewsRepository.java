package com.uptevia.ms.bff.investor.business.domain.repository;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.NewsDTO;

public interface INewsRepository {

    //@Cacheable("News")
    NewsDTO getNews(int idEmet, int idActi, int pTituNume) throws FunctionnalException;
}

