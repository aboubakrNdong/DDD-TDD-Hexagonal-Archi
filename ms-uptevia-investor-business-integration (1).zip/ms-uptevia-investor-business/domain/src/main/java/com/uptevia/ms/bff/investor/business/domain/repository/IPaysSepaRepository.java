package com.uptevia.ms.bff.investor.business.domain.repository;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.PaysSepaDTO;


public interface IPaysSepaRepository {

    PaysSepaDTO getPaysSepa(Integer emetIden, String paramName) throws FunctionnalException;


}

