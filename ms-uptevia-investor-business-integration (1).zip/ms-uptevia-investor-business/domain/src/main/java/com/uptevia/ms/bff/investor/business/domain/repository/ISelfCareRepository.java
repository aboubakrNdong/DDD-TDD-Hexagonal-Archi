package com.uptevia.ms.bff.investor.business.domain.repository;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.DemandeDTO;
import com.uptevia.ms.bff.investor.business.domain.model.SousCategoriesDTO;
import com.uptevia.ms.bff.investor.business.domain.model.TraductionDTO;
import org.springframework.dao.DataAccessException;

import java.util.List;

public interface ISelfCareRepository {

    List<SousCategoriesDTO> getCategories(final String pIndiLogged) throws FunctionnalException;

    Long createSelfCare(DemandeDTO demandeTosave) throws FunctionnalException;

    List<TraductionDTO> getTraductions(String lang, Integer themeID) throws DataAccessException;
}
