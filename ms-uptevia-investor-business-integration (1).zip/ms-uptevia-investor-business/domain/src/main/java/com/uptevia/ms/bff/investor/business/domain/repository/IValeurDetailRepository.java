package com.uptevia.ms.bff.investor.business.domain.repository;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;

import java.util.List;

public interface IValeurDetailRepository {

    List<ValeurDTO> getValeurs(int idEmet) throws FunctionnalException;

    BaremeDTO getBareme(int idEmet, int isValeurEtrangere, String valeIden, String valeNatu, String baremeWeb) throws FunctionnalException;

    List<PasCotationDTO> getPasCotation(String valeIden) throws FunctionnalException;
    ValeurDetailDTO  getValeurDetails(int idEmet, int isValeurEtrangere, String valeIden, String valeNatu, String baremeWeb) throws FunctionnalException;

    List<ValeurDTO> getValeursCessibles(int idEmet, int idActi) throws FunctionnalException;

    List<LigneAvoirsDTO> getAvoirsAvendre(int idEmet, int idActi, String valeIden) throws FunctionnalException;


}