package com.uptevia.ms.bff.investor.business.domain.service;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;

import java.util.List;

public interface ActionnaireService {

    PsSelDetailTituDTO getActionnaire(final int idEmet, final int idActi, final int pTituNume) throws FunctionnalException;

    List<CompteDTO> getComptes(final String login) throws FunctionnalException;

    PaysSepaDTO getPaysSepa(Integer emetIden, String paramName) throws FunctionnalException;

    CodeIso2DTO getCodeIso2(String paysIden, String codeLangue) throws FunctionnalException;

    PsSelDetailTituDTO getFirstActionnaireByLogin(String login) throws FunctionnalException;

    void updateMailPhone(ReqUpdateMailPhone req) throws FunctionnalException;

    boolean chekTitulaireKyc(String login) throws FunctionnalException;

    String updateAdresseTitu(ReqUpdateAdresseTituDto req) throws FunctionnalException;

    String updateContactTitu(ReqUpdateContactTituDto req) throws FunctionnalException;

    String updateBancaireTitu(ReqUpdateBancaireTituDto req) throws FunctionnalException;

    String updateCspLanguage(ReqUpdateCspLanguageDto req) throws FunctionnalException;


    boolean updateMifid(MifidNatMajDTO req) throws FunctionnalException;
}
