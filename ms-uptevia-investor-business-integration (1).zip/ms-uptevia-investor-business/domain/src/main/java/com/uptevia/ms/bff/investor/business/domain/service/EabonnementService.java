package com.uptevia.ms.bff.investor.business.domain.service;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;

public interface EabonnementService {
    Long insertEabonnement(EabonnementDTO eabonnement)  throws FunctionnalException;

}
