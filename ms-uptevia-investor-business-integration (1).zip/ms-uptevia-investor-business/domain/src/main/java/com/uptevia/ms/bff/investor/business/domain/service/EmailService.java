package com.uptevia.ms.bff.investor.business.domain.service;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.EmailBodyDTO;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface EmailService {
    void sendMail(String  recipients, EmailBodyDTO textBody, String htmlBody, String subject, String typeMail, List<MultipartFile> attachments) throws FunctionnalException;
}
