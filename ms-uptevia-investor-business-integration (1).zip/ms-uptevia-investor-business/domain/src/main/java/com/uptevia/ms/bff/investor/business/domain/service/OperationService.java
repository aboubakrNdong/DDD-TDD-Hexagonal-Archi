package com.uptevia.ms.bff.investor.business.domain.service;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface OperationService {
    List<ValeurDTO> getValeurs(int idEmet, int idActi) throws FunctionnalException;

    ValeurDetailDTO getValeurDetails(int idEmet, int isValeurEtrangere, String valeIden, String valeNatu, String baremeWeb) throws FunctionnalException;

    String processOrdreBourse(OrdreBourseDTO demandeAchat) throws FunctionnalException;


    List<ValeurDTO> getValeursCessibles(int idEmet, int idActi) throws FunctionnalException;
    boolean isKYCCompleted(int idEmet, int idActi, int pTituNume) throws FunctionnalException;

    OperationPrerequisDTO checkPrerequisOperation(int idEmet, int idActi, int pTituNume) throws FunctionnalException;

    List<LigneAvoirsDTO> getAvoirsAvendre(int idEmet, int idActi, String valeIden) throws FunctionnalException;

    Map<String, List<LigneAvoirsDTO>> groupTitresByCategory(List<LigneAvoirsDTO> allTitres);

    List<LocalDate> getClosedDays(LocalDate dateDebut, LocalDate dateFin) throws FunctionnalException;


    List<OperationDTO> getOperationsByActi(String login) throws FunctionnalException;
}
