package com.uptevia.ms.bff.investor.business.domain.service;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;

public interface ParamsService {
    String getParamValueByName(String paramName) throws FunctionnalException;
}