package com.uptevia.ms.bff.investor.business.domain.service;


import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.PositionsDTO;


public interface PositionsDetailsService {

    PositionsDTO getPositions(int idEmet, int idActi) throws FunctionnalException;

}
