package com.uptevia.ms.bff.investor.business.domain.service;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.CategoriesDTO;
import com.uptevia.ms.bff.investor.business.domain.model.DemandeDTO;

import java.util.List;

public interface SelfCareService {
    List<CategoriesDTO> getCategories(final String pIndiLogged) throws FunctionnalException;

    void createSelfCare(DemandeDTO demandeTosave, String grcMail, boolean isConnected)  throws FunctionnalException;

    String getText(String key);
}
