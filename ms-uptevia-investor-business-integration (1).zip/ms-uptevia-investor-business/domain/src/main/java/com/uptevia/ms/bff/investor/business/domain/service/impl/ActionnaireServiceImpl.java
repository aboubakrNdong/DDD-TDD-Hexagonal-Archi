package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IActionnaireRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IPaysSepaRepository;
import com.uptevia.ms.bff.investor.business.domain.service.ActionnaireService;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.routines.IBANValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ActionnaireServiceImpl extends AbstractBusinessService implements ActionnaireService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String MANDATORY_FIELD = "form.field.validator.mandatory";

    private static final String NOT_VALID_FIELD = "form.field.validator.invalid";

    private static final String IBAN_LENGTH_NOT_VALID = "form.field.iban.notvalid";

    private final IActionnaireRepository actionnaireRepository;

    private final IPaysSepaRepository paysSepaRepository;

    private static final String UPDATE_ERROR = "error.update.data";

    public ActionnaireServiceImpl(final IActionnaireRepository actionnaireRepository, final IPaysSepaRepository paysSepaRepository) {
        this.actionnaireRepository = actionnaireRepository;
        this.paysSepaRepository = paysSepaRepository;
    }

    @Override
    public PsSelDetailTituDTO getActionnaire(final int idEmet, final int idActi, final int pTituNume) throws FunctionnalException {
        return actionnaireRepository.getActionnaire(idEmet, idActi, pTituNume);
    }

    @Override
    public List<CompteDTO> getComptes(String login) throws FunctionnalException {
        return actionnaireRepository.getComptes(login);
    }

    @Override
    public PaysSepaDTO getPaysSepa(Integer emetIden, String paramName) throws FunctionnalException {
        return paysSepaRepository.getPaysSepa(emetIden, paramName);
    }

    @Override
    public CodeIso2DTO getCodeIso2(String paysIden, String codeLangue) throws FunctionnalException {



        return actionnaireRepository.getCodeIso2(paysIden, codeLangue);
    }


    /**
     * @param login
     * @return
     * @throws FunctionnalException
     */
    @Override
    public PsSelDetailTituDTO getFirstActionnaireByLogin(String login) throws FunctionnalException {
        PsSelDetailTituDTO psSelDetailTituDTO = actionnaireRepository.getFirstActionnaireByLogin(login);
        psSelDetailTituDTO.setAcceptCGU(isAcceptedCgu(psSelDetailTituDTO.getDateAcceptCGU()));

        return psSelDetailTituDTO;
    }

    boolean isAcceptedCgu(String dateAsString) {
        if (dateAsString == null) {
            return false;
        }
        LocalDate today = LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDate datecgu = LocalDate.parse(dateAsString, formatter);
        LocalDate date90dayAgo = today.minusDays(90);
        return datecgu.isAfter(date90dayAgo) || datecgu.isEqual(date90dayAgo);
    }

    @Override
    public void updateMailPhone(ReqUpdateMailPhone req) throws FunctionnalException {
        Map<String, Object> contextParams = new HashMap<>();
        long result = actionnaireRepository.updateMailPhone(req);
        if (result != 1) {
            contextParams.put("updateLogin", req.getLogin());
            contextParams.put("updatePhone", req.getTelephone());
            contextParams.put("updateMail", req.getMail());
            contextParams.put("Proc Result", result);
            throw new FunctionnalException(UPDATE_ERROR, UPDATE_ERROR, contextParams);
        }
    }

    @Override
    public boolean chekTitulaireKyc(String login) throws FunctionnalException {
        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("login", login);
        return actionnaireRepository.chekTitulaireKyc(login);
    }

    @Override
    public String updateAdresseTitu(final ReqUpdateAdresseTituDto reqUpdateAdresseTituDto) throws FunctionnalException {
        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("pActiIden", reqUpdateAdresseTituDto.getActiIden());

        //if actiIden, emetIden are null

        if (StringUtils.isBlank(reqUpdateAdresseTituDto.getEmetIden()) || StringUtils.isBlank(reqUpdateAdresseTituDto.getActiIden())) {
            contextParams.put("EmetIden or actiIden are null", reqUpdateAdresseTituDto.getEmetIden());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        //if TituNum or typeAdre are null

        if (StringUtils.isBlank(reqUpdateAdresseTituDto.getTituNum()) || StringUtils.isBlank(reqUpdateAdresseTituDto.getTypeAdre())) {
            contextParams.put("TituNum or typeAdre are null", reqUpdateAdresseTituDto.getEmetIden());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        String result = actionnaireRepository.updateAdresseTitu(reqUpdateAdresseTituDto);

        if (StringUtils.isBlank(result)) {
            contextParams.put("result is blank", reqUpdateAdresseTituDto.getActiIden());
            throw new FunctionnalException(UPDATE_ERROR, UPDATE_ERROR, contextParams);
        }
        return result;
    }

    @Override
    public String updateContactTitu(final ReqUpdateContactTituDto reqUpdateContactTituDto) throws FunctionnalException {
        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("pActiIden", reqUpdateContactTituDto.getActiIden());

        //if actiIden, emetIden, are null

        if (StringUtils.isBlank(reqUpdateContactTituDto.getEmetIden()) || StringUtils.isBlank(reqUpdateContactTituDto.getActiIden())) {
            contextParams.put("EmetIden or actiIden are null", reqUpdateContactTituDto.getEmetIden());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        //if TituNum or email are null

        if (StringUtils.isBlank(reqUpdateContactTituDto.getTituNum()) || StringUtils.isBlank(reqUpdateContactTituDto.getTituEmail())) {
            contextParams.put("TituNum or email are null", reqUpdateContactTituDto.getEmetIden());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        String result = actionnaireRepository.updateContactTitu(reqUpdateContactTituDto);

        if (StringUtils.isBlank(result)) {
            contextParams.put("result is blank", reqUpdateContactTituDto.getActiIden());
            throw new FunctionnalException(UPDATE_ERROR, UPDATE_ERROR, contextParams);
        }
        return result;
    }

    @Override
    public String updateBancaireTitu(final ReqUpdateBancaireTituDto reqUpdateBancaireTituDto) throws FunctionnalException {
        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("pActiIden", reqUpdateBancaireTituDto.getActiIden());

        //if actiIden, emetIden, are null

        if (StringUtils.isBlank(reqUpdateBancaireTituDto.getEmetIden()) || StringUtils.isBlank(reqUpdateBancaireTituDto.getActiIden())) {
            contextParams.put("EmetIden or actiIden are null", reqUpdateBancaireTituDto.getEmetIden());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        //if TituNum or type are null

        if (StringUtils.isBlank(reqUpdateBancaireTituDto.getTituNum()) || StringUtils.isBlank(reqUpdateBancaireTituDto.getType())) {
            contextParams.put("TituNum or email are null", reqUpdateBancaireTituDto.getEmetIden());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        String country= reqUpdateBancaireTituDto.getSCodePaysReglement();
        String iban = reqUpdateBancaireTituDto.getSRibIban();

        IBANValidator ibanValidator =  IBANValidator.getInstance();

        // get Iban length from Registrar
        CodeIso2DTO codeIso2 =  getCodeIso2(country,null);

        codeIso2.getPaysIbanLong(); //TODO concatenate the length to display it in the error message

        if(!(ibanValidator.isValid(iban))){
            return IBAN_LENGTH_NOT_VALID;
        }



        String result = actionnaireRepository.updateBancaireTitu(reqUpdateBancaireTituDto);

        if (StringUtils.isBlank(result)) {
            contextParams.put("result is blank", reqUpdateBancaireTituDto.getActiIden());
            throw new FunctionnalException(UPDATE_ERROR, UPDATE_ERROR, contextParams);
        }
        return result;
    }


    @Override
    public String updateCspLanguage(final ReqUpdateCspLanguageDto reqUpdateCspLanguageDto) throws FunctionnalException {
        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("pActiIden", reqUpdateCspLanguageDto.getActiIden());

        //if actiIden, emetIden, are null

        if (StringUtils.isBlank(reqUpdateCspLanguageDto.getEmetIden()) || StringUtils.isBlank(reqUpdateCspLanguageDto.getActiIden())) {
            contextParams.put("EmetIden or actiIden are null", reqUpdateCspLanguageDto.getEmetIden());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        //if TituNum or type are null

        if (StringUtils.isBlank(reqUpdateCspLanguageDto.getTituNum()) || StringUtils.isBlank(reqUpdateCspLanguageDto.getLanguage())) {
            contextParams.put("TituNum or email are null", reqUpdateCspLanguageDto.getEmetIden());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        String result = actionnaireRepository.updateCspLanguage(reqUpdateCspLanguageDto);

        return result;
    }

    @Override
    public boolean updateMifid(MifidNatMajDTO req) throws FunctionnalException {
        return actionnaireRepository.updateMifid(req);
    }
}



