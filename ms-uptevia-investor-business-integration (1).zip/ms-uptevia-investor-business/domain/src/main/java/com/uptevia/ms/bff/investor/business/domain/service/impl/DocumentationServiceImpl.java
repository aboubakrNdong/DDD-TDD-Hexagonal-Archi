package com.uptevia.ms.bff.investor.business.domain.service.impl;
import com.uptevia.ms.bff.investor.business.domain.model.FileDTO;
import com.uptevia.ms.bff.investor.business.domain.model.TypeDocumentDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.IDocumentationRepository;
import com.uptevia.ms.bff.investor.business.domain.service.DocumentationService;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;

import java.util.List;


public class DocumentationServiceImpl implements DocumentationService {
    private final IDocumentationRepository documentationRepository;
    public DocumentationServiceImpl(final IDocumentationRepository documentationRepo) {
        this.documentationRepository = documentationRepo;
    }
    @Override
    public List<TypeDocumentDTO> getTypeDocuments(int idEmet, int idActi, int pTituNume) throws FunctionnalException {
        return documentationRepository.getTypeDocuments(idEmet,idActi,pTituNume);
    }

    @Override
    public List<FileDTO> getFiles(int idEmet, int idActi, int pTituNume, int pDocId, String pCodeLangue) throws FunctionnalException {
        return documentationRepository.getFiles(idEmet,idActi,pTituNume,pDocId,pCodeLangue);
    }
}