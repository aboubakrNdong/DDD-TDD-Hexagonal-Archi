package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IEabonnementRepository;
import com.uptevia.ms.bff.investor.business.domain.service.EabonnementService;
import org.apache.commons.lang3.StringUtils;
import java.util.HashMap;
import java.util.Map;

public class EabonnementServiceImpl implements EabonnementService {
    private static final String MANDATORY_FIELD = "form.field.validator.mandatory";
    private static final String NOT_VALID_FIELD = "form.field.validator.invalid";
    private final IEabonnementRepository iEabonnementRepository;

    public EabonnementServiceImpl( final IEabonnementRepository iEabonnementRepository) {
        this.iEabonnementRepository = iEabonnementRepository;
    }

    @Override
    public Long insertEabonnement(EabonnementDTO eabonnement) throws FunctionnalException {

        Map<String, Object> contextParams = new HashMap<>();

        /**
         cette case à cocher est cochée s'il a répondu oui lors de la création de son compte (toggle activé en popine)
         => elle est décochée s'il a désactivé le toggle
         */

        if (eabonnement.getParamChoix() == null || StringUtils.isBlank(eabonnement.getParamChoix())) {
            contextParams.put("paramChoix", eabonnement.getParamChoix());
            throw new FunctionnalException(MANDATORY_FIELD, MANDATORY_FIELD, contextParams);
        }

        /**
         cette case à cocher est cochée s'il a répondu oui,  équivaut à 1
         => elle est décochée,  equivaut à 0
         */

        if (!(eabonnement.getParamChoix()).equals("1") && !(eabonnement.getParamChoix()).equals("0")  ) {
            contextParams.put("paramChoix", eabonnement.getParamChoix());
            throw new FunctionnalException(NOT_VALID_FIELD, NOT_VALID_FIELD, contextParams);
        }
       return this.iEabonnementRepository.insertEabonnement(eabonnement) ;
    }
}
