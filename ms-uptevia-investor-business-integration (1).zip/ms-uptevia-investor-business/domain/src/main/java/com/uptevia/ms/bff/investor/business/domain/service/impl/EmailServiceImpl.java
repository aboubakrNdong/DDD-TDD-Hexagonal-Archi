package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.model.EmailBodyDTO;
import com.uptevia.ms.bff.investor.business.domain.service.EmailService;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import freemarker.template.Configuration;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.*;


@Service
@Slf4j
public class EmailServiceImpl implements EmailService {

    Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class.getName());
    private final JavaMailSender javaMailSender;

    @Value("${spring.mail.from.caceis}")
    private String from;

    @Value("${spring.mail.subject.prefix}")
    private String prefix;

    @Value("${spring.mail.to.moe}")
    private String cci;

    @Value("${spring.mail.to.moe.groupe}")
    private String destination;


    private final Configuration freemarkerConfiguration;


    public EmailServiceImpl(final JavaMailSender javaMailSender, final Configuration freemarkerConfiguration) {
        this.javaMailSender = javaMailSender;
        this.freemarkerConfiguration = freemarkerConfiguration;
    }


    @Override
    @Async
    public void sendMail(String recipients, EmailBodyDTO textBody, String htmlBody, String subject, String typeMail, List<MultipartFile> attachments) {

        // Creating a mime message
        MimeMessage mimeMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper;
        try {
            logger.info("Trying to send a mail to {} ...", recipients);

            // Setting multipart as true for attachments to be sent
            mimeMessageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            //Setting mail sender origin
            mimeMessageHelper.setFrom(from);
            if (recipients != null && !recipients.isEmpty()) {
                mimeMessageHelper.setTo(recipients);
            }

            //Processing body mail from template
            Map<String, Object> model = new HashMap<>();

            model.put("content", textBody);

            model.put("title", subject);
            //setting content as html to true
            if (StringUtils.isBlank(htmlBody))
                mimeMessageHelper.setText(fillTemplate("templates/mail", "mail/form_contact_mail.ftl", model), true);
            //Add subject to helper message
            mimeMessageHelper.setSubject(prefix + subject);
            // test if null
            if(attachments != null && !attachments.isEmpty()){
                for (MultipartFile multipartFile : attachments) {

                    File file = convertMultipartFileToFile(multipartFile);   // Adding the attachments

                    if (file != null) {
                        mimeMessageHelper.addAttachment(file.getName(), file);
                    }
                }
            }

            // Sending the mail
            javaMailSender.send(mimeMessage);
            logger.info("Trying to send a mail from {}, to {} ... OK ", from, recipients);
        }
        // Catch block to handle MessagingException
        catch (MessagingException e) {
            logger.error("An exception occurred while sending message ...", e);
        }
    }


    public String fillTemplate(final String templateFolder, final String templateName, final Map<String, Object> model) {
        String retour = null;
        try {
            Template template = freemarkerConfiguration.getTemplate(templateName);
            StringWriter out = new StringWriter();
            template.process(model, out);
            retour = out.toString();
        } catch (TemplateException e) {
            logger.error("Error occurred in template : {}", templateFolder + "/" + templateName, e);
        } catch (IOException e) {
            logger.error("Error occurred in method : fillTemplate(...)", e);
        }

        return retour;
    }

    private File convertMultipartFileToFile(MultipartFile multipartFile) {

        if (multipartFile == null) {
            logger.info("Multipart is Null");
            return null;
        }

        File file = new File(multipartFile.getOriginalFilename());


        try {
            Path filePath = file.toPath();
            Files.copy(multipartFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        } catch (IOException e) {
            // Gérer l'exception selon vos besoins
            logger.error("Erreur lors de la conversion de MultipartFile en File {}", e);
        }
        return file;
    }
}
