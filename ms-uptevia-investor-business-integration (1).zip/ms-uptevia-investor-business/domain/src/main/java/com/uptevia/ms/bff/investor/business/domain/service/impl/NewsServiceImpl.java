package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.NewsDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.INewsRepository;
import com.uptevia.ms.bff.investor.business.domain.service.NewsService;

public class NewsServiceImpl implements NewsService {

    private final INewsRepository newsRepository;

    public NewsServiceImpl(final INewsRepository nRepository) {
        this.newsRepository = nRepository;
    }

    @Override
    public NewsDTO getNews(final int idEmet, final int idActi, final int pTituNume) throws FunctionnalException {
        return newsRepository.getNews(idEmet, idActi, pTituNume);
    }
}
