package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IActionnaireRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IOperationRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IValeurDetailRepository;
import com.uptevia.ms.bff.investor.business.domain.service.OperationService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.util.CollectionUtils;


import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.*;
import java.util.stream.Collectors;

public class OperationServiceImpl implements OperationService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final IValeurDetailRepository valeurDetailRepository;
    private final IOperationRepository operationRepository;
    private final IActionnaireRepository actionnaireRepository;


    public OperationServiceImpl(final IValeurDetailRepository valeurDetailRepository, IOperationRepository iOperationRepository, IActionnaireRepository actionnaireRepository) {

        this.valeurDetailRepository = valeurDetailRepository;
        this.operationRepository = iOperationRepository;
        this.actionnaireRepository = actionnaireRepository;
    }

    @Override
    public List<ValeurDTO> getValeurs(int idEmet, int idActi) throws FunctionnalException {
        List<ValeurDTO> allValeurs = valeurDetailRepository.getValeurs(idEmet);
        List<ValeurDTO> valeursCessibles = this.getValeursCessibles(idEmet, idActi);

        //Mettre à jour la liste allValeurs en fonction de valeursCessibles
        for (ValeurDTO valeur : allValeurs) {
            for (ValeurDTO valeurCessible : valeursCessibles) {
                if (valeur.getValeIden().equals(valeurCessible.getValeIden())) {
                    valeur.setPossedeTitres(true);
                    valeur.setSolde(valeurCessible.getSolde());
                    valeur.setRepartie(valeurCessible.getRepartie());
                    valeur.setDisponible(valeurCessible.getDisponible());
                    valeur.setIndisponible(valeurCessible.getIndisponible());
                    valeur.setDerogation(valeurCessible.getDerogation());
                }
            }
        }

        return allValeurs;
    }

    @Override
    public ValeurDetailDTO getValeurDetails(int idEmet, int isValeurEtrangere, String valeIden, String valeNatu, String baremeWeb) throws FunctionnalException {
        ValeurDetailDTO valeurDetail = new ValeurDetailDTO();

        valeurDetail.setPasCotation(valeurDetailRepository.getPasCotation(valeIden));
        valeurDetail.setBareme(valeurDetailRepository.getBareme(idEmet, isValeurEtrangere, valeIden, valeNatu, baremeWeb));
        return valeurDetail;
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public String processOrdreBourse(OrdreBourseDTO demande) throws FunctionnalException {

        //logger.info("debut processOrdreBourse pour Actionnaire: {}", demande.getLogin());
        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("login", demande.getLogin());
        try {

            if (demande.getNatureDemande() == 4 && CollectionUtils.isEmpty(demande.getTitres())) {
                throw new FunctionnalException("operation.error.missing.data.titres", "operation.error.missing.data.titres", contextParams);
            }
            // Étape 0 : Récupérer les infos en BD du titulaire
            PsSelDetailTituDTO titulaire = actionnaireRepository.getActionnaire(demande.getEmetIden(), demande.getActiIden(), demande.getTituNume());

            if (titulaire != null) {
                demande.setTituEmail(titulaire.getEmailPerso());
                demande.setTituNom(titulaire.getNom());
                demande.setTituPrenom(titulaire.getPrenom());
                demande.setTituQualite(titulaire.getQualite());
                demande.setTituDateNais(titulaire.getTituNaisDate().toLocalDate());
            }

            // Étape 1 : Insérez la demande et récupérer une Ref et ID
            OrdreBourseDTO createdDemande = insertDemandeOlis(demande);
            String refDemande = createdDemande.getNumDemandeCurrval();

            demande.setIdDemande(createdDemande.getIdDemande());

            // Étape 2 : Insérez un ordre de bourse
            Long ordreBourseId = insertOrdreBourse(demande);


            int inserTitres = insertListAvoirAVendre(demande);


            // Étape 3 : Insérez un règlement
            int reglementResult = insertReglement(demande);

            // Uniquement si paiement par CB et Transaction CB effectuée avec succès
            if (demande.getModeReglt() == 9 && demande.getOcbIdTransaction() != null) {
                // Étape 4 : Confirmer la Transaction après règlement par CB
                confirmTransactionCB(demande);
            }

            // Vérifiez si toutes les étapes se sont déroulées avec succès
            if (refDemande != null && ordreBourseId != null && reglementResult == 1 && inserTitres != 0) {
                // Tout s'est bien passé,retourner la  ref Demande
                return refDemande;
            }
        } catch (FunctionnalException e) {
            logger.error(e.getMessage() + " with the param : " + e.getContextParams().toString());
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return null;
    }

    int confirmTransactionCB(OrdreBourseDTO demande) throws Exception {
        return operationRepository.confirmTransactionCB(demande);
    }

    private OrdreBourseDTO insertDemandeOlis(OrdreBourseDTO demande) throws FunctionnalException {
        return operationRepository.insertDemandeOlis(demande);
    }

    private Long insertOrdreBourse(OrdreBourseDTO demande) throws FunctionnalException {
        return operationRepository.insertOrdreBourse(demande);
    }

    private int insertListAvoirAVendre(OrdreBourseDTO demande) {
        if (demande.getNatureDemande() == 8)
            return 1;

        if (demande.getNatureDemande() == 4) {
            return operationRepository.insertAvoirsAVendre(demande);
        }
        return 0;
    }

    private int insertReglement(OrdreBourseDTO demande) throws FunctionnalException {
        logger.info("Reglement Service insertReglement: " + demande.getRegltAttendu());
        return operationRepository.insertReglement(demande);
    }


    @Override
    public List<ValeurDTO> getValeursCessibles(int idEmet, int idActi) throws FunctionnalException {
        return valeurDetailRepository.getValeursCessibles(idEmet, idActi);
    }


    @Override
    public boolean isKYCCompleted(int idEmet, int idActi, int pTituNume) throws FunctionnalException {
        PsSelDetailTituDTO titulaire = actionnaireRepository.getActionnaire(idEmet, idActi, pTituNume);
        /*
        Les règles de vérification de KYC peuvent évoluer dans le temps.
        Pour le moment, nous vérifions uniquement le mode de règlement.
        */
        return StringUtils.equals(titulaire.getTituModeReglement(), "CHEQUE")
                || StringUtils.equals(titulaire.getTituModeReglement(), "VIREMENT");
    }


    @Override
    public OperationPrerequisDTO checkPrerequisOperation(int idEmet, int idActi, int pTituNume) throws FunctionnalException {
        List motifsBlocageVente = new ArrayList<>();
        List motifsBlocageAchat = new ArrayList<>();
        OffsetDateTime offsetdatetime
                = OffsetDateTime.now();

        List<ValeurDTO> valeursCessibles = getValeursCessibles(idEmet, idActi);
        List<ValeurDTO> valeurs = getValeurs(idEmet, idActi);
        boolean kycCompleted = isKYCCompleted(idEmet, idActi, pTituNume);

        if (!kycCompleted) {
            motifsBlocageVente.add("kycNotCompleted");
        }

        if (valeursCessibles.isEmpty()) {
            motifsBlocageVente.add("aucunePositionDisponible");
        }

        boolean existeValeurDisponible = valeursCessibles.stream().anyMatch(valeur -> valeur.getDisponible() > 0);


        return OperationPrerequisDTO.builder()
                .serverDateTime(offsetdatetime)
                .peutVendre(kycCompleted && existeValeurDisponible)
                .peutAcheter(true) // TODO : A faire dans la Story in UPI_DFS006_OPE2_ACHAT
                .motifsBlocageVente(motifsBlocageVente)
                .motifsBlocageAchat(motifsBlocageAchat) // TODO : A faire dans la Story in UPI_DFS006_OPE2_ACHAT
                .valeurs(valeurs)
                .build();

    }

    @Override
    public List<LigneAvoirsDTO> getAvoirsAvendre(int idEmet, int idActi, String valeIden) throws FunctionnalException {
        return valeurDetailRepository.getAvoirsAvendre(idEmet, idActi, valeIden);
    }

    @Override
    public Map<String, List<LigneAvoirsDTO>> groupTitresByCategory(List<LigneAvoirsDTO> allTitres) {
        // Regroupement personnalisé
        return allTitres.stream()
                .collect(Collectors.groupingBy(dto -> {
                    String natureJuridique = dto.getNatureJuridique();
                    switch (natureJuridique) {
                        case "L", "B", "N", "W", "R":
                            return "titres.nominatifs";
                        case "S":
                            return "titres.plans.droits";
                        case "P":
                            return "titres.plans.salaries";
                        case "G":
                            return "titres.paga";
                        default:
                            return "titres.autres";
                    }
                }));
    }

    @Override
    public List<LocalDate> getClosedDays(LocalDate dateDebut, LocalDate dateFin) throws FunctionnalException {
        return operationRepository.getClosedDays(dateDebut, dateFin);
    }


    /**
     * @param login
     * @return
     */
    @Override
    public List<OperationDTO> getOperationsByActi(String login) throws FunctionnalException {
        return actionnaireRepository.getOperations(login);
    }

}
