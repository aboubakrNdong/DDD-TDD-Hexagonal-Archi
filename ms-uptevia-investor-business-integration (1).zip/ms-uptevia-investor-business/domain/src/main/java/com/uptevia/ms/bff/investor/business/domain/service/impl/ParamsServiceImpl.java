package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.ParamsDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.IParamsRepository;
import com.uptevia.ms.bff.investor.business.domain.service.ParamsService;

import java.util.List;

public class ParamsServiceImpl implements ParamsService {
    private final IParamsRepository paramsRepository ;


    public ParamsServiceImpl(IParamsRepository paramsRepository) {
        this.paramsRepository = paramsRepository;

    }

    @Override
    public String getParamValueByName(String paramName) throws FunctionnalException {
        List<ParamsDTO> paramsList = paramsRepository.getAllParams();

        ParamsDTO paramDTO = paramsList.stream()
                .filter(param -> param.getParamName().equalsIgnoreCase(paramName))
                .findFirst()
                .orElseThrow(() -> new FunctionnalException("PARAM_NOT_FOUND", "Param not found with name: " + paramName));

        return paramDTO.getParamValue();

    }
}
