package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.PositionsDTO;
import com.uptevia.ms.bff.investor.business.domain.model.PositionsDetailsDTO;
import com.uptevia.ms.bff.investor.business.domain.model.PositionsTypeDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.IPositionsDetailsRepository;
import com.uptevia.ms.bff.investor.business.domain.service.PositionsDetailsService;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.List;

public class PositionsDetailsServiceImpl implements PositionsDetailsService {
    private final IPositionsDetailsRepository detailsRepository;

    public PositionsDetailsServiceImpl(IPositionsDetailsRepository detailsRepository) {
        this.detailsRepository = detailsRepository;
    }

    @Override
    public PositionsDTO getPositions(int idEmet, int idActi) throws FunctionnalException {
        PositionsDTO positionsDTO = new PositionsDTO();

        List<PositionsDetailsDTO> allDetails = detailsRepository.getAllPositionsDetails(idEmet, idActi)
                .stream()
                .toList();

        positionsDTO.setTitres(getPositionsByType(allDetails, "titres"));
        positionsDTO.setDroits(getPositionsByType(allDetails, "droits"));
        positionsDTO.setFonds(getPositionsByType(allDetails, "fonds"));
        return positionsDTO;
    }



    private PositionsTypeDTO getPositionsByType(List<PositionsDetailsDTO> allLinesDetails, String typePosition) {

        PositionsTypeDTO titres = new PositionsTypeDTO();
        List<PositionsDetailsDTO> linesDetails = allLinesDetails
                .stream()
                .filter(details ->
                        StringUtils.equalsIgnoreCase(details.getTypePosition(), typePosition)
                ).toList();


        if (!linesDetails.isEmpty()) {
            // Pour les valeurs fixes pour toutes les lignes

            titres.setDerniereMaj(linesDetails.get(0).getDerniereMaj());
            titres.setDevise(linesDetails.get(0).getDevise());
            titres.setTypePosition(linesDetails.get(0).getTypePosition());

            //Pour les sommes
            Integer titresQteTotale = linesDetails.stream()
                    .mapToInt(PositionsDetailsDTO::getQte)
                    .sum();
            titres.setQteTotale(titresQteTotale);

            double titresValorisationTotale = linesDetails.stream()
                    .mapToDouble(PositionsDetailsDTO::getValorisation)
                    .sum();
            titres.setValorisationTotale(BigDecimal.valueOf(titresValorisationTotale));

            //Pour les détails
            titres.setDetails(linesDetails);

        }
        return titres;
    }

}
