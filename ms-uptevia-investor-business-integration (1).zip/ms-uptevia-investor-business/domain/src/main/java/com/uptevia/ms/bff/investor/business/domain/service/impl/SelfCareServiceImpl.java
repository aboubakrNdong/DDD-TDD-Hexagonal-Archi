package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.ISelfCareRepository;
import com.uptevia.ms.bff.investor.business.domain.service.EmailService;
import com.uptevia.ms.bff.investor.business.domain.service.SelfCareService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;


public class SelfCareServiceImpl extends AbstractBusinessService implements SelfCareService {
    private final ISelfCareRepository iSelfCareRepository;

    private final EmailService emailService;

    private static final String NOT_VALID_FIELD = "form.field.validator.invalid";

    private static final String MANDATORY_FIELD = "form.field.validator.mandatory";

    private static final String MF = "MANDATORY_FIELD";

    private static final String NVD = "NOT_VALID_DATA";

    public static Map<String, TraductionDTO> traductions = new HashMap<>();

    @PostConstruct
    private void postConstruct() {
        Locale locale = Locale.getDefault();

    }

    public SelfCareServiceImpl(final ISelfCareRepository iSelfCareRepository, EmailService emailService) {
        this.iSelfCareRepository = iSelfCareRepository;
        this.emailService = emailService;
    }

    @Override
    public List<CategoriesDTO> getCategories(String pIndiLogged) throws FunctionnalException {

        List<CategoriesDTO> categoriesDTOS = new ArrayList<>();
        List<SousCategoriesDTO> result = iSelfCareRepository.getCategories(pIndiLogged);
        for (SousCategoriesDTO sousCategoriesDTO : result) {
            CategoriesDTO object = createCategoriesDto(sousCategoriesDTO);
            List<SousCategoriesDTO> simplifiedSousCategories = createSimplifiedSousCategoriesList(sousCategoriesDTO, result);
            object.setSousCategories(simplifiedSousCategories);
            categoriesDTOS.add(object);
        }
        return categoriesDTOS.stream().filter(distinctByKey(CategoriesDTO::getTypoTraductionKey)).toList();
    }

    private CategoriesDTO createCategoriesDto(SousCategoriesDTO sousCategoriesDTO) {
        CategoriesDTO object = new CategoriesDTO();
        object.setTypoTraductionKey(sousCategoriesDTO.getCateTypoTraductionKey());
        object.setTypoOrdre(sousCategoriesDTO.getCateTypoOrdre());
        object.setTypoId(sousCategoriesDTO.getCateTypoId());
        return object;
    }

    private List<SousCategoriesDTO> createSimplifiedSousCategoriesList(SousCategoriesDTO sousCategoriesDTO, List<SousCategoriesDTO> allSousCategories) {
        List<SousCategoriesDTO> simplifiedSousCategories = new ArrayList<>();
        for (SousCategoriesDTO simplifiedSousCategoriesDTO : allSousCategories) {
            if (sousCategoriesDTO.getCateTypoTraductionKey().equals(simplifiedSousCategoriesDTO.getCateTypoTraductionKey())) {
                SousCategoriesDTO simplifiedDTO = createSimplifiedSousCategories(simplifiedSousCategoriesDTO);
                simplifiedSousCategories.add(simplifiedDTO);
            }
        }
        return simplifiedSousCategories;
    }

    private SousCategoriesDTO createSimplifiedSousCategories(SousCategoriesDTO simplifiedSousCategoriesDTO) {
        return SousCategoriesDTO.builder()
                .cateTypoId(simplifiedSousCategoriesDTO.getCateTypoId())
                .cateTypoTraductionKey(simplifiedSousCategoriesDTO.getCateTypoTraductionKey())
                .cateTypoOrdre(simplifiedSousCategoriesDTO.getCateTypoOrdre())
                .sousTypoId(simplifiedSousCategoriesDTO.getSousTypoId())
                .sousTypoTraductionKey(simplifiedSousCategoriesDTO.getSousTypoTraductionKey())
                .sousTypoIndiPjObligatoire(simplifiedSousCategoriesDTO.getSousTypoIndiPjObligatoire())
                .sousTypoOrdre(simplifiedSousCategoriesDTO.getSousTypoOrdre())
                .build();
    }


    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public void createSelfCare(DemandeDTO demandeTosave, String grcMail, boolean isConnected) throws FunctionnalException {

        String regexEmail = "^[A-Za-z.]+@[A-Za-z.]+fr";
        String regexAddressFisc = "[A-Za-z ]+-+ [A-Za-z]*$";

        Map<String, Object> contextParams = new HashMap<>();
        List<TraductionDTO> traductionDTOS = iSelfCareRepository.getTraductions(getLangue(demandeTosave.getLang()), 1);
        traductions = traductionDTOS.stream()
                .collect(Collectors.toMap(TraductionDTO::getKey, Function.identity()));

        if (!isConnected) {
            contextParams.put("actiIden", demandeTosave.getActiIden());
            contextParams.put("emetIden", demandeTosave.getEmetIden());
            /** Ajout de régles de gestion pour non connecté
             * régle 1: Identifiant :  champ entre 8 et 10 caractères alphanumérique /facultatif / vide par défaut
             * Si contient plus de caractères ou caractères spéciaux, afficher message : la donnée saisie est incorrecte
             */
            if (!isAlphaNumeric(demandeTosave.getActiIden()) && demandeTosave.getActiIden().length() > 7) {
                throw new FunctionnalException(NVD, NOT_VALID_FIELD, contextParams);
            }
            /**
             * Emetteur : champ texte libre / obligatoire / vide par défaut
             * Champ texte qui peut contenir soit un identifiant soit un texte libre (ex : BNP PARIBAS ou 5003)
             * si pas de choix fait , afficher message : ce champ est obligatoire
             */
            if (!(demandeTosave.getEmetIden().chars().allMatch(Character::isDigit)
                    || demandeTosave.getEmetIden().chars().allMatch(Character::isAlphabetic))) {
                throw new FunctionnalException(NVD, "form.field.validator.invalidIden", contextParams);
            }
            if (demandeTosave.getEmetIden().length() == 0 || StringUtils.equals(demandeTosave.getEmetIden(), "")) {
                throw new FunctionnalException(MF, MANDATORY_FIELD, contextParams);
            }
            /**
             * CCN : champ numérique 7 caractères / obligatoire / vide par défaut
             * Champ numérique pouvant contenir de 1 à 7 caractères
             * Si contient plus de caractères ou caractères spéciaux ou lettre, afficher message : la donnée saisie est incorrecte.
             * si pas de choix fait , afficher message : ce champ est obligatoire
             */
            /*if (!demandeTosave.getTituNume().chars().allMatch(Character::isDigit)
                    || demandeTosave.getTituNume().length() > 7) {
                contextParams.put("tituNume", demandeTosave.getTituNume());
                throw new FunctionnalException(NVD, NOT_VALID_FIELD, contextParams);
            }
            if (demandeTosave.getTituNume().length() == 0 || StringUtils.equals(demandeTosave.getTituNume(), "")) {
                if (contextParams.get("tituNume") == null) {
                    contextParams.put("tituNume", demandeTosave.getTituNume());
                }
                throw new FunctionnalException(MF, MANDATORY_FIELD, contextParams);
            }*/
            /**
             * Nom : champ texte libre / obligatoire / vide par défaut
             * Champ texte contenant 32 caractères
             * Si contient plus de caractères, afficher message : la donnée saisie est incorrecte.
             * si pas de choix fait , afficher message : ce champ est obligatoire
             */
            if (demandeTosave.getFirstName().length() > 32) {
                contextParams.put("firstName", demandeTosave.getFirstName());
                throw new FunctionnalException(NVD, NOT_VALID_FIELD, contextParams);
            }
            if (demandeTosave.getFirstName().length() == 0 || StringUtils.equals(demandeTosave.getFirstName(), "")) {
                contextParams.put("firstName", demandeTosave.getFirstName());
                throw new FunctionnalException(MF, MANDATORY_FIELD, contextParams);
            }
            /**
             * Prénom  : champ texte libre / obligatoire / vide par défaut
             * Champ texte contenant 32 caractères
             * Si contient plus de caractères, afficher message : la donnée saisie est incorrecte.
             * si pas de choix fait , afficher message : ce champ est obligatoire
             */
            if (demandeTosave.getLastName().length() > 32) {
                contextParams.put("lastName", demandeTosave.getLastName());
                throw new FunctionnalException(NVD, NOT_VALID_FIELD, contextParams);
            }
            if (demandeTosave.getLastName().length() == 0 || StringUtils.equals(demandeTosave.getLastName(), "")) {
                contextParams.put("lastName", demandeTosave.getLastName());
                throw new FunctionnalException(MF, MANDATORY_FIELD, contextParams);
            }
            /**
             * Téléphone : liste indicateur pays + champ numérique / obligatoire / vide par défaut
             * Ce champ est composé de 2 items : l’indicateur et le pays
             * Il respecte des règles de base (que je peux communiquer si existe pas côté Montrouge)
             * si pas de choix fait , afficher message : ce champ est obligatoire
             */
            if (StringUtils.isBlank(demandeTosave.getTelephone())) {
                contextParams.put("Telephone", demandeTosave.getTelephone());
                throw new FunctionnalException(MF, MANDATORY_FIELD, contextParams);
            }
            if (!demandeTosave.getTelephone().chars().allMatch(Character::isDigit)
                    || demandeTosave.getTelephone().length() < 3 || demandeTosave.getTelephone().length() < 10) {
                contextParams.put("Telephone", demandeTosave.getTelephone());
                throw new FunctionnalException(NVD, NOT_VALID_FIELD, contextParams);
            }

            /**
             * Email : champ texte libre / obligatoire / vide par défaut
             * Champ au format x@x.fr
             * Si respecte pas cette règle, indiquer : la donnée saisie est incorrecte.
             * si pas de choix fait , afficher message : ce champ est obligatoire
             */
            if (StringUtils.isBlank(demandeTosave.getEmail())) {
                contextParams.put("email", demandeTosave.getEmail());
                throw new FunctionnalException(MF, MANDATORY_FIELD, contextParams);
            }
            if (!Pattern.compile(regexEmail).matcher(demandeTosave.getEmail()).matches()) {
                contextParams.put("email", demandeTosave.getEmail());
                throw new FunctionnalException(NVD, NOT_VALID_FIELD, contextParams);
            }
            /**
             * Pays adresse fiscale : champ texte libre / obligatoire / vide par défaut
             * Format combobox qui contient code pays iso 3 – Pays
             * Ex : FRA – France
             * si pas de choix fait , afficher message : ce champ est obligatoire
             */
            if (StringUtils.isBlank(demandeTosave.getPays())) {
                contextParams.put("pays", demandeTosave.getPays());
                throw new FunctionnalException(MF, MANDATORY_FIELD, contextParams);
            }
            if (!Pattern.compile(regexAddressFisc).matcher(demandeTosave.getPays()).matches()) {
                contextParams.put("pays", demandeTosave.getPays());
                throw new FunctionnalException(NVD, NOT_VALID_FIELD, contextParams);
            }
            /**
             * Date de naissance : champ texte libre / obligatoire / vide par défaut
             * Format date : jj/mm/aaaa
             * Si date future, afficher message : la donnée saisie est incorrecte.
             * si pas de choix fait , afficher message : ce champ est obligatoire
             */
            if (StringUtils.isBlank(demandeTosave.getDob())) {
                contextParams.put("dateOfBirth", demandeTosave.getDob());
                throw new FunctionnalException(MF, MANDATORY_FIELD, contextParams);
            }

            if (!dateValidator(demandeTosave.getDob())) {
                contextParams.put("dateOfBirth", demandeTosave.getDob());
                throw new FunctionnalException(NVD, NOT_VALID_FIELD, contextParams);
            }
        }


        this.iSelfCareRepository.createSelfCare(demandeTosave);

        final String emailBody = this.buildMessage(demandeTosave.getLastName(), demandeTosave.getFirstName(), demandeTosave.getCategory(),
                demandeTosave.getSubCategory(), demandeTosave.getEmetIden(), demandeTosave.getActiIden());

        EmailBodyDTO emailBodyDTO = EmailBodyDTO.builder()
                .textBody(emailBody)
                .securityLib(getText("footer.item.securite"))
                .cguLib(getText("footer.item.cgu"))
                .rgpdLib(getText("footer.item.rgpd"))
                .accessibilityLib(getText("footer.item.accessibilite"))
                .conformLib(getText("footer.item.conformite"))
                .build();

        String subject = "";
        if (isConnected) {
            subject = getText("form_contact.subject_connected");
        } else {
            subject = getText("form_contact.subject_not_connected");
        }

        this.emailService.sendMail(grcMail, emailBodyDTO, "", subject, "", null);

    }

    @Override
    public String getText(final String key) {
        var libelle = "";
        if(traductions != null && !traductions.entrySet().isEmpty()){
            libelle = traductions.get(key).getLibelle();
        }
        return libelle;
    }


    String buildMessage(final String prenom, final String nom, final String category,
                        final String subCategory, final String emetteur, final String actiIden) {

        return String.format("Bonjour  Madame, Monsieur,<br><br>\n"
                        + "Vous avez reçu une demande issue du formulaire de contact via UPI, provenant de <br><br>\n"
                        + "l'actionnaire &ensp; %s &ensp; %s <br><br>\n"
                        + "souhaitant &ensp; %s &ensp; %s <br><br>\n"
                        + "Code émetteur/Compte : %s/%s <br><br>\n"
                        + "Cordialement, <br><br>\n"
                        + "Service UPI <br><br>\n",
                prenom, nom, category, subCategory, emetteur, actiIden);
    }

    public static String getLangue(String lang){

        Map<String, String> mapLangue = new HashMap<>();

        mapLangue.put("en", "ENG");
        mapLangue.put("fr", "FRA");
        mapLangue.put("de", "DEU");
        mapLangue.put("es", "ESP");
        mapLangue.put("pt", "PRT");
        mapLangue.put("it", "ITA");
        mapLangue.put("nl", "NLD");

        return mapLangue.get(lang);
    }
}
