package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IActionnaireRepository;
import com.uptevia.ms.bff.investor.business.domain.repository.IPaysSepaRepository;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class ActionnaireServiceImplTest {

    Logger logger = LoggerFactory.getLogger(ActionnaireServiceImplTest.class.getName());

    @Mock
    private IPaysSepaRepository paysSepaRepository;

    @Mock
    private IActionnaireRepository actionnaireRepository;

    @InjectMocks
    ActionnaireServiceImpl actionnaireService;

    private EasyRandom easyRandom = new EasyRandom();

    private static final String MANDATORY_FIELD = "form.field.validator.mandatory";

    private static final String NOT_VALID_FIELD = "form.field.validator.invalid";


    private static final String PPAYS = "DEU";

    private static final String PDEVISE = "EUR";

    private static final String PIBAN = "DE90518500791101010046";

    private static final String PBIC = "DEUTDEFFXXX";

    private static final String PUSER = "ABOUBAKR";

    private static final String PORIG = "GRC";

    private static final Integer PEMETIDEN = 150;

    private static final Integer PACTIIDEN = 810;
    private static final Integer PTITUNUME = 1;
    private static final String PTITUEMAIL = "aboubakr.ndong@gmail.fr";
    private static final String PTITUNUMEMOBILEPERSO = "0758919832";
    private static final String PADREFISCINFORUE =  "8 RUE DU PORT AUX CERISES";
    private static final String PADREFISCCODP = "91123";
    private static final String PADREINFORUE ="5 PLACE DES GARDIANS";
    private static final String PADRENOMCOMU = "PARIS";


    @Test
    void should_return_get_comptes_ok() throws Exception {

        String login = "61691966";
        List<CompteDTO> comptes = easyRandom.objects(CompteDTO.class, 5)
                .collect(Collectors.toList());

        Mockito.when(actionnaireRepository.getComptes(login)).thenReturn(comptes);

        Assertions.assertThat(actionnaireService.getComptes(login).size()).isEqualTo(comptes.size());

    }

    @Test
    void should_return_paysSepa_ok() throws Exception {

        //Given
        int idEmet = 99963514;
        String paramName = "MAJ_COORD_BANK_PAYS_AUTORISE";
        PaysSepaDTO paysSepa = easyRandom.nextObject(PaysSepaDTO.class);

        // When
        Mockito.when(actionnaireService.getPaysSepa(idEmet, paramName)).thenReturn(paysSepa);

        //Then
        Assertions.assertThat(actionnaireService.getPaysSepa(idEmet, paramName)).isSameAs(paysSepa);
    }

    @Test
    void should_return_CodeIso2_ok() throws Exception {

        //Given
        String paysIden = "FRA";
        String codeLangue = "FR";
        CodeIso2DTO codeIso2DTO = easyRandom.nextObject(CodeIso2DTO.class);

        // When
        Mockito.when(actionnaireService.getCodeIso2(paysIden, codeLangue)).thenReturn(codeIso2DTO);

        //Then
        Assertions.assertThat(actionnaireService.getCodeIso2(paysIden, codeLangue)).isSameAs(codeIso2DTO);
    }





    @Test
    void when_emetIden_null_should_return_update_Titu_KO() throws FunctionnalException {

        ReqUpdateAdresseTituDto request = easyRandom.nextObject(ReqUpdateAdresseTituDto.class);

        request.setEmetIden("");
        request.setActiIden("12");
        request.setTituNum("1");
        request.setTypeAdre("postale");
        request.setAdreInfoRue("12 rougerie");
        request.setAdreComp("PARIS");
        request.setAdreCodp("75010");
        request.setAdreNomComu("HAUT DE SEINE");
        request.setAdrePaysIden("FRA");
        request.setAdreBati("1 ROUTULE ");
        request.setAdreFiscDept("75011");
        request.setAdreFiscCodeComu("75");

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> actionnaireService.updateAdresseTitu(request));
        assertEquals(MANDATORY_FIELD, exception.getCode());

    }

 @Test
    void should_update_Titu_Adresse_OK() throws Exception {

        ReqUpdateAdresseTituDto request = easyRandom.nextObject(ReqUpdateAdresseTituDto.class);

        request.setEmetIden("458");
        request.setActiIden("12");
        request.setTituNum("1");
        request.setTypeAdre("postale");
        request.setAdreInfoRue("ROND");
        request.setAdreComp("LYON");
        request.setAdreCodp("45012");
        request.setAdreNomComu("LILLE 22");
        request.setAdrePaysIden("FRA");
        request.setAdreBati("LILLE1");
        request.setAdreFiscDept("24");
        request.setAdreFiscCodeComu("91");

        Mockito.when(actionnaireRepository.updateAdresseTitu(request)).thenReturn(String.valueOf(request));

        actionnaireService.updateAdresseTitu(request);

        verify(actionnaireRepository, times(1)).updateAdresseTitu(any());

    }

    @Test
    void when_emetIden_null_should_return_update_Contact_KO() throws FunctionnalException {

        ReqUpdateContactTituDto request = easyRandom.nextObject(ReqUpdateContactTituDto.class);

        request.setEmetIden("");
        request.setActiIden("12");
        request.setTituNum("1");
        request.setTituEmail("stephane.duris@uptevia.com");
        request.setTituEmail2("stephane2.duris@uptevia.com");
        request.setTituNumMobilePerso("626353226");
        request.setTituNumMobilePersoIndiPays("33");
        request.setTituNumMobilePro("626353224");
        request.setTituNumMobileProIndiPays("33");
        request.setTituNumTel("0153001576");
        request.setTituNumTelIndiPays("0123005577");
        request.setTituNumTel2("0153005571");
        request.setTypecontact("type");
        request.setTypeCoord("coord");
        request.setNumFaxPro("");
        request.setNumFaxProIndiPays("");
        request.setNumFaxPerso("");
        request.setNumFaxPersoIndiPays("");

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> actionnaireService.updateContactTitu(request));
        assertEquals(MANDATORY_FIELD, exception.getCode());

    }

    @Test
    void should_update_Titu_Contact_OK() throws Exception {

        ReqUpdateContactTituDto request = easyRandom.nextObject(ReqUpdateContactTituDto.class);

        request.setEmetIden("458");
        request.setActiIden("12");
        request.setTituNum("1");
        request.setTituEmail("stephane.duris@uptevia.com");
        request.setTituEmail2("stephane2.duris@uptevia.com");
        request.setTituNumMobilePerso("626353226");
        request.setTituNumMobilePersoIndiPays("33");
        request.setTituNumMobilePro("626353224");
        request.setTituNumMobileProIndiPays("33");
        request.setTituNumTel("0153001576");
        request.setTituNumTelIndiPays("0123005577");
        request.setTituNumTel2("0153005571");
        request.setTypecontact("type");
        request.setTypeCoord("coord");
        request.setNumFaxPro("");
        request.setNumFaxProIndiPays("");
        request.setNumFaxPerso("");
        request.setNumFaxPersoIndiPays("");

        Mockito.when(actionnaireRepository.updateContactTitu(request)).thenReturn(String.valueOf((request)));

        actionnaireService.updateContactTitu(request);

        verify(actionnaireRepository, times(1)).updateContactTitu(any());

    }


    @Test
    void should_update_CSP_Language_OK() throws Exception {

        ReqUpdateCspLanguageDto request = easyRandom.nextObject(ReqUpdateCspLanguageDto.class);

        request.setEmetIden("458");
        request.setActiIden("12");
        request.setTituNum("1");
        request.setLanguage("EN");
        request.setCsp("S05");

        Mockito.when(actionnaireRepository.updateCspLanguage(request)).thenReturn(String.valueOf((request)));

        actionnaireService.updateCspLanguage(request);

        verify(actionnaireRepository, times(1)).updateCspLanguage(any());

    }



/*
    @Test
    void when_emetIden_null_should_return_update_Bancaire_KO() throws FunctionnalException {

        ReqUpdateBancaireTituDto request = easyRandom.nextObject(ReqUpdateBancaireTituDto.class)

        request.setEmetIden(req.getEmetIden());
        request.setActiIden(req.getActiIden());
        request.setTituNume(req.getTituNum());
        request.setType(req.getType());
        request.setSCodePaysReglement(req.getSCodePaysReglement());
        request.setSDevise(req.getSDevise());
        request.setSModeReglement(req.getSModeReglement());
        request.setSAgence(req.getSAgence());
        request.setSBanque(req.getSBanque());
        request.setSCle(req.getSCle());
        request.setSCompte(req.getSCompte());
        request.setSDomiciliation(req.getSDomiciliation());
        request.setSBeneficiaire(req.getSBeneficiaire());
        request.setSRibeBankCode(req.getSRibeBankCode());
        request.setSRibeAgen(req.getSRibeAgen());
        request.setSRibeCtrlInte(req.getSRibCtrlInte());
        request.setSRibeCpt1(req.getSRibCpt1());
        request.setSRibeCpt2(req.getSRibCpt2());
        request.setSRibeCtrlFin(req.getSRibCtrlFin());
        request.setSRibeBic(req.getSRibBic());
        request.setSRibeBankNom(req.getSRibBankNom());
        request.setSRibeBankAdre(req.getSRibBankAdress());
        request.setSRibeIban(req.getSRibIban());
        request.setSRibeBicIntermediaire(req.getSRibBicIntermediaire());
        request.setSRibeBicCouverture(req.getSRibBicCouverture());
        request.setSRibeBankIntermediaireNom(req.getSRibBankIntermediaireNom());
        request.setSRibeBankIntermediaireNomAdre(req.getSRibBankIntermediaireNom());
        request.setSRibeCptBankBenefChezBankIntermediaire(req.getSRibeCptBankBenefChezBankIntermediaire());
        request.setSRibeBankCouvertureNom(req.getSRibeBankCouvertureNom());
        request.setSRibeBankIntermediaireNomAdre(req.getSRibeBankCouvertureNomAdre());
        request.setSRibeCptBankInterChezBankCouverture(req.getSRibeCptBankInterChezBankCouverture());

        FunctionnalException exception = assertThrows(FunctionnalException.class, () -> actionnaireService.updateBancaireTitu(request));
        assertEquals(MANDATORY_FIELD, exception.getCode());

    }

    @Test
    void should_update_Titu_Bancaire_OK() throws Exception {

        ReqUpdateBancaireTituDto request = easyRandom.nextObject(ReqUpdateBancaireTituDto.class)

        request.setEmetIden("458");
        request.setActiIden("12");
        request.setTituNum("1");
        request.setTituEmail("stephane.duris@uptevia.com");
        request.setTituEmail2("stephane2.duris@uptevia.com");
        request.setTituNumMobilePerso("626353226");
        request.setTituNumMobilePersoIndiPays("33");
        request.setTituNumMobilePro("626353224");
        request.setTituNumMobileProIndiPays("33");
        request.setTituNumTel("0153001576");
        request.setTituNumTelIndiPays("0123005577");
        request.setTituNumTel2("0153005571");
        request.setTypecontact("type");
        request.setTypeCoord("coord");
        request.setNumFaxPro("");
        request.setNumFaxProIndiPays("");
        request.setNumFaxPerso("");
        request.setNumFaxPersoIndiPays("");

        Mockito.when(actionnaireRepository.updateBancaireTitu(request)).thenReturn(String.valueOf((request)));

        actionnaireService.updateBancaireTitu(request);

        verify(actionnaireRepository, times(1)).updateContactTitu(any());

    }*/

}
