package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.model.FileDTO;
import com.uptevia.ms.bff.investor.business.domain.model.TypeDocumentDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.IDocumentationRepository;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.stream.Collectors;

@ExtendWith(MockitoExtension.class)
class DocumentationServiceImplTest {

    Logger logger = LoggerFactory.getLogger(DocumentationServiceImplTest.class.getName());

    @Mock
    private IDocumentationRepository documentationRepository;
    @InjectMocks
    DocumentationServiceImpl documentationService;
    private final EasyRandom easyRandom = new EasyRandom();
    @Test
    void should_return_typeDocument_ok() throws Exception {

        int idEmet = 99963514;
        int idActi = 2;
        int pTituNume = 1;

        List<TypeDocumentDTO> detailsTypeDocumentDTO = easyRandom.objects(TypeDocumentDTO.class,2)
                .collect(Collectors.toList());

        detailsTypeDocumentDTO.forEach(e -> {
            e.setDocumentId(1);
            e.setDocumentLangueIso3("FRA");
        });

        Mockito.when(documentationRepository.getTypeDocuments(idEmet, idActi,pTituNume)).thenReturn(detailsTypeDocumentDTO);
        Assertions.assertThat(documentationService.getTypeDocuments(idEmet, idActi,pTituNume)).hasSameSizeAs(detailsTypeDocumentDTO);
    }

    @Test
    void should_return_file_ok() throws Exception {

        int idEmet = 99963514;
        int idActi = 2;
        int pTituNume = 1;
        int pDocId = 1;
        String pCodeLangue = "FRA";

        List<FileDTO> fileDTO = easyRandom.objects(FileDTO.class,1)
                .collect(Collectors.toList());

        fileDTO.forEach(e -> {
            e.setDocumentId(1);
            e.setDocumentContentType("application/pdf");
        });


        Mockito.when(documentationRepository.getFiles(idEmet, idActi,pTituNume, pDocId, pCodeLangue)).thenReturn(fileDTO);

        Assertions.assertThat(documentationService.getFiles(idEmet, idActi,pTituNume, pDocId, pCodeLangue)).hasSameSizeAs(fileDTO);
    }
}
