package com.uptevia.ms.bff.investor.business.domain.service.impl;

import freemarker.template.Configuration;
import freemarker.template.Template;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.*;
import static org.mockito.MockitoAnnotations.initMocks;

@ExtendWith(MockitoExtension.class)
public class EmailServiceImplTest {

    @InjectMocks
    EmailServiceImpl emailService;

    @Value("${spring.mail.from.caceis}")
    private String from;

    @Mock
    JavaMailSender javaMailSender;

    @Mock
    Configuration freemarkerConfiguration;

    @Mock
    private MimeMessage message = mock(MimeMessage.class);

    private final EasyRandom easyRandom = new EasyRandom();

    @BeforeEach
    public void setUp() throws IOException {
        initMocks(this);
        emailService = new EmailServiceImpl(javaMailSender, freemarkerConfiguration);
    }

    //@Test
   void should_send_mail_ok() throws Exception {
        org.springframework.test.util.ReflectionTestUtils.setField(emailService, "from", "no-reply@uptevia.com");
        //EmailDetailsDTO emailToSend = easyRandom.nextObject(EmailDetailsDTO.class);
        final String templateFile = "test";
        Map<String, Object> model = new HashMap<>();
        final Configuration mockCfg = mock (Configuration.class);
        final Template mockTemplate = mock( Template.class );
        lenient().when(mockCfg.getTemplate(templateFile)).thenReturn(mockTemplate);
        ArgumentCaptor<MimeMessage> mimeMessageArgumentCaptor = ArgumentCaptor.forClass(MimeMessage.class);
        when(javaMailSender.createMimeMessage()).thenReturn(message);
        doNothing().when(javaMailSender).send(message);
        //emailService.sendMail(emailToSend);
        verify(javaMailSender, times(1)).send((mimeMessageArgumentCaptor.capture()));
    }
}
