package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.model.ActusDTO;
import com.uptevia.ms.bff.investor.business.domain.model.NewsDTO;
import com.uptevia.ms.bff.investor.business.domain.model.PositionsDetailsDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.INewsRepository;
import com.uptevia.ms.bff.investor.business.domain.service.impl.NewsServiceImpl;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

@ExtendWith(MockitoExtension.class)
class NewsServiceImplTest {

    Logger logger = Logger.getLogger(NewsServiceImplTest.class.getName());

    @Mock
    private INewsRepository newsRepository;

    @InjectMocks
    NewsServiceImpl newsService;

    private EasyRandom easyRandom = new EasyRandom();


    @Test
    void should_return_get_news_ok() throws Exception {

        //Given
        NewsDTO newsDTO = easyRandom.nextObject(NewsDTO.class);

        List<ActusDTO> actusDTOS = easyRandom.objects(ActusDTO.class, 3)
                .collect(Collectors.toList());

        int idEmet = 99963514;
        int idActi = 1;
        int pTituNume = 1;

        // When
        Mockito.when(newsService.getNews(idEmet, idActi, pTituNume)).thenReturn(newsDTO);
        //Then
        Assertions.assertThat(newsService.getNews(idEmet,idActi,pTituNume)
                .getActus()).isEqualTo(newsDTO.getActus());

    }
}
