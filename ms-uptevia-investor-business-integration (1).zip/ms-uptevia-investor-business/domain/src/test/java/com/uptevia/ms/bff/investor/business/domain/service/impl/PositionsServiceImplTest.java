package com.uptevia.ms.bff.investor.business.domain.service.impl;


import com.uptevia.ms.bff.investor.business.domain.model.PositionsDetailsDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.IPositionsDetailsRepository;
import com.uptevia.ms.bff.investor.business.domain.service.impl.PositionsDetailsServiceImpl;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

@ExtendWith(MockitoExtension.class)
class PositionsServiceImplTest {

    Logger logger = Logger.getLogger(PositionsServiceImplTest.class.getName());

    @Mock
    private IPositionsDetailsRepository detailsRepository;

    @InjectMocks
    PositionsDetailsServiceImpl detailsService;

    private final EasyRandom easyRandom = new EasyRandom();


    @Test
    void should_return_positions_titres_ok() throws Exception {

        int idEmet = 99963514;
        int idActi = 1;

        List<PositionsDetailsDTO> listDetailsDTO = easyRandom.objects(PositionsDetailsDTO.class, 3)
                .collect(Collectors.toList());

        listDetailsDTO.forEach(e -> {
            e.setTypePosition("titres");
            e.setValorisation(100);
        });


        Mockito.when(detailsRepository.getAllPositionsDetails(idEmet, idActi)).thenReturn(listDetailsDTO);


        Assertions.assertThat(detailsService.getPositions(idEmet, idActi).getTitres().getValorisationTotale()).
                isEqualTo(new BigDecimal("300.0"));


    }

    @Test
    void should_return_positions_droits_ok() throws Exception {

        int idEmet = 99963514;
        int idActi = 1;

        List<PositionsDetailsDTO> listDetailsDTO = easyRandom.objects(PositionsDetailsDTO.class, 3)
                .collect(Collectors.toList());

        listDetailsDTO.forEach(e -> {
            e.setTypePosition("droits");
            e.setValorisation(250);
        });


        Mockito.when(detailsRepository.getAllPositionsDetails(idEmet, idActi)).thenReturn(listDetailsDTO);


        Assertions.assertThat(detailsService.getPositions(idEmet, idActi).getDroits().getValorisationTotale()).
                isEqualTo(new BigDecimal("750.0"));


    }
}
