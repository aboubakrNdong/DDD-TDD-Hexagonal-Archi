package com.uptevia.ms.bff.investor.business.domain.service.impl;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.DemandeDTO;
import com.uptevia.ms.bff.investor.business.domain.model.SousCategoriesDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.ISelfCareRepository;
import com.uptevia.ms.bff.investor.business.domain.service.EmailService;
import freemarker.template.Configuration;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.javamail.JavaMailSender;


import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.MockitoAnnotations.initMocks;

@ExtendWith(MockitoExtension.class)
class SelfCareServiceImplTest {

    @Mock
    private ISelfCareRepository selfCareRepository;
    @InjectMocks
    SelfCareServiceImpl selfCareService;

    @Mock
    EmailService emailService;

    private final EasyRandom easyRandom = new EasyRandom();

    private final String grcMail = "fake_grc_email@uptevia.com";

    @Mock
    JavaMailSender javaMailSender;

    @Mock
    Configuration freemarkerConfiguration;

    @BeforeEach
    public void setUp() throws IOException {
        emailService = new EmailServiceImpl(javaMailSender, freemarkerConfiguration);
    }

    @Test
    void should_return_piecejointe_ok() throws Exception {

        String pIndiLogged = "O";
        List<SousCategoriesDTO> allSousCategoriesDTO = easyRandom.objects(SousCategoriesDTO.class, 5)
                .collect(Collectors.toList());

        allSousCategoriesDTO.forEach(e -> {
            e.setCateTypoOrdre(1);
            e.setSousTypoIndiPjObligatoire("O");
        });

        Mockito.when(selfCareRepository.getCategories(pIndiLogged)).thenReturn(allSousCategoriesDTO);
        Assertions.assertThat(selfCareService.getCategories(pIndiLogged).size()).isEqualTo(5);
    }

    @Test
    void should_return_send_demande_KO() throws Exception {

        DemandeDTO demandeDTO = easyRandom.nextObject(DemandeDTO.class);


        demandeDTO.setPIndiLogged("N");

        demandeDTO.setActiIden("88824NOOP");


        assertThrows(FunctionnalException.class, () -> selfCareService.createSelfCare(demandeDTO, grcMail, false));

        demandeDTO.setDob("29/10/2023");

        assertThrows(FunctionnalException.class, () -> selfCareService.createSelfCare(demandeDTO, grcMail, false));
    }


    @Test
    void should_return_send_demande_OK() throws Exception {
        org.springframework.test.util.ReflectionTestUtils.setField(emailService, "from", "no-reply@uptevia.com");

        DemandeDTO demandeDTO = easyRandom.nextObject(DemandeDTO.class);

        Mockito.when(selfCareRepository.createSelfCare(demandeDTO)).thenReturn(Long.valueOf(1));

        selfCareService.createSelfCare(demandeDTO, grcMail, true);
    }

}