package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.BaremeDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class BaremeRowMapper implements RowMapper<BaremeDTO> {
    @Override
    public BaremeDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        return BaremeDTO.builder()
                .emetIden(rs.getInt("EMET_IDEN"))
                .idextBarcomms(rs.getString("IDEXT_BARCOMMS"))
                .baremeWeb(rs.getString("BAREME_WEB"))
                .amount0D(rs.getDouble("AMOUNT0D"))
                .amount1D(rs.getDouble("AMOUNT1D"))
                .amount2D(rs.getDouble("AMOUNT2D"))
                .amount3D(rs.getDouble("AMOUNT3D"))
                .amount4D(rs.getDouble("AMOUNT4D"))
                .amount5D(rs.getDouble("AMOUNT5D"))
                .amount6D(rs.getDouble("AMOUNT6D"))
                .amount7D(rs.getDouble("AMOUNT7D"))
                .amount8D(rs.getDouble("AMOUNT8D"))
                .amount9D(rs.getDouble("AMOUNT9D"))
                .mtMinD(rs.getDouble("MTMIND"))
                .mtMaxD(rs.getDouble("MTMAXD"))
                .percent0D(rs.getDouble("PERCENT0D"))
                .percent1D(rs.getDouble("PERCENT1D"))
                .percent2D(rs.getDouble("PERCENT2D"))
                .percent3D(rs.getDouble("PERCENT3D"))
                .percent4D(rs.getDouble("PERCENT4D"))
                .percent5D(rs.getDouble("PERCENT5D"))
                .percent6D(rs.getDouble("PERCENT6D"))
                .percent7D(rs.getDouble("PERCENT7D"))
                .percent8D(rs.getDouble("PERCENT8D"))
                .percent9D(rs.getDouble("PERCENT9D"))
                .build();
    }
}
