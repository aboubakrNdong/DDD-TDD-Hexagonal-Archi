package com.uptevia.ms.bff.investor.business.infra.mapper;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class ClosedDaysRowMapper implements RowMapper<LocalDate> {
    @Override
    public LocalDate mapRow(ResultSet rs, int rowNum) throws SQLException {
        LocalDate closedDay;
        closedDay = rs.getDate("CALE_JOUR").toLocalDate();
        return closedDay;
    }
}
