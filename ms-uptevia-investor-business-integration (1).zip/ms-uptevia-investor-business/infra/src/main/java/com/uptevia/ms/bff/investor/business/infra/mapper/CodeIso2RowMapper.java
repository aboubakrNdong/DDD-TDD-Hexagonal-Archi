package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.CodeIso2DTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;


public class CodeIso2RowMapper implements RowMapper<CodeIso2DTO> {

    @Override
    public CodeIso2DTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        return CodeIso2DTO.builder()
                .libelle(rs.getString("LIBELLE"))
                .paysIso2(rs.getString("PAYS_ISO2"))
                .paysIndiSepa(rs.getString("PAYS_INDI_SEPA"))
                .paysIso2Bic(rs.getString("PAYS_ISO2_BIC"))
                .paysIbanLong(rs.getInt("PAYS_IBAN_LONG"))
                .build();
    }
}
