package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.CompteDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CompteRowMapper implements RowMapper<CompteDTO> {
@Override
public CompteDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        return CompteDTO.builder()
                .emetIden(rs.getInt("EMET_IDEN"))
                .actiIden(rs.getInt("ACTI_IDEN"))
                .tituNume(rs.getInt("TITU_NUME"))
                .themeId(rs.getInt("ID_THEME"))
                .nom(rs.getString("NOM"))
                .prenom(rs.getString("PRENOM"))
                .qualite(rs.getString("QUALITE"))
                .actiTypeCompte(rs.getString("ACTITYPECPTE"))
                .typeCpte(rs.getString("TYPE_CPTE"))
                .build();
        }
}
