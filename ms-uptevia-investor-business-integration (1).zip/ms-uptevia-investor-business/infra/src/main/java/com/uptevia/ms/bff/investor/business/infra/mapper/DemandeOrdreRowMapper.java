package com.uptevia.ms.bff.investor.business.infra.mapper;


import com.uptevia.ms.bff.investor.business.domain.model.OrdreBourseDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DemandeOrdreRowMapper implements RowMapper<OrdreBourseDTO> {
    @Override
    public OrdreBourseDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        return OrdreBourseDTO.builder()
                .idDemande(rs.getInt("DEMANDE_CURRVAL"))
                .numDemandeCurrval(rs.getString("NUM_DEMANDE_CURRVAL"))
                .build();
    }

}
