package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.LigneAvoirsDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class LigneAvoirsRowMapper implements RowMapper<LigneAvoirsDTO> {
    @Override
    public LigneAvoirsDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        return LigneAvoirsDTO
                .builder()
                .natureJuridique(rs.getString("NATURE_JURI"))
                .regptAvoir(rs.getInt("REGPT_AVOIR"))
                .rubCompta(rs.getString("RUB_COMPTA"))
                .prixAcquisition(rs.getDouble("PRIX_ACQUISITION"))
                .qualificatif(rs.getString("QUALIFICATIF"))
                .nbActionDispo(rs.getInt("NB_ACTION_DISPO"))
                .categorie(rs.getString("CATEGORIE"))
                .dateDispo(convertNotNullDate(rs.getDate("DATE_DISPO")))
                .dateLevee(convertNotNullDate(rs.getDate("DATE_LEVEE")))
                .dateSouscription(convertNotNullDate(rs.getDate("D_SOUSCRIPTION")))
                .libePlan(rs.getString("LIBELLE_PLAN"))
                .valeIdenPlan(rs.getString("VALE_IDEN_PLAN"))
                .restrictionJuridique(rs.getString("RESTRICTION_JURIDIQUE"))
                .dateSoaa(convertNotNullDate(rs.getDate("SOAA_DATE")))
                .numAvoa(rs.getInt("AVOA_NUME"))
                .dateVoteDoubleBrut(convertNotNullDate(rs.getDate("D_VOTE_DOUBLE_BRUT")))
                .dateDetentionBrut(convertNotNullDate(rs.getDate("D_DETENTION_BRUT")))
                .dateCessFiscale(convertNotNullDate(rs.getDate("DATE_CESS_FISCALE")))
                .build();
    }

    private LocalDate convertNotNullDate(java.sql.Date databaseValue) {
        if (databaseValue != null) {
            return databaseValue.toLocalDate();
        }
        return null;
    }
}
