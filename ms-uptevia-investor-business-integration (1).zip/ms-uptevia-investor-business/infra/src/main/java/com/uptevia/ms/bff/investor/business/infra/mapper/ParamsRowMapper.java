package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.ParamsDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ParamsRowMapper implements RowMapper<ParamsDTO> {
    @Override
    public ParamsDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        return ParamsDTO.builder()
                .paramName(rs.getString("PARAM_NAME"))
                .paramValue(rs.getString("PARAM_VALUE"))
                .paramCategory(rs.getString("PARAM_CATEGORY"))
                .build();
    }
}