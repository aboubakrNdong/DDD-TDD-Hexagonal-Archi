package com.uptevia.ms.bff.investor.business.infra.mapper;


import com.uptevia.ms.bff.investor.business.domain.model.PositionsDetailsDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class PositionsDetailsRowMapper implements RowMapper<PositionsDetailsDTO> {
    @Override
    public PositionsDetailsDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        return PositionsDetailsDTO.builder()
                .typePosition(rs.getString("type_position"))
                .derniereMaj(rs.getString("derniere_maj"))
                .qte(rs.getInt("quantite"))
                .valorisation(rs.getDouble("valorisation"))
                .natureJuridique(rs.getString("nature_juri"))
                .codeLibelle(("avoirs." + rs.getString("type_position")+"."+rs.getString("nature_juri")).toLowerCase())
                .devise(rs.getString("devise"))
                .build();
    }
}
