package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.PsSelDetailTituDTO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

import static com.uptevia.ms.bff.investor.business.domain.service.impl.AbstractBusinessService.*;

public class TituDetailRowMapper implements RowMapper<PsSelDetailTituDTO> {

    @Override
    public PsSelDetailTituDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        PsSelDetailTituDTO psSelDetailTituDTO = new PsSelDetailTituDTO();
        ZoneOffset offset = ZoneOffset.UTC;
        psSelDetailTituDTO.setNom(rs.getString("TITU_NOM"));
        psSelDetailTituDTO.setPrenom(rs.getString("TITU_PREN"));
        psSelDetailTituDTO.setPrenom2(rs.getString("TITU_PREN2"));
        psSelDetailTituDTO.setQualite(rs.getString("TITU_QUAL"));
        LocalDate dateDerniereConnexion = null;
        if (rs.getDate("TITU_DATE_DERNIERE_CNX") != null) {
            dateDerniereConnexion = rs.getDate("TITU_DATE_DERNIERE_CNX").toLocalDate();
            OffsetDateTime offsetDateTime = dateDerniereConnexion.atTime(OffsetTime.now());
            psSelDetailTituDTO.setDateDerniereConnexion(offsetDateTime);
        }
        psSelDetailTituDTO.setNomJF(rs.getString("TITU_NOM_JF"));
        psSelDetailTituDTO.setEmailPerso(rs.getString("TITU_EMAIL_PERSO"));
        psSelDetailTituDTO.setEmailPro(rs.getString("TITU_EMAIL_PRO"));
        psSelDetailTituDTO.setNumFixePerso(rs.getString("TITU_NUM_FIXE_PERSO"));
        psSelDetailTituDTO.setNumFixePro(rs.getString("TITU_NUM_FIXE_PRO"));
        psSelDetailTituDTO.setNumMobilePro(rs.getString("TITU_NUM_MOBILE_PRO"));
        psSelDetailTituDTO.setNumMobilePerso(rs.getString("TITU_NUM_MOBILE_PERSO"));
        psSelDetailTituDTO.setTituLanguage(rs.getString("TITU_LANG"));
        /** Mapper l'adresse fiscale */
        psSelDetailTituDTO.setAdreFiscInfoBati(rs.getString("ADRE_FISC_INFO_BATI"));
        psSelDetailTituDTO.setAdreFiscInfoRue(rs.getString("ADRE_FISC_INFO_RUE"));
        psSelDetailTituDTO.setAdreFiscComp(rs.getString("ADRE_FISC_COMP"));
        psSelDetailTituDTO.setAdreFiscCodp(rs.getString("ADRE_FISC_CODP"));
        psSelDetailTituDTO.setAdreFiscDept(rs.getString("ADRE_FISC_DEPT"));
        psSelDetailTituDTO.setAdreFiscNomCommune(rs.getString("ADRE_FISC_NOM_COMU"));
        psSelDetailTituDTO.setAdreFiscCodeCommune(rs.getString("ADRE_FISC_CODE_COMU"));
        psSelDetailTituDTO.setAdreFiscPaysIden(rs.getString("ADRE_FISC_PAYS_IDEN"));
        /** Fin Mapper l'adresse fiscale */

        /** Mapper l'adresse postale */
        psSelDetailTituDTO.setAdreInfoBati(rs.getString("ADRE_INFO_BATI"));
        psSelDetailTituDTO.setAdreInfoRue(rs.getString("ADRE_INFO_RUE"));
        psSelDetailTituDTO.setAdreComplement(rs.getString("ADRE_COMP"));
        psSelDetailTituDTO.setAdreCodp(rs.getString("ADRE_CODP"));
        psSelDetailTituDTO.setAdreNomCommune(rs.getString("ADRE_NOM_COMU"));
        psSelDetailTituDTO.setAdrePaysIden(rs.getString("ADRE_PAYS_IDEN"));
        LocalDate tituDateNaissance = null;
        if (rs.getDate("TITU_DATE_NAIS") != null) {
            tituDateNaissance = rs.getDate("TITU_DATE_NAIS").toLocalDate();
            psSelDetailTituDTO.setTituNaisDate(tituDateNaissance.atStartOfDay(offset).toOffsetDateTime());
        }
        psSelDetailTituDTO.setTituNaisComu(rs.getString("TITU_COMU_NAIS"));
        psSelDetailTituDTO.setTituNaisComuCode(rs.getString("TITU_COMU_NAIS_CODE"));
        psSelDetailTituDTO.setTituNaisDept(rs.getString("TITU_DEPT_NAIS"));
        psSelDetailTituDTO.setTituNaisPaysIden(rs.getString("PAYS_NAIS_IDEN"));
        /** Fin Mapper l'adresse postale */

        /** Mapper Données bancaires */
        psSelDetailTituDTO.setTituModeReglement(rs.getString("TITU_MODE_REGL"));
        psSelDetailTituDTO.setTituDevise(rs.getString("TITU_DEVI"));
        psSelDetailTituDTO.setRegrReglIden(rs.getString("REGR_REGL_IDEN"));
        psSelDetailTituDTO.setRibBank(rs.getString("RIB_BANK"));
        psSelDetailTituDTO.setRibAgen(rs.getString("RIB_AGEN"));
        psSelDetailTituDTO.setRibCompte(rs.getString("RIB_CPTE"));

        psSelDetailTituDTO.setRibCle(StringUtils.leftPad(rs.getString("RIB_CLE"), 2, "0"));

        psSelDetailTituDTO.setRibDomi(rs.getString("RIB_DOMI"));
        psSelDetailTituDTO.setRibIban(rs.getString("RIBE_IBAN"));
        psSelDetailTituDTO.setRibeBic(rs.getString("RIBE_BIC"));
        psSelDetailTituDTO.setRibeBicInte(rs.getString("RIBE_BIC_INTE"));
        psSelDetailTituDTO.setRibeBankNom(rs.getString("RIBE_BANK_NOM"));
        psSelDetailTituDTO.setRibeBankAdre(rs.getString("RIBE_BANK_ADRE"));
        psSelDetailTituDTO.setRibePaysIden(rs.getString("RIBE_PAYS_IDEN"));
        psSelDetailTituDTO.setRibeAgence(rs.getString("RIBE_AGEN"));
        psSelDetailTituDTO.setRibeCtrlInte(rs.getString("RIBE_CTRL_INTE"));
        psSelDetailTituDTO.setRibeCpte1(rs.getString("RIBE_CPT1"));
        psSelDetailTituDTO.setRibeCpte2(rs.getString("RIBE_CPT2"));
        psSelDetailTituDTO.setRibeCtrlFinal(rs.getString("RIBE_CTRL_FIN"));
        psSelDetailTituDTO.setRibeBic2(rs.getString("RIBE_BIC2"));
        psSelDetailTituDTO.setRibeBankCode(rs.getString("RIBE_BANK_CODE"));
        psSelDetailTituDTO.setTituBene(rs.getString("TITU_BENE"));
        psSelDetailTituDTO.setTituCsp(rs.getString("TITU_CSP"));

        /** Fin Mapper Données bancaires */

        psSelDetailTituDTO.setActiRefeScte(rs.getString("ACTI_REFE_SCTE"));
        psSelDetailTituDTO.setActiRefeSala(rs.getString("ACTI_REFE_SALA"));
        psSelDetailTituDTO.setActiTypeCpte(rs.getString("ACTI_TYPE_CPTE"));

        LocalDate actiConDateEnvoi = null;
        if (rs.getDate("ACTI_CONV_DATE_ENVOI") != null) { // we might have some null values
            actiConDateEnvoi = rs.getDate("ACTI_CONV_DATE_ENVOI").toLocalDate();
            psSelDetailTituDTO.setActiConvDateEnvoi(actiConDateEnvoi.atStartOfDay(offset).toOffsetDateTime());
        }

        LocalDate actiConDateRecept = null;
        if (rs.getDate("ACTI_CONV_DATE_RECEPT") != null) { // we might have some null values
            actiConDateRecept = rs.getDate("ACTI_CONV_DATE_RECEPT").toLocalDate();
            psSelDetailTituDTO.setActiConvDateRecept(actiConDateRecept.atStartOfDay(offset).toOffsetDateTime());
        }
        LocalDate actiConDateRelance = null;
        if (rs.getDate("ACTI_CONV_DATE_RELANCE") != null) { // we might have some null values
            actiConDateRelance = rs.getDate("ACTI_CONV_DATE_RELANCE").toLocalDate();
            psSelDetailTituDTO.setActiConvDateRelance(actiConDateRelance.atStartOfDay(offset).toOffsetDateTime());
        }

        psSelDetailTituDTO.setActiMifClass(rs.getString("ACTI_MIF_CLASS"));
        if (StringUtils.equals(rs.getString("ACTI_CONV_INDI_EXCLU"), "O")) {
            psSelDetailTituDTO.setActiConvIndiExclu(true);
        }
        if (StringUtils.equals(rs.getString("ACTI_CONV_INDI_EXCLU"), "N")) {
            psSelDetailTituDTO.setActiConvIndiExclu(false);
        }
        if (StringUtils.equals(rs.getString("ACTI_CONV_INDI_INCOMP"), "O")) {
            psSelDetailTituDTO.setActiConvIndiIncomp(true);
        }
        if (StringUtils.equals(rs.getString("ACTI_CONV_INDI_INCOMP"), "N")) {
            psSelDetailTituDTO.setActiConvIndiIncomp(false);
        }

        psSelDetailTituDTO.setEmetLibelle(rs.getString("EMET_LIBELLE"));
        psSelDetailTituDTO.setDrhRattachement(rs.getString("DRH_RATTACHEMENT"));

        psSelDetailTituDTO.setNatioIso3(rs.getString("NATIO_ISO3"));
        psSelDetailTituDTO.setIdNatioType(rs.getString("ID_NATIO_TYPE"));
        psSelDetailTituDTO.setIdNatioMifid(rs.getString("ID_NATIO_MIFID"));
        psSelDetailTituDTO.setPjType(rs.getString("PJ_TYPE"));
        psSelDetailTituDTO.setPjNume(rs.getString("PJ_NUME"));
        LocalDate pjDateExpir = null;
        if (rs.getDate("PJ_DATE_EXPIR") != null) { // we might have some null values
            pjDateExpir = rs.getDate("PJ_DATE_EXPIR").toLocalDate();
            psSelDetailTituDTO.setPjDateExpir(pjDateExpir.atStartOfDay(offset).toOffsetDateTime());
        }
        LocalDate pjDateDeliv = null;
        if (rs.getDate("PJ_DATE_DELIV") != null) { // we might have some null values
            pjDateDeliv = rs.getDate("PJ_DATE_DELIV").toLocalDate();
            psSelDetailTituDTO.setPjDateDeliv(pjDateDeliv.atStartOfDay(offset).toOffsetDateTime());
        }

        psSelDetailTituDTO.setPjTypeLib(rs.getString("pj_type_lib"));
        psSelDetailTituDTO.setIdNatioTypeLib(rs.getString("id_natio_type_lib"));
        psSelDetailTituDTO.setDateAcceptCGU ( rs.getString("DATE_ACCEPT_CGU"));

        psSelDetailTituDTO.setIndiAbonnement(int2boolean(rs.getInt("INDI_ABONNEMENT")));

        psSelDetailTituDTO.setTituNume(rs.getInt("TITU_NUME"));

        return psSelDetailTituDTO;
    }
}
