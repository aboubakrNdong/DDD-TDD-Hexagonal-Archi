package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.ValeurDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ValeurCessibleRowMapper implements RowMapper<ValeurDTO> {
@Override
public ValeurDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        return ValeurDTO.builder()
                .valeIden(rs.getString("VALE_IDEN"))
                .solde(rs.getLong("SOLDE"))
                .repartie(rs.getLong("REPARTIE"))
                .disponible(rs.getLong("DISPONIBLE"))
                .indisponible(rs.getLong("INDISPONIBLE"))
                .derogation(rs.getLong("DEROGATION"))
                .build();
        }
}
