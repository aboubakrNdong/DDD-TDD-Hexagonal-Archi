package com.uptevia.ms.bff.investor.business.infra.mapper;

import com.uptevia.ms.bff.investor.business.domain.model.ValeurDTO;
import org.springframework.jdbc.core.RowMapper;
import java.sql.ResultSet;
import java.sql.SQLException;

import static com.uptevia.ms.bff.investor.business.domain.service.impl.AbstractBusinessService.ONtoBoolean;

public class ValeurRowMapper implements RowMapper<ValeurDTO> {
    @Override
    public ValeurDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        return ValeurDTO.builder()
                .isValeurPrincipale(ONtoBoolean(rs.getString("I_VALEUR_PRINCIPALE")))
                .valeIden(rs.getString("VALE_IDEN"))
                .valeGestIden(rs.getString("VALE_GEST_IDEN"))
                .valeLibe(rs.getString("VALE_LIBE"))
                .valeLibe2(rs.getString("VALE_LIBE2"))
                .valeNatu(rs.getString("VALE_NATU"))
                .valeDepo(rs.getString("VALE_DEPO"))
                .valeNego(rs.getString("VALE_NEGO"))
                .valeCate(rs.getString("VALE_CATE"))
                .coursDate(rs.getString("COURS_DATE"))
                .deviseNego(rs.getString("DEVISE_NEGO"))
                .codePlace(rs.getString("CODE_PLACE"))
                .libelleCodePlace(rs.getString("LIBELLE_CODE_PLACE"))
                .iCodePrime(rs.getString("I_CODE_PRIME"))
                .valeurPatio(rs.getString("VALEUR_PATIO"))
                .deviseCours(rs.getString("DEVISE_COURS"))
                .valeScale(rs.getInt("VALE_SCALE"))
                .iPromesse(rs.getInt("I_PROMESSE"))
                .isValeurEtrangere(rs.getInt("ISVALEURETRANGERE"))
                .isValEtrAutorisee(rs.getInt("IS_VAL_ETR_AUTORISEE"))
                .displayTutoSpe(rs.getInt("DISPLAY_TUTO_SPE"))
                .valeurAffichableVente(rs.getInt("VALEURAFFICHABLEVENTE"))
                .valeurVendableOlis(rs.getInt("VALEURVENDABLEOLIS"))
                .valeurAffichableAchat(rs.getInt("VALEURAFFICHABLEACHAT"))
                .valeurAchetableOlis(rs.getInt("VALEURACHETABLEOLIS"))
                .minFrais(rs.getDouble("MIN_FRAIS"))
                .tauxTtf(rs.getDouble("TAUX_TTF"))
                .tauxFraisBancaires(rs.getDouble("TAUX_FRAIS_BANCAIRES"))
                .tauxImpotBourse(rs.getDouble("TAUX_IMPOT_BOURSE"))
                .dernierCours(rs.getDouble("DERNIER_COURS"))
                .dernierCoursEuro(rs.getDouble("DERNIER_COURS_EURO"))
                .coursOuverture(rs.getDouble("COURS_OUVERTURE"))
                .build();
    }
}
