package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.uptevia.ms.bff.investor.business.domain.model.FileDTO;
import com.uptevia.ms.bff.investor.business.domain.model.TypeDocumentDTO;
import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.repository.IDocumentationRepository;
import com.uptevia.ms.bff.investor.business.infra.mapper.FileRowMapper;
import com.uptevia.ms.bff.investor.business.infra.mapper.TypeDocumentRowMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class DocumentationRepository implements IDocumentationRepository {

    public static final String NAME_OF_PROC = "FILE_GET_BY_ID";
    public static final String ID_EMET = "P_EMET_IDEN";
    public static final String ID_ACTI = "P_ACTI_IDEN";
    public static final String TITU_NUM = "P_TITU_NUME";
    public static final String DOC_ID = "P_DOC_ID";
    public static final String CODE_LANGUE = "P_CODE_LANGUE";
    public static final String RETURNING_RESULT_SET = "PS_CUR";


    Logger logger = LoggerFactory.getLogger(DocumentationRepository.class.getName());

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;


    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public List<TypeDocumentDTO> getTypeDocuments(int idEmet, int idActi, int pTituNume) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("TITU_GET_FILES")
                .returningResultSet(RETURNING_RESULT_SET,
                        new TypeDocumentRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(ID_EMET, idEmet)
                .addValue(ID_ACTI, idActi)
                .addValue(TITU_NUM, pTituNume);

        Map<String, Object> out = jdbcCall.execute(in);

        List<TypeDocumentDTO> result = (List<TypeDocumentDTO>) out.get(RETURNING_RESULT_SET);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put(ID_EMET, idEmet);
            contextParams.put(ID_ACTI, idActi);
            contextParams.put(TITU_NUM, pTituNume);
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }
        return result;
    }

    @Override
    public List<FileDTO> getFiles(int idEmet, int idActi, int pTituNume, int pDocId, String pCodeLangue) throws FunctionnalException {

        logger.info("Beginning get Files with id emet {}", idEmet);

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(NAME_OF_PROC)
                .returningResultSet(RETURNING_RESULT_SET,
                        new FileRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(ID_EMET, idEmet)
                .addValue(ID_ACTI, idActi)
                .addValue(TITU_NUM, pTituNume)
                .addValue(DOC_ID, pDocId)
                .addValue(CODE_LANGUE, pCodeLangue);

        Map<String, Object> out = jdbcCall.execute(in);

        List<FileDTO> result = (List<FileDTO>) out.get(RETURNING_RESULT_SET);
        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return result;
    }
}
