package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.EabonnementDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.IEabonnementRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


@Repository
public class EabonnementRepository implements IEabonnementRepository {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final JdbcTemplate jdbcTemplate;

    public EabonnementRepository(@Qualifier("jdbcTemplate2") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public Long insertEabonnement(EabonnementDTO eabonnement) throws FunctionnalException {
        long returnValue = 0;
        try {
            logger.info(" beginning save value with ActiIDen: " + eabonnement.getParamActiIden());

            String todaysDate = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH).format(LocalDateTime.now());

            Timestamp timestamp = Timestamp.valueOf(LocalDateTime.parse(todaysDate, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                    .withFunctionName("TITU_INSERT_EABONNEMENT")
                    .declareParameters(
                            new SqlParameter("PARAM_LOGIN", Types.VARCHAR),
                            new SqlParameter("PARAM_EMET_IDEN", Types.NUMERIC),
                            new SqlParameter("PARAM_ACTI_IDEN", Types.NUMERIC),
                            new SqlParameter("PARAM_TITU_NUME", Types.NUMERIC),
                            new SqlParameter("PARAM_CHOIX", Types.VARCHAR),
                            new SqlParameter("PARAM_DATE_CHOIX", Types.DATE),
                            new SqlOutParameter("RETURN VALUE", Types.NUMERIC)
                    );

            // Créez un HashMap pour les paramètres d'entrée
            Map<String, Object> inParams = new HashMap<>();
            inParams.put("PARAM_LOGIN", eabonnement.getParamLogin());
            inParams.put("PARAM_EMET_IDEN", eabonnement.getParamEmetIden());
            inParams.put("PARAM_TITU_NUME", eabonnement.getParamTituNume());
            inParams.put("PARAM_ACTI_IDEN", eabonnement.getParamActiIden());
            inParams.put("PARAM_CHOIX", eabonnement.getParamChoix());
            inParams.put("PARAM_DATE_CHOIX", timestamp);

            Map<String, Object> result = jdbcCall.execute(inParams);

            // Récupération de la valeur de retour
            returnValue = ((Number) result.get("RETURN VALUE")).intValue();
        } catch (DataAccessException e) {
            Map<String, Object> contextParams = new HashMap<>();
            // Gérez l'erreur SQL
            Throwable rootCause = e.getRootCause();
            if (rootCause != null) {
                contextParams.put("login", eabonnement.getParamLogin());
                contextParams.put("emetIden", eabonnement.getParamEmetIden());
                throw new FunctionnalException("SDX", rootCause.getMessage(), contextParams);
            }
        }
        return returnValue;
    }
}


