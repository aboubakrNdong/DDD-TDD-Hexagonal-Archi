package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.ParamsDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.IParamsRepository;
import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import com.uptevia.ms.bff.investor.business.infra.mapper.ParamsRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.logging.Logger;

@Repository
public class ParamsRepository implements IParamsRepository {
    Logger logger = Logger.getLogger(ParamsRepository.class.getName());

    @Value("${spring.profiles.active}")
    private String activeProfiles;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;


    @PostConstruct
    public void init() {
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public String getActiveCurrentEnv() {
        //RULE: Si plusieurs profils active, la première valeur doit être celle de l'environement
        return activeProfiles.split(",")[0];
    }

    @Override
    public List<ParamsDTO> getAllParams() throws FunctionnalException {
        String currentEnv = getActiveCurrentEnv();
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("SITE_GET_PARAM")
                .returningResultSet(Constantes.PS_CUR,
                        new ParamsRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_EMET_IDEN", 0)
                .addValue("PARAM_PARAM_NAME", null)
                .addValue("PARAM_PARAM_CATEGORY", null)
                .addValue("PARAM_PARAM_ENV", currentEnv);

        Map<String, Object> out = jdbcCall.execute(in);

        List<ParamsDTO> result = (List<ParamsDTO>) out.get(Constantes.PS_CUR);

        if (result == null) {
            throw new FunctionnalException(Constantes.NO_DATA_FOUND , "Empty_Data_Params_For " + currentEnv);
        }

        return result;
    }
}