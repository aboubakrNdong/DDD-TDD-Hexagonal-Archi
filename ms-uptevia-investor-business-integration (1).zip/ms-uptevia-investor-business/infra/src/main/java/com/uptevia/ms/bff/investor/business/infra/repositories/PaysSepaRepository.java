package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IPaysSepaRepository;
import com.uptevia.ms.bff.investor.business.infra.mapper.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;


@Repository
public class PaysSepaRepository implements IPaysSepaRepository {

    private static final String GET_PARAM_EMETTEUR = "PARAM_EMETTEUR_GET";

    public static final String PS_CUR = "PS_CUR";
    private static final String ID_EMET = "IDEMET";
    private static final String ID_ACTI = "IDACTI";

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    Logger logger = Logger.getLogger(PaysSepaRepository.class.getName());


    private final JdbcTemplate jdbcTemplate;

    public PaysSepaRepository(
            @Qualifier("jdbcTemplate2") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    @PostConstruct
    public void init() {
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }


 //   @Override
    public PaysSepaDTO getPaysSepa(Integer emetIden, String paramName) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(GET_PARAM_EMETTEUR)
                .returningResultSet(PS_CUR,
                        new PaysSepaRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_EMET_IDEN", emetIden)
                .addValue("PARAM_PARAM_NAME", paramName);
        Map<String, Object> out = jdbcCall.execute(in);

        List<PaysSepaDTO> result = (List<PaysSepaDTO>) out.get(PS_CUR);

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return result.get(0);
    }
}
