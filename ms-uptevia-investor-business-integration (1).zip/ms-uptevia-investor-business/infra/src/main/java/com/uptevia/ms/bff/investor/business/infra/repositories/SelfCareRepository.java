package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.DemandeDTO;
import com.uptevia.ms.bff.investor.business.domain.model.SousCategoriesDTO;
import com.uptevia.ms.bff.investor.business.domain.model.TraductionDTO;
import com.uptevia.ms.bff.investor.business.domain.repository.ISelfCareRepository;
import com.uptevia.ms.bff.investor.business.infra.mapper.SousCategoryRowMapper;
import com.uptevia.ms.bff.investor.business.infra.tradClient.TradClient;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;


@Repository
public class SelfCareRepository implements ISelfCareRepository {
    Logger logger = Logger.getLogger(SelfCareRepository.class.getName());

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    private TradClient tradClient;

    public SelfCareRepository(@Qualifier("jdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;


    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }
    @Override
    public List<SousCategoriesDTO> getCategories(String pIndiLogged ) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("GRC_GET_TYPOLOGIE")
                .returningResultSet("PS_CUR",
                        new SousCategoryRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_INDI_LOGGED", pIndiLogged);

        Map<String, Object> out = jdbcCall.execute(in);

        List<SousCategoriesDTO> result = (List<SousCategoriesDTO>) out.get("PS_CUR");

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("P_INDI_LOGGED", pIndiLogged);
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return result;
    }


    @Override
    public Long createSelfCare(DemandeDTO demandeTosave) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName("UPI_DEMANDE_INSERT"); //function name

        String compteKey = buildCompteKey(demandeTosave.getEmetIden(), demandeTosave.getActiIden(), demandeTosave.getTituNume(), "", "", "");
        //Add parameters needed to execute the SQL function
        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("param_origine", "UPI")
                .addValue("param_typologie", demandeTosave.getCategory())
                .addValue("param_sous_typologie", demandeTosave.getSubCategory())
                .addValue("param_clob", DemandeDTO.toJson(demandeTosave))
                .addValue("param_compte_key", compteKey)
                .addValue("param_commentaire", demandeTosave.getMessage())
                .addValue("param_commentaire_histo", "")
                .addValue("param_user_crea", demandeTosave.getEmail().split("[@]")[0]);

        return jdbcCall.executeFunction(BigDecimal.class, in).longValue();
    }

    @Override
    public List<TraductionDTO> getTraductions(String lang, Integer themeId) throws DataAccessException {
        return tradClient.traductions(lang, themeId).getBody();
    }


    public static String buildCompteKey(String emetIden, String actiIden, String tituNume, String titrIdCat, String titrCreelia, String idAutre){
        return StringUtils.leftPad(StringUtils.defaultIfBlank(emetIden,"0"), 8, "0")
                + "-" +StringUtils.leftPad(StringUtils.defaultIfBlank(actiIden,"0"), 7, "0")
                + "-" +StringUtils.leftPad(StringUtils.defaultIfBlank(tituNume,"0"), 2, "0")
                + "-" +StringUtils.defaultIfBlank(titrCreelia, "0")
                + "-" +StringUtils.defaultIfBlank(titrIdCat, "0")
                + "-" +StringUtils.defaultIfBlank(idAutre, "0");
    }
}
