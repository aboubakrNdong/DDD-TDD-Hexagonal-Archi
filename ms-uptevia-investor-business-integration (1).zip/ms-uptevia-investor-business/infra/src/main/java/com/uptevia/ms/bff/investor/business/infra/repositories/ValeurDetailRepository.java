package com.uptevia.ms.bff.investor.business.infra.repositories;

import com.uptevia.ms.bff.investor.business.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.business.domain.model.*;
import com.uptevia.ms.bff.investor.business.domain.repository.IValeurDetailRepository;
import com.uptevia.ms.bff.investor.business.domain.service.impl.AbstractBusinessService;
import com.uptevia.ms.bff.investor.business.domain.util.Constantes;
import com.uptevia.ms.bff.investor.business.infra.mapper.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;


@Repository
public class ValeurDetailRepository implements IValeurDetailRepository {

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;

    Logger logger = Logger.getLogger(ValeurDetailRepository.class.getName());


    private final JdbcTemplate jdbcTemplate;
    private final JdbcTemplate jdbcTemplateUptevia;


    public ValeurDetailRepository(
            @Qualifier("jdbcTemplate2") JdbcTemplate jdbcTemplate, @Qualifier("jdbcTemplate") JdbcTemplate jdbcTemplateUptevia) {
        this.jdbcTemplate = jdbcTemplate;
        this.jdbcTemplateUptevia = jdbcTemplateUptevia;
    }


    @PostConstruct
    public void init() {
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }


    @Override
    public List<ValeurDTO> getValeurs(int idEmet) throws FunctionnalException {




        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplateUptevia)
                .withProcedureName(Constantes.PROC_VALEURS)
                .returningResultSet(Constantes.PS_CUR,
                        new ValeurRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_EMET_IDEN", idEmet)
                .addValue("P_VALE_IDEN", null);


        Map<String, Object> out = jdbcCall.execute(in);

        List<ValeurDTO> result = (List<ValeurDTO>) out.get(Constantes.PS_CUR);

        if (result.isEmpty()) {
            Collections.emptyList();
        }

        return result;
    }


    @Override
    public BaremeDTO getBareme(int idEmet, int isValeurEtrangere, String valeIden, String valeNatu, String baremeWeb) throws FunctionnalException {

        logger.log(Level.INFO, "Beginning get Barem with idEmet: {0} ", idEmet);

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.PROC_BAREME)
                .returningResultSet(Constantes.PS_CUR,
                        new BaremeRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_EMET_IDEN", idEmet)
                .addValue("P_BAREME_WEB", baremeWeb)
                .addValue("P_IS_VAL_ETR", AbstractBusinessService.translateIntToON(isValeurEtrangere))
                .addValue("P_VALE_NATU", valeNatu)
                .addValue("P_VALE_IDEN", valeIden)
                .addValue("P_OPA_IDEN", null);

        Map<String, Object> out = jdbcCall.execute(in);

        List<BaremeDTO> result = (List<BaremeDTO>) out.get(Constantes.PS_CUR);
        if (result.isEmpty()) {
            return null;
        }

        return result.get(0);
    }

    @Override
    public List<PasCotationDTO> getPasCotation(String valeIden) throws FunctionnalException {
        logger.log(Level.INFO, "Beginning get PasCotation with valeIden: {0} ", valeIden);

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.PROC_PAS_DE_COTATION)
                .returningResultSet(Constantes.PS_CUR,
                        new PasCotationRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("VALEIDEN", valeIden);

        Map<String, Object> out = jdbcCall.execute(in);

        List<PasCotationDTO> result = (List<PasCotationDTO>) out.get(Constantes.PS_CUR);
        if (result.isEmpty()) {
            Collections.emptyList();
        }

        return result;
    }

    @Override
    public ValeurDetailDTO getValeurDetails(int idEmet, int isValeurEtrangere, String valeIden, String valeNatu, String baremeWeb) throws FunctionnalException {
        return null;
    }

    @Override
    public List<ValeurDTO> getValeursCessibles(int idEmet, int idActi) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.PROC_VALEURS_CESSIBLES)
                .returningResultSet(Constantes.PS_CUR,
                        new ValeurCessibleRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue(Constantes.ID_EMET, idEmet)
                .addValue(Constantes.ID_ACTI, idActi)
                .addValue(Constantes.VALEUR, null);


        Map<String, Object> out = jdbcCall.execute(in);

        List<ValeurDTO> result = (List<ValeurDTO>) out.get(Constantes.PS_CUR);

        if (result.isEmpty()) {
            Collections.emptyList();
        }
        return result;
    }

    @Override
    public List<LigneAvoirsDTO> getAvoirsAvendre(int idEmet, int idActi, String valeIden) throws FunctionnalException {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName(Constantes.PROC_AVOIRS_A_VENDRE)
                .returningResultSet(Constantes.PS_CUR,
                        new LigneAvoirsRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("IDDEMANDE", null)
                .addValue(Constantes.ID_EMET, idEmet)
                .addValue(Constantes.ID_ACTI, idActi)
                .addValue(Constantes.VALEUR, valeIden)
                .addValue("SITE", null);


        Map<String, Object> out = jdbcCall.execute(in);

        List<LigneAvoirsDTO> result = (List<LigneAvoirsDTO>) out.get(Constantes.PS_CUR);
        if (result.isEmpty()) {
            Collections.emptyList();
        }

        return result;
    }


}
