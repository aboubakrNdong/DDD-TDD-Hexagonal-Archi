package com.uptevia.ms.bff.investor.business.infra.tradClient;

import com.uptevia.ms.bff.investor.business.domain.model.TraductionDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "ms-investor-resource-app", url = "${resource.base.url}")
public interface TradClient {

    @RequestMapping(method = RequestMethod.GET, value = "api/v1/traduction/{lang}/{themeId}")
    public ResponseEntity<List<TraductionDTO>> traductions(@PathVariable(value = "lang") String lang,
                                                           @PathVariable(value = "themeId") Integer themeId);
}
