package com.uptevia.ms.bff.investor.ext.app.configuration;

import com.uptevia.ms.bff.investor.ext.domain.repository.*;
import com.uptevia.ms.bff.investor.ext.domain.service.*;
import com.uptevia.ms.bff.investor.ext.domain.service.impl.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DomainConfiguration {
    @Bean
    PaiementService operatePaiement(IPaiementRepository paiementRepository){
        return new PaiementServiceImpl(paiementRepository);
    }

    @Bean
    RecaptchaService checkRecaptcha(IRecaptchaRepository recaptchaRepository){
        return new RecaptchaServiceImpl(recaptchaRepository);
    }

    @Bean
    SmsService sendSms(ISmsRepository smsRepository){
        return new SmsServiceImpl(smsRepository) ;
    }

    @Bean
    VialinkService callVialink(IVialinkRepository vialinkRepository){
        return new VialinkServiceImpl(vialinkRepository) ;
    }

    @Bean
    GedService getDocs(IGedRepository gedRepository){
        return new GedServiceImpl(gedRepository) ;
    }

    @Bean
    ParamsService getParams(IParamsRepository iParametrageRepository){
        return  new ParamsServiceImpl(iParametrageRepository);
    }
}