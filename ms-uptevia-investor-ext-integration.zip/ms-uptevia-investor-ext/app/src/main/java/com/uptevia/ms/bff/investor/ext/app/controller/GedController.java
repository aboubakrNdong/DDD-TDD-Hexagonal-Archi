package com.uptevia.ms.bff.investor.ext.app.controller;

import com.uptevia.ms.bff.investor.ext.api.GedApi;
import com.uptevia.ms.bff.investor.ext.api.model.FileJson;
import com.uptevia.ms.bff.investor.ext.api.model.UserDocsJson;
import com.uptevia.ms.bff.investor.ext.app.mapper.FileJsonMapper;
import com.uptevia.ms.bff.investor.ext.app.mapper.UserDocsJsonMapper;
import com.uptevia.ms.bff.investor.ext.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.ext.domain.model.FileDTO;
import com.uptevia.ms.bff.investor.ext.domain.model.UserDocsDTO;
import com.uptevia.ms.bff.investor.ext.domain.service.GedService;
import com.uptevia.ms.bff.investor.ext.domain.util.Constantes;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class GedController implements GedApi {
    private final GedService gedService;

    @Autowired
    private JwtUtils jwtUtils;

    public GedController(GedService gedService) {
        this.gedService = gedService;
    }


    @Override
    public ResponseEntity<FileJson> downloadDoc(final String uuid) {
        FileDTO file = null;
        try {
            //Récupérer les Paramètrses du token
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));
            file = gedService.downloadDoc(Integer.valueOf(claims.get("emetIden").toString()),
                    Integer.valueOf(claims.get("actiIden").toString()),
                    Integer.valueOf(claims.get("titunume").toString()), uuid);
            if (file == null) return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            throw new RuntimeException(e);

        }

        return new ResponseEntity<>(
                FileJsonMapper.INSTANCE.dtoToJson(
                        file
                ), HttpStatus.OK);

    }



    @Override
    public ResponseEntity<List<UserDocsJson>> getDocs() {
        List<UserDocsDTO> rep = null;

        try {
            //Récupérer les Paramètres du token
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));
            rep = gedService.getDocsGed(claims.get("emetIden").toString(),
                    Integer.valueOf(claims.get("actiIden").toString()),
                    Integer.valueOf(claims.get("titunume").toString()));

            if (rep == null) return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


        return new ResponseEntity<>(rep
                .stream()
                .map(UserDocsJsonMapper.INSTANCE::dtoToJson)
                .toList(), HttpStatus.OK);
    }

}
