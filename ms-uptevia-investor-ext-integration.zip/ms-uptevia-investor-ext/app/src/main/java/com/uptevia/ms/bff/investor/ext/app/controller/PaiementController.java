package com.uptevia.ms.bff.investor.ext.app.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.uptevia.ms.bff.investor.ext.api.PaiementApi;
import com.uptevia.ms.bff.investor.ext.api.model.*;
import com.uptevia.ms.bff.investor.ext.app.mapper.PaiementCbUrlDTOMapper;
import com.uptevia.ms.bff.investor.ext.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.ext.domain.model.PaiementCBUrlRequestDTO;
import com.uptevia.ms.bff.investor.ext.domain.service.PaiementService;
import com.uptevia.ms.bff.investor.ext.domain.util.Constantes;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/v1")
public class PaiementController implements PaiementApi {
    private final PaiementService paiementService;

    @Autowired
    private JwtUtils jwtUtils;

    public PaiementController(final PaiementService paiementService) {
        this.paiementService = paiementService;
    }

    @Override
    public ResponseEntity<PaiementCBUrlJson> generateUrlSsoTransaction(PaiementCBUrlRequestJson paiementCBUrlRequestJson) {

        PaiementCBUrlRequestDTO cbUrlRequestDto = PaiementCbUrlDTOMapper.INSTANCE.JsonToDto(paiementCBUrlRequestJson);
        String url;
        try {
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constantes.AUTHORIZATION));
            cbUrlRequestDto.setLogin(claims.getSubject());
            cbUrlRequestDto.setEmetIden(Integer.valueOf(claims.get("emetIden").toString()));
            cbUrlRequestDto.setActiIden(Integer.valueOf(claims.get("actiIden").toString()));
            url = paiementService.generateUrlSsoTransaction(cbUrlRequestDto);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new ResponseEntity<>(
                new PaiementCBUrlJson().urlPaiement(url)
                , HttpStatus.OK);
    }

    @Override
    public ResponseEntity<PaiementCBRetourJson> decryptParamRetour(final String d1) {
        JsonNode jsonDecrypt;
        try {
            jsonDecrypt = paiementService.decryptParamRetour(d1);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new ResponseEntity<>(
                new PaiementCBRetourJson().params(jsonDecrypt)
                , HttpStatus.OK);
    }

}