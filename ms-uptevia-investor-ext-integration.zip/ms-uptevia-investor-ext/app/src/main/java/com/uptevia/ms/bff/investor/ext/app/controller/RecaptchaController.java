package com.uptevia.ms.bff.investor.ext.app.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.uptevia.ms.bff.investor.ext.api.RecaptchaApi;
import com.uptevia.ms.bff.investor.ext.api.model.PaiementCBUrlJson;
import com.uptevia.ms.bff.investor.ext.api.model.RecaptchaResultJson;
import com.uptevia.ms.bff.investor.ext.api.model.RecaptchaVerifyJson;
import com.uptevia.ms.bff.investor.ext.app.mapper.RecaptchaVerifyDTOMapper;
import com.uptevia.ms.bff.investor.ext.domain.model.RecaptchaVerifyDTO;
import com.uptevia.ms.bff.investor.ext.domain.service.ParamsService;
import com.uptevia.ms.bff.investor.ext.domain.service.RecaptchaService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class RecaptchaController implements RecaptchaApi {
    private final RecaptchaService recaptchaService ;
   private final ParamsService paramsService ;

    public RecaptchaController(final RecaptchaService recaptchaService, ParamsService paramsService) {

        this.recaptchaService = recaptchaService ;
       this.paramsService = paramsService;
    }

    /**
     * @param recaptchaVerifyJson (required)
     * @return
     */
    @Override
    public ResponseEntity<RecaptchaResultJson> verifyRecaptcha(RecaptchaVerifyJson recaptchaVerifyJson) {
        RecaptchaVerifyDTO captchaVerifyDTO = RecaptchaVerifyDTOMapper.INSTANCE.jsonToDto(recaptchaVerifyJson);

        float minScoreCaptchaV3;
        float score;
        try {
            minScoreCaptchaV3 = Float.parseFloat(paramsService.getParamValueByName("MIN_SCORE_CAPTCHA_V3"));
            System.out.println("Le score min attendu est " + minScoreCaptchaV3);
            score = recaptchaService.verifyRecaptcha(captchaVerifyDTO);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>(
                new RecaptchaResultJson().success(score >= minScoreCaptchaV3)
                , HttpStatus.OK);
    }

}