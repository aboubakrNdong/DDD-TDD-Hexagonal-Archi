package com.uptevia.ms.bff.investor.ext.app.controller;

import com.uptevia.ms.bff.investor.ext.api.SmsApi;
import com.uptevia.ms.bff.investor.ext.api.model.ResultStatusJson;
import com.uptevia.ms.bff.investor.ext.api.model.SmsSendJson;
import com.uptevia.ms.bff.investor.ext.app.mapper.SmsSendDTOMapper;
import com.uptevia.ms.bff.investor.ext.domain.model.SmsSendDTO;
import com.uptevia.ms.bff.investor.ext.domain.service.SmsService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class SmsController implements SmsApi {
    private final SmsService smsService;

    public SmsController(SmsService smsService) {
        this.smsService = smsService;
    }

    /**
     * @param smsSendJson
     * @return
     */
    @Override
    public ResponseEntity<ResultStatusJson> sendOneSMS(SmsSendJson smsSendJson) {
        SmsSendDTO smsSend = SmsSendDTOMapper.INSTANCE.jsonToDto(smsSendJson);
        String rep;
        try {
            rep = smsService.sendOneSMStoOne(smsSend.getText(), smsSend.getMobileNumbers());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new ResponseEntity<>(new ResultStatusJson().status(rep)
                , HttpStatus.OK);
    }
}
