package com.uptevia.ms.bff.investor.ext.app.controller;

import com.uptevia.ms.bff.investor.ext.api.VialinkApi;
import com.uptevia.ms.bff.investor.ext.api.model.ResultStatusJson;
import com.uptevia.ms.bff.investor.ext.api.model.VialinkResponseJson;
import com.uptevia.ms.bff.investor.ext.api.model.VlkDocJson;
import com.uptevia.ms.bff.investor.ext.app.exception.CustomResponseStatusException;
import com.uptevia.ms.bff.investor.ext.app.mapper.VialinkResponseJsonMapper;
import com.uptevia.ms.bff.investor.ext.app.mapper.VlkDocJsonMapper;
import com.uptevia.ms.bff.investor.ext.domain.model.VialinkResponseDTO;
import com.uptevia.ms.bff.investor.ext.domain.model.vialink.VlkDoc;
import com.uptevia.ms.bff.investor.ext.domain.service.VialinkService;
import com.uptevia.ms.bff.investor.ext.domain.util.Constantes;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/api/v1")
@Slf4j
public class VialinkController implements VialinkApi {
    private final VialinkService vialinkService;

    private final Map<String, Object> contextParams = new HashMap<>();

    public VialinkController(VialinkService vialinkService) {
        this.vialinkService = vialinkService;
    }


    /**
     * @param verificationKey (required)
     * @param phone (required)
     * @param email (required)
     * @return
     */
    @Override
    public ResponseEntity<VialinkResponseJson> createControl(String verificationKey, String phone, String email, String useCase) {
        //Provisioirement en attendant la mise à jour du front
        if(useCase == null) useCase = "Onboarding";
        VialinkResponseDTO responseDTO;
        try {
            responseDTO = vialinkService.newControl(verificationKey, phone, email, useCase);
        } catch (Exception e) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), contextParams);
        }
        return new ResponseEntity<>(VialinkResponseJsonMapper.INSTANCE.dtoTojson(responseDTO)
                , HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<Void> delDocument(String secondToken, Integer documentId) {
        contextParams.put("documentId", documentId);
        try {
            vialinkService.delDocument(secondToken, documentId);

        } catch (Exception e) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), contextParams);
        }
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }


    /**
     * @param secondToken Identifiant du dossier (required)
     * @return
     */
    @Override
    public ResponseEntity<ResultStatusJson> submitControl(final String secondToken) {

        int resultStatus;
        String msg = "OK";
        try {
            resultStatus = vialinkService.submitControl(secondToken);
            if(resultStatus == 0){
                return new ResponseEntity<>(new ResultStatusJson().status(Constantes.MSG_VIALINK_CONTROL_NOT_SUBMITTED), HttpStatus.CONFLICT);
            }

            if(resultStatus == 1){
                msg = Constantes.MSG_VIALINK_FILES_NOT_SAVED;
            }

        } catch (Exception e) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, Constantes.MSG_VIALINK_GENERIC_ERROR, contextParams);
        }

        return new ResponseEntity<>(new ResultStatusJson().status(msg), HttpStatus.OK);
    }


    /**
     * @param token Identifiant du dossier (required)
     * @return
     */
    @Override
    public ResponseEntity<VialinkResponseJson> getControlStatus(String token, String lang) {
        VialinkResponseDTO responseDTO;
        try {
            responseDTO = vialinkService.getControlStatus(token, lang);
        } catch (Exception e) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), contextParams);
        }
        return new ResponseEntity<>(VialinkResponseJsonMapper.INSTANCE.dtoTojson(responseDTO)
                , HttpStatus.OK);
    }

    /**
     * @param secondToken (optional)
     * @param type      (optional)
     * @param file      (optional)
     * @param existingDoc     (optional)
     * @return
     */

    @Override
    public ResponseEntity<Object> addDocument(String type, MultipartFile file, String existingDoc, String secondToken) {
        String result;

        try {
            result = vialinkService.addDocument(type, file, existingDoc, secondToken);
        } catch (Exception e) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), contextParams);
        }
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }


    @Override
    public ResponseEntity<VlkDocJson> smartUploadDocument(final MultipartFile file, final String secondToken) {
        VlkDoc dto = null;
        try {
            dto = vialinkService.smartUploadDocument(file, secondToken);
        } catch (Exception e) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), contextParams);
        }
        return new ResponseEntity<>(VlkDocJsonMapper.INSTANCE.dtoToJson(dto), HttpStatus.CREATED);
    }

    /**
     * @param secondToken Identifiant du dossier (required)
     * @return
     */
    @Override
    public ResponseEntity<List<VlkDocJson>> getControlDocuments(final String secondToken) {
        List<VlkDoc> docs;
        try {
            docs = vialinkService.getControlDocuments(secondToken);
        } catch (Exception e) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), contextParams);
        }

        return new ResponseEntity<>(docs.stream()
                .map(VlkDocJsonMapper.INSTANCE::dtoToJson).toList(), HttpStatus.OK);

    }


    /**
     * @param controlId Identifiant du dossier (required)
     * @return
     */
    @Override
    public ResponseEntity<Object> getControlResult(final String controlId) {
        String result;
        try {
            result = vialinkService.getControlResult(controlId);
        } catch (Exception e) {
            throw new CustomResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage(), contextParams);
        }
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

}