package com.uptevia.ms.bff.investor.ext.app.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EnumStatus {

    STATUS_OK ("OK"),
    STATUS_NOT_FOUND ("Not Found");

    private final String status;

}