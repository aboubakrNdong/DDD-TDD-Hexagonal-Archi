package com.uptevia.ms.bff.investor.ext.app.mapper;

import com.uptevia.ms.bff.investor.ext.domain.model.AddressDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AddressDTOMapper {
    AddressDTOMapper INSTANCE = Mappers.getMapper(AddressDTOMapper.class);
    AddressDTO jsonToDto(String json);
}
