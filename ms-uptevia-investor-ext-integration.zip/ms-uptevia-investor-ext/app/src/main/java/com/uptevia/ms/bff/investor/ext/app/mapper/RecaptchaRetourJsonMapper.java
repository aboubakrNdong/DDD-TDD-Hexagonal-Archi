package com.uptevia.ms.bff.investor.ext.app.mapper;

import com.uptevia.ms.bff.investor.ext.api.model.RecaptchaRetourJson;
import com.uptevia.ms.bff.investor.ext.domain.model.RecaptchaRetourDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface RecaptchaRetourJsonMapper {
    RecaptchaRetourJsonMapper INSTANCE = Mappers.getMapper(RecaptchaRetourJsonMapper.class);
    RecaptchaRetourJson dtoToJson(RecaptchaRetourDTO dto);
}