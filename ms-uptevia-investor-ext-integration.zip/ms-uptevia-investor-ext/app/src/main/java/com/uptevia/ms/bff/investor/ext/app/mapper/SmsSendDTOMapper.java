package com.uptevia.ms.bff.investor.ext.app.mapper;

import com.uptevia.ms.bff.investor.ext.api.model.SmsSendJson;
import com.uptevia.ms.bff.investor.ext.domain.model.SmsSendDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SmsSendDTOMapper {
    SmsSendDTOMapper INSTANCE = Mappers.getMapper(SmsSendDTOMapper.class);
    SmsSendDTO jsonToDto(SmsSendJson json);
}
