package com.uptevia.ms.bff.investor.ext.app.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SubscriberVlkDTOMapper {
    //SubscriberVlkDTOMapper INSTANCE = Mappers.getMapper(SubscriberVlkDTOMapper.class);
    //SubscriberVlkDTO jsonToDto(SubscriberVlkJson json);
}
