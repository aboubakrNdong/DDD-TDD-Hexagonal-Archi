package com.uptevia.ms.bff.investor.ext.app.mapper;


import com.uptevia.ms.bff.investor.ext.api.model.UserDocsJson;
import com.uptevia.ms.bff.investor.ext.domain.model.UserDocsDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface UserDocsJsonMapper {


    UserDocsJsonMapper INSTANCE = Mappers.getMapper(UserDocsJsonMapper.class);

    UserDocsJson dtoToJson(UserDocsDTO dto);
}
