package com.uptevia.ms.bff.investor.ext.app.mapper;

import com.uptevia.ms.bff.investor.ext.api.model.VialinkResponseJson;
import com.uptevia.ms.bff.investor.ext.domain.model.AddressDTO;
import com.uptevia.ms.bff.investor.ext.domain.model.VialinkResponseDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import javax.annotation.ManagedBean;

@Mapper
public interface VialinkResponseJsonMapper {
    VialinkResponseJsonMapper INSTANCE = Mappers.getMapper(VialinkResponseJsonMapper.class);
    VialinkResponseJson dtoTojson(VialinkResponseDTO json);
}
