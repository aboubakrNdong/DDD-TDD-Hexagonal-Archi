package com.uptevia.ms.bff.investor.ext.app.mapper;


import com.uptevia.ms.bff.investor.ext.api.model.VlkDocJson;
import com.uptevia.ms.bff.investor.ext.domain.model.vialink.VlkDoc;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface VlkDocJsonMapper {


    VlkDocJsonMapper INSTANCE = Mappers.getMapper(VlkDocJsonMapper.class);

    VlkDocJson dtoToJson(VlkDoc dto);
}
