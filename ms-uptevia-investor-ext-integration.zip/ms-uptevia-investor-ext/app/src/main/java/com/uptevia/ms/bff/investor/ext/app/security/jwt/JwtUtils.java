package com.uptevia.ms.bff.investor.ext.app.security.jwt;



import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.*;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import java.security.Key;
@Component
@Slf4j
public class JwtUtils {

    @Value("${ext.app.jwtSecret}")
    private String secretKey;
    private static final String AUTHORIZATION = "Authorization";

    private static final SignatureAlgorithm algorithm = SignatureAlgorithm.HS256;



    //generate secure key from java.security to sign jwt token
    private Key key() {
        return new SecretKeySpec(secretKey.getBytes(), algorithm.getJcaName());
    }

    //Extract subject as username  from JWT  token
    public String getUserNameFromJwtToken(final String token) {
        return Jwts.parser().setSigningKey(key()).build()
                .parseClaimsJws(token).getBody().getSubject();
    }

    public boolean validateJwtToken(final String authToken) {
        try {
            Jwts.parser().setSigningKey(key()).build().parse(authToken);
            return true;
        } catch (MalformedJwtException e) {
            log.error("Invalid JWT token: {}", e.getMessage());
        } catch (ExpiredJwtException e) {
            log.error("JWT token is expired: {}", e.getMessage());
        } catch (UnsupportedJwtException e) {
            log.error("JWT token is unsupported: {}", e.getMessage());
        } catch (IllegalArgumentException e) {
            log.error("JWT claims string is empty: {}", e.getMessage());
        }

        return false;
    }


    public String resolveToken(final HttpServletRequest req) {

        String bearerToken = req.getHeader(AUTHORIZATION);
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7, bearerToken.length());
        }
        if (bearerToken != null) {
            return bearerToken;
        }
        return null;
    }

    public Claims getAllClaimsFromToken(final String token) {
        String parsed = token;
        if (token != null && token.startsWith("Bearer ")) {
            parsed = token.substring(7, token.length());
        }
        return Jwts.parser().verifyWith((SecretKey) key()).build().parseSignedClaims(parsed).getPayload();
    }
}
