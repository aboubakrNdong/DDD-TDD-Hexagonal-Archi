package com.uptevia.ms.bff.investor.ext.app.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.model.PaiementCBUrlRequestDTO;
import com.uptevia.ms.bff.investor.ext.domain.model.PaiementResponseDTO;
import com.uptevia.ms.bff.investor.ext.domain.service.PaiementService;

import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = PaiementController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
class PaiementControllerTest {
/*
    private static final String URL_REQUEST_URL_CB_LINKS = "/api/v1/paiement/url-cb";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PaiementService paiementService;


    private final EasyRandom easyRandom = new EasyRandom();

    private final PaiementCBUrlRequestDTO urlRequestDTO = PaiementCBUrlRequestDTO.builder()
            .login("92605493")
            .emetIden(484)
            .actiIden(193)
            .langue("FRA")
            .module("ACHAT")
            .theme("UPTEVIA")
            .coursLimite(BigDecimal.valueOf(100.2))
            .dateValidite(LocalDate.parse("2023-12-01"))
            .typeValidite("JOUR")
            .modalite(3)
            .quantite(1)
            .isDirect(true)
            .isMontantReel(true)
            .moisValiditeMax(1)
            .build();

    @Test
    void should_return_url_paiement_ok() throws Exception {

        PaiementResponseDTO paiementResponseDTO = easyRandom.nextObject(PaiementResponseDTO.class);

        Mockito.when(paiementService.generateUrlSsoTransaction(urlRequestDTO)).thenReturn(paiementResponseDTO.getUrlPaiement());

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_REQUEST_URL_CB_LINKS)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(urlRequestDTO))
                .characterEncoding("UTF-8"))
                .andExpect(status().isOk());

    }

    @Test
    void should_return_url_paiement_and_return_500() throws Exception {

        Mockito.when(paiementService.generateUrlSsoTransaction(any(PaiementCBUrlRequestDTO.class))).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.post(URL_REQUEST_URL_CB_LINKS)
                        .content(asJsonString(urlRequestDTO))
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void should_return_url_paiement_and_return_400() throws Exception {

        Mockito.when(paiementService.generateUrlSsoTransaction(any(PaiementCBUrlRequestDTO.class))).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/paiement/url-cb-fake")
                        .content(asJsonString(urlRequestDTO))
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().is4xxClientError());
    }

    public static String asJsonString(final Object obj) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }*/
}
