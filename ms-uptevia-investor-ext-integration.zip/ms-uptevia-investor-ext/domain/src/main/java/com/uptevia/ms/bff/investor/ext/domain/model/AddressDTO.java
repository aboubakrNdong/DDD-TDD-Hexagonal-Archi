package com.uptevia.ms.bff.investor.ext.domain.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AddressDTO {

    String address;
    String city;
    String province;
    String country;
    String countryIso;
    String zipCode;

    public AddressDTO() {
    }
}
