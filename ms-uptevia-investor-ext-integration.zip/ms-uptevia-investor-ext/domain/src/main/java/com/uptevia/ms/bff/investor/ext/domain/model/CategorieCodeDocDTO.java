package com.uptevia.ms.bff.investor.ext.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter
public class CategorieCodeDocDTO {
    private String documentCode;
    private String categorieDoc;
    private String codeCouleur;
    private int indiDemat;
}
