package com.uptevia.ms.bff.investor.ext.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CompletenessDTO {
    String type;
    int number;
    String side;
    boolean available;
    String status;

    public CompletenessDTO() {
    }
}
