package com.uptevia.ms.bff.investor.ext.domain.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class ControlStatusDTO {
    String id;
    String spaceId;
    String spaceName;
    String status;
    String controlProfileId;
    String controlProfileName;
    String subscriberId;
    SubscriberVlkDTO subscriber;
    String createdAt;
    String lastModified;
    String removedAt;
    List<CompletenessDTO> completeness;
    int score;
    Object result;

    public ControlStatusDTO() {
    }
}
