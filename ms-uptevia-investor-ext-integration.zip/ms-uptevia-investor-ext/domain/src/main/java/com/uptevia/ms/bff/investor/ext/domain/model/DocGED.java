package com.uptevia.ms.bff.investor.ext.domain.model;

import com.caceis.ged.dto.DocumentGed;
import lombok.*;

import java.time.LocalDate;
import java.util.Date;

@Getter
@Setter
@Builder
@AllArgsConstructor
public class DocGED extends DocumentGed {

    private LocalDate dateArrete;

    private String uuid;
    private String technicalName;
    private String functionalName;
    private String appUnicReference;
    private String documentCode;
    private String operationCode;
    private String businessDate;
    private Date generationDate;
    private Date busDate;
    private String keyTitle;
    private String extension;
    private String status;
    private Integer indiDemat;
    private Date lifeCycleStartDate;
    private Date lifeCycleActiveEndDate;
    private Integer lifeCycleActiveDuration;
    private String lifeCycleActiveDurationUnit;
    private Date lifeCycleArchiveEndDate;
    private Integer lifeCycleArchiveDuration;
    private String lifeCycleArchiveDurationUnit;
    private String languageCode;
    private String locale;
}
