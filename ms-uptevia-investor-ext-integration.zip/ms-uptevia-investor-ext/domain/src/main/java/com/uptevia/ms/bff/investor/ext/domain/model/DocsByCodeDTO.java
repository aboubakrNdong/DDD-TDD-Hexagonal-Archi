package com.uptevia.ms.bff.investor.ext.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;


@Getter
@Builder
@Setter
public class DocsByCodeDTO {
    private String documentCode;
    private List<DocGED> listDocs = null;
}
