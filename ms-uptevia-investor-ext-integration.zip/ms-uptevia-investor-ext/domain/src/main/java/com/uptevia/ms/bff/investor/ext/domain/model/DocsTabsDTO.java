package com.uptevia.ms.bff.investor.ext.domain.model;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Builder
@Setter
public class DocsTabsDTO {
    private UserDocsDTO general;

    private UserDocsDTO releves;

    private UserDocsDTO rapports;

    private UserDocsDTO avis;
}
