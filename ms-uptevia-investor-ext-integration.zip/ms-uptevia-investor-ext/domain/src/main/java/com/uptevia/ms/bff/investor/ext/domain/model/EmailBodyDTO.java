package com.uptevia.ms.bff.investor.ext.domain.model;


import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EmailBodyDTO {

    private String textBody;

    private String securityLib;

    private String rgpdLib;

    private String accessibilityLib;

    private String cguLib;

    private String conformLib;
}
