package com.uptevia.ms.bff.investor.ext.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Builder
@Getter
@Setter
public class PaiementCBUrlRequestDTO {
    private String login;
    private Integer emetIden;
    private Integer actiIden;
    private String module;
    private String theme;
    private String langue;
    private BigDecimal montant;
    private Integer moisValiditeMax;
    private Boolean isDirect;
    private Boolean isMontantReel;
    private Integer modalite;
    private String typeValidite;
    private LocalDate dateValidite;
    private Integer quantite;
    private BigDecimal coursLimite;

}
