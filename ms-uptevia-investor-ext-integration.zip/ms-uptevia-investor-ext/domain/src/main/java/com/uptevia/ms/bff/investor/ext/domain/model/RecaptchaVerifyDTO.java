package com.uptevia.ms.bff.investor.ext.domain.model;


import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class RecaptchaVerifyDTO {
    private String captchaToken;
    private String version;
}
