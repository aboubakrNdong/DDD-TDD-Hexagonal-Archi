package com.uptevia.ms.bff.investor.ext.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class SubscriberVlkDTO {

    private String type;
    private String id;
    private String spaceId;
    private AddressDTO address;
    private String complementaryData;
    private String contact;
    private String usageName;
    private String nationality;
    private String nationalityIso;
    private String gender;
    private String placeOfBirth;
    private String departmentOfBirth;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String email;
    private String birthday;
    private String actiTypeCpte;
    private Integer emetIden;
    private Integer actiIden;

    public SubscriberVlkDTO() {
    }
}
