package com.uptevia.ms.bff.investor.ext.domain.model;

/**
 * Cree le 11 déc. 07<br>
 * Propriete de CACEIS Corporate Trust
 */

/**
 * <b>Description : Enum representant les fond de commerce de CACEIS</b><br>
 * CACEIS   :1<br>
 * HSBC     :2<br>
 * CASA     :3<br>
 * @author Christian NGUYEN VAN THAN<br>
 */
public enum TypeFondCommerce {
    CACEIS(1),
    HSBC(2),
    CASA(3),
    CREELIA(5);

    private int fondCommerce;

    TypeFondCommerce(int pTypeFondCommerce) {
        this.fondCommerce = pTypeFondCommerce;
    }

    /**
     * @return la valeur de l'enumeration TypeFondCommerce
     */
    public int getValue() {
        return fondCommerce;
    }

    /**
     * Retourne le type demande a partir d'un code type demande
     * @param type int
     * @return TypeDemande correspondant ou null si inexistante
     */
    public static TypeFondCommerce valueOf(int type) {
        for (TypeFondCommerce t : TypeFondCommerce.values()) {
            if (t.getValue() == type) {
                return t;
            }
        }
        return null;
    }




}
