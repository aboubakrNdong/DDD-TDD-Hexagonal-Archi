package com.uptevia.ms.bff.investor.ext.domain.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Builder
@Setter
public class UserDocsDTO {
    private String categorieDoc;
    private String codeCouleur;
    private List<DocsByCodeDTO> listDocsByCode = null;
}
