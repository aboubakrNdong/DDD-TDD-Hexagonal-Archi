package com.uptevia.ms.bff.investor.ext.domain.model.vialink;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)

public class Sheet {
    private int id;
    private String side;
    private String fileName;
    private String hash;
    private String mimeType;
    private int size;
    private List<String> subTypes;
    private String identifier;

    public Sheet() {
    }

}