package com.uptevia.ms.bff.investor.ext.domain.model.vialink;

public enum Status {

    UPLOADING,

    UPLOADED,

    QUEUING,

    PROCESSING,

    ERROR,

    INVALID_DOC_ERROR,

    MODIFIED,

    CHECKED

}