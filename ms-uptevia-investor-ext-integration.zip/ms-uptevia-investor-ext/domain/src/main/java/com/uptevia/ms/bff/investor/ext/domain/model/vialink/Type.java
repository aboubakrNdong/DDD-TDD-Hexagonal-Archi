package com.uptevia.ms.bff.investor.ext.domain.model.vialink;

public enum Type {

    MRZ,

    STATE_ID,

    PASSPORT,

    RESIDENCE_PERMIT,

    PAYSLIP,

    BANK_ID,

    TAX_ASSESSMENT,

    ADDRESS_PROOF,

    VEHICLE_REGISTRATION,

    KBIS,

    CUSTOM,

    DRIVING_LICENCE,

    TAX_BUNDLE,

    BANK_STATEMENT,

    COMPANY_IDENTIFICATION,

    TRADES_REGISTER,

    EMPLOYEE_CONTRACT,

    OTHER

}