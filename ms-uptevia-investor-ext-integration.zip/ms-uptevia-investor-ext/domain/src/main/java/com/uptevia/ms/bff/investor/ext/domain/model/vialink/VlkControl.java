package com.uptevia.ms.bff.investor.ext.domain.model.vialink;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class VlkControl {

    private String controlId;
    private String subscriber;
    private String useCase;

    private List<VlkDoc> documents;

    public VlkControl(){}
    public VlkControl(String controlId){}


}
