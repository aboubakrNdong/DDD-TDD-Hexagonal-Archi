package com.uptevia.ms.bff.investor.ext.domain.model.vialink;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class VlkDoc {
        long id;
        Type type;
        String subType;
        int number;
        Status status;
        List<Sheet> sheets;
        int score;
        String origin;
        String createdAt;
    public VlkDoc(){}

}