package com.uptevia.ms.bff.investor.ext.domain.repository;


import com.uptevia.ms.bff.investor.ext.domain.model.CategorieCodeDocDTO;

import java.util.List;

public interface IGedRepository {

    List<CategorieCodeDocDTO> getCategCodeOperation(int emetIden, int actiIden, int pTituNume);
}
