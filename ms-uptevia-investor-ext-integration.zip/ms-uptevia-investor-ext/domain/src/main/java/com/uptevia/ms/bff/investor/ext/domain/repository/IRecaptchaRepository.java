package com.uptevia.ms.bff.investor.ext.domain.repository;

import com.uptevia.ms.bff.investor.ext.domain.model.RecaptchaVerifyDTO;

public interface IRecaptchaRepository {
    String sendgRecaptchatoServer(RecaptchaVerifyDTO captchaVerifyDTO);
}
