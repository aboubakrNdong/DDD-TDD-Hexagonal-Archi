package com.uptevia.ms.bff.investor.ext.domain.repository;

import com.uptevia.ms.bff.investor.ext.domain.model.ControlStatusDTO;
import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.model.vialink.Sheet;
import com.uptevia.ms.bff.investor.ext.domain.model.vialink.VlkControl;
import org.springframework.http.HttpStatus;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;

public interface IVialinkRepository {

    String newControl(String login, String useCase) throws FunctionnalException, IOException;

    String uploadDocument(String controlId, File file, String documentId, String type) throws IOException, FunctionnalException;

    String smartUploadDocument(String controlId, File file) throws IOException, FunctionnalException;

    String addSheetToDocument(String controlId, Long documentId, String side, File file) throws IOException, InterruptedException, FunctionnalException;

    HttpStatus submitControl(String controlId) throws IOException, FunctionnalException;

    String getControlStatus(String controlId) throws IOException, FunctionnalException;

    String getControlDocuments(String controlId) throws IOException, FunctionnalException;

    String getControlReport(String controlId) throws IOException, FunctionnalException;

    String getControlResult(String controlId) throws IOException, FunctionnalException;


    void sendMaiToGrc(final ControlStatusDTO controlStatusDTO, final String login, final String lang) throws FunctionnalException;

    String validateToken(final String login, final String token, final String useCase);

    BigDecimal insertTokenEmailTelVialink(String secondToken, String login, String email, String phone, String tokenTypeVialink);

    String updateContacts(final String token, final String login, final int score);

    String delDocument(final String controlId, final Integer documentId) throws FunctionnalException, IOException;

    Long saveVialinkDemande(VlkControl control) throws FunctionnalException;


    Long saveVialinkDocuments(long idDemande, String controlId, String documentId, Sheet sheet) throws FunctionnalException, IOException;
}
