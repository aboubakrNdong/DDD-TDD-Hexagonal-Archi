package com.uptevia.ms.bff.investor.ext.domain.service;


import com.uptevia.ms.bff.investor.ext.domain.model.FileDTO;
import com.uptevia.ms.bff.investor.ext.domain.model.UserDocsDTO;

import java.util.List;

public interface GedService {

    List<UserDocsDTO> getDocsGed(final String idEmet, final int idActi, final int tituNume) throws Exception;

    FileDTO downloadDoc(final Integer emetIden, final Integer actiIden, final Integer tituNume, final String uuid) throws Exception;
}
