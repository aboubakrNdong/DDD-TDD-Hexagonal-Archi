package com.uptevia.ms.bff.investor.ext.domain.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.model.PaiementCBUrlRequestDTO;

import java.io.IOException;

public interface PaiementService {
    String generateUrlSsoTransaction(PaiementCBUrlRequestDTO cbUrlRequest) throws FunctionnalException;

    JsonNode decryptParamRetour(String d1) throws IOException;
}