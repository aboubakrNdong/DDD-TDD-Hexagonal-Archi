package com.uptevia.ms.bff.investor.ext.domain.service;

import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;

public interface ParamsService {
    String getParamValueByName(String minScoreCaptchaV3) throws FunctionnalException;
}
