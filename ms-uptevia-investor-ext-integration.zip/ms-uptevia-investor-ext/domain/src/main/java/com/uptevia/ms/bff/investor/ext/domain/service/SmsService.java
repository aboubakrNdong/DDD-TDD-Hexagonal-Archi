package com.uptevia.ms.bff.investor.ext.domain.service;

import java.util.List;

public interface SmsService {
    String  sendOneSMStoOne(String textSMS, List<String> nums);
}
