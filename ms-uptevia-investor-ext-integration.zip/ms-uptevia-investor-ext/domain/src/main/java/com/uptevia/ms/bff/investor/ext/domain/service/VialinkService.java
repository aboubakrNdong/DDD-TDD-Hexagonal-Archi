package com.uptevia.ms.bff.investor.ext.domain.service;

import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.exception.TokenVialinkException;
import com.uptevia.ms.bff.investor.ext.domain.model.VialinkResponseDTO;
import com.uptevia.ms.bff.investor.ext.domain.model.vialink.VlkDoc;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface VialinkService {
    VialinkResponseDTO newControl(final String token, String phone, String email, String useCase) throws FunctionnalException, IOException, TokenVialinkException;

    String addDocument(String type, MultipartFile file, String documentId, String secondToken) throws FunctionnalException, IOException, TokenVialinkException;

    VlkDoc smartUploadDocument(MultipartFile file, String secondToken) throws FunctionnalException, IOException, InterruptedException, TokenVialinkException;
    int submitControl(String token) throws FunctionnalException, IOException, TokenVialinkException;

    VialinkResponseDTO getControlStatus(final String token, final String lang) throws FunctionnalException, IOException, TokenVialinkException;

    List<VlkDoc> getControlDocuments(final String token) throws FunctionnalException, IOException, TokenVialinkException;

    String getControlReport(String controlId) throws FunctionnalException, IOException;

    String getControlResult(String controlId) throws FunctionnalException, IOException;

    String validateToken(final String login, final String token, final String tokenType) throws FunctionnalException;

    String delDocument(final String controlId, final Integer documentId) throws FunctionnalException, IOException, TokenVialinkException;

    String addSheetToDocument(String secondToken, Long documentId, String side, MultipartFile file) throws IOException, InterruptedException, FunctionnalException, TokenVialinkException;
}
