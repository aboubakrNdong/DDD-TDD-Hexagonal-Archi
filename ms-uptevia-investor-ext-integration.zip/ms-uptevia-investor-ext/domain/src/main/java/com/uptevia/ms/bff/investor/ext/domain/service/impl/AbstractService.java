package com.uptevia.ms.bff.investor.ext.domain.service.impl;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uptevia.ms.bff.investor.ext.domain.repository.IParamsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
public class AbstractService {


    private static final Logger logger = LoggerFactory.getLogger(AbstractService.class);

    public AbstractService() {

    }

    public static String formatDateFR(LocalDate date_yyyy_mm_dd) {
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.US);
        String formattedDate = date_yyyy_mm_dd.format(outputFormatter);
        return formattedDate;
    }

    public static JsonNode stringToJson(String jsonString)
            throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        JsonFactory factory = mapper.getJsonFactory();
        JsonParser parser = factory.createJsonParser(jsonString);
        return mapper.readTree(parser);
    }


}
