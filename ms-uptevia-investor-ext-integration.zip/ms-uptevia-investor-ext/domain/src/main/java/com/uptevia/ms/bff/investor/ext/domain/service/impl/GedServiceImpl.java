package com.uptevia.ms.bff.investor.ext.domain.service.impl;

import com.caceis.ged.dto.ConfigGed;
import com.caceis.ged.dto.DocumentGed;
import com.caceis.ged.tools.GedTools;
import com.caceis.stc.util.PropertyUtils;
import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.model.*;
import com.uptevia.ms.bff.investor.ext.domain.repository.IGedRepository;
import com.uptevia.ms.bff.investor.ext.domain.service.GedService;
import org.apache.commons.lang3.StringUtils;


import javax.activation.DataHandler;
import java.io.IOException;
import java.io.InputStream;
import java.time.ZoneId;
import java.util.*;

import java.util.function.Function;
import java.util.logging.Logger;
import java.util.stream.Collectors;


public class GedServiceImpl implements GedService {
    static Logger LOG = Logger.getLogger(GedServiceImpl.class.getName());

    private InputStream resultStream;
    private GedTools gedHsbc;
    private GedTools gedCorpo;


    private static final String PROPERTIES_FILENAME = "ged.properties";
    private static Properties propertiesFile;
    private static String USER_ALFRESCO_CT; // Login
    private static String USER_ALFRESCO_HSBC;
    private static String PASSWORD_ALFRESCO_CT; // Mot de passe
    private static String PASSWORD_ALFRESCO_HSBC;
    private static String GED_INSTANCE; // Instance
    private static String GED_IDENTIFIER; // Identifier
    private static String GED_PROTOCOL; // Protocol
    private static String GED_PATH_CT; // Chemin du répertoire contenant les dossiers
    private static String GED_PATH_HSBC;

    static {

        propertiesFile = PropertyUtils.getPropertiesFileNoFail(PROPERTIES_FILENAME);

        if (propertiesFile != null) {
            try {
                GED_INSTANCE = propertiesFile.getProperty("ged.instance");
                GED_IDENTIFIER = propertiesFile.getProperty("ged.identifier");
                GED_PROTOCOL = propertiesFile.getProperty("ged.protocol");
                USER_ALFRESCO_HSBC = propertiesFile.getProperty("ged.user.hsbc");
                PASSWORD_ALFRESCO_HSBC = propertiesFile.getProperty("ged.password.hsbc");
                GED_PATH_HSBC = propertiesFile.getProperty("ged.path.hsbc");
                USER_ALFRESCO_CT = propertiesFile.getProperty("ged.user.ct");
                PASSWORD_ALFRESCO_CT = propertiesFile.getProperty("ged.password.ct");
                GED_PATH_CT = propertiesFile.getProperty("ged.path.ct");
            } catch (Exception e) {
                LOG.warning("ERREUR - Impossible d'obtenir une des properties pour acceder a la GED ");
            }
        } else {
            LOG.info("Props is null ... Initializing... KO");
        }
    }

    private final IGedRepository gedRepository;

    public GedServiceImpl(IGedRepository gedRepository) {
        this.gedRepository = gedRepository;
    }

    /**
     * Récupère les infos de connexion d'un titulaire en fonction du fond de commerce
     */
    private GedTools getInfoConnection(TypeFondCommerce fondCommerce) {

        // fond de commerce HSBC
        if (fondCommerce == TypeFondCommerce.HSBC) {
            return getGedHsbc();

            // fond de commerce CACEIS ou CAsa
        } else if (fondCommerce == TypeFondCommerce.CACEIS || fondCommerce == TypeFondCommerce.CASA) {
            return getGedCorpo();

        } else {
            LOG.info("fond de commerce inconnu, on instancie à null");
            return null;
        }
    }


    private DocGED findDocByUuid(List<DocGED> userDocs, String uuidToFind) {
        return userDocs.stream()
                .filter(doc -> Objects.equals(doc.getUuid(), uuidToFind))
                .findFirst()
                .orElse(null);
    }

    public InputStream loadDocumentCaceisUser(TypeFondCommerce fondCommerce, String docName, String uuid) {
        InputStream result = null;
        GedTools gedInstance = getInfoConnection(fondCommerce);

        if (gedInstance != null && gedInstance.gedInitOk) {
            DataHandler dh = gedInstance.getDocument(docName, uuid);
            if (dh != null) {
                try {
                    result = dh.getInputStream();
                } catch (IOException e) {
                    LOG.info("Error");
                }
            }
        } else {
            LOG.warning("gedInstance is null");
        }

        return result;
    }

    public List<DocGED> findDocumentCaceisUser(TypeFondCommerce fondCommerce, String emetIden, String actiIden, String tituNume, String codeDocument) {
        GedTools gedInstance = getInfoConnection(fondCommerce);
        List<DocumentGed> userDocsFromGed = new ArrayList<>();
        List<DocGED> userDocs = new ArrayList<>();
        if (gedInstance != null && gedInstance.gedInitOk) {
            userDocsFromGed = gedInstance.getDocumentsByActiIden(emetIden, actiIden, tituNume, codeDocument);
        }


        if (userDocsFromGed != null && !userDocsFromGed.isEmpty()) {
            try {
                userDocsFromGed.forEach(documentGed -> {
                    userDocs.add(DocGED.builder()
                            .uuid(documentGed.getUuid())
                            .documentCode(documentGed.getDocumentCode())
                            .extension(documentGed.getExtension())
                            .businessDate(documentGed.getBusinessDate())
                            .functionalName(documentGed.getFunctionalName())
                            .generationDate(documentGed.getGenerationDate())
                            .operationCode(documentGed.getOperationCode())
                            .technicalName(documentGed.getTechnicalName())
                            .languageCode(documentGed.getLanguageCode())
                            .busDate(documentGed.getBusDate())
                            .keyTitle(documentGed.getKeyTitle())
                            .status(documentGed.getStatus())
                            .indiDemat(documentGed.getIndiDemat())
                            .lifeCycleActiveEndDate(documentGed.getLifeCycleActiveEndDate())
                            .lifeCycleArchiveEndDate(documentGed.getLifeCycleArchiveEndDate())
                            .dateArrete(documentGed.getBusDate().toInstant()
                                    .atZone(ZoneId.systemDefault())
                                    .toLocalDate())
                            .build());
                });
            } catch (Exception e) {
                LOG.info("*Problme de conversion to DocGED");
            }

        }


        return userDocs;
    }

    /**
     * Recupere la liste des codes operations de documents qu'il est possible d'afficher pour un emetteur donne
     */


    public GedTools getGedHsbc() {
        if (gedHsbc == null) {
            initGedHsbc();
        }

        return gedHsbc;
    }

    public GedTools getGedCorpo() {
        if (gedCorpo == null) {
            initGedCorpo();
        }

        return gedCorpo;
    }

    public void initGedHsbc() {
        gedHsbc = GedTools.getInstance();
        gedHsbc.init(new ConfigGed(GED_IDENTIFIER, GED_PROTOCOL, GED_INSTANCE, USER_ALFRESCO_HSBC, PASSWORD_ALFRESCO_HSBC, true, GED_PATH_HSBC));
    }

    public void initGedCorpo() {
        gedCorpo = GedTools.getInstance();
        gedCorpo.init(new ConfigGed(GED_IDENTIFIER, GED_PROTOCOL, GED_INSTANCE, USER_ALFRESCO_CT, PASSWORD_ALFRESCO_CT, true, GED_PATH_CT));

    }

    /**
     * Recupere la liste des codes operations de documents qu'il est possible d'afficher pour un emetteur donne
     */
    public List<CategorieCodeDocDTO> getCategCodeOperation(int emetIden, int actiIden, int pTituNume) {
        List<CategorieCodeDocDTO> result = new ArrayList<>();
        try {
            result = gedRepository.getCategCodeOperation(emetIden, actiIden, pTituNume);
        } catch (Exception e) {
            LOG.info("*Impossible de recuperer les codes operation et ccateg");
        }

        return result;
    }


    /**
     * Methode Principace de récupération des documents
     */
    @Override
    public List<UserDocsDTO> getDocsGed(String idEmet, int idActi, int tituNume) throws Exception {
        Map<String, Object> contextParams = new HashMap<>();
        contextParams.put("idEmet", idEmet);
        contextParams.put("idActi", idActi);
        contextParams.put("tituNume", tituNume);


        List<CategorieCodeDocDTO> listCategorieCode = getCategCodeOperation(Integer.parseInt(idEmet), idActi, tituNume);

        System.out.println("Nombre dans CategorieCodeDocDTO Brute = " + listCategorieCode.size());

        List<CategorieCodeDocDTO> categorieCodeDocDTOs = listCategorieCode.stream()
                .collect(Collectors.toMap(CategorieCodeDocDTO::getDocumentCode, Function.identity(), (existing, replacement) -> existing))
                .values()
                .stream()
                .collect(Collectors.toList());

        System.out.println("Nombre dans CategorieCodeDocDTO Filtree = " + categorieCodeDocDTOs.size());

        if (categorieCodeDocDTOs.isEmpty())
            return null;

        LOG.info("Trying to retrieve documents from GED Alfresco for {}-{}-{}" + idEmet + "-" + idActi + "-" + tituNume);

        List<DocGED> documentGeds;

        try {
            // On recupere les docs de l'actionnaire
            documentGeds = findDocumentCaceisUser(
                    TypeFondCommerce.valueOf(1), //pour l'instant met 1  (Greg)
                    StringUtils.leftPad(idEmet, 8, "0"),
                    StringUtils.leftPad(String.valueOf(idActi), 7, "0"),
                    StringUtils.leftPad(String.valueOf(tituNume), 2, "0"),
                    null
            );

            System.out.println("Nombre dans documentGeds = " + documentGeds.size());

            if (documentGeds.isEmpty())
                return null;


            // Étape 1: Regrouper les DocGED par documentCode
            Map<String, List<DocGED>> docsByCodeMap = documentGeds.stream()
                    .collect(Collectors.groupingBy(DocGED::getDocumentCode));

            // Étape 2: Créer des objets DocsByCodeDTO
            List<DocsByCodeDTO> docsByCodeDTOs = docsByCodeMap.entrySet().stream()
                    .map(entry -> {
                        DocsByCodeDTO docsByCodeDTO = DocsByCodeDTO.builder()
                                .listDocs(entry.getValue())
                                .documentCode(entry.getKey())
                                .build();
                        return docsByCodeDTO;
                    })
                    .collect(Collectors.toList());

            // Étape 3: Créer une Map pour accélérer la recherche de categorieDoc et codeCouleur
            Map<String, CategorieCodeDocDTO> categorieCodeDocMap = categorieCodeDocDTOs.stream()
                    .collect(Collectors.toMap(CategorieCodeDocDTO::getDocumentCode, dto -> dto));

            // Étape 4: Regrouper les DocsByCodeDTO par categorieDoc
            Map<String, List<DocsByCodeDTO>> docsByCategorieDocMap = docsByCodeDTOs.stream()
                    .filter(dto -> dto.getDocumentCode() != null)
                    .collect(Collectors.groupingBy(dto -> getCategorieDoc(dto.getDocumentCode(), categorieCodeDocMap),
                            Collectors.toList()));


            // Étape 5: Créer des objets UserDocsDTO
            return docsByCategorieDocMap.entrySet().stream()
                    .map(entry -> {
                        UserDocsDTO userDocsDTO = UserDocsDTO.builder()
                                .listDocsByCode(entry.getValue())
                                .categorieDoc(entry.getKey())
                                .codeCouleur(getCodeCouleur(entry.getKey(), categorieCodeDocMap)).
                                build();
                        return userDocsDTO;
                    })
                    .collect(Collectors.toList());

        } catch (Exception e) {
            LOG.info("*Error while retrieving documents from GED Alfresco ...");

            throw new FunctionnalException("GetDocuments", "Error_retrieving_documents_from_GED_Alfresco", contextParams);
        }

    }

    @Override
    public FileDTO downloadDoc(Integer idEmet, Integer idActi, Integer tituNume, String uuidDocument) throws Exception {
        FileDTO file = null;
        String docName = null;
        DocGED docFound;
        try {

            // On recupere les docs de l'actionnaire
            List<DocGED> documentGeds = findDocumentCaceisUser(
                    TypeFondCommerce.valueOf(1),
                    StringUtils.leftPad(String.valueOf(idEmet), 8, "0"),
                    StringUtils.leftPad(String.valueOf(idActi), 7, "0"),
                    StringUtils.leftPad(String.valueOf(tituNume), 2, "0"),
                    null
            );

            docFound = findDocByUuid(documentGeds, uuidDocument);
            if (docFound != null) {
                docName = docFound.getFunctionalName();
            }

            resultStream = loadDocumentCaceisUser(TypeFondCommerce.valueOf(1), docName, uuidDocument);

            if (resultStream == null) {
                LOG.warning("*Error document.error.filenotfound ..." + uuidDocument);
                return null;
            }
        } catch (Exception e) {
            LOG.warning("*Error while downloading a document from GED Alfresco ..." + e);
            return null;
        }

        return file.builder()
                .documentId(1)
                .documentFileName(docName.replace(" ", "_"))
                .documentContentType(docFound.getExtension())
                .documentContent(resultStream.readAllBytes())
                .build();
    }


    private String getCategorieDoc(String documentCode, Map<String, CategorieCodeDocDTO> categorieCodeDocMap) {
        return categorieCodeDocMap.getOrDefault(documentCode, CategorieCodeDocDTO.builder().build())
                .getCategorieDoc();
    }

    private String getCodeCouleur(String categorieDoc, Map<String, CategorieCodeDocDTO> categorieCodeDocMap) {
        return categorieCodeDocMap.values().stream()
                .filter(dto -> dto.getCategorieDoc().equals(categorieDoc))
                .findFirst()
                .map(CategorieCodeDocDTO::getCodeCouleur)
                .orElse(null);
    }


}
