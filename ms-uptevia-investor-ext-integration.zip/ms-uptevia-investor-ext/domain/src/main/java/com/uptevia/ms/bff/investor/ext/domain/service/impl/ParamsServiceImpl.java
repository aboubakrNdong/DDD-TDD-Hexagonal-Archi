package com.uptevia.ms.bff.investor.ext.domain.service.impl;

import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.model.ParamsDTO;
import com.uptevia.ms.bff.investor.ext.domain.repository.IParamsRepository;
import com.uptevia.ms.bff.investor.ext.domain.service.ParamsService;
import java.util.List;


public class ParamsServiceImpl implements ParamsService {
    private final IParamsRepository paramsRepository ;


    public ParamsServiceImpl(IParamsRepository paramsRepository) {
        this.paramsRepository = paramsRepository;

    }

    @Override
    public String getParamValueByName(String paramName) throws FunctionnalException {
        List<ParamsDTO> paramsList = paramsRepository.getAllParams();

        ParamsDTO paramDTO = paramsList.stream()
                .filter(param -> param.getParamName().equals(paramName))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Param not found with name: " + paramName));

        return paramDTO.getParamValue();

    }
}
