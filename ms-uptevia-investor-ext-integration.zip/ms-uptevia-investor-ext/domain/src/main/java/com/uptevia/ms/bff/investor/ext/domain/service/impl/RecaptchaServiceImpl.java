package com.uptevia.ms.bff.investor.ext.domain.service.impl;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uptevia.ms.bff.investor.ext.domain.model.RecaptchaVerifyDTO;
import com.uptevia.ms.bff.investor.ext.domain.repository.IParamsRepository;
import com.uptevia.ms.bff.investor.ext.domain.repository.IRecaptchaRepository;
import com.uptevia.ms.bff.investor.ext.domain.service.RecaptchaService;
import org.springframework.stereotype.Service;


import java.io.IOException;

public class RecaptchaServiceImpl implements RecaptchaService  {
    private final IRecaptchaRepository repository ;

    public RecaptchaServiceImpl(IRecaptchaRepository captchaRepository) {

        this.repository = captchaRepository;
    }

    @Override
    public float verifyRecaptcha(RecaptchaVerifyDTO captchaVerifyDTO) throws IOException {
        return ckeckRetourCaptcha(repository.sendgRecaptchatoServer(captchaVerifyDTO));
    }

    private float ckeckRetourCaptcha(String jsonString)
            throws IOException {
        JsonNode jObj;
        ObjectMapper mapper = new ObjectMapper();
        JsonFactory factory = mapper.getJsonFactory();
        JsonParser parser = factory.createJsonParser(jsonString);
        jObj = mapper.readTree(parser);

        System.out.println("retour brut de Google" + jsonString);
        boolean success = jObj.get("success").asBoolean();

        if(success){
            float score = jObj.get("score").floatValue();
            return score;
        } else { return -1;
        }
    }
}
