package com.uptevia.ms.bff.investor.ext.domain.service.impl;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.exception.TokenVialinkException;
import com.uptevia.ms.bff.investor.ext.domain.model.ControlStatusDTO;
import com.uptevia.ms.bff.investor.ext.domain.model.VialinkResponseDTO;
import com.uptevia.ms.bff.investor.ext.domain.model.vialink.ControlDocument;
import com.uptevia.ms.bff.investor.ext.domain.model.vialink.Sheet;
import com.uptevia.ms.bff.investor.ext.domain.model.vialink.VlkControl;
import com.uptevia.ms.bff.investor.ext.domain.model.vialink.VlkDoc;
import com.uptevia.ms.bff.investor.ext.domain.repository.IVialinkRepository;
import com.uptevia.ms.bff.investor.ext.domain.service.VialinkService;
import com.uptevia.ms.bff.investor.ext.domain.util.Constantes;
import com.uptevia.ms.bff.investor.ext.domain.util.ToolsManager;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;


import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;


@Slf4j
public class VialinkServiceImpl implements VialinkService {
    private final IVialinkRepository vialinkRepository;
    private ObjectMapper objectMapper = null;

    public VialinkServiceImpl(IVialinkRepository repo) {
        this.vialinkRepository = repo;
    }

    /**
     * @param token
     * @param useCase
     * @return
     * @throws FunctionnalException
     */
    @Override
    public VialinkResponseDTO newControl(String token, String phone, String email, String useCase) throws FunctionnalException, IOException, TokenVialinkException {

        ControlStatusDTO controlStatusDTO = null;
        token = token.replaceAll("^\"|\"$", "");
        String login = ToolsManager.extractLoginFromVerificationKey(token);

        if (StringUtils.isBlank(login)) {
            throw new FunctionnalException(HttpStatus.BAD_REQUEST.toString(), "You have to provide a valid login");
        }

        final String validate = vialinkRepository.validateToken(login, token, Constantes.TOKEN_TYPE_VIALINK);

        String secondToken;
        if (validate != null && validate.equals("OK")) {
            String retourVialinkControl = vialinkRepository.newControl(login, useCase);

            objectMapper = new ObjectMapper();
            controlStatusDTO = objectMapper.readValue(retourVialinkControl, ControlStatusDTO.class);
            String controlId = controlStatusDTO.getId();

            secondToken = createSecondToken(login, controlId, phone, email);

            if (!tokenInsertedinDB(phone, email, secondToken, login)) {
                log.warn("Details= Exception occurred while inserting token in database, please try later");
                throw new TokenVialinkException(HttpStatus.FORBIDDEN, Constantes.MSG_INVALID_VIALINK_TOKEN);
            }
        } else {
            log.warn("Details="+validate);
            throw new TokenVialinkException(HttpStatus.FORBIDDEN, Constantes.MSG_INVALID_VIALINK_TOKEN);
        }
        return VialinkResponseDTO.builder()
                .id(controlStatusDTO.getId())
                .status(controlStatusDTO.getStatus())
                .score(controlStatusDTO.getScore())
                .secondToken(secondToken)
                .build();
    }

    private boolean tokenInsertedinDB(String phone, String email, String secondToken, String login) {
        return Objects.equals(vialinkRepository.insertTokenEmailTelVialink(secondToken, login, email, phone, Constantes.TOKEN_TYPE_VIALINK), BigDecimal.valueOf(0));
    }


    @Override
    public String addDocument(String type, MultipartFile file, String documentId, String secondToken) throws FunctionnalException, IOException, TokenVialinkException {
        String result = "";
        secondToken = secondToken.replaceAll("^\"|\"$", "");
        String controlId = ToolsManager.getControlIdFromToken(secondToken);
        if (ToolsManager.isInvalid(secondToken)) {
            throw new TokenVialinkException(HttpStatus.FORBIDDEN, Constantes.MSG_INVALID_VIALINK_TOKEN);
        }

        result = vialinkRepository.uploadDocument(controlId, convertMultipartFileToFile(file), documentId, type);
        return result;
    }

    @Override
    public VlkDoc smartUploadDocument(MultipartFile file, String secondToken) throws FunctionnalException, IOException, InterruptedException, TokenVialinkException {
        String result = "";
        secondToken = secondToken.replaceAll("^\"|\"$", "");
        if (ToolsManager.isInvalid(secondToken)) {
            throw new TokenVialinkException(HttpStatus.FORBIDDEN, Constantes.MSG_INVALID_VIALINK_TOKEN);
        }
        String controlId = ToolsManager.getControlIdFromToken(secondToken);
        result = vialinkRepository.smartUploadDocument(controlId, convertMultipartFileToFile(file));
        objectMapper = new ObjectMapper();
        return objectMapper.readValue(result, VlkDoc.class);
    }

    /**
     * @param secondToken
     * @return
     * @throws FunctionnalException
     */
    @Override
    public int submitControl(String secondToken) throws FunctionnalException, IOException, TokenVialinkException {

        secondToken = secondToken.replaceAll("^\"|\"$", "");

        String controlId = ToolsManager.getControlIdFromToken(secondToken);

        if (ToolsManager.isInvalid(secondToken)) {
            throw new TokenVialinkException(HttpStatus.FORBIDDEN, Constantes.MSG_INVALID_VIALINK_TOKEN);
        }

        int responseCase = 0;
        HttpStatus statusVlk = vialinkRepository.submitControl(controlId);

        Long idDemande = (long) -1;
        if (statusVlk == HttpStatus.ACCEPTED) {

            responseCase = 1; //OK vialink
            // Insérer une demande dans UPI avec les documents vialink
            VlkControl ctrl = new VlkControl();
            ctrl.setUseCase("onborading");
            ctrl.setControlId(controlId);
            ctrl.setSubscriber("requester");
            idDemande = vialinkRepository.saveVialinkDemande(ctrl);

            System.out.println("idDemande en DB: " + idDemande);
        }

        if (idDemande != (long) -1) {
            // Insérer les PJ
            List<VlkDoc> docs = getDocsByControlId(controlId);
            for (VlkDoc doc : docs) {
                List<Sheet> sheets = doc.getSheets();
                if (!sheets.isEmpty()) {
                    for (Sheet sheet : sheets) {
                        Long repInsertPJ = vialinkRepository.saveVialinkDocuments(idDemande, controlId, String.valueOf(doc.getId()), sheet);
                        System.out.println("rep Insertion PJ en DB: " + repInsertPJ);
                    }
                }
            }

            responseCase = 2; //OK vialink et insertion de tous les fichiers en BD
        }

        return responseCase;
    }

    /**
     * @param token
     * @return
     * @throws FunctionnalException
     */
    @Override
    public VialinkResponseDTO getControlStatus(String token, String lang) throws FunctionnalException, IOException, TokenVialinkException {
        ControlStatusDTO controlStatusDTO = null;
        token = token.replaceAll("^\"|\"$", "");
        String login = ToolsManager.extractLoginFromVerificationKey(token);
        String controlId = ToolsManager.getControlIdFromToken(token);
        if (ToolsManager.isInvalid(token)) {
            throw new TokenVialinkException(HttpStatus.FORBIDDEN, Constantes.MSG_INVALID_VIALINK_TOKEN);

        }  String control = vialinkRepository.getControlStatus(controlId);
        objectMapper = new ObjectMapper();
        controlStatusDTO = objectMapper.readValue(control, ControlStatusDTO.class);

        if (controlStatusDTO.getStatus().equals("DONE")) {
            String updateContacts = vialinkRepository.updateContacts(token, login, controlStatusDTO.getScore());
            log.info("contacts updated ...", updateContacts);
            log.info("status is done, begin sending mail ...");
            //TODO : Gérer cette exception
            vialinkRepository.sendMaiToGrc(controlStatusDTO, login, lang);
        }
        return VialinkResponseDTO.builder().id(controlStatusDTO.getId())
                .status(controlStatusDTO.getStatus())
                .score(controlStatusDTO.getScore())
                .build();
    }
    @Override
    public List<VlkDoc> getControlDocuments(String token) throws FunctionnalException, IOException, TokenVialinkException {

        token = token.replaceAll("^\"|\"$", "");

        if (ToolsManager.isInvalid(token)) {
            throw new TokenVialinkException(HttpStatus.FORBIDDEN, Constantes.MSG_INVALID_VIALINK_TOKEN);
        }

        String controlId = ToolsManager.getControlIdFromToken(token);

        return getDocsByControlId(controlId);
    }

    private List<VlkDoc> getDocsByControlId(String controlId) throws IOException, FunctionnalException {
        List<VlkDoc> listLight = new ArrayList<>();

        String apiResponse = vialinkRepository.getControlDocuments(controlId);

        ObjectMapper objectMapperControlDocument = new ObjectMapper();
        ControlDocument[] controlDocuments = objectMapperControlDocument.readValue(apiResponse,
                ControlDocument[].class);

        for (ControlDocument controlDocument : controlDocuments) {
            List<VlkDoc> documents = controlDocument.getDocuments();
            if(!documents.isEmpty()) listLight.addAll(documents);
        }

        return listLight;
    }

    @Override
    public String getControlReport(final String controlId) throws FunctionnalException, IOException {
        return vialinkRepository.getControlReport(controlId);
    }

    @Override
    public String getControlResult(final String controlId) throws FunctionnalException, IOException {
        return vialinkRepository.getControlResult(controlId);
    }


    private File convertMultipartFileToFile(final MultipartFile multipartFile) throws IOException {

        if (multipartFile == null) {
            return null;
        }

        File file = new File(multipartFile.getOriginalFilename());
        try {
            Path filePath = file.toPath();
            Files.copy(multipartFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new IOException("Erreur lors de la conversion de MultipartFile en File", e);
        }

        return file;
    }

    @Override
    public String validateToken(final String login, final String token, final String useCase) throws FunctionnalException {
        return vialinkRepository.validateToken(login, token, useCase);
    }

    @Override
    public String delDocument(String secondToken, Integer documentId) throws FunctionnalException, IOException, TokenVialinkException {
        secondToken = secondToken.replaceAll("^\"|\"$", "");

        if (ToolsManager.isInvalid(secondToken)) {
            throw new TokenVialinkException(HttpStatus.FORBIDDEN, Constantes.MSG_INVALID_VIALINK_TOKEN);
        }

        String controlId = ToolsManager.getControlIdFromToken(secondToken);
        String repVialik;

        repVialik = vialinkRepository.delDocument(controlId, documentId);
        return repVialik;
    }

    @Override
    public String addSheetToDocument(String secondToken, Long documentId, String side, MultipartFile file) throws IOException, InterruptedException, FunctionnalException, TokenVialinkException {
        String result = "";
        secondToken = secondToken.replaceAll("^\"|\"$", "");

        if (ToolsManager.isInvalid(secondToken)) {
            throw new TokenVialinkException(HttpStatus.FORBIDDEN, Constantes.MSG_INVALID_VIALINK_TOKEN);
        }

        String controlId = ToolsManager.getControlIdFromToken(secondToken);
        result =  vialinkRepository.addSheetToDocument(controlId, documentId, side, convertMultipartFileToFile(file));

        return result;
    }


    private String createSecondToken(final String login, final String controlId, final String phone, final String email) {
        long currentTimeInUTC = new Date().getTime();

        ObjectMapper objectMap = new ObjectMapper();
        ObjectNode json = objectMap.createObjectNode();

        json.put(Constantes.JSON_PARAM_TIME, currentTimeInUTC);
        json.put(Constantes.JSON_PARAM_PHONE, phone);
        json.put(Constantes.JSON_PARAM_EMAIL, email);
        json.put(Constantes.JSON_PARAM_LOGIN, login);
        json.put(Constantes.JSON_PARAM_CONTROL_ID, controlId);
        return ToolsManager.asHex(ToolsManager.encryptJSONStringToBytes(ToolsManager.SECRET_KEY, ToolsManager.IV_PARAMETER_SPEC, json.toString()));
    }


}
