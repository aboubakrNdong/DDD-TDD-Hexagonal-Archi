package com.uptevia.ms.bff.investor.ext.domain.util;

/**
 * <b>Description : Classe utilitaire contenant des constantes utilisees frequemment</b>
 *
 * @author Boris SODOLOUFO
 */
public class Constantes {



    private Constantes() {

    }

    // Parametres propres à UPI et à l'ACHAT
    public static final String APPLICATION = "UPI";
    public static final String METHODE_ACHAT = "TRANSACTION";
    public static final String METHODE_SUPPRESSION_CB = "DESABONNEMENT";

    // OLIS
    public static final String GET_ABONNE = "CB_GET_ABONNE";
    public static final String GET_URL_CB_OLIS = "CB_GET_URL_BY_ACTION";

    public static final String IV_PARAMETER_SPEC_CHIFF = "DA467qsPem9s5DG2";    //vector
    public static final String SECRET_KEY_CHIFF = "c2DMSnJGf965a2h7";    //key

    public static final String GET_CONFIRM_TRANSACTION = "CB_UPD_TRANSACTION_ID_DMD";
    public static final String GET_CONFIRM_TRANSACTION_BY_REF = "CB_UPD_TRANSACTION_ID_BY_REF";
    public static final String CB_IS_TRANSACTION_CONFIRME = "CB_IS_TRANSACTION_CONFIRME";
    public static final String CB_VALIDER_MONTANT_TRANSACTION = "CB_VALIDER_MONTANT_TRANSACTION";
    public static final String CB_VERIFIER_TRANSACTION = "CB_VERIFIER_TRANSACTION";
    public static final String IV_PARAMETER_SPEC_DECHIFF = "qr9J5Gyg7tJ777XE";    //vector
    public static final String SECRET_KEY_DECHIFF = "4dB7eQYtp9rG32G4";    //key

    // Parametres necessaires au paiement
    public static final String OCB_APPLICATION = "o_a";
    public static final String OCB_MODULE = "o_m";
    public static final String OCB_THEME = "o_t";
    public static final String OCB_REFERENCE_TRANSACTION = "o_rt";
    public static final String OCB_REFERENCE_CLIENT = "o_rc";
    public static final String OCB_MONTANT = "o_mo";
    public static final String OCB_DATE = "o_d";
    public static final String OCB_MOIS_VALDITE_MIN = "o_mvm";
    public static final String OCB_IS_DIRECT = "o_id";
    public static final String OCB_IS_MONTANT_REEL = "o_mr";
    public static final String OCB_LOGIN = "o_l";
    public static final String OCB_MARGE = "o_ma";
    public static final String OCB_EMAIL_PORTEUR = "o_ep";

    public static final String OCB_ADDRESS_1 = "o_ad1";
    public static final String OCB_ADDRESS_2 = "o_ad2";
    public static final String OCB_CITY = "o_ci";
    public static final String OCB_ZIP_CODE = "o_zc";
    public static final String OCB_COUNTRY_CODE = "o_cc";
    public static final String OCB_FIRST_NAME = "o_fn";
    public static final String OCB_LAST_NAME = "o_ln";
    public static final String OCB_TOTAL_QUANTITY = "o_tq";

    public static final String GOOGLE_RECAPTCHA_VERIF = "https://www.google.com/recaptcha/api/siteverify";

    public static final String SMS_RETARUS_BASEURL = "https://sms4a.retarus.com/";
    public static final String SMS_RETARUS_USER = "josselin.foy@uptevia.com";
    public static final String SMS_RETARUS_PASSWORD = "alga-aZUqTMZRw6CgT2w7";

    public static final String PROXY_SERVER_HOST = "proxybc.hld.net";
    public static final int  PROXY_SERVER_PORT = 8080;
    public static final int  TOKEN_VLK_EXPIRATION_DELAY = 530000;

    public static final String VIALINK_PARAMS =  "VIALINK_PARAMS";

    public static final String AUTHORIZATION = "Authorization";

    public static final String JSON_PARAM_LOGIN = "lg";
    public static final String JSON_PARAM_ACTION = "action";
    public static final String JSON_PARAM_TIME = "time";

    public static final String JSON_PARAM_PHONE = "phone";
    public static final String JSON_PARAM_EMAIL = "email";

    public static final String JSON_PARAM_CONTROL_ID = "controlId";
    public static final String TOKEN_TYPE_VIALINK = "VIALINK";

    public static final String MSG_INVALID_VIALINK_TOKEN = "vialink.error.invalid.token";
    public static final String MSG_VIALINK_GENERIC_ERROR = "vialink.error.generic" ;
    public static final String MSG_VIALINK_FILES_NOT_SAVED = "vialink.error.file.notSaved" ;
    public static final String MSG_VIALINK_CONTROL_NOT_SUBMITTED = "vialink.error.control.notSubmited" ;

}

