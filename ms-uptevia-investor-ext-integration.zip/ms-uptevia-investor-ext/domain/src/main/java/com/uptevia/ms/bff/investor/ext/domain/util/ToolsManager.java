package com.uptevia.ms.bff.investor.ext.domain.util;
/*
 * Cette classe a pour objectif de fournir des outils de cryptage et hashage des mot
 * de passes, des questions secrètes ou tout autre outil utilisé pour
 * sécuriser les comptes d'un utilisateur
 *
 */


import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.exception.TokenVialinkException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.*;
import java.time.temporal.ChronoUnit;

@Slf4j
public class ToolsManager {



    /* Declaration of variables */
    private static final String RSA = "RSA/ECB/OAEPWITHSHA-256ANDMGF1PADDING";

    public static final String IV_PARAMETER_SPEC 	= "P8PoFEsef548Uhet"; 	//vector
    public static final String SECRET_KEY 			= "srjcaplg8e354dg0";

    private static final String ALGORITHM = "AES";
    private static final String MODE_PADDING = "AES/ECB/PKCS5Padding";

    private static final Logger LOG = LoggerFactory.getLogger("ToolsManager");

    /*
     * private constructor for  utility classes
     */
    private ToolsManager(){

    }

    public static String decrypt(final String strEncrypted, final String strKey) {

        String decryption = "";

        try {
            SecretKeySpec sKeySpec=new SecretKeySpec(strKey.getBytes(), RSA);
            Cipher cipher = Cipher.getInstance(RSA);
            cipher.init(Cipher.DECRYPT_MODE, sKeySpec);
            byte[] decrypted = cipher.doFinal(strEncrypted.getBytes());
            decryption = new String(decrypted);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return decryption;
    }


    // Méthode copiée de EncryptUtils de com.caceis.olis2.util
    public static String asHex(byte buf[]) {
        StringBuffer strbuf = new StringBuffer(buf.length * 2);
        for (int index = 0; index < buf.length; index++) {
            if (((int) buf[index] & 0xff) < 0x10) {
                strbuf.append("0");
            }
            strbuf.append(Long.toString((int) buf[index] & 0xff, 16));
        }
        return strbuf.toString();
    }


    // Méthode copiée de EncryptUtils de com.caceis.olis2.util
    public static byte[] decryptAes(byte[] cipherText) {
        SecretKey key = new SecretKeySpec(SECRET_KEY.getBytes(), "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(IV_PARAMETER_SPEC.getBytes());
        Cipher cipher;
        byte[] clearText = null;
        try {
            cipher = Cipher.getInstance("AES/CBC/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key, ivSpec);
            clearText = cipher.doFinal(cipherText);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
            LOG.error("*Erreur lors du décrytage AES", e);
        }

        return clearText;
    }

    // Méthode copiée de EncryptUtils de com.caceis.olis2.util
    public static byte[] hexToByteArray(String s) {

        byte data[] = new byte[s.length()/2];
        for (int i = 0; i < data.length; i++) {
            data[i] = Integer.decode("#"+s.charAt(i*2)+s.charAt(i*2+1)).byteValue();
        }
        return data;
    }

    // Méthode copiée de EncryptUtils de com.caceis.olis2.util
    public static byte[] encryptJSONStringToBytes(String pSecretKey, String vector, String pJsonString) {
        byte[] result = null;
        if (StringUtils.isNoneBlank(pSecretKey, pJsonString )) {
            try {
                byte[] keyData = pSecretKey.getBytes();
                SecretKey key = new SecretKeySpec(keyData, "AES");
                IvParameterSpec ivSpec = new IvParameterSpec(vector.getBytes());
                Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
                cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);
                // The String is padded with the good size.
                String chaineToEncryp = new String(pJsonString);
                int blocksize = cipher.getBlockSize();
                int remainder = chaineToEncryp.length() % blocksize;
                if (remainder > 0) {
                    chaineToEncryp = org.apache.commons.lang3.StringUtils.rightPad(chaineToEncryp, chaineToEncryp.length() - remainder + blocksize);
                }
                result = cipher.doFinal(chaineToEncryp.getBytes());
            } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalStateException |
                     IllegalBlockSizeException | BadPaddingException | InvalidAlgorithmParameterException e) {
                LOG.error("*Erreur", e);
            }

        }
        return result;
    }

    public static String extractLoginFromVerificationKey(final String chaine) throws IOException{
        JsonNode jObj;
        String login = "";
        try {
            if (StringUtils.isBlank(chaine)) {
                throw new IllegalArgumentException("EMPTY_TOKEN");
            }
            byte[] bSd = ToolsManager.hexToByteArray(chaine);
            bSd = ToolsManager.decryptAes(bSd);
            String decrypt = new String(bSd);

            ObjectMapper mapper = new ObjectMapper();
            JsonFactory factory = mapper.getJsonFactory();
            JsonParser parser = factory.createJsonParser(decrypt);
            jObj = mapper.readTree(parser);
            login = jObj.get(Constantes.JSON_PARAM_LOGIN).asText();
        } catch (Exception exception) {
            log.error("Exception occurred while extracting login from token", exception.getMessage());
        }

        return login;
    }

    public static boolean isInvalid(final String token) throws FunctionnalException {
        JsonNode jObj = null;
        long creationTimeInUTC = 0;
        try {
            if (StringUtils.isBlank(token)) {
                throw new FunctionnalException(HttpStatus.NO_CONTENT.toString(), "Your token is empty, please provide valid one");
            }
            byte[] bSd = ToolsManager.hexToByteArray(token);
            bSd = ToolsManager.decryptAes(bSd);
            String decrypt = new String(bSd);
            ObjectMapper mapper = new ObjectMapper();
            JsonFactory factory = mapper.getJsonFactory();
            JsonParser parser = factory.createJsonParser(decrypt);
            jObj = mapper.readTree(parser);
            creationTimeInUTC = jObj.get(Constantes.JSON_PARAM_TIME).asLong();
        } catch (Exception exception) {
            throw new FunctionnalException(HttpStatus.BAD_REQUEST.toString(), "Exception occurred while extracting date from token. Details: " + exception.getMessage());
        }
        return isOutDelay(creationTimeInUTC, 15);
    }




    public static String getControlIdFromToken(final String chaine) {
        JsonNode jObj;
        String controlId = "";

        String decrypt = null;
        try {
            if (StringUtils.isBlank(chaine)) {
                throw new FunctionnalException(HttpStatus.NO_CONTENT.toString(), "Your token is empty, please provide valid one");
            }
            byte[] bSd = ToolsManager.hexToByteArray(chaine);
            bSd = ToolsManager.decryptAes(bSd);
            decrypt = new String(bSd);

            jObj = strToJson(decrypt);
            controlId = jObj.get(Constantes.JSON_PARAM_CONTROL_ID).asText();
            System.out.println("controlId: " + controlId);
        } catch (Exception exception) {
            log.error("Exception occurred while extracting ControlId from secondToken. Details of decrypt: " + decrypt, exception.getMessage());
        }

        return controlId;
    }

    private static JsonNode strToJson(String str) throws IOException {

        ObjectMapper mapper = new ObjectMapper();
        JsonFactory factory = mapper.getJsonFactory();
        JsonParser parser = factory.createJsonParser(str);
        return mapper.readTree(parser);
    }

    public static boolean isOutDelay(long timeInUTC, int delay) {
        Instant instant = Instant.ofEpochMilli(timeInUTC);
        ZonedDateTime time = ZonedDateTime.ofInstant(instant, ZoneId.of("UTC"));

        ZonedDateTime currentTime = ZonedDateTime.now(ZoneId.of("UTC"));

        long minutesDifference = ChronoUnit.MINUTES.between(time, currentTime);
        return minutesDifference > delay;
    }
}
