package com.uptevia.ms.bff.investor.ext.infra.configuration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

@Configuration
@EnableTransactionManagement
public class DbConfiguration {

    @Value("${base.business.url}")
    private String baseBusinessUrl;

    @Value("${spring.datasource.jndi-name}")
    private String datasourceJndiName; //Uptevia

    @Value("${spring.datasource.oraoaec01.jndi-name}")
    private String datasourceOraoaec01JndiName; //Oraoaec01

    @Bean(name = "jdbcTemplate2")
    public JdbcTemplate jdbcTemplate2(@Qualifier("dataSource2") DataSource dataSource2) {
        return new JdbcTemplate(dataSource2);
    }

    @Bean(name = "jdbcTemplate")
    public JdbcTemplate jdbcTemplate1(@Qualifier("dataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }



    @Primary
    @Bean(name = "dataSource")
    @Qualifier("dataSource")
    public DataSource dataSource() throws NamingException {
        Context ctx = new InitialContext();
        return (DataSource) ctx.lookup(datasourceJndiName);
    }


    @Bean(name = "dataSource2")
    @Qualifier("dataSource2")
    public DataSource dataSource2() throws NamingException {
        Context ctx = new InitialContext();
        return (DataSource) ctx.lookup(datasourceOraoaec01JndiName);
    }

}
