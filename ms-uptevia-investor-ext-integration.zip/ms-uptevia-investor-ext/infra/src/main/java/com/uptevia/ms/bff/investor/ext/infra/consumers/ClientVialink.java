package com.uptevia.ms.bff.investor.ext.infra.consumers;

import com.caceis.stc.util.PropertyUtils;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uptevia.ms.bff.investor.ext.domain.util.Constantes;
import com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels.Control;
import com.uptevia.ms.bff.investor.ext.infra.exception.CustomResponseStatusException;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.*;

@Configuration
@EnableCaching
public class ClientVialink {



    private static ClientVialink instance;
    private static final String PROPERTIES_FILENAME = "application.properties";
    private static Properties propertiesFile;

    private String accessToken;
    private RestTemplate restTemplate;
  
    private long expiresIn;
    static java.util.logging.Logger LOG = java.util.logging.Logger.getLogger(ClientVialink.class.getName());

    private static String PROXY_SERVER_HOST;

    private String VIALINK_CLIENT_SECRET;

    private String VIALINK_CLIENT_ID;

    private String VIALINK_BASE_URL;

    static {
        propertiesFile = PropertyUtils.getPropertiesFileNoFail(PROPERTIES_FILENAME);
        if (propertiesFile != null) {
            try {
                PROXY_SERVER_HOST = propertiesFile.getProperty("proxy.server.host");
                System.out.println("PROXY_SERVER_HOST: " + PROXY_SERVER_HOST);
            } catch (Exception e) {
                LOG.warning("ERREUR - Impossible d'obtenir une des properties pour acceder a Vialink");
            }
        } else {
            LOG.info("Props is null ... Initializing... KO");
        }
    }


    public ClientVialink() {
        try {
            Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(PROXY_SERVER_HOST, Constantes.PROXY_SERVER_PORT));
            SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
            requestFactory.setProxy(proxy);

            this.restTemplate = new RestTemplate();
            requestFactory.setBufferRequestBody(false);
            this.restTemplate.setRequestFactory(requestFactory);
            this.restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());

        } catch (Exception e) {
            throw new RuntimeException("Fail to initialize  ClientVialink", e);
        }

    }

    // Obtenir l'instance unique de ClientVialink
    public static ClientVialink getInstance() {
        if (instance == null) {
            instance = new ClientVialink();
        }
        return instance;
    }

    public void setVlkParams(String params) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        JsonFactory factory = mapper.getJsonFactory();
        JsonParser parser = factory.createJsonParser(params);
        JsonNode jsonParams = mapper.readTree(parser);

        VIALINK_CLIENT_SECRET = jsonParams.get("clientSecret").asText();
        VIALINK_CLIENT_ID = jsonParams.get("clientId").asText();
        VIALINK_BASE_URL = jsonParams.get("baseUrl").asText();
    }


    @Cacheable("accessTokenCache")
    public String getAccessToken() {

        if (accessToken == null || hasExpired()) {
            generateNewToken();
        }

        return accessToken;
    }

    private boolean hasExpired() {
        return System.currentTimeMillis() > expiresIn ;
    }


    private void generateNewToken() {
        String urlConnect = VIALINK_BASE_URL + "connect/api/auth/oauth/token";

        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("grant_type", "client_credentials");
        params.add("scope", "kyc-requester");
        HttpHeaders headers = new HttpHeaders();
        String basicAuth = Base64.getEncoder().encodeToString((VIALINK_CLIENT_ID + ":" + VIALINK_CLIENT_SECRET).getBytes());
        headers.set(Constantes.AUTHORIZATION, "Basic " + basicAuth);

        HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(params, headers);
        
        ResponseEntity<ConnectResult> responseEntity = restTemplate.exchange(
                urlConnect,
                HttpMethod.POST,
                requestEntity,
                ConnectResult.class
        );


        if (responseEntity.getStatusCode() == HttpStatus.OK) {
            this.expiresIn = System.currentTimeMillis() + Constantes.TOKEN_VLK_EXPIRATION_DELAY;
            this.accessToken = Objects.requireNonNull(responseEntity.getBody()).getAccess_token();
        } else {
            throw new RuntimeException("Failed to obtain access token");
        }
    }


    public String createControle(Control reqControl) {
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(Constantes.AUTHORIZATION, "Bearer " + getAccessToken());

        HttpEntity<Control> requestEntity = new HttpEntity<>(reqControl, headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(
                VIALINK_BASE_URL + "kyc/api/requester/v1/controls",
                HttpMethod.POST,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();

    }

    public String uploadDocument(String controlId, File file, String documentId, String type) {

        String apiUrl = VIALINK_BASE_URL + "kyc/api/requester/v1/controls/" + controlId + "/documents/" + documentId + "/sheets.multipart?side=" + type;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.set(Constantes.AUTHORIZATION, "Bearer " + getAccessToken());

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", new FileSystemResource(file));


        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.POST,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();
    }

    public String smartUploadDocument(String controlId, File file) {

        String apiUrl = VIALINK_BASE_URL + "kyc/api/requester/v1/controls/" + controlId + "/documents.multipart";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.set(Constantes.AUTHORIZATION, "Bearer " + getAccessToken());

        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", new FileSystemResource(file));


        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);
        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.POST,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();
    }

    public String addSheetToDocument(String controlId, Long documentId, String side, File file) throws IOException, InterruptedException {
        String apiUrl = VIALINK_BASE_URL + "kyc/api/requester/v1/controls/" + controlId + "/documents/" + documentId + "/sheets.multipart";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        headers.set(Constantes.AUTHORIZATION, "Bearer " + getAccessToken());
        MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
        body.add("file", new FileSystemResource(file));

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);
        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.POST,
                requestEntity,
                String.class
        );
        return responseEntity.getStatusCode() == HttpStatus.CREATED ? "OK" : responseEntity.getBody();
    }

    public HttpStatus submitControl(String controlId) {

        String apiUrl = VIALINK_BASE_URL + "kyc/api/requester/v1/controls/" + controlId + "/submit";
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(Constantes.AUTHORIZATION, "Bearer " + getAccessToken());

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.POST,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode();
    }

    public String getControlStatus(String controlId) {

        String apiUrl = VIALINK_BASE_URL + "kyc/api/requester/v1/controls/" + controlId;
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(Constantes.AUTHORIZATION, "Bearer " + getAccessToken());

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.GET,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();
    }

    public String getControlResult(String controlId) {

        String apiUrl = VIALINK_BASE_URL + "kyc/api/requester/v1/controls/" + controlId + "/result?addNonApplicable=true";
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(Constantes.AUTHORIZATION, "Bearer " + getAccessToken());

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.GET,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();
    }

    public String getControlDocuments(String controlId) {

        String apiUrl = VIALINK_BASE_URL + "kyc/api/requester/v1/controls/" + controlId + "/documents";
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(Constantes.AUTHORIZATION, "Bearer " + getAccessToken());

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.GET,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();
    }

    public String getControlReport(String controlId) {

        String apiUrl = VIALINK_BASE_URL + "kyc/api/requester/v1/controls/" + controlId + "/report";
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(Constantes.AUTHORIZATION, "Bearer " + getAccessToken());

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.GET,
                requestEntity,
                String.class
        );

        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();
    }

    public String delDocument(String controlId, Integer documentId) throws CustomResponseStatusException {
        String apiUrl = VIALINK_BASE_URL + "kyc/api/requester/v1/controls/" + controlId + "/documents/" + documentId;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(Constantes.AUTHORIZATION, "Bearer " + getAccessToken());
        ResponseEntity<String> responseEntity = null;
        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);
        responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.DELETE,
                requestEntity,
                String.class);

        return responseEntity.getStatusCode() == HttpStatus.NO_CONTENT ? "OK" : responseEntity.getBody();
    }

    public byte[] getDocumentFile(String controlId, String documentId, String sheetId)
            throws CustomResponseStatusException {
        String apiUrl = VIALINK_BASE_URL + "kyc/api/requester/v1/controls/" + controlId + "/documents/" + documentId
                + "/sheets.file/" + sheetId;

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(Constantes.AUTHORIZATION, "Bearer " + getAccessToken());

        HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<byte[]> responseEntity = restTemplate.exchange(apiUrl,
                HttpMethod.GET,
                requestEntity,
                byte[].class);

        return responseEntity.getStatusCode() == HttpStatus.OK ? responseEntity.getBody() : null;
    }

}

