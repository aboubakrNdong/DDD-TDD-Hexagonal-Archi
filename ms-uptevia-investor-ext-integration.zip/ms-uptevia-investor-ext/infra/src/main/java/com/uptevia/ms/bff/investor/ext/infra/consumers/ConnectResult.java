package com.uptevia.ms.bff.investor.ext.infra.consumers;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels.ApiKeyInfo;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ConnectResult {
    private String access_token;
    private ApiKeyInfo api_key_info;
    private String token_type;

    public ConnectResult() {
    }

    public ConnectResult(String access_token, ApiKeyInfo api_key_info, String token_type) {
        this.access_token = access_token;
        this.api_key_info = api_key_info;
        this.token_type = token_type;
    }

    public String getAccess_token() {
        return access_token;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }

    public ApiKeyInfo getApi_key_info() {
        return api_key_info;
    }

    public void setApi_key_info(ApiKeyInfo api_key_info) {
        this.api_key_info = api_key_info;
    }

    public String getToken_type() {
        return token_type;
    }

    public void setToken_type(String token_type) {
        this.token_type = token_type;
    }
}
