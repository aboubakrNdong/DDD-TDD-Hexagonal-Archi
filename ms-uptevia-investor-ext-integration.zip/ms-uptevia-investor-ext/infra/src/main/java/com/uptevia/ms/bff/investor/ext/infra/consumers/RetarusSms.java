package com.uptevia.ms.bff.investor.ext.infra.consumers;

/**
 * <b>Description : Classe contenant pour consommer les APIs SMS de Retarus</b>
 *
 * @author Boris SODOLOUFO
 */

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uptevia.ms.bff.investor.ext.domain.util.Constantes;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.Collections;
import java.util.List;

public class RetarusSms {

    /**
     * Cette fonction implémente le cas le pus usuel: envpyer un SMS à une seule personne
     *
     * @param msgTxt      : le msg à envoyer
     * @param phoneNumbers : les numéros du bénéficaire
     * @return
     */
    public static String sendOneSmsToOne(String msgTxt, List<String> phoneNumbers) {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(Constantes.PROXY_SERVER_HOST, Constantes.PROXY_SERVER_PORT));
        requestFactory.setProxy(proxy);

        RestTemplate restTemplate = new RestTemplate(requestFactory);

        HttpHeaders headers = new HttpHeaders();
        headers.setBasicAuth(Constantes.SMS_RETARUS_USER, Constantes.SMS_RETARUS_PASSWORD);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> requestEntity = new HttpEntity<>(makeRequestBody(msgTxt, phoneNumbers), headers);
        ResponseEntity<String> responseEntity = restTemplate.exchange(Constantes.SMS_RETARUS_BASEURL + "rest/v1/jobs", HttpMethod.POST, requestEntity, String.class);

        // Vérifier le statut de la réponse
        String response;
        if (responseEntity.getStatusCode() == HttpStatus.CREATED) {
            response = responseEntity.getBody();
        } else {
            System.err.println("Échec de la requête. Statut : " + responseEntity.getStatusCode());
            response = "FAILED : " + responseEntity.getStatusCode();
        }
        return response;
    }

    private static String makeRequestBody(String msgTxt, List<String> phoneNumbers) {

        RequestBody requestBody = new RequestBody(
                Collections.singletonList(
                        new Message(msgTxt,
                                phoneNumbers.stream().map(Recipient::new).toList())
                )
        );

        // Convertir l'objet en JSON
        String jsonRequest;
        try {
            jsonRequest = new ObjectMapper().writeValueAsString(requestBody);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Erreur lors de la conversion de l'objet en JSON", e);
        }
        System.out.println("La requete: " + jsonRequest);
        return jsonRequest;
    }

    // records pour représenter la structure du corps de la requête
    record RequestBody(List<Message> messages) {
    }

    record Message(String text, List<Recipient> recipients) {
    }

    record Recipient(String dst) {
    }
}