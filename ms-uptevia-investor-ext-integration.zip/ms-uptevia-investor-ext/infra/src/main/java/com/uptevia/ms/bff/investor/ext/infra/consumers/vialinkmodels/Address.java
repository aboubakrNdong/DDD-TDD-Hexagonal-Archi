package com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class Address {
    @JsonProperty("address")
    private String address;

    @JsonProperty("city")
    private String city;

    @JsonProperty("province")
    private String province;

    @JsonProperty("country")
    private String country;

    @JsonProperty("countryIso")
    private String countryIso;

    @JsonProperty("zipCode")
    private String zipCode;

}
