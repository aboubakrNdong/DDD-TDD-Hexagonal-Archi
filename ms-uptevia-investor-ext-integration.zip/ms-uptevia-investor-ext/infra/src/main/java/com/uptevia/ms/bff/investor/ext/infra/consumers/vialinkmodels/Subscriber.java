package com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class Subscriber {
    @JsonProperty("type")
    private String type;

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("phoneNumber")
    private String phoneNumber;

    @JsonProperty("email")
    private String email;

    @JsonProperty("birthday")
    private String birthday;

    @JsonProperty("address")
    private Address address;

}
