package com.uptevia.ms.bff.investor.ext.infra.mapper;

import com.uptevia.ms.bff.investor.ext.domain.model.CategorieCodeDocDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CategorieCodeDocRowMapper implements RowMapper<CategorieCodeDocDTO> {
    @Override
    public CategorieCodeDocDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
        return CategorieCodeDocDTO.builder()
                .documentCode(rs.getString("code_operation"))
                .categorieDoc(mapcategorieDocToUPI(rs.getInt("CATEGORY_DOC")))
                .codeCouleur(rs.getString("code_couleur"))
                .indiDemat(rs.getInt("INDI_DEMAT"))
                .build();
    }

    String mapcategorieDocToUPI(int cat){
        switch (cat) {
            case 1:
                return "documentation.tab.general.title";
            case 2:
                return "documentation.tab.releves.title";
            case 3:
                return "documentation.tab.rapports.title";
            case 4:
                return "documentation.tab.avis.title";
            default:
                return "documentation.tab." + cat + ".title";
        }
    }
}
