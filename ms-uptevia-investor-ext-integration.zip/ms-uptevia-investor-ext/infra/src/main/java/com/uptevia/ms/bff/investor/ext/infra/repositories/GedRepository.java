package com.uptevia.ms.bff.investor.ext.infra.repositories;

import com.uptevia.ms.bff.investor.ext.domain.model.CategorieCodeDocDTO;
import com.uptevia.ms.bff.investor.ext.domain.repository.IGedRepository;
import com.uptevia.ms.bff.investor.ext.infra.mapper.CategorieCodeDocRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.*;


@Repository
public class GedRepository implements IGedRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;


    public GedRepository(@Qualifier("jdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    @PostConstruct
    public void init() {
        jdbcTemplate.setResultsMapCaseInsensitive(true);
    }
    @Override
    public List<CategorieCodeDocDTO> getCategCodeOperation(int emetIden, int actiIden, int pTituNume) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("emetIden", emetIden);
        params.put("pActiIden", actiIden);
        params.put("pTituNume", pTituNume);

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("GED_GET_CATEGORY_CODE_OPERATION")
                .returningResultSet("PS_CUR",
                        new CategorieCodeDocRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_EMET_IDEN", emetIden)
                .addValue("P_ACTI_IDEN", actiIden)
                .addValue("P_TITU_NUME", pTituNume);

        Map<String, Object> out = jdbcCall.execute(in);

        List<CategorieCodeDocDTO> result = (List<CategorieCodeDocDTO>) out.get("PS_CUR");
        if (result.isEmpty())
            return null;

        return result;
    }
}
