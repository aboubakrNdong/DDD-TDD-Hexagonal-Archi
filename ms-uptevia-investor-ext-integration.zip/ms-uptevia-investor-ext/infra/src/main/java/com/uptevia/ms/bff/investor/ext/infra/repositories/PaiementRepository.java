package com.uptevia.ms.bff.investor.ext.infra.repositories;


import com.caceis.stc.jdbc.sql.ProcStockHelper;
import com.caceis.stc.util.EncryptUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.model.PaiementCBUrlRequestDTO;
import com.uptevia.ms.bff.investor.ext.domain.model.PsSelDetailTituDTO;
import com.uptevia.ms.bff.investor.ext.domain.repository.IPaiementRepository;
import com.uptevia.ms.bff.investor.ext.domain.util.Constantes;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.math.BigDecimal;

import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.logging.Logger;

@Repository
public class PaiementRepository implements IPaiementRepository {

    Logger logger = Logger.getLogger(PaiementRepository.class.getName());

    @Value("${base.business.url}")
    private String baseBusinessUrl;

    @Override
    public String getPaiementCBUrl(PaiementCBUrlRequestDTO cbUrlRequest) throws FunctionnalException {

        String retour = "";

        String login = cbUrlRequest.getLogin();
        Integer emetIden = cbUrlRequest.getEmetIden();
        Integer actiIden = cbUrlRequest.getActiIden();
        Integer tituNume = 1;

        BigDecimal marge = new BigDecimal("1.10");

        PsSelDetailTituDTO titulaire = getProfile(emetIden, actiIden, tituNume);

        String today = DateTimeFormatter.ofPattern("yyyyMMddhhmmss", Locale.ENGLISH).format(LocalDateTime.now());
        String theme = cbUrlRequest.getTheme();
        String referenceTransaction = "REF-" + emetIden + actiIden + tituNume + today;
        String referenceClient = emetIden + "-" + actiIden + "-" + tituNume;


        String actionNamePatch = Constantes.METHODE_ACHAT;
        Date dateDuJour = new Date();
        ObjectMapper objectMap = new ObjectMapper();
        ObjectNode json = objectMap.createObjectNode();


        ObjectMapper objectMapperParams = new ObjectMapper();
        JsonNode jsonParamsObj = objectMapperParams.createObjectNode();

        if (cbUrlRequest.getModalite() != null) {
            ((ObjectNode) jsonParamsObj).put("modalite", cbUrlRequest.getModalite());
        }

        if (cbUrlRequest.getCoursLimite() != null) {
            ((ObjectNode) jsonParamsObj).put("courLimite", cbUrlRequest.getCoursLimite());
        }

        if (!StringUtils.isBlank(cbUrlRequest.getTypeValidite())) {
            ((ObjectNode) jsonParamsObj).put("typeValidite", cbUrlRequest.getTypeValidite());
        }

        String dateValidite = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH).format(cbUrlRequest.getDateValidite());
        if (!StringUtils.isBlank(cbUrlRequest.getDateValidite().toString())) {
            ((ObjectNode) jsonParamsObj).put("dateValidite", dateValidite);
        }

        if (cbUrlRequest.getQuantite() != null) {
            ((ObjectNode) jsonParamsObj).put("quantite", cbUrlRequest.getQuantite());
        }


        if (jsonParamsObj.isObject()) {
            Iterator<Map.Entry<String, JsonNode>> fields = jsonParamsObj.fields();
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                String paramName = entry.getKey();
                if (!paramName.startsWith("o_")) {
                    json.put(paramName, entry.getValue());
                }
            }
        }

        //Infos actionnaire
        json.put(Constantes.OCB_LOGIN, login);
        json.put(Constantes.OCB_EMAIL_PORTEUR, titulaire.getEmailPro());
        json.put(Constantes.OCB_ADDRESS_1, titulaire.getAdreFiscInfoRue());
        json.put(Constantes.OCB_ADDRESS_2, titulaire.getAdreComplement());
        json.put(Constantes.OCB_CITY, titulaire.getAdreFiscNomCommune());
        json.put(Constantes.OCB_ZIP_CODE, titulaire.getAdreFiscCodp());
        json.put(Constantes.OCB_COUNTRY_CODE, titulaire.getAdreFiscPaysIden());
        json.put(Constantes.OCB_FIRST_NAME, titulaire.getPrenom());
        json.put(Constantes.OCB_LAST_NAME, titulaire.getNom());
        json.put(Constantes.OCB_APPLICATION, Constantes.APPLICATION);
        json.put(Constantes.OCB_MODULE, cbUrlRequest.getModule());
        json.put(Constantes.OCB_THEME, cbUrlRequest.getTheme());
        json.put(Constantes.OCB_REFERENCE_TRANSACTION, referenceTransaction);
        json.put(Constantes.OCB_REFERENCE_CLIENT, referenceClient);
        json.put(Constantes.OCB_MONTANT, cbUrlRequest.getMontant().setScale(4, RoundingMode.HALF_UP).toString());
        json.put(Constantes.OCB_DATE, dateDuJour.getTime() + "");
        json.put(Constantes.OCB_MOIS_VALDITE_MIN, cbUrlRequest.getMoisValiditeMax() + "");
        json.put(Constantes.OCB_IS_DIRECT, cbUrlRequest.getIsDirect());
        json.put(Constantes.OCB_IS_MONTANT_REEL, cbUrlRequest.getIsMontantReel());
        json.put(Constantes.OCB_TOTAL_QUANTITY, cbUrlRequest.getQuantite() + "");

        if (marge == null) {
            marge = BigDecimal.ONE;
        }
        json.put(Constantes.OCB_MARGE, marge.setScale(2, RoundingMode.HALF_UP).toString());

        String langue = cbUrlRequest.getLangue().substring(0, 1);
        if (!StringUtils.equalsIgnoreCase("en", langue)) {
            langue = "fr";
        }

        if ("LOCAL".equals(theme)) {
            actionNamePatch = actionNamePatch + "_LOCAL";
        } else {
            if (StringUtils.isNotBlank(theme) && !"UPTEVIA".equals(theme) && theme.contains("UPTEVIA")) {
                actionNamePatch = actionNamePatch + "_UPTEVIA";
            }
        }

        try {
            String chained1 = EncryptUtils.encryptAndHexJSONString(json.toString(), Constantes.SECRET_KEY_CHIFF, Constantes.IV_PARAMETER_SPEC_CHIFF);
            retour = getUrlOlisByAction(actionNamePatch)
                    + "?d1=" + chained1
                    + "&request_locale=" + langue;

        } catch (Exception e) {
            logger.warning("Error while encrypting data " + retour + "Exception : " + e);
        }

        return retour;
    }

    public String getUrlOlisByAction(String action) throws Exception {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("PARAM_ACTION", action);
        String url = ProcStockHelper.callFunctionOnOlis(Constantes.GET_URL_CB_OLIS, String.class, params);
        return url;
    }


    public PsSelDetailTituDTO getProfile(int emetIden, int actiIden, int tituNume) {

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseBusinessUrl + "restricted/profile")
                .queryParam("emetIden", emetIden)
                .queryParam("actiIden", actiIden)
                .queryParam("tituNume", tituNume);

        String apiUrl = builder.toUriString();

        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<PsSelDetailTituDTO> response = restTemplate.getForEntity(apiUrl, PsSelDetailTituDTO.class);

        PsSelDetailTituDTO titulaire = null;
        if (response.getStatusCode().is2xxSuccessful()) {
            titulaire = response.getBody();
        } else {
            logger.warning("Erreur lors de l'appel HTTP. Statut : " + response.getStatusCode());
        }

        return titulaire;
    }

    @Override
    public String decryptParamRetour(String chaine) throws IOException {

        if (StringUtils.isBlank(chaine) || !chaine.matches("[0-9a-fA-F]{0,1024}")) {
            logger.warning("chaine invalide : " + chaine);
            return null;
        }
        byte[] result;
        try {
            result = EncryptUtils.decryptAes(chaine, Constantes.SECRET_KEY_DECHIFF, Constantes.IV_PARAMETER_SPEC_DECHIFF);
        } catch (Exception e1) {
            logger.warning("La chaine d1 n'a pas pu etre dechiffree du a une erreur dans celle-ci : " + chaine);
            return null;
        }
        return new String(result);
    }
}
