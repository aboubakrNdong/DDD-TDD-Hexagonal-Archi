package com.uptevia.ms.bff.investor.ext.infra.repositories;


import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.model.ParamsDTO;
import com.uptevia.ms.bff.investor.ext.domain.repository.IParamsRepository;
import com.uptevia.ms.bff.investor.ext.infra.mapper.ParamsRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Repository
public class ParamsRepository implements IParamsRepository {
    Logger logger = Logger.getLogger(ParamsRepository.class.getName());

    @Value("${spring.profiles.active}")
    private String activeProfiles;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;


    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }

    @Override
    public String getActiveCurrentEnv() {
        return activeProfiles;
    }

    @Override
    @Cacheable("getAllParams")
    public List<ParamsDTO> getAllParams() throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("SITE_GET_PARAM")
                .returningResultSet("PS_CUR",
                        new ParamsRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_EMET_IDEN", 0)
                .addValue("PARAM_PARAM_NAME", null)
                .addValue("PARAM_PARAM_CATEGORY", null)
                .addValue("PARAM_PARAM_ENV", activeProfiles);

        Map<String, Object> out = jdbcCall.execute(in);

        List<ParamsDTO> result = (List<ParamsDTO>) out.get("PS_CUR");

        if (result == null) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("PARAM_PARAM_ENV", activeProfiles);
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return result;
    }
}
