package com.uptevia.ms.bff.investor.ext.infra.repositories;


import com.uptevia.ms.bff.investor.ext.domain.model.RecaptchaVerifyDTO;
import com.uptevia.ms.bff.investor.ext.domain.repository.IRecaptchaRepository;
import com.uptevia.ms.bff.investor.ext.domain.util.Constantes;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.logging.Logger;



@Repository
public class RecaptchaRepository implements IRecaptchaRepository {

    Logger logger = Logger.getLogger(RecaptchaRepository.class.getName());

    @Value("${proxy.host}")
    private String proxyHost;

    @Value("${google.server.secret.v3}")
    private String googleServerSecretv3;



    /**
     * @param captchaVerifyDTO
     * @return
     */
    @Override
    public String sendgRecaptchatoServer(RecaptchaVerifyDTO captchaVerifyDTO) {

        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();

        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(proxyHost, 8080));
        requestFactory.setProxy(proxy);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();

        map.add("secret", googleServerSecretv3);
        map.add("response", captchaVerifyDTO.getCaptchaToken());

        HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(map, headers);

        RestTemplate restTemplate = new RestTemplate();

        try {
            requestFactory.setBufferRequestBody(false);
            restTemplate.setRequestFactory(requestFactory);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ResponseEntity<String> responseEntity = restTemplate.exchange(Constantes.GOOGLE_RECAPTCHA_VERIF, HttpMethod.POST, requestEntity, String.class);
        return responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST ? null : responseEntity.getBody();
    }


}