package com.uptevia.ms.bff.investor.ext.infra.repositories;

import com.uptevia.ms.bff.investor.ext.domain.repository.ISmsRepository;
import com.uptevia.ms.bff.investor.ext.infra.consumers.RetarusSms;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public class SmsRepository implements ISmsRepository {

    @Override
    public String sendOneSMStoOneByRetarus(List<String> mobilePhones, String textSMS) {
        return RetarusSms.sendOneSmsToOne(textSMS, mobilePhones);
    }
}
