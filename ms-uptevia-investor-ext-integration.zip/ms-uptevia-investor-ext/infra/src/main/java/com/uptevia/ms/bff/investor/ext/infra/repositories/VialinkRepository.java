package com.uptevia.ms.bff.investor.ext.infra.repositories;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.neovisionaries.i18n.CountryCode;
import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.model.*;

import com.uptevia.ms.bff.investor.ext.domain.model.vialink.Sheet;
import com.uptevia.ms.bff.investor.ext.domain.model.vialink.VlkControl;

import com.uptevia.ms.bff.investor.ext.domain.util.Constantes;
import com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels.*;
import com.uptevia.ms.bff.investor.ext.domain.repository.IVialinkRepository;
import com.uptevia.ms.bff.investor.ext.infra.consumers.ClientVialink;
import com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels.Address;
import com.uptevia.ms.bff.investor.ext.infra.consumers.vialinkmodels.Control;
import com.uptevia.ms.bff.investor.ext.infra.mapper.ParamsRowMapper;
import com.uptevia.ms.bff.investor.ext.infra.tradClient.TradClient;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;


import javax.annotation.PostConstruct;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;


@Repository
@Slf4j
public class VialinkRepository implements IVialinkRepository {

    private static final Logger LOG = LoggerFactory.getLogger(VialinkRepository.class);

    public static Map<String, TraductionDTO> traductions = new HashMap<>();

    @Value("${base.business.url}")
    private String baseBusinessUrl;

    @Value("${spring.profiles.active}")
    private String activeProfiles;
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private TradClient tradClient;

    @PostConstruct
    public void init() {
        jdbcTemplate.setResultsMapCaseInsensitive(true);
    }

    public PsSelDetailTituDTO getTitulaire(String login) {

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseBusinessUrl + "restricted/titulaire")
                .queryParam("login", login);

        String apiUrl = builder.toUriString();

        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<PsSelDetailTituDTO> response = restTemplate.getForEntity(apiUrl, PsSelDetailTituDTO.class);

        PsSelDetailTituDTO titulaire = null;
        if (response.getStatusCode().is2xxSuccessful()) {
            titulaire = response.getBody();
        } else {
            log.warn("Erreur lors de l'appel HTTP. Statut : " + response.getStatusCode());
        }

        return titulaire;
    }


    /**
     * @param login
     * @param useCase
     * @return
     */
    @Override
    public String newControl(final String login, final String useCase) throws FunctionnalException, IOException {
        ClientVialink client = ClientVialink.getInstance();
        String vlkParams = getParamValueByName(Constantes.VIALINK_PARAMS);
        client.setVlkParams(vlkParams);

        Control reqControl = makeControl(login, useCase, vlkParams);
        return client.createControle(reqControl);
    }

    public String getProfileId(String params, String useCase) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        JsonFactory factory = mapper.getJsonFactory();
        JsonParser parser = factory.createJsonParser(params);
        JsonNode jsonParams = mapper.readTree(parser);

        return jsonParams.get(useCase+".profile.id").asText();

    }

    @Override
    public String uploadDocument(String controlId, File file, String documentId, String type) throws IOException, FunctionnalException {
        ClientVialink client = ClientVialink.getInstance();
        String vlkParams = getParamValueByName(Constantes.VIALINK_PARAMS);
        client.setVlkParams(vlkParams);

        return client.uploadDocument(controlId, file, documentId, type);
    }

    @Override
    public String smartUploadDocument(String controlId, File file) throws IOException, FunctionnalException {
        ClientVialink client = ClientVialink.getInstance();
        String vlkParams = getParamValueByName(Constantes.VIALINK_PARAMS);
        client.setVlkParams(vlkParams);

        return client.smartUploadDocument(controlId, file);
    }

    @Override
    public String addSheetToDocument(String controlId, Long documentId, String side, File file) throws IOException, InterruptedException, FunctionnalException {
        ClientVialink client = ClientVialink.getInstance();
        String vlkParams = getParamValueByName(Constantes.VIALINK_PARAMS);
        client.setVlkParams(vlkParams);
        return client.addSheetToDocument(controlId, documentId, side, file);
    }

    /**
     * @param controlId
     * @return
     */
    @Override
    public HttpStatus submitControl(String controlId) throws IOException, FunctionnalException {
        ClientVialink client = ClientVialink.getInstance();
        String vlkParams = getParamValueByName(Constantes.VIALINK_PARAMS);
        client.setVlkParams(vlkParams);

        return client.submitControl(controlId);
    }

    /**
     * @param controlId
     * @return
     */
    @Override
    public String getControlStatus(String controlId) throws IOException, FunctionnalException {
        ClientVialink client = ClientVialink.getInstance();
        String vlkParams = getParamValueByName(Constantes.VIALINK_PARAMS);
        client.setVlkParams(vlkParams);
        return client.getControlStatus(controlId);
    }

    @Override
    public String getControlDocuments(String controlId) throws IOException, FunctionnalException {
        ClientVialink client = ClientVialink.getInstance();
        String vlkParams = getParamValueByName(Constantes.VIALINK_PARAMS);
        client.setVlkParams(vlkParams);
        return client.getControlDocuments(controlId);
    }

    @Override
    public String getControlReport(String controlId) throws IOException, FunctionnalException {
        ClientVialink client = ClientVialink.getInstance();
        String vlkParams = getParamValueByName(Constantes.VIALINK_PARAMS);
        client.setVlkParams(vlkParams);
        return client.getControlReport(controlId);
    }

    @Override
    public String getControlResult(String controlId) throws IOException, FunctionnalException {
        ClientVialink client = ClientVialink.getInstance();
        String vlkParams = getParamValueByName(Constantes.VIALINK_PARAMS);
        client.setVlkParams(vlkParams);
        return client.getControlResult(controlId);
    }

    @Override
    public void sendMaiToGrc(final ControlStatusDTO controlStatusDTO, final String login, final String lang) throws FunctionnalException {

        traductions = tradClient.traductions(getLangue(lang), 1).getBody()
                .stream().collect(Collectors.toMap(TraductionDTO::getKey, Function.identity()));
        
        PsSelDetailTituDTO titulaire = getTitulaire(login);

        final String subject = controlStatusDTO.getScore() < 100 ? "UPI + KYC KO" : "UPI + KYC OK";

        final String score = String.valueOf(controlStatusDTO.getScore()).concat("%");
        final SendEmailDTO thesendEmailDTO = SendEmailDTO.builder()
                .from("no-reply@uptevia.com")
                .htmlBody("")
                .subject(subject)
                .typeMail("")
                .build();
        EmailBodyDTO emailBodyDTO = EmailBodyDTO.builder()
                .textBody(buildMessage(controlStatusDTO.getSubscriber().getFirstName(), controlStatusDTO.getSubscriber().getLastName(),
                        String.valueOf(titulaire.getEmetIden()), String.valueOf(titulaire.getActiIden()),
                        score, controlStatusDTO.getId()))
                .securityLib(getText("footer.item.securite"))
                .cguLib(getText("footer.item.cgu"))
                .rgpdLib(getText("footer.item.rgpd"))
                .accessibilityLib(getText("footer.item.accessibilite"))
                .conformLib(getText("footer.item.conformite"))
                .build();
        log.info("Begin sending mail to GRC ...");
        sendEmail(thesendEmailDTO, emailBodyDTO);
    }

    String buildMessage(final String prenom, final String nom, final String codeEmetteur,
                        final String ccn, final String scoreVialink, final String controlId) {

        return String.format("Bonjour  Madame, Monsieur,<br><br>\n"
                        + "Vous avez reçu un dossier KYC via le site investisseur UPI, provenant de l'actionnaire <br><br>\n"
                        + "%s &ensp; %s .<br><br>\n"
                        + "Code émetteur/Compte : %s/%s <br><br>\n"
                        + "Ces documents ont obtenu un score global de %s .<br><br>\n"
                        + "Pour des informations supplémentaires, vous pouvez accéder en détail à son dossier "
                        + "sur le portail Vialink en <br><br> utilisant le numéro ci-joint : %s <br><br>\n"
                        + "Bien Cordialement, <br><br>\n\n"
                        + "Service UPI <br><br>\n\n",
                prenom, nom, codeEmetteur, ccn, scoreVialink, controlId);
    }


    @Override
    public String validateToken(final String login, final String token, final String tokenType) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName("TOKEN_CHECK_VALIDITY");

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_LOGIN", login)
                .addValue("P_TOKEN_TYPE", tokenType)
                .addValue("P_TOKEN", token);
        return jdbcCall.executeFunction(String.class, in);
    }

    //This method is to insert the second token generated with controlId, login, email and phone
    @Override
    public BigDecimal insertTokenEmailTelVialink(String secondToken, String login, String email, String phone, String tokenTypeVialink) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName("TOKEN_INSERT_EMAIL_TEL_VIALINK");

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_LOGIN", login)
                .addValue("P_EMAIL", email)
                .addValue("P_NUM_TEL", phone)
                .addValue("P_TOKEN", secondToken);

        return jdbcCall.executeFunction(BigDecimal.class, in);
    }


    @Override
    public String updateContacts(String token, String login, int score) {
        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName("UPI_UTIL_UPDATE_EMAIL_TEL");

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_LOGIN", login)
                .addValue("P_SCORE_VIALINK", score)
                .addValue("P_TOKEN", token);
        log.info("updating tel and phone for authenticated user");
        return jdbcCall.executeFunction(String.class, in);
    }

    @Override
    public String delDocument(String controlId, Integer documentId) throws FunctionnalException, IOException {
        ClientVialink client = ClientVialink.getInstance();
        String vlkParams = getParamValueByName(Constantes.VIALINK_PARAMS);
        client.setVlkParams(vlkParams);
        return client.delDocument(controlId, documentId);
    }

    public boolean sendEmail(final SendEmailDTO sendEmailDTO, final EmailBodyDTO emailBodyDTO) throws FunctionnalException {

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseBusinessUrl + "restricted/sendMail");

        String mailGrc = getParamValueByName("GRC_MAIL");
        MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
        map.add("textBody", emailBodyDTO);
        map.add("htmlBody", sendEmailDTO.getHtmlBody());
        map.add("subject", sendEmailDTO.getSubject());
        map.add("typeMail", sendEmailDTO.getTypeMail());
        map.add("recipients", mailGrc);
        map.add("attachments", null);
        String apiUrl = builder.toUriString();

        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        HttpEntity<MultiValueMap<String, Object>> entity = new HttpEntity<>(map, headers);

        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<String> response = restTemplate.postForEntity(apiUrl, entity, String.class);

        return response.getStatusCode().is2xxSuccessful();
    }

    public Subscriber createSubscriber(String login) {

        PsSelDetailTituDTO titulaire = getTitulaire(login);

        Address ad = Address.builder()
                .address(titulaire.getAdreFiscInfoRue())
                .city(titulaire.getAdreFiscNomCommune())
                .zipCode(titulaire.getAdreFiscCodp())
                .build();

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        return Subscriber.builder()
                .firstName(titulaire.getPrenom())
                .lastName(titulaire.getNom())
                .email(titulaire.getEmailPro())
                .birthday(fmt.format(titulaire.getTituNaisDate()))
                .phoneNumber(titulaire.getNumMobilePro())
                .type("PERSON")
                .address(ad)
                .build();
    }

    public Control makeControl(String login, String useCase, String vlkParams) throws IOException {
        return Control.builder()
                .controlProfileId(getProfileId(vlkParams, useCase))
                .spaceId("99802e26-8e40-4b81-b655-020e99c54814")
                .subscriber(createSubscriber(login))
                .build();

    }

    //TODO: To clean : Suivant discussion dans Squad Dev, jar STC ou MS Ressources
    @Cacheable("getAllParams")
    public List<ParamsDTO> getAllParams() throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("SITE_GET_PARAM")
                .returningResultSet("PS_CUR",
                        new ParamsRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_EMET_IDEN", 0)
                .addValue("PARAM_PARAM_NAME", null)
                .addValue("PARAM_PARAM_CATEGORY", null)
                .addValue("PARAM_PARAM_ENV", activeProfiles);

        Map<String, Object> out = jdbcCall.execute(in);

        List<ParamsDTO> result = (List<ParamsDTO>) out.get("PS_CUR");

        if (result == null) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("PARAM_PARAM_ENV", activeProfiles);
            throw new FunctionnalException("EDX", "No Params found", contextParams);
        }

        return result;
    }

    public String getParamValueByName(String paramName) throws FunctionnalException {
        List<ParamsDTO> paramsList = getAllParams();

        ParamsDTO paramDTO = paramsList.stream()
                .filter(param -> param.getParamName().equals(paramName))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Param not found with name: " + paramName));

        return paramDTO.getParamValue();
    }


    @Override
    public Long saveVialinkDemande(VlkControl control) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withFunctionName("UPI_DEMANDE_INSERT");

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("param_origine", "UPI")
                .addValue("param_typologie", Constantes.TOKEN_TYPE_VIALINK)
                .addValue("param_sous_typologie", control.getUseCase())
                .addValue("param_clob", "")
                .addValue("param_compte_key", control.getControlId())
                .addValue("param_commentaire", "")
                .addValue("param_commentaire_histo", "")
                .addValue("param_user_crea", control.getSubscriber());

        return jdbcCall.executeFunction(BigDecimal.class, in).longValue();
    }




    @Override
    public Long saveVialinkDocuments(long idDemande, String controlId, String documentId, Sheet sheet) throws FunctionnalException, IOException {

        //TODO: Use the new methode from Joss: private static final String INSERT_UTIL_DEMANDE_JUSTIF = "INSERT INTO UTIL_DEMANDE_JUSTIF(ID_JUSTIF, ID_DEMANDE, CODE, NAME, CONTENT_TYPE, CONTENT, USER_CREA, USER_MAJ, DATE_CREA, DATE_MAJ) VALUES (0,?,?,?,?,?,?,?, SYSDATE, SYSDATE)";

        ClientVialink client = ClientVialink.getInstance();
        String vlkParams = getParamValueByName(Constantes.VIALINK_PARAMS);
        client.setVlkParams(vlkParams);

        byte[] contentFile = client.getDocumentFile(controlId, documentId, String.valueOf(sheet.getId()));

        try {
            SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                    .withFunctionName("UPI_DEMANDE_JUSTIF_INSERT");

            SqlParameterSource in = new MapSqlParameterSource()
                    .addValue("P_ID_DEMANDE", idDemande)
                    .addValue("P_CODE", "ID VIALINK: "+ sheet.getId())
                    .addValue("P_FILENAME", sheet.getFileName())
                    .addValue("P_CONTENT_TYPE", sheet.getMimeType())
                    .addValue("P_FILE_CONTENT", new ByteArrayInputStream(contentFile))
                    .addValue("P_USER_CREA", "UPI");

            return jdbcCall.executeFunction(BigDecimal.class, in).longValue();

        } catch (Exception ignore) { }

        return 1L;
    }

    private String getText(final String key) {
        var libelle = "";
        if(traductions != null && !traductions.entrySet().isEmpty()){
            libelle = traductions.get(key).getLibelle();
        }
        return libelle;
    }

    private static String getLangue(final String lang){

        Map<String, String> mapLangue = new HashMap<>();

        mapLangue.put("en", "ENG");
        mapLangue.put("fr", "FRA");
        mapLangue.put("de", "DEU");
        mapLangue.put("es", "ESP");
        mapLangue.put("pt", "PRT");
        mapLangue.put("it", "ITA");
        mapLangue.put("nl", "NLD");

        return mapLangue.get(lang);
    }
}