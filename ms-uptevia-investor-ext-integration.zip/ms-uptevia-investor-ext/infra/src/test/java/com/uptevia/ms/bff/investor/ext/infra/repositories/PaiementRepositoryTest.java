package com.uptevia.ms.bff.investor.ext.infra.repositories;

import com.uptevia.ms.bff.investor.ext.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.ext.domain.model.PaiementCBUrlRequestDTO;
import com.uptevia.ms.bff.investor.ext.domain.model.PsSelDetailTituDTO;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class PaiementRepositoryTest {

    @Mock
    private RestTemplate restTemplate;

    @Autowired
    private PaiementRepository paiementRepository;

    private final EasyRandom easyRandom = new EasyRandom();

    private final PaiementCBUrlRequestDTO request = PaiementCBUrlRequestDTO.builder()
            .login("92605493")
            .emetIden(484)
            .actiIden(193)
            .langue("FRA")
            .module("ACHAT")
            .theme("UPTEVIA")
            .coursLimite(BigDecimal.valueOf(100.2))
            .dateValidite(LocalDate.parse("2023-12-01"))
            .typeValidite("JOUR")
            .modalite(3)
            .quantite(1)
            .isDirect(true)
            .isMontantReel(true)
            .moisValiditeMax(1)
            .build();

    @Test
    public void should_return_cb_url_ok() throws FunctionnalException {

        PsSelDetailTituDTO titulaire = easyRandom.nextObject(PsSelDetailTituDTO.class);

        ResponseEntity<PsSelDetailTituDTO> responseEntity = ResponseEntity.ok(titulaire);

    }

}