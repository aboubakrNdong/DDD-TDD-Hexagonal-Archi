package com.uptevia.ms.bff.investor.resource.app.configuration;


import com.uptevia.ms.bff.investor.resource.domain.repository.*;
import com.uptevia.ms.bff.investor.resource.domain.service.*;
import com.uptevia.ms.bff.investor.resource.domain.service.impl.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DomainConfiguration {

    @Bean
    ThemeService getThemeService(IThemeRepository themeRepository) {
        return new ThemeServiceImpl(themeRepository);
    }

    @Bean
    LogoService getLogoService(ILogoRepository logoRepository) {
        return new LogoServiceImpl(logoRepository);
    }

    @Bean
    TraductionService getTraductionService(ITraductionRepository traductionRepository) {
        return new TraductionServiceImpl(traductionRepository);
    }

    @Bean
    FaqService getFAQService(IFaqsRepository iFaqsRepository) {
        return new FaqServiceImpl(iFaqsRepository);
    }

    @Bean
    ModuleService getModuleService(IModuleRepository iModuleRepository){return new ModuleServiceImpl(iModuleRepository);}

    @Bean
    ParametrageService getParametrage(IParametrageRepository iParametrageRepository){
        return  new ParametrageServiceImpl(iParametrageRepository);
    }

    @Bean
    LanguesService getLanguesService(ILanguesRepository languesRepository) {
        return new LanguesServiceImpl(languesRepository);
    }

}
