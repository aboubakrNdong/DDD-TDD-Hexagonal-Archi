package com.uptevia.ms.bff.investor.resource.app.controller;

import com.uptevia.ms.bff.investor.resource.api.ModuleApi;
import com.uptevia.ms.bff.investor.resource.api.model.ModuleJson;
import com.uptevia.ms.bff.investor.resource.app.mapper.ModuleJsonMapper;
import com.uptevia.ms.bff.investor.resource.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.ModuleDTO;

import com.uptevia.ms.bff.investor.resource.domain.service.ModuleService;
import com.uptevia.ms.bff.investor.resource.domain.util.Constants;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Objects;
import java.util.logging.Logger;

@RestController
@RequestMapping("/api/v1")
public class ModuleController implements ModuleApi {
    Logger logger = Logger.getLogger(ModuleController.class.getName());

    private final ModuleService moduleService;

    @Autowired
    private JwtUtils jwtUtils;

    public ModuleController(final ModuleService mmoduleService) {
        this.moduleService = mmoduleService;
    }

    /**
     * GET /menus
     * getMenu
     *
     * @return une liste de Menu a été trouvé pour ce paramétres (status code 200)
     * or Retour de la procédure stockée incorrect (status code 400)
     * or Utilisateur non autorisé, JWT tokken incorrect (status code 401)
     * or Menu non trouvé pour ces parametres (status code 404)
     * or Erreur d&#39;accès à la requete ou à la base de données (status code 500)
     */
    @Override
    public ResponseEntity<List<ModuleJson>> getModules() {
        List<ModuleDTO> moduleDTOS = null;
        try {
            HttpServletRequest currentRequest = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
            Claims claims = jwtUtils.getAllClaimsFromToken(currentRequest.getHeader(Constants.AUTHORIZATION));
           if(!Objects.isNull(claims))
            moduleDTOS = moduleService.getModule(Integer.valueOf(claims.get("emetIden").toString()),
                    Integer.valueOf(claims.get("actiIden").toString()),
                    Integer.valueOf(claims.get("titunume").toString()));
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(moduleDTOS.stream()
                .map(ModuleJsonMapper.INSTANCE::dtoToJson).toList(), HttpStatus.OK);
    }
}