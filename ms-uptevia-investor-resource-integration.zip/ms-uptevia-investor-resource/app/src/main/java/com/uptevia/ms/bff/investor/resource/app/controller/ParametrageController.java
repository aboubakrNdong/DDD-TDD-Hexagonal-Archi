package com.uptevia.ms.bff.investor.resource.app.controller;

import com.uptevia.ms.bff.investor.resource.api.ParametreSiteApi;
import com.uptevia.ms.bff.investor.resource.api.model.ParametrageJson;
import com.uptevia.ms.bff.investor.resource.app.mapper.ParametrageJsonMapper;
import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.ParametrageDTO;
import com.uptevia.ms.bff.investor.resource.domain.service.ParametrageService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.logging.Logger;

@RestController
@RequestMapping("/api/v1")
public class ParametrageController implements ParametreSiteApi {

    Logger logger = Logger.getLogger(ParametrageController.class.getName());

    private final ParametrageService parametrageService;

    public ParametrageController(ParametrageService parametrageService) {
        this.parametrageService = parametrageService;
    }

    @Override
    public ResponseEntity<ParametrageJson> getParamsSite(Integer emetIden, String paramName, String paramCategory) {
        ParametrageDTO parametrageDTO = null;

        try {
            parametrageDTO = parametrageService.getParamsSite(emetIden, paramName, paramCategory);
        } catch (FunctionnalException e) {
            logger.info(e.getMessage() + " with the param : " + e.getContextParams().toString());
            return new ResponseEntity<>(
                    HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(ParametrageJsonMapper.INSTANCE.dtoToJson(parametrageDTO),
                HttpStatus.OK);
    }
}
