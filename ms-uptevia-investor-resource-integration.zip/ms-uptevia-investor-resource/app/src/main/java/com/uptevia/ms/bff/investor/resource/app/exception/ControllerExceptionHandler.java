package com.uptevia.ms.bff.investor.resource.app.exception;

import com.uptevia.ms.bff.investor.resource.api.model.MSExceptionDTOJson;
import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@RestControllerAdvice
public class ControllerExceptionHandler {

    @ExceptionHandler(value = {FunctionnalException.class})
    public ResponseEntity<MSExceptionDTOJson> resourceNotFoundException(FunctionnalException ex, WebRequest request) {
        MSExceptionDTOJson message = new MSExceptionDTOJson()
                .message(ex.getMessage())
                .errorCode(ex.getCode())
                .contextParams(ex.getContextParams());

        return new ResponseEntity<MSExceptionDTOJson>(message, HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(value = {RuntimeException.class})
    public ResponseEntity<MSExceptionDTOJson> resourceRuntimeException(RuntimeException ex, WebRequest request) {
        MSExceptionDTOJson message = new MSExceptionDTOJson()
                .message(ex.getMessage());

        return new ResponseEntity<MSExceptionDTOJson>(message, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
