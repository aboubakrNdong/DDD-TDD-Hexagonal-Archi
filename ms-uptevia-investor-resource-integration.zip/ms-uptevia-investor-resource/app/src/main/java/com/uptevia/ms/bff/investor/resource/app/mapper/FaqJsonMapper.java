package com.uptevia.ms.bff.investor.resource.app.mapper;

import com.uptevia.ms.bff.investor.resource.api.model.FreqAskedQJson;
import com.uptevia.ms.bff.investor.resource.domain.model.FaqsDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface FaqJsonMapper {

    FaqJsonMapper INSTANCE = Mappers.getMapper(FaqJsonMapper.class);
    FreqAskedQJson dtoToJson(FaqsDTO faqDTO);
}
