package com.uptevia.ms.bff.investor.resource.app.mapper;

import com.uptevia.ms.bff.investor.resource.api.model.LanguesJson;
import com.uptevia.ms.bff.investor.resource.domain.model.LanguesDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface LanguesJsonMapper {

    LanguesJsonMapper INSTANCE = Mappers.getMapper(LanguesJsonMapper.class);
    LanguesJson dtoToJson(LanguesDTO languesDTO);
}

