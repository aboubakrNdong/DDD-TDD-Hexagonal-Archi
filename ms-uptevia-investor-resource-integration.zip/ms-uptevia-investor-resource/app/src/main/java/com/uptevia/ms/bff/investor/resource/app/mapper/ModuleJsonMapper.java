package com.uptevia.ms.bff.investor.resource.app.mapper;

import com.uptevia.ms.bff.investor.resource.api.model.ModuleJson;
import com.uptevia.ms.bff.investor.resource.domain.model.ModuleDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;


@Mapper
public interface ModuleJsonMapper {

    ModuleJsonMapper INSTANCE = Mappers.getMapper(ModuleJsonMapper.class);

    ModuleJson dtoToJson(ModuleDTO moduleDTO);

}
