package com.uptevia.ms.bff.investor.resource.app.mapper;

import com.uptevia.ms.bff.investor.resource.api.model.TraductionJson;
import com.uptevia.ms.bff.investor.resource.domain.model.TraductionDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TraductionJsonMapper {

    TraductionJsonMapper INSTANCE = Mappers.getMapper(TraductionJsonMapper.class);
    TraductionJson dtoToJson(TraductionDTO traductionDTO);
}
