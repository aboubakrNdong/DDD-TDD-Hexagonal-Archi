package com.uptevia.ms.bff.investor.resource.app.security;

import com.uptevia.ms.bff.investor.resource.app.security.jwt.AuthTokenFilter;
import com.uptevia.ms.bff.investor.resource.app.security.jwt.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

//@Configuration
public class WebSecurityConfig {

    private static final String[] RES_WHITELIST = {
            // -- Swagger UI v3 (OpenAPI)
            "/v3/api-docs/**",
            "/ms-investor-resource.v1.json",
            "/swagger-ui.html",
            "/swagger-ui/**",
            "/**/traduction/**",
            "/**/actuator/**",
            "/**/faq/**",
            "/**/parametreSite/**"
            // other public endpoints of your API may be appended to this array.
    };

    /*@Autowired
    private JwtUtils jwtUtils;


    @Bean
    public AuthTokenFilter authenticationJwtTokenFilter() {
        return new AuthTokenFilter(jwtUtils);
    }*/

    @Bean
    public SecurityFilterChain filterChain(final HttpSecurity http) throws Exception {

        // Disable CSRF (cross site request forgery)
        http.csrf().disable();

        http.formLogin().disable();

        // No session will be created or used by spring security
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        // Entry points
        http.authorizeRequests()
                //List of urls to be allowed
                .antMatchers(RES_WHITELIST).permitAll()
                // Disallow everything else..
                .anyRequest().authenticated();

        // If a user try to access a resource without having enough permissions
        http.exceptionHandling().accessDeniedPage("/login");

        // Apply JWT
        //http.addFilterAfter(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);

        return http.build();

    }

}