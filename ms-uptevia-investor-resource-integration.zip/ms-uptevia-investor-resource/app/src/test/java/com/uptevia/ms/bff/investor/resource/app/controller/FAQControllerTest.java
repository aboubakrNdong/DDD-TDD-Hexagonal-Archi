package com.uptevia.ms.bff.investor.resource.app.controller;

import com.uptevia.ms.bff.investor.resource.app.dto.UserDTO;
import com.uptevia.ms.bff.investor.resource.app.security.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.FaqsDTO;
import com.uptevia.ms.bff.investor.resource.domain.service.FaqService;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.List;
import java.util.stream.Collectors;


import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = FAQController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
public class FAQControllerTest {

    private static String URL_GET_FAQ_LINKS = "/api/v1/faq";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private JwtUtils jwtUtils;

    @MockBean
    private FaqService faqService;

    private EasyRandom easyRandom = new EasyRandom();
    @Test
    void should_return_get_faq_ok() throws Exception {

        List<FaqsDTO> faqsDTO = easyRandom.objects(FaqsDTO.class, 1)
                .collect(Collectors.toList());

        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);

        Mockito.when(faqService.getFaqs("O")).thenReturn(faqsDTO);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_FAQ_LINKS)
                        .header("Authorization", "Bearer ", userDTO.getToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .queryParam("piLoggedFaq", "O")
                        .characterEncoding("UTF-8"))
                .andExpect(jsonPath("$.*").isArray())
                .andExpect(jsonPath("$.[0].qresponses").exists());

    }

    @Test
    void should_return_get_faq_and_return_500() throws Exception {

        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);

        Mockito.when(faqService.getFaqs("O")).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_FAQ_LINKS)
                        .header("Authorization", "Bearer ", userDTO.getToken())
                        .queryParam("piLoggedFaq", "O")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void should_return_get_actionnaire_and_return_404() throws Exception {

        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(faqService.getFaqs("O")).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_FAQ_LINKS)
                        .queryParam("piLoggedFaq", "O")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());
    }

}
