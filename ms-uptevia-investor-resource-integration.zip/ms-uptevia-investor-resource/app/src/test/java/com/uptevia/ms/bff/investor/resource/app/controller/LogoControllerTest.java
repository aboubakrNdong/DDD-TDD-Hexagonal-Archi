package com.uptevia.ms.bff.investor.resource.app.controller;

import com.uptevia.ms.bff.investor.resource.app.dto.UserDTO;
import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.LogoDTO;
import com.uptevia.ms.bff.investor.resource.domain.service.LogoService;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.Base64;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = LogoController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
public class LogoControllerTest {

    private static String URL_GET_LOGO_LINKS = "/api/v1/logo";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private LogoService logoService;


    private EasyRandom easyRandom = new EasyRandom();
    //@Test
    void should_return_get_logo_ok() throws Exception {

        LogoDTO logoDTO = easyRandom.nextObject(LogoDTO.class);
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(logoService.getLogo(99963514)).thenReturn(logoDTO);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_LOGO_LINKS + "/99963514")
                        .header("Authorization", "Bearer ", userDTO.getToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(jsonPath("$.*").isArray())
                .andExpect(jsonPath("$.emetIden").exists())
                .andExpect(jsonPath("$.emetIden").value(logoDTO.getEmetIden()))
                .andExpect(jsonPath("$.type").value(logoDTO.getType()))
                .andExpect(jsonPath("$.file").value(Base64.getEncoder().encodeToString(logoDTO.getFile())));
    }

    //@Test
    void should_return_get_logo_and_return_500() throws Exception {
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(logoService.getLogo(99963514)).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_LOGO_LINKS + "/99963514")
                        .header("Authorization", "Bearer ", userDTO.getToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    //@Test
    void should_return_get_logo_and_return_404() throws Exception {
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(logoService.getLogo(99963514)).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_LOGO_LINKS + "/99963514")
                        .header("Authorization", "Bearer ", userDTO.getToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());
    }

}
