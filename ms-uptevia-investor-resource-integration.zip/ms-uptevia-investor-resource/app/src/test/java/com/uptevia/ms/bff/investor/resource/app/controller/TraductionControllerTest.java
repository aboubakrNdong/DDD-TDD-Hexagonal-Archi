package com.uptevia.ms.bff.investor.resource.app.controller;

import com.uptevia.ms.bff.investor.resource.app.dto.UserDTO;
import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.TraductionDTO;
import com.uptevia.ms.bff.investor.resource.domain.service.TraductionService;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(value = TraductionController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
public class TraductionControllerTest {

    private static String URL_GET_TRAD_LINKS = "/api/v1/traduction";

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private TraductionService traductionService;

    private EasyRandom easyRandom = new EasyRandom();


    @Test
    void should_return_get_trad_ok() throws Exception {

        List<TraductionDTO> traductions = easyRandom.objects(TraductionDTO.class, 5)
                .collect(Collectors.toList());
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        traductions.forEach(
                e -> {
                    e.setCodeLangue("FRA");
                    e.setThemeId(1);
                }
        );

        Mockito.when(traductionService.getTrads("FRA", 1)).thenReturn(traductions);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_TRAD_LINKS + "/FRA/1")
                        .header("Authorization", "Bearer ", userDTO.getToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(jsonPath("$.*").isArray())
                .andExpect(jsonPath("$.[0].key").exists())
                .andExpect(jsonPath("$.[1].libelle").exists());
    }

    @Test
    void should_return_get_trad_and_return_500() throws Exception {
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(traductionService.getTrads("FRA", 1)).thenThrow(NullPointerException.class);

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_TRAD_LINKS + "/FRA/1")
                        .header("Authorization", "Bearer ", userDTO.getToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isInternalServerError());

    }

    @Test
    void should_return_get_trad_and_return_404() throws Exception {
        UserDTO userDTO = easyRandom.nextObject(UserDTO.class);
        Mockito.when(traductionService.getTrads("FRA", 1)).thenThrow(new FunctionnalException("code", "message"));

        this.mockMvc.perform(MockMvcRequestBuilders.get(URL_GET_TRAD_LINKS + "/FRA/1")
                        .header("Authorization", "Bearer ", userDTO.getToken())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF-8"))
                .andExpect(status().isNotFound());
    }
}
