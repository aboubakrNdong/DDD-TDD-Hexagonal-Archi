package com.uptevia.ms.bff.investor.resource.domain.repository;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.DetailsFreqAskedQDTO;

import java.util.List;

public interface IFaqsRepository {
    List<DetailsFreqAskedQDTO> getFaqs(final String piLoggedFaq) throws FunctionnalException;
}
