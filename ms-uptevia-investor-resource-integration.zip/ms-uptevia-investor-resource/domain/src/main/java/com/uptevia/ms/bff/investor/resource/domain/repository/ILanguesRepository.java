package com.uptevia.ms.bff.investor.resource.domain.repository;


import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.LanguesDTO;

import java.util.List;

public interface ILanguesRepository {

    List<LanguesDTO> getLangues(String codeLangue) throws FunctionnalException;

}

