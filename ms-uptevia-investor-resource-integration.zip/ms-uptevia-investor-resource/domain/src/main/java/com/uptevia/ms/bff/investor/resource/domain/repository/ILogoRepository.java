package com.uptevia.ms.bff.investor.resource.domain.repository;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.LogoDTO;

public interface ILogoRepository {
    LogoDTO getLogo(final int idEmet) throws FunctionnalException;
}

