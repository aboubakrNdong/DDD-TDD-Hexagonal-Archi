package com.uptevia.ms.bff.investor.resource.domain.repository;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.ParametrageDTO;


public interface IParametrageRepository {
    ParametrageDTO getParamsSite(Integer emetIden, String paramName, String paramCategory) throws FunctionnalException;
}
