package com.uptevia.ms.bff.investor.resource.domain.repository;

import com.uptevia.ms.bff.investor.resource.domain.model.ThemeDTO;

import java.util.List;

public interface IThemeRepository {

    List<ThemeDTO> findThemes();
}
