package com.uptevia.ms.bff.investor.resource.domain.service;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.FaqsDTO;

import java.util.List;

public interface FaqService {

    List<FaqsDTO> getFaqs(final String piLoggedFaq) throws FunctionnalException;
}