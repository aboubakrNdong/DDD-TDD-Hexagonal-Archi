package com.uptevia.ms.bff.investor.resource.domain.service;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.ModuleDTO;

import java.util.List;

public interface ModuleService {
    List<ModuleDTO> getModule(final int idEmet, final int idActi, final int pTituNume) throws FunctionnalException;

}