package com.uptevia.ms.bff.investor.resource.domain.service;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.ParametrageDTO;

public interface ParametrageService {

    ParametrageDTO getParamsSite(Integer emetIden, String paramName, String paramCategory) throws FunctionnalException;
}
