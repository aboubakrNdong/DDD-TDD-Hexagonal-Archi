package com.uptevia.ms.bff.investor.resource.domain.service;

import com.uptevia.ms.bff.investor.resource.domain.model.ThemeDTO;

import java.util.List;

public interface ThemeService {

    public List<ThemeDTO> findThemes();

}
