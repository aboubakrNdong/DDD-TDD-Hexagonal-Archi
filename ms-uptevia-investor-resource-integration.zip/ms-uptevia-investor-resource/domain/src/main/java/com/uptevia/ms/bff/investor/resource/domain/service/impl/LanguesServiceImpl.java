package com.uptevia.ms.bff.investor.resource.domain.service.impl;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.LanguesDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.ILanguesRepository;
import com.uptevia.ms.bff.investor.resource.domain.service.LanguesService;

import java.util.List;

public class LanguesServiceImpl implements LanguesService {

    private final ILanguesRepository iLanguesRepository;

    public LanguesServiceImpl(final ILanguesRepository iLanguesRepository) {
        this.iLanguesRepository = iLanguesRepository;
    }

    @Override
    public List<LanguesDTO> getLangues(String codeLangue) throws FunctionnalException {
        return iLanguesRepository.getLangues(codeLangue);
    }

}