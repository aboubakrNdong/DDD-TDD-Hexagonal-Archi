package com.uptevia.ms.bff.investor.resource.domain.service.impl;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.*;
import com.uptevia.ms.bff.investor.resource.domain.repository.IModuleRepository;
import com.uptevia.ms.bff.investor.resource.domain.service.ModuleService;

import java.util.ArrayList;
import java.util.List;

import static com.uptevia.ms.bff.investor.resource.domain.service.impl.AbstractService.toBooleanStrict;
import static com.uptevia.ms.bff.investor.resource.domain.service.impl.FaqServiceImpl.distinctByKey;

public class ModuleServiceImpl implements ModuleService {
    private final IModuleRepository iModuleRepository;

    public ModuleServiceImpl(final IModuleRepository iModuleRepository) {
        this.iModuleRepository = iModuleRepository;
    }

    @Override
    public List<ModuleDTO> getModule(final int idEmet, final int idActi, final int pTituNume) throws FunctionnalException {
        List<ModuleDTO> moduleDTOS = new ArrayList<>();
        List<SousModuleDTO> result = iModuleRepository.getModule(idEmet, idActi, pTituNume);
        List<ModuleDTO> distinctModuleDTO;
        for (SousModuleDTO sousModuleDTO : result) {
            ModuleDTO object = createModuleDto(sousModuleDTO);
            object.setShowMenu(toBooleanStrict(sousModuleDTO.getModuleGroupeIndicateurMenu()));
            object.setSousModule(createSimplifiedSousModuleList(sousModuleDTO, result));
            moduleDTOS.add(object);
        }
        distinctModuleDTO = moduleDTOS.stream().filter(distinctByKey(ModuleDTO::getGroupeNom)).toList();

        return distinctModuleDTO;
    }

    private ModuleDTO createModuleDto(SousModuleDTO sousModuleDTO) {
        ModuleDTO object = new ModuleDTO();
        object.setGroupeNom(sousModuleDTO.getModuleGroupeNom());
        object.setGroupeUrl(sousModuleDTO.getModuleGroupeUrl().toLowerCase());
        object.setGroupeOrdre(sousModuleDTO.getModuleGroupeOrdre());
        object.setGroupeImgName(sousModuleDTO.getModuleGroupeImgName());
        return object;
    }

    private List<SousModuleDTO> createSimplifiedSousModuleList(SousModuleDTO sousModuleDTO, List<SousModuleDTO> allSousModules) {
        List<SousModuleDTO> simplifiedSousModule = new ArrayList<>();
        for (SousModuleDTO simplifiedSousModuleDTO : allSousModules) {
            if (sousModuleDTO.getModuleGroupeNom().equals(simplifiedSousModuleDTO.getModuleGroupeNom())) {
                SousModuleDTO simplifiedDTO = createSimplifiedSousModule(simplifiedSousModuleDTO);
                simplifiedSousModule.add(simplifiedDTO);
            }
        }
        return simplifiedSousModule;
    }

    private SousModuleDTO createSimplifiedSousModule(SousModuleDTO simplifiedSousModuleDTO) {
        return SousModuleDTO.builder()
                .moduleNom(simplifiedSousModuleDTO.getModuleNom())
                .moduleUrl(simplifiedSousModuleDTO.getModuleUrl().toLowerCase())
                .moduleOrdre(simplifiedSousModuleDTO.getModuleOrdre())
                .moduleIndicateurMenu(simplifiedSousModuleDTO.getModuleIndicateurMenu())
                .moduleImgName(simplifiedSousModuleDTO.getModuleImgName())
                .habiliteActi(simplifiedSousModuleDTO.isHabiliteActi())
                .habiliteEmet(simplifiedSousModuleDTO.isHabiliteEmet())
                .motifsBlocage(simplifiedSousModuleDTO.getMotifsBlocage())
                .build();
    }
}