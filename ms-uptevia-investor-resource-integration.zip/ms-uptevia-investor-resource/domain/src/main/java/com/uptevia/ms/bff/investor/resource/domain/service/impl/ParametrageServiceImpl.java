package com.uptevia.ms.bff.investor.resource.domain.service.impl;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.ParametrageDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.IParametrageRepository;
import com.uptevia.ms.bff.investor.resource.domain.service.ParametrageService;

public class ParametrageServiceImpl implements ParametrageService {

    private final IParametrageRepository iParametrageRepository;

    public ParametrageServiceImpl(IParametrageRepository iParametrageRepository) {
        this.iParametrageRepository = iParametrageRepository;
    }

    @Override
    public ParametrageDTO getParamsSite(Integer emetIden, String paramName, String paramCategory) throws FunctionnalException {
        return iParametrageRepository.getParamsSite(emetIden, paramName, paramCategory);
    }
}
