package com.uptevia.ms.bff.investor.resource.domain.service.impl;

import com.uptevia.ms.bff.investor.resource.domain.model.ThemeDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.IThemeRepository;
import com.uptevia.ms.bff.investor.resource.domain.service.ThemeService;

import java.util.List;

public class ThemeServiceImpl implements ThemeService {

    private final IThemeRepository themeRepository;

    public ThemeServiceImpl(final IThemeRepository themeRepository) {
        this.themeRepository = themeRepository;
    }

    @Override
    public List<ThemeDTO> findThemes() {
        return themeRepository.findThemes();
    }
}
