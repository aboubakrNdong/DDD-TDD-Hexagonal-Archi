package com.uptevia.ms.bff.investor.resource.domain.util;

/**
 * <b>Description : Utility java Class for constants used everywhere in the application</b>
 *
 * @author Farhat Bouchnak
 */
public class Constants {


    private Constants() {

    }

    public static final String AUTHORIZATION = "Authorization";

    public static final String LOGIN_TEXT_BAD_CREDENTIALS = "login.text.BadCredentials";

    public static final String SITE_GET_LANGUES = "SITE_GET_LANGUES";

    public static final String PS_CUR = "PS_CUR";
}
