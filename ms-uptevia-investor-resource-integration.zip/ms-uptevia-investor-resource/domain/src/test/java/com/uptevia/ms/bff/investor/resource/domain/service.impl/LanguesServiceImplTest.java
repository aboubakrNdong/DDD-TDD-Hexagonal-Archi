package com.uptevia.ms.bff.investor.resource.domain.service.impl;

import com.uptevia.ms.bff.investor.resource.domain.model.LanguesDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.ILanguesRepository;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.stream.Collectors;

@ExtendWith(MockitoExtension.class)
class LanguesServiceImplTest {

    @Mock
    private ILanguesRepository languesRepository;
    @InjectMocks
    LanguesServiceImpl languesService;
    private final EasyRandom easyRandom = new EasyRandom();


    @Test
    void should_return_languesService_ok() throws Exception {

        String codeLangue = "FRA";

        List<LanguesDTO> languesDTOS = easyRandom.objects(LanguesDTO.class, 2)
                .collect(Collectors.toList());

        languesDTOS.forEach(e -> {
            e.setLangueIso3("FRA");
            e.setLangueLibelle("Francais");
            e.setLangueOrdre("1");
        });

        Mockito.when(languesRepository.getLangues(codeLangue)).thenReturn(languesDTOS);
        Assertions.assertThat(languesService.getLangues(codeLangue)).hasSameSizeAs(languesDTOS);
    }

}

