package com.uptevia.ms.bff.investor.resource.domain.service.impl;

import com.uptevia.ms.bff.investor.resource.domain.model.TraductionDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.ITraductionRepository;
import org.assertj.core.api.Assertions;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.stream.Collectors;

@ExtendWith(MockitoExtension.class)
class TraductionServiceImplTest {

    @Mock
    private ITraductionRepository traductionRepository;

    @InjectMocks
    TraductionServiceImpl traductionService;

    private EasyRandom easyRandom = new EasyRandom();


    @Test
    void should_return_get_traductions_ok() throws Exception {

        List<TraductionDTO> traductions = easyRandom.objects(TraductionDTO.class, 5)
                .collect(Collectors.toList());


        traductions.forEach(
                        e -> {
                            e.setCodeLangue("fra");
                            e.setThemeId(1);
                        }
                );


        Mockito.when(traductionRepository.getAllTrads()).thenReturn(traductions);

        Assertions.assertThat(traductionService.getTrads("FRA", 1).size()).isEqualTo(traductions.size());

    }
}
