package com.uptevia.ms.bff.investor.resource.infra.mapper;

import com.uptevia.ms.bff.investor.resource.domain.model.LanguesDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;


public class LanguesRowMapper implements RowMapper<LanguesDTO> {

    @Override
    public LanguesDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        return LanguesDTO.builder()
                .langueIso3(rs.getString("LANGUE_ISO3"))
                .langueLibelle(rs.getString("LANGUE_LIBELLE"))
                .langueOrdre(rs.getString("LANGUE_ORDRE"))
                .build();
    }
}
