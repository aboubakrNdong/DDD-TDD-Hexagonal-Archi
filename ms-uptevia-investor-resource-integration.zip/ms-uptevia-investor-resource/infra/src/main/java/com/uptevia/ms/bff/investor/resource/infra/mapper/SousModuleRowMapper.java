package com.uptevia.ms.bff.investor.resource.infra.mapper;

import com.uptevia.ms.bff.investor.resource.domain.model.SousModuleDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

import static com.uptevia.ms.bff.investor.resource.domain.service.impl.AbstractService.toBooleanStrict;

public class SousModuleRowMapper implements RowMapper<SousModuleDTO> {
    @Override
    public SousModuleDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        return SousModuleDTO.builder()
                .moduleGroupeNom(rs.getString("module_groupe_traduction_key"))
                .moduleGroupeUrl(rs.getString("module_groupe_nom"))
                .moduleGroupeOrdre(rs.getInt("module_groupe_ordre"))
                .moduleGroupeImgName(rs.getString("module_groupe_img_filename"))
                .moduleNom(rs.getString("module_traduction_key"))
                .moduleUrl(rs.getString("module_nom"))
                .moduleOrdre(rs.getInt("module_ordre"))
                .moduleGroupeIndicateurMenu(rs.getString("module_groupe_indicateur_menu"))
                .moduleIndicateurMenu(rs.getString("module_indicateur_menu"))
                .moduleImgName(rs.getString("module_img_filename"))
                .habiliteActi(toBooleanStrict(rs.getString("habilite_actionnaire")))
                .habiliteEmet(toBooleanStrict(rs.getString("habilite_emetteur")))
                .motifsBlocage(List.of(rs.getString("habilite_actionnaire").toLowerCase()
                                        .split(";")).stream().map(cle_motif -> "habilitations.restriction.msg." + cle_motif)
                        .collect(Collectors.toList()))
                .build();
    }
}