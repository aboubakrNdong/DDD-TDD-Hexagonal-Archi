package com.uptevia.ms.bff.investor.resource.infra.mapper;

import com.uptevia.ms.bff.investor.resource.domain.model.ThemeDTO;
import com.uptevia.ms.bff.investor.resource.infra.db.entity.Theme;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ThemeDTOMapper {

    ThemeDTOMapper INSTANCE = Mappers.getMapper(ThemeDTOMapper.class);

    ThemeDTO themeToThemeDTO(Theme theme);


}
