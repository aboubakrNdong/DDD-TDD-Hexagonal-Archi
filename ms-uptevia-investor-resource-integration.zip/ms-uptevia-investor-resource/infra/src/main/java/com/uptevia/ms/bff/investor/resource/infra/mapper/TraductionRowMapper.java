package com.uptevia.ms.bff.investor.resource.infra.mapper;

import com.uptevia.ms.bff.investor.resource.domain.model.TraductionDTO;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TraductionRowMapper implements RowMapper<TraductionDTO> {
    @Override
    public TraductionDTO mapRow(ResultSet rs, int rowNum) throws SQLException {

        return TraductionDTO.builder()
                .key(rs.getString("CLE"))
                .libelle(rs.getString("LIBELLE"))
                .themeId(rs.getInt("THEME_ID"))
                .codeLangue(rs.getString("CODE_LANGUE"))
                .build();
    }
}
