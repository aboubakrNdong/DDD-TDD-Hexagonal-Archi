package com.uptevia.ms.bff.investor.resource.infra.repositories;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.DetailsFreqAskedQDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.IFaqsRepository;
import com.uptevia.ms.bff.investor.resource.domain.util.Constants;
import com.uptevia.ms.bff.investor.resource.infra.mapper.FaqDetailsRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Repository
public class FaqsRepository implements IFaqsRepository {

    Logger logger = Logger.getLogger(FaqsRepository.class.getName());

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;


    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }
    @Override
    public List<DetailsFreqAskedQDTO> getFaqs(String piLoggedFaq) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("UPI_GET_FAQ")
                .returningResultSet("PS_CUR",
                        new FaqDetailsRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("P_I_LOGGED_FAQ", piLoggedFaq);

        Map<String, Object> out = jdbcCall.execute(in);

        List<DetailsFreqAskedQDTO> result = (List<DetailsFreqAskedQDTO>) out.get("PS_CUR");

        if (result.isEmpty()) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("P_I_LOGGED_FAQ", piLoggedFaq);
            throw new FunctionnalException(Constants.LOGIN_TEXT_BAD_CREDENTIALS, Constants.LOGIN_TEXT_BAD_CREDENTIALS, contextParams);
        }

        return result;
    }
}
