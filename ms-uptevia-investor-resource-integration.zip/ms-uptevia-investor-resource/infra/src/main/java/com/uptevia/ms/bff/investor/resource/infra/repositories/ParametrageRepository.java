package com.uptevia.ms.bff.investor.resource.infra.repositories;

import com.uptevia.ms.bff.investor.resource.domain.exception.FunctionnalException;
import com.uptevia.ms.bff.investor.resource.domain.model.DetailsFreqAskedQDTO;
import com.uptevia.ms.bff.investor.resource.domain.model.ParametrageDTO;
import com.uptevia.ms.bff.investor.resource.domain.repository.IParametrageRepository;
import com.uptevia.ms.bff.investor.resource.infra.mapper.FaqDetailsRowMapper;
import com.uptevia.ms.bff.investor.resource.infra.mapper.ParametrageRowMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Repository
public class  ParametrageRepository implements IParametrageRepository {

    Logger logger = Logger.getLogger(ParametrageRepository.class.getName());

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Value("${jdbc.fetch.size.default}")
    private int fetchSize;


    @PostConstruct
    public void init() {
        // o_name and O_NAME, same
        jdbcTemplate.setResultsMapCaseInsensitive(true);
        jdbcTemplate.setFetchSize(fetchSize);
    }
    @Override
    public ParametrageDTO getParamsSite(Integer emetIden, String paramName, String paramCategory) throws FunctionnalException {

        SimpleJdbcCall jdbcCall = new SimpleJdbcCall(jdbcTemplate)
                .withProcedureName("SITE_GET_PARAM")
                .returningResultSet("PS_CUR",
                        new ParametrageRowMapper());

        SqlParameterSource in = new MapSqlParameterSource()
                .addValue("PARAM_EMET_IDEN", emetIden)
                .addValue("PARAM_PARAM_NAME", paramName)
                .addValue("PARAM_PARAM_ENV", null)
                .addValue("PARAM_PARAM_CATEGORY", paramCategory);

        Map<String, Object> out = jdbcCall.execute(in);

        List<ParametrageDTO> result = (List<ParametrageDTO>) out.get("PS_CUR");

        if (result == null) {
            Map<String, Object> contextParams = new HashMap<>();
            contextParams.put("PARAM_EMET_IDEN", emetIden);
            contextParams.put("PARAM_PARAM_NAME", paramName);
            throw new FunctionnalException("EDX", "Empty_Data_Exception", contextParams);
        }

        return result.get(0);
    }
}
