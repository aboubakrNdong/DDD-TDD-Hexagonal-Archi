## Install dependencies
Run `npm install` to install node_modules
## Build Uptevia lib common-ui
Run `npm start build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Publishing

After building your library with `npm run build`,  run `npm run publish`.

## Build + publishing
 run `npm run build-pub`.