import { Component, Input } from '@angular/core';


@Component({
  selector: 'uptevia-ui-amount-detail',
  templateUrl: './amount-detail.component.html',
  styleUrls: ['./amount-detail.component.css'],
})
export class AmountDetailComponent {
  @Input() amount: any;
  @Input() label: string;
  @Input() size: 'small' | 'medium' | 'large' | 'x-large' | 'xx-large' | 'xxx-large' = 'medium';
  @Input() amountColor: string;
  @Input() labelColor: string;
  

}
