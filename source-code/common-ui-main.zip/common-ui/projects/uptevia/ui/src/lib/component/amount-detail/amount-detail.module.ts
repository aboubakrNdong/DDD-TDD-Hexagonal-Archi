import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AmountDetailComponent } from './amount-detail.component';
import { LabelModule } from '../label/label.module';



@NgModule({
  declarations: [
    AmountDetailComponent,
  ],
  imports: [
    CommonModule,
    LabelModule
  ],
  exports: [
    AmountDetailComponent
  ]
})
export class AmountDetailModule { }
