import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BlocProfilComponent } from './bloc-profil.component';

describe('BlocProfilComponent', () => {
  let component: BlocProfilComponent;
  let fixture: ComponentFixture<BlocProfilComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BlocProfilComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BlocProfilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
