import { Component, Input } from '@angular/core';

@Component({
  selector: 'uptevia-ui-bloc-profil',
  templateUrl: './bloc-profil.component.html',
  styleUrls: ['./bloc-profil.component.css']
})
export class BlocProfilComponent {

  @Input()
  dataToDisplay: any | null = null;
  unsorted = (a:any, b:any) => {
    return a;
  }
}
