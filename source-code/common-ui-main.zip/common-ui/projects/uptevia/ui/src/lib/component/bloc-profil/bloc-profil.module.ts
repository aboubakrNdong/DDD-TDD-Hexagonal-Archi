import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BlocProfilComponent } from './bloc-profil.component';



@NgModule({
  declarations: [
    BlocProfilComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    BlocProfilComponent
  ]
})
export class BlocProfilModule { }
