import { Component, Input } from '@angular/core';

@Component({
  selector: 'uptevia-ui-bloc',
  templateUrl: './bloc.component.html',
  styleUrls: ['./bloc.css'],
})
export class BlocComponent {
  @Input()
  user: any= null;

  @Input()
  trad: any = null;

}
