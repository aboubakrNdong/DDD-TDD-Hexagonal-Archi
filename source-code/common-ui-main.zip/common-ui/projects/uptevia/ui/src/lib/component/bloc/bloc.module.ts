import { NgModule } from '@angular/core';
import { BlocComponent } from './bloc.component';
import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [
    BlocComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    BlocComponent
  ]
})
export class BlocModule { }
