import { Component, Input } from '@angular/core';

@Component({
  selector: 'uptevia-ui-button-toggle',
  templateUrl: './button-toggle.component.html',
  styleUrls: ['./button-toggle.component.css']
})
export class ButtonToggleComponent {

  /**
  * Button contents
  *
  * @required
  */
  @Input() label = 'Button';

  /**
 * icone
 *
 * @required
 */
  @Input() icon: string;

}
