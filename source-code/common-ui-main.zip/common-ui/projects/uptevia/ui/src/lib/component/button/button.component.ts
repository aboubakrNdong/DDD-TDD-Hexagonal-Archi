import { Component, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'uptevia-ui-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css'],
})
export class ButtonComponent {
  @Input() disabled: boolean = false;
  @Input() color: string = 'primary';

  /**
   * How large should the button be?
   */
  @Input() size: 'xsmall' | 'small' | 'medium' | 'large' | 'unset' = 'medium';

    /**
   * What should be displayed first : text or image ? 
   */

  @Input() direction : "normal" | "reverse" | "column" = "normal"; 

  /**
   * Which font-family should be applied ? 
   */

  @Input() font: 'Montserrat' | 'Inter' = 'Inter';

  @Input() weight : 'normal' | 'bold'

  /**
   * Button contents
   *
   * @required
   */
  @Input() label = 'Button';

  /**
 * icone
 *
 * @required
 */
  @Input() icon: string;

  /**
   * Optional click handler
   */
  @Output()
  onClick = new EventEmitter<Event>();


  public get classes(): string[] {
    let classes = [`uptevia-ui-button--${this.color}`, `uptevia-ui-button--${this.size}`, `uptevia-ui-button--${this.direction}`, `uptevia-ui-button--${this.font}`, `uptevia-ui-button--${this.weight}`]
    if (this.disabled) {
      classes.push('disabled-button')
    }
    return classes;
  }
}
