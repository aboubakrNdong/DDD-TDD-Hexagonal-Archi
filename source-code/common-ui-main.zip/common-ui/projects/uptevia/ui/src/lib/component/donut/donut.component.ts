import { AfterViewInit, Component, ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { Chart } from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
Chart.register(ChartDataLabels);

@Component({
  selector: 'uptevia-ui-donut',
  templateUrl: './donut.component.html',
  styleUrls: ['./donut.component.css'],
})
export class DonutComponent implements AfterViewInit {
  ngAfterViewInit(): void {
    this.createChart();
  }
  /**
    * Optional click handler
    */
  @Output() chartClick = new EventEmitter<Object>();
  @Input() doughnutData: any[] = [];
  @Input() backgroundColors = ['rgb(0, 86, 111)', 'rgb(236, 102, 8)', 'rgb(0, 164, 183)', 'rgb(11, 140, 19)',];
  @ViewChild('myChart', { static: true }) myChart: ElementRef<HTMLCanvasElement>;

  chart: any;
  lang = localStorage.getItem('lang')
  /** 
 * createChart() initialze the chartjs after the view is ready
 */
  createChart() {
    this.chart = new Chart(this.myChart.nativeElement, {
      type: 'doughnut', //this denotes tha type of chart

      data: {
        datasets: [
          //data and BackgroundColors as Inouts for the component
          {
            data: this.doughnutData,
            backgroundColor: this.backgroundColors,
          },
        ],
      },
      options: {
        onClick: this.onClickChart.bind(this),
        responsive: true,
        // radius: 140,
        maintainAspectRatio: false,
        events: ['click'],
        plugins: {
          tooltip: {
            enabled: false,
            displayColors: false,
          },
          datalabels: {
            formatter: (value, context) => {
              const formattedVal = new Intl.NumberFormat(this.lang === 'fr' ? 'fr-FR' : 'en-US', {
                style: 'decimal'
              }).format(value);
              return formattedVal
            },
            color: 'black',
            font: {
              size: 20,
              weight: 700
            },
            textAlign: "center"
          },
        },
      },
    });
  }
  /**
   * 
   * @param e $event
   * @param activeElement 
   */
  public onClickChart(e: any, activeElement: any[]): void {
    if (activeElement.length > 0) {
      // console.log("click chart", activeElement[0].element)
      //get element clicked Index
      const index = activeElement[0].index;
      //get element clicked Value
      const value = e.chart.data.datasets[0].data[index]
      const eventData = { index, value };
      //Emit the onClickChart event with event data
      this.chartClick.emit(eventData);
    }
  }
}
