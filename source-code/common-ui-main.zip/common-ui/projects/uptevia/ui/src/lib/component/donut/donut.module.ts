import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DonutComponent } from './donut.component';
import { NgChartsModule } from 'ng2-charts';



@NgModule({
  declarations: [
    DonutComponent
  ],
  imports: [
    CommonModule,
    NgChartsModule
  ],
  exports: [
    DonutComponent
  ]
})
export class DonutModule { }
