import { Component, Input } from '@angular/core';

@Component({
  selector: 'uptevia-ui-fileariane',
  templateUrl: './file-ariane.component.html',
  styleUrls: ['./file-ariane.component.css'],
})
export class FileArianeComponent {
  @Input() url: string;
  @Input() label: string;
  @Input() last: boolean = true;
}
