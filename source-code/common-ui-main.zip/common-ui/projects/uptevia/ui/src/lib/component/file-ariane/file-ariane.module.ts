import { NgModule } from '@angular/core';
import { FileArianeComponent } from './file-ariane.component';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    FileArianeComponent
  ],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports: [
    FileArianeComponent
  ]
})
export class FileArianeModule { }
