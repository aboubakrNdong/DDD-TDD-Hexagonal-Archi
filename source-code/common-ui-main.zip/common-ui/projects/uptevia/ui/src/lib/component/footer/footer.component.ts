import { Component, Input } from '@angular/core';

@Component({
  selector: 'uptevia-ui-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css'],
})
export class FooterComponent   {

  
  @Input()
  boukmarkSecurite: string = '';

  lienSecurite: string = 'https://www.uptevia.com/plan-site/';
  @Input()
  bookmarkRGPD: string = '';

  lienRGPD = 'https://www.uptevia.com/legal/notice-protection-des-donnees/';

  @Input()
  bookmarkMentions: string = '';

  lienMentionsLeg = 'https://www.uptevia.com/legal/mentions-legales/'
 
}
