import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FooterComponent } from './footer.component';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LinkComponent } from '../link/link.component';

@NgModule({
    declarations: [
      FooterComponent,
      LinkComponent
    ],
    imports: [
      CommonModule,
      FormsModule
    ],
    exports: [
      FooterComponent
    ],
    schemas:[
      CUSTOM_ELEMENTS_SCHEMA
    ]
  })
  export class FooterModule { }