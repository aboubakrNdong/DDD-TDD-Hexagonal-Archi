import { Component, Input } from '@angular/core';

@Component({
  selector: 'uptevia-ui-image',
  template: '<img [src]="source" [ngStyle]="classes" alt="">',
  styleUrls: ['./image.component.css']
})
export class ImageComponent {

  

  @Input() source?: any;

  @Input() width: string = '100px'; //choisi valeur par default expemple 100px
  
  @Input() height: string = '100px' //choisi valeur par default expemple 100px

 

  public get classes() {
   
    return { 'width':this.width, 'height':this.height, }
  
  }


}
