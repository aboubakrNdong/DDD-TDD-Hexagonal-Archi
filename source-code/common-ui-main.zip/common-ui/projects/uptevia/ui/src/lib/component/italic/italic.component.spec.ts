import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ItalicComponent } from './italic.component';

describe('ItalicComponent', () => {
  let component: ItalicComponent;
  let fixture: ComponentFixture<ItalicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ItalicComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItalicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
