import { Component, Input } from '@angular/core';

@Component({
  selector: 'uptevia-ui-italic',
  templateUrl: './italic.component.html',
  styleUrls: ['./italic.component.css'],
})
export class ItalicComponent  {

  @Input() 
  destination: string = '';

 

}
