import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ItalicComponent } from './italic.component';
import { RouterModule } from '@angular/router';



@NgModule({
  declarations: [
    ItalicComponent
  ],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports: [
    ItalicComponent
  ]
})
export class ItalicModule { }
