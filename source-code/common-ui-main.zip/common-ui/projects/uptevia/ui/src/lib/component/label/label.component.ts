import { Component, Input  } from '@angular/core';


@Component({
  selector: 'uptevia-ui-label',
  templateUrl: './label.component.html',
  styleUrls: ['./label.component.css'],
})
export class LabelComponent {
  @Input() size: 'small' | 'medium' | 'ml' | 'large' | 'x-large' | 'xx-large' | 'xxx-large' = 'medium';
  @Input() color: string;
  @Input() label:any; 
  @Input() weight:number;
  
 }
