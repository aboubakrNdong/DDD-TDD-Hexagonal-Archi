import { NgModule } from '@angular/core';
import { LabelComponent } from './label.component';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [
    LabelComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    LabelComponent
  ]
})
export class LabelModule { }
