import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListBlocprofilComponent } from './list-blocprofil.component';

describe('ListBlocprofilComponent', () => {
  let component: ListBlocprofilComponent;
  let fixture: ComponentFixture<ListBlocprofilComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListBlocprofilComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListBlocprofilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
