import { Component, Input } from '@angular/core';

@Component({
  selector: 'lib-list-blocprofil',
  templateUrl: './list-blocprofil.component.html',
  styleUrls: ['./list-blocprofil.component.css']
})
export class ListBlocprofilComponent  {

  @Input()
  dataToDisplay: any = null;

   

}
