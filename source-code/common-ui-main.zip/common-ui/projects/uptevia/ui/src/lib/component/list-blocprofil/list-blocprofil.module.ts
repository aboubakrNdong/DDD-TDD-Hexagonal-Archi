import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListBlocprofilComponent } from './list-blocprofil.component';



@NgModule({
  declarations: [
    ListBlocprofilComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
   ListBlocprofilComponent
  ]
})
export class ListBlocprofilModule { }
