import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';


@Component({
  selector: 'uptevia-ui-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
 

  username: string = '';
  password: string = '';
  
  @Input() trad: any | null = null;
  
      /**
   * Optional click handler
   */
  @Output()  onClick = new EventEmitter<Object>();
  
  sendEvent(e:Event) {
    this.onClick.emit({login:this.username,psw:this.password});
  }

}
