import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { LoginComponent } from './login.component';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';
import { ButtonModule } from '../button/button.module';
import { LabelModule } from '../label/label.module';


@NgModule({
  declarations: [
    LoginComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ButtonModule,
    LabelModule
  ],
  exports: [
    LoginComponent
  ],
  schemas:[
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class LoginModule { }
