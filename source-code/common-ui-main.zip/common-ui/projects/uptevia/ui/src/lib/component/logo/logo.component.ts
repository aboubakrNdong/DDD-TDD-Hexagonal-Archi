import { Component, Input } from '@angular/core';

@Component({
  selector: 'uptevia-ui-logo',
  templateUrl: './logo.component.html',
  styleUrls: ['./logo.component.css']
})
export class LogoComponent {

  

  @Input() source?: any;

  @Input() link?: string;


  


  openLink() {
    if (this.link) {
      window.open(this.link, '_blank')
    }
  }
}
