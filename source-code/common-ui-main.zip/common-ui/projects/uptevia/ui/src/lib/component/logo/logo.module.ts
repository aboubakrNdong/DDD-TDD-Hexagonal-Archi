import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { LogoComponent } from './logo.component';


@NgModule({
  declarations: [
    LogoComponent
  ],
  imports: [
    CommonModule,
  ],
  exports: [
    LogoComponent
  ],
  schemas:[
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class LogoModule { }
