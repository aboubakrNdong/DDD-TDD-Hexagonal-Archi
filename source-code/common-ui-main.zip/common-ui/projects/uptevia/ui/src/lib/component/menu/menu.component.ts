
import { Router } from '@angular/router';
import { Component, EventEmitter, Input, Output } from '@angular/core';


@Component({
  selector: 'uptevia-ui-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent {
  @Input() menu: any;
  @Input() isOpen: boolean = false;
  @Output() toggle = new EventEmitter<Event>();
  constructor(private router: Router) { }


  open(menu: any) {
    if (menu && menu.showMenu) {
      this.toggle.emit();
    } else {
      this.router.navigate([menu.groupeUrl]);
    }
  }
}
