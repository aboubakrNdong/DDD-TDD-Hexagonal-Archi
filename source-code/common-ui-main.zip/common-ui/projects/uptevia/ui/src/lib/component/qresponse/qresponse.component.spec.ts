import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QresponseComponent } from './qresponse.component';

describe('QresponseComponent', () => {
  let component: QresponseComponent;
  let fixture: ComponentFixture<QresponseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QresponseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QresponseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
