import { Component, Input } from '@angular/core';

@Component({
  selector: 'uptevia-ui-qresponse',
  templateUrl: './qresponse.component.html',
  styleUrls: ['./qresponse.component.css']
})
export class QresponseComponent  {

  @Input()
  title = '';

  @Input()
  text = '';



}
