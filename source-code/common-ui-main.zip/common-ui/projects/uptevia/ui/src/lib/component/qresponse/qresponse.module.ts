import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';  
import { QresponseComponent } from './qresponse.component';

@NgModule({
  declarations: [
    QresponseComponent
  ],
  imports: [
    CommonModule,
    FormsModule, 
  ],
  exports: [
    QresponseComponent
  ],
  schemas:[
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class QresponseModule { }
