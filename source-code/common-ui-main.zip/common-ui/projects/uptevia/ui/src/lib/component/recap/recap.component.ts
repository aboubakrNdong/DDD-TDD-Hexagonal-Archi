import { Component, ContentChild, Input, Output, TemplateRef, EventEmitter } from '@angular/core';
 


@Component({
  selector: 'uptevia-ui-recap',
  templateUrl: './recap.component.html',
  styleUrls: ['./recap.component.css'],
})
export class RecapComponent {
  @ContentChild('icon') icon!: TemplateRef<any>;
  @Input() image: string;
  @Input() title: string;
  @Input() labels: string[] = [];
  @Input() values: any[] = [];
  @Input() buttonLabel: string;
  @Output()  onClick = new EventEmitter<Event>();


}
