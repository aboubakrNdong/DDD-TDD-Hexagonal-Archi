import { NgModule } from '@angular/core';
import { RecapComponent } from './recap.component';
import { CommonModule } from '@angular/common';
import { ButtonModule } from '../button/button.module';



@NgModule({
  declarations: [
    RecapComponent
  ],
  imports: [
    CommonModule,
    ButtonModule
  ],
  exports: [
    RecapComponent
  ]
})
export class RecapModule { }
