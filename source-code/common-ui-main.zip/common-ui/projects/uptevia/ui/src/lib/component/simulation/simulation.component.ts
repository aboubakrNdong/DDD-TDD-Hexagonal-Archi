import { Component, ContentChild, Input, TemplateRef } from '@angular/core';


@Component({
  selector: 'uptevia-ui-simulation',
  templateUrl: './simulation.component.html',
  styleUrls: ['./simulation.component.css'],
})
export class SimulationComponent {
  @ContentChild('icon') icon!: TemplateRef<any>;
  @Input() image: string;
  @Input() title: string;
  @Input() placeHolder: string;
  @Input() labels:string[] = [];
  @Input() amounts: any;
  @Input() tooltip : number[]=[];
  @Input() isValid : boolean=false;

  get showTooltip(): (index:number)=>boolean{
    return   (index:number)=>{
      return this.tooltip.includes(index) ;
    }
  }
 }
