import { NgModule } from '@angular/core';
import { SimulationComponent } from './simulation.component';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [
    SimulationComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    SimulationComponent
  ]
})
export class SimulationModule { }
