import { Component, Input } from '@angular/core';

@Component({
  selector: 'uptevia-ui-step',
  templateUrl: './step.component.html',
  styleUrls: ['./step.component.css']
})
export class StepComponent {
  @Input() steps: string[];
  @Input() currentStep = 0;
}
