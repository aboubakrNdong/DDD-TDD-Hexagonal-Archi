import { Component, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'uptevia-ui-stock-type',
  templateUrl: './stock-type.component.html',
  styleUrls: ['./stock-type.component.css'],
})
export class StockTypeComponent {
  @Input() title: string = '';
  @Input() image: string = '';
  @Input() placeholder: string = '';
  @Input() list: any[] | undefined;
  @Input() type: string;

  /**
   * Optional click handler
   */
  @Output() onSelect = new EventEmitter<Event>();
  @Output() onClick = new EventEmitter<Event>();
  selected(event: any) {
    this.onSelect.emit(event);
  }
}
