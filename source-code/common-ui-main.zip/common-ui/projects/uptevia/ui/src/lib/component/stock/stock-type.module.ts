import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StockTypeComponent } from './stock-type.component';



@NgModule({
  declarations: [
    StockTypeComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    StockTypeComponent
  ]
})
export class StockTypeModule { }
