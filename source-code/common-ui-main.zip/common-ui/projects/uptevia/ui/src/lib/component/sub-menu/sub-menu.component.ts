import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Router, } from '@angular/router';


@Component({
  selector: 'uptevia-ui-sub-menu',
  templateUrl: './sub-menu.component.html',
  styleUrls: ['./sub-menu.component.css']
})
export class SubMenuComponent {
  @Input() typeMenu: string;
  @Input() label: string;
  @Input() route: any;
  @Input() currentRoute: string;
  @Input() display = true;
  @Output() onClick = new EventEmitter<any>();
  constructor(private router: Router) { }
  public get classes(): string[] {
    const classeList = [`class-${this.typeMenu}`]
    if (this.route === this.currentRoute) {
      classeList.push('selected');
    }
    return classeList;
  }

  onItemClick(event: Event) {
    event.stopPropagation();
    this.onClick.emit();
    this.router.navigate([this.route]);
  }
}

