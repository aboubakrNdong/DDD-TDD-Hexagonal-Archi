import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SubMenuComponent } from './sub-menu.component';
import { RouterModule } from '@angular/router';



@NgModule({
  declarations: [
    SubMenuComponent
  ],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports: [
    SubMenuComponent
  ],
  schemas:[
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class SubMenuModule { }
