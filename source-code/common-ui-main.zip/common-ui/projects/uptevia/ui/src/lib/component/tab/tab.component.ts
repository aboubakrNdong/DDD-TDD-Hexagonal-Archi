import { Component, EventEmitter, Input, Output, TemplateRef } from '@angular/core';

@Component({
  template:'',
  selector: 'uptevia-ui-tab',
})
export class TabComponent {
  @Input() tabName: any;
  @Input() templateRef!: TemplateRef<any>;
  @Input() content?: any;
  @Input() route  : string;
 

 
}
