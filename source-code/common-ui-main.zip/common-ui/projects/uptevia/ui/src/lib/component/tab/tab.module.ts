import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TabComponent } from './tab.component';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';  

@NgModule({
  declarations: [
    TabComponent
  ],
  imports: [
    CommonModule,
    FormsModule, 
  ],
  exports: [
    TabComponent
  ],
  schemas:[
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class TabModule { }
