import { Component, ContentChildren, Input, QueryList, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { TabComponent } from '../tab/tab.component';



@Component({
  selector: 'uptevia-ui-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.css'],
})
export class TabsComponent {

  @Input() color: string;
  @Input() activeRoute: string;
  @Output() onClick: EventEmitter<string> = new EventEmitter<string>();
  @ContentChildren(TabComponent) tabs!: QueryList<TabComponent>;
  activeComponent!: TabComponent;

  ngAfterContentInit() {
    let active: TabComponent[] = []
    if (this.activeRoute) {
      active = this.tabs.filter(tab => tab.route === this.activeRoute)
    }
    this.activeComponent = active.length > 0 ? active[0] : this.tabs.first;
  }

  activateTab(tab: TabComponent) {
    this.activeComponent = tab;
    this.onClick.emit(tab.route)
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.activeRoute && this.tabs) {
      let active = this.tabs.filter(tab => tab.route === changes['activeRoute'].currentValue);
      this.activeComponent = active.length > 0 ? active[0] : this.tabs.first;
    }
  }

  public get classes(): string[] {
    let classes = [`nav-tabs--${this.color}`]
    return classes;
  }
}
