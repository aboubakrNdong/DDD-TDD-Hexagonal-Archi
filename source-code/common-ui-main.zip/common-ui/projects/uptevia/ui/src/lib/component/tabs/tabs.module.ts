import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TabsComponent } from './tabs.component';
import { CommonModule } from '@angular/common';  
import { FormsModule } from '@angular/forms';  

@NgModule({
  declarations: [
    TabsComponent
  ],
  imports: [
    CommonModule,
    FormsModule, 
  ],
  exports: [
    TabsComponent
  ],
  schemas:[
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class TabsModule { }
