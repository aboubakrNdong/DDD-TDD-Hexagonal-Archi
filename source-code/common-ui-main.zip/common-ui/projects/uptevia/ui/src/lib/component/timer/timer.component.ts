import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'uptevia-ui-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.css']
})
export class TimerComponent {

  @Input() pictoSource: string;
  @Input() title: string;
  @Input() description: string;
  @Input() buttonLabel: string;
  @Input() iconSource: string;
  @Output() onClick = new EventEmitter<Event>();

  stayConnected() {
    this.onClick.emit();
  }
}