import { Component, Input } from '@angular/core';

@Component({
  selector: 'uptevia-ui-title',
  templateUrl: './title.component.html',
  styleUrls: ['./title.component.css']
})
export class TitleComponent {
  @Input()
  title: string = "";

  /* To define the size oh title. <h1> to <h6> tags */
  @Input()
  hsize!: '1' | '2' | '3' | '4'| '5' | '6';
  
  @Input()
  textColor?: string;

  public get classes(): string[] {
    return ['uptevia-ui-title', `uptevia-ui-title-h${this.hsize}`];
  }
}
