import { Component, Input, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'uptevia-ui-valeur',
  templateUrl: './valeur.component.html',
  styleUrls: ['./valeur.component.css'],
})
export class ValeurComponent {
  @Input() valeIden: string = '';
  @Input() libelle: string = '';
  @Input() coursValeur: string = '';
  @Input() dernierCours: any ; 

  /**
   * Optional click handler
   */
  @Output() onClick = new EventEmitter<Event>();

}
