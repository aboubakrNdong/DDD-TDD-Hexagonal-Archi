import { NgModule } from '@angular/core';
import { ValeurComponent } from './valeur.component';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [
    ValeurComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    ValeurComponent
  ]
})
export class ValeurModule { }
