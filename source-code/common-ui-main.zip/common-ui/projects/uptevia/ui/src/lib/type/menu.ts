export interface Menu{
    href?: string;
    label?: string;
}