import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { DocumentationsTabComponent } from './pages/documentations-tab/documentations-tab.component';
import { LoginContainerComponent } from './pages/login-container/login-container.component';
import { OperationsComponent } from './pages/operations/operations.component';
import { ParametersComponent } from './pages/parameters/parameters.component';
import { PortfeuillePageComponent } from './pages/portfeuille/portfeuille.component';
import { HomeGuard } from './services/home.guard';
import { LoginGuard } from './services/login.guard';
import { HabilitationGuard } from './services/permission.service';



const routes: Routes = [
  {
    path: '',
    component: DashboardComponent,
    data: { breadcrumb: 'dashboard.item.title' },
    canActivate: [HomeGuard],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },

      { path: 'dashboard', loadChildren: () => import('./pages/home/home.module').then(d => d.HomeModule) },
      {
        path: '',
        component: PortfeuillePageComponent,
        data: { breadcrumb: 'layout.menu.portefeuille' },
        children: [
          { path: '', redirectTo: 'droits', pathMatch: 'full' },
          {
            path: 'titres', loadChildren: () => import('./pages/portfeuille/titres-page/titres-page.module').then(t => t.TitresPageModule),
            canActivate: [HabilitationGuard], data: { route: 'titres', parent: 'portefeuille' }
          },
          {
            path: 'droits', loadChildren: () => import('./pages/portfeuille/droits-page/droits-page.module').then(t => t.DroitsPageModule),
            canActivate: [HabilitationGuard], data: { route: 'droits', parent: 'portefeuille' }
          },
          {
            path: 'fonds', loadChildren: () => import('./pages/portfeuille/fonds-page/fonds-page.module').then(t => t.FondsPageModule),
            canActivate: [HabilitationGuard], data: { route: 'fonds', parent: 'portefeuille' }
          }
        ]
      },
      {
        path: 'histo_ope', loadChildren: () => import('./pages/historique-ops/historique-ops.module').then(d => d.HistoriqueOpsModule),
        canActivate: [HabilitationGuard], data: { route: 'histo_ope', parent: 'suivi_operations' }
      },
      {
        path: 'profil', loadChildren: () => import('./pages/profil/profil.module').then(d => d.ProfilModule),
        canActivate: [HabilitationGuard], data: { route: 'profil', parent: 'profil' }
      },
       
      { path: 'contact', loadChildren: () => import('./pages/contact-us/contact-us.module').then(d => d.ContactUsModule) },
      {
        path: '', component: OperationsComponent, data: { breadcrumb: 'layout.menu.passage' },
        children: [
          { path: '', redirectTo: 'achat', pathMatch: 'full' },
          {
            path: 'operation_acheter', loadChildren: () => import('./pages/operations/achat/acheter.module').then(d => d.AcheterPageModule),
            canActivate: [HabilitationGuard], data: { route: 'operation_acheter', parent: 'passage_operations' }
          },
          {
            path: 'operation_vendre', loadChildren: () => import('./pages/operations/vente/vente.module').then(d => d.VentePageModule),
            canActivate: [HabilitationGuard], data: { route: 'operation_vendre', parent: 'passage_operations' }
          },
          {
            path: 'operation_exercer', loadChildren: () => import('./pages/operations/levee/levee.module')
              .then(d => d.ExercerPageModule), canActivate: [HabilitationGuard], data: { route: 'operation_exercer', parent: 'passage_operations' }
          }
        ]
      },

      {
        path: '', component: ParametersComponent, data: { breadcrumb: 'layout.menu.parametres' },
        children: [
          { path: '', redirectTo: 'parametres', pathMatch: 'full' },
          {
            path: 'maj_password', loadChildren: () => import('./pages/parameters/update-password/update-password.module').then(d => d.UpdatePasswordModule),
            canActivate: [HabilitationGuard], data: { route: 'maj_password', parent: 'parametres' }
          },
          {
            path: 'e_services', loadChildren: () => import('./pages/parameters/e-services/e-services.module').then(d => d.EServicesModule),
            canActivate: [HabilitationGuard], data: { route: 'e_services', parent: 'parametres' }
          },
        ]
      },

      {
        path: '', component: DocumentationsTabComponent, data: { breadcrumb: 'layout.menu.documentation' },
        children: [
          { path: '', redirectTo: 'documentation', pathMatch: 'full' },
          {
            path: 'doc_generique', loadChildren: () => import('./pages/documentations-tab/documentations-tab.module').then(d => d.DocumentationsTabModule),
            canActivate: [HabilitationGuard], data: { route: 'doc_generique', parent: 'documentation' }
          },
        ]
      }
    ]
  },
  {
    path: '', component: LoginContainerComponent, data: { breadcrumb: 'general.text.seConnecter' },
    children: [
      { path: '', redirectTo: 'login', pathMatch: 'full' },
      { path: 'contact-us', loadChildren: () => import('./pages/contact-us/contact-us.module').then(d => d.ContactUsModule), },
      { path: 'login', loadChildren: () => import('./pages/login-container/login/login.module').then(d => d.LoginModule), canActivate: [LoginGuard] },
      { path: 'firstconnexion', loadChildren: () => import('./pages/login-container/firstconnexion/firstconnexion.module').then(d => d.FirstConnexionModule), },
      { path: 'ancienolis', loadChildren: () => import('./pages/login-container/ancienolis/ancienolis.module').then(d => d.AncienOlisModule), },
      { path: 'ancienpls', loadChildren: () => import('./pages/login-container/ancienpls/ancienpls.module').then(d => d.AncienPlsModule), },
      { path: 'ancienolis-upi', loadChildren: () => import('./pages/login-container/ancienolissecond/ancienolissecond.module').then(d => d.AncienOlisSecondModule), },
      { path: 'ancienolisorpls', loadChildren: () => import('./pages/login-container/ancienolisorpls/ancienolisorpls.module').then(d => d.AncienOrPlsModule), },
      { path: 'forgotcredentials', loadChildren: () => import('./pages/login-container/forgotcredentials/forgotcredentials.module').then(d => d.ForgotCredentialsModule), },
      { path: 'forgotidentifiant', loadChildren: () => import('./pages/login-container/forgot-identifiant/forgot-identifiant.module').then(d => d.ForgotIdentifiantModule), },
      { path: 'forgotpassword', loadChildren: () => import('./pages/forgot-password/forgot-password.module').then(d => d.ForgotPasswordModule), },
      { path: 'resetsuccess', loadChildren: () => import('./pages/resetpasswordsuccess/resetpasswordsuccess.module').then(d => d.ResetPasswordSuccessModule), },
      { path: 'firstconnexion-upi', loadChildren: () => import('./pages/login-container/firstconnexionsecond/firstconnexionsecond.module').then(d => d.FirstConnexionSecondModule), },
      { path: 'ancienolis-upi', loadChildren: () => import('./pages/login-container/ancienolissecond/ancienolissecond.module').then(d => d.AncienOlisSecondModule), },
      { path: 'setpassword', loadChildren: () => import('./pages/login-container/ancienplssecond/ancienplssecond.module').then(d => d.AncienPlsSecondModule), },
      { path: 'loginwithsms', loadChildren: () => import('./pages/login-container/loginwithsms/loginwithsms.module').then(d => d.LoginWithSmsModule), },
      { path: 'loginwithoutsms', loadChildren: () => import('./pages/login-container/loginwithoutsms/loginwithoutsms.module').then(d => d.LoginWithoutSmsModule), },
     ]
  },

  { path: '', redirectTo: 'home', pathMatch: 'full' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
