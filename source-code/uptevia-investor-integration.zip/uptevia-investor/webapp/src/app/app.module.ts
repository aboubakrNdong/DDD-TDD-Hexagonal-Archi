import { CommonModule, CurrencyPipe, HashLocationStrategy, LocationStrategy, registerLocaleData } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import localeFr from '@angular/common/locales/fr';
import { CUSTOM_ELEMENTS_SCHEMA, LOCALE_ID, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ComponentsModule } from './components/components.module';
import { LoaderModule } from './components/loader/loader.module';
import { PasswordModalComponent } from './components/password-modal/password-modal.component';
import { WarningModalComponent } from './components/warning-modal/warning-modal.component';
import { I18nModule } from './i18n/i18n.module';
import { PagesModule } from './pages/pages.module';
import { HttpErrorHandler } from './services/http-error-handler.service';
import { LoaderInterceptor } from './services/interceptor.service';
import { LoaderService } from './services/loader.service';
import { AuthEffects } from './store/effects/auth.effects';
import { OperationsEffects } from './store/effects/operations.effects';
import { RessourcesEffects } from './store/effects/ressources.effects';
import { ViaLinkEffects } from './store/effects/viaLink-effects';
import { AppReducer } from './store/reducers/app.reducer';


registerLocaleData(localeFr);

@NgModule({
  declarations: [AppComponent, PasswordModalComponent, WarningModalComponent],
  imports: [
    BrowserModule,
    FormsModule,
    CommonModule,
    HttpClientModule,
    AppRoutingModule,
    RouterModule,
    PagesModule,
    ComponentsModule,
    BrowserAnimationsModule,
    StoreModule.forRoot({ form: AppReducer }),
    EffectsModule.forRoot([OperationsEffects, RessourcesEffects, ViaLinkEffects, AuthEffects]),
    LoaderModule,
    I18nModule,
  ],
  exports: [I18nModule],
  providers: [
    HttpErrorHandler,
    CurrencyPipe,
    { provide: LOCALE_ID, useValue: 'fr-IN' },
    { provide: LocationStrategy, useClass: HashLocationStrategy },
    LoaderService,
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true },
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
