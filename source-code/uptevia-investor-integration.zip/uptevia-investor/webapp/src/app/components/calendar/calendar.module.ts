import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CalendarComponent } from './calendar.component';
import { CalendarModule } from 'primeng/calendar';


@NgModule({
  declarations: [CalendarComponent],
  imports: [
    CommonModule, 
    UpteviaLibModule,
    CalendarModule,
    FormsModule,
    ReactiveFormsModule],
  exports: [CalendarComponent],
})
export class AppCalendarModule {}
