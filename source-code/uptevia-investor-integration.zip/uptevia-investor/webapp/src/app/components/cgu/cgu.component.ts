import { Component, ElementRef, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { CGU_TRADS_KEYS } from 'src/app/utils/const-vars';

@Component({
  selector: 'app-cgu',
  templateUrl: './cgu.component.html',
  styleUrls: ['./cgu.component.css']
})
export class CguComponent {
  keys = CGU_TRADS_KEYS;
  @ViewChild('modalBody') modalBody :ElementRef | undefined
  constructor(
    
    private translate: TranslateService) { }
  //
  get translationCgu() {
    const translatedKeys = this.keys.map(key => this.translate.instant(key))
    return translatedKeys.join('&nbsp');
  }

   
  

}
