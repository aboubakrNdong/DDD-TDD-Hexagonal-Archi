import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { CguComponent } from './cgu.component';



@NgModule({
  declarations: [CguComponent],
  imports: [
    CommonModule, UpteviaLibModule, 
  ],
  exports: [CguComponent]
})
export class CguModule { }
