import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { ReactiveFormsModule } from '@angular/forms';
import { ContactSupportModule } from './contact-support/contact-support.module';
import { ContactformModule } from './contactform/contactform.module';
import { FooterModule } from './footer/footer.module';
import { HeaderModule } from './header/header.module';
import { PortefeuilleTabModule } from './portefeuille-tab/porefeuille-tab.module';
import { RubriqueModule } from './rubrique-aide/rubrique.module';
import { UpteviaLibModule } from './uptevia-lib.module';

import { DisclaimerCookieModule } from './disclaimercookie/disclaimercookie.module';
import { NotificationModule } from './notification/notification.module';
import { AchatModule } from './operations/acheter-components/achat/achat.module';
import { ConfirmationModule } from './operations/acheter-components/confirmation/confirmation.module';
import { PaiementModule } from './operations/acheter-components/paiement/paiement.module';
import { VenteComponetModule } from './operations/vendre-components/vente/vente.module';
import { ProfilTabModule } from './profil-tab/profil-tab.module';
import { SideBarModule } from './side-menu/side-menu.module';
 
import { VenteConfirmationModule } from './operations/vendre-components/confirmation/confirmation.module';
import { VentePaiementModule } from './operations/vendre-components/vente-paiement/vente-paiement.module';
import { QuickAccessModule } from './quick-access/quick-access.module';
import { IdentificationModule } from './signup/identification/identification.module';
import { PwdHandlerModule } from './signup/pwd-handler/pwdHandler.module';
import { SecretQModule } from './signup/secret-q/secret-q.module';
import { SecuringModule } from './signup/securing/securing.module';
import { StrongSecuringModule } from './signup/strongsecuring/strongsecuring.module';
import { UploadModule } from './signup/upload/upload.module';
import { YourSpaceModule } from './signup/yourspace/yourspace.module';
import { PortefeuilleModule } from './portefeuille-components/porefeuille-components.module';
import { OldAccountModule } from './signup/oldaccount/oldaccount.module';
import { NewIdentifiantModule } from './forgot-credentials/newidentifiant/newidentifiant.module';
import { ForgotQuestionsModule } from './forgot-credentials/forgotquestions/forgotquestions.module';
import { ForgotSecretQModule } from './forgot-credentials/forgot-secretq/forgot-secretq.module';
import { ForgotIdentificationModule } from './forgot-credentials/forgotidentification/forgotidentification.module';
import { CguModule } from './cgu/cgu.module';
import { OperationComponentModule } from './operation-element/operation-element.module';
import { LoginIdentificationModule } from './signup/loginidentification/loginidentification.module';
import { WriteIdentifiantModule } from './forgot-credentials/writeidentifiant/writeidentifiant.module';
import { EditcontactDataModule } from './forgot-credentials/editcontact-data/editcontact-data.module';
import { ShowcontactDataModule } from './forgot-credentials/showcontact-data/showcontact-data.module';
import { ForgotLoginModule } from './forgot-credentials/forgotlogin/forgotlogin.module';

@NgModule({

  imports: [
    CommonModule,
    ReactiveFormsModule,
  ],
  exports: [
    CommonModule,
    ReactiveFormsModule,
    UpteviaLibModule,
    SideBarModule,
    PortefeuilleTabModule,
    HeaderModule,
    FooterModule,
    RubriqueModule,
    ContactSupportModule,
    ContactformModule,
    ProfilTabModule,
    AchatModule,
    PaiementModule,
    ConfirmationModule,
    DisclaimerCookieModule,
    VenteComponetModule,
    NotificationModule,
    VentePaiementModule,
    VenteConfirmationModule,
    SecuringModule,
    IdentificationModule,
    PwdHandlerModule,
    SecretQModule,
    YourSpaceModule,
    StrongSecuringModule,
    UploadModule,
    QuickAccessModule,
    PortefeuilleModule,
    OldAccountModule,
    NewIdentifiantModule,
    ForgotQuestionsModule,
    ForgotSecretQModule,
    ForgotIdentificationModule,
    CguModule,
    OperationComponentModule,
    LoginIdentificationModule,
    WriteIdentifiantModule,
    EditcontactDataModule,
    ShowcontactDataModule,
    ForgotLoginModule,
  ],
  declarations: [
  ],
})
export class ComponentsModule { }
