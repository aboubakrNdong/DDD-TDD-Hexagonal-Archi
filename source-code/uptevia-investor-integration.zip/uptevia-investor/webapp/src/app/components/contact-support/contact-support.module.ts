import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { ContactSupportComponent } from './contact-support.component';



@NgModule({
  declarations: [ContactSupportComponent],
  imports: [
    CommonModule,
    UpteviaLibModule
  ],
  exports: [ContactSupportComponent]
})
export class ContactSupportModule { }