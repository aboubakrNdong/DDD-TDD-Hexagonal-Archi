import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, Renderer2, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Category, SubCategory } from 'src/app/entity/categories';
import { Profil } from 'src/app/entity/profil';
import { Titulaire } from 'src/app/entity/titulaire';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-contactformconnected',
  templateUrl: './contactformconnected.component.html',
  styleUrls: ['./contactformconnected.component.css']
})
export class ContactFormConnectedComponent {

  formName = 'form'
  categories: Category[] = []; // Data containing categories and subcategories
  selectedCategoryId: number;
  filteredSubCategories: SubCategory[] = [];
  selectedSubCategoryId: number;
  cacheData: any;
  submitted = false;
  maxChars = 5;
  characters: any;

  @ViewChild("text") text: ElementRef;
  @ViewChild('nameField') nameField!: ElementRef;


  form: FormGroup;
  varPhone: any;

  profil: Profil;

  constructor(private formBuilder: FormBuilder,
    public translate: TranslateService,
    private loginService: LoginService,
    private bffService: BffService,
    private renderer: Renderer2,
    private Translate: TranslateService,) { }

  ngOnInit(): void {
    this.getTitulaireInfos();
    this.createEditFormGroup();
    this.getCategories();
    this.charactersCounter();
  }

  ngAfterViewInit(): void {
    if (this.text) {
      this.text.nativeElement.addEventListener('input', () => {
        this.charactersCounter();
      })
    }
  }


  getTitulaireInfos() {
    let key = 'profile';
    this.cacheData = sessionStorage.getItem(key);
    this.profil = JSON.parse(this.cacheData);
    console.log("show titulaire data", this.profil);
  }

  createEditFormGroup(): void {
    this.form = this.formBuilder.group({
      categoriesList: ['', Validators.required],
      selectedSubcategory: ['', Validators.required],
      identifiant: this.profil.actiRefeSala,
      emetteur: this.profil.emetIden,
      ccn: this.profil.actiIden,
      firstName: this.profil.prenom,
      lastName: this.profil.nom,
      selectphone: this.getTelephoneValue().slice(0,2), //TODO bug
      telephone: this.getTelephoneValue(),
      email: this.profil.emailPerso !== null ? this.profil.emailPerso : this.profil.emailPro,
      pays: this.profil.adreFiscPaysIden,
      dob: this.profil.tituNaisDate,
      message: ['', Validators.required],
      acceptTerms: [false, Validators.requiredTrue]
    })
  }



  getTelephoneValue(): string {
    if (this.profil.numMobilePerso !== null) {
      return this.profil.numMobilePerso.toString();
    } else if (this.profil.numMobilePro !== null) {
      return this.profil.numMobilePro.toString();
    } else if (this.profil.numFixePerso !== null) {
      return this.profil.numFixePerso.toString();
    } else if (this.profil.numFixePro !== null) {
      this.varPhone = this.profil.numFixePro.toString();
    }
    return ''; //TODO to be cleaned
  }

  onCategorySelect(event: Event) {
    this.selectedCategoryId = Number((event.target as HTMLSelectElement)?.value);
    const selectedCategory = this.categories.find(
      (category) => category.typoId === this.selectedCategoryId
    );
    this.filteredSubCategories = selectedCategory
      ? selectedCategory.sousCategories
      : [];
    this.form.patchValue({ selectedSubcategory: '' });
  }

  onSubCategorySelect(event: Event) {
    this.selectedSubCategoryId = Number((event.target as HTMLSelectElement).value);
  }

  charactersCounter() {
    this.characters = this.text ? this.text.nativeElement.value.length : 0;
  }

  onFormSubmit() {
    this.submitted = true;
   // console.log(this.form.value);
    if (this.form.invalid) {
      this.renderer.selectRootElement(this.nameField.nativeElement).scrollIntoView({ behavior: 'smooth' });
      return;
    }
    const selectedCategory = this.getCategory(this.selectedCategoryId);
    const selectedSubCategory = this.getSubCategory(this.selectedSubCategoryId);
    const identifiant = this.form.get('identifiant')?.value;
    const emetteur = this.form.get('emetteur')?.value;
    const ccn = this.form.get('ccn')?.value;
    const firstName = this.form.get('firstName')?.value;
    const lastName = this.form.get('lastName')?.value;
    const selectphone = this.form.get('selectphone')?.value;
    const telephone = this.form.get('telephone')?.value;
    const email = this.form.get('email')?.value;
    const pays = this.form.get('pays')?.value;
    const dob = this.form.get('dob')?.value;
    const message = this.form.get('message')?.value;
    const acceptTerms = this.form.get('acceptTerms')?.value;

    const data = {
      category: this.Translate.instant(selectedCategory?.typoTraductionKey as string),
      subCategory: this.Translate.instant(selectedSubCategory?.sousTypoTraductionKey as string),
      emetIden: identifiant,
      tituNume: emetteur,
      actiIden: ccn,
      firstName: firstName,
      lastName: lastName,
      selectphone: selectphone,
      telephone: telephone,
      email: email,
      pays: pays,
      dob: dob,
      message: message,
      acceptTerms: acceptTerms,
    }
    // Send the selected category, the typoTraductionKey and the name and ...
    this.sendDataToServer(data);
  }


  getCategories() {
    const isConnected = this.loginService.isAuthenticated() ? 'O' : 'N';
    //handle cache
    let key = 'categories';
    this.cacheData = sessionStorage.getItem(key);
    if (this.cacheData) {
      this.categories = JSON.parse(this.cacheData);
    }
    else {
      this.bffService.getCategories(isConnected).subscribe(
        (reponse) => {
          if (reponse) {
            this.categories = reponse;
            //Save Data to cache
            sessionStorage.setItem(key, JSON.stringify(reponse))
          } else {
            console.log('reponse from server is null')
          }
        },
        (error) => {
          console.log('can not get categories', error);
        }
      );
    }
  }


  sendDataToServer(data: any) {
    //  console.log('Data to be sent:', data);
    this.bffService.createDemande(data).subscribe(
      async () => {

        //TODO display a popin when submit is success

        await console.log('Demande crée avec succés!!')
      },
      async (error: HttpErrorResponse) => {
        await console.log(`Erreur de création de la requete: ${error.message}`);
      }
    );
  }


  getCategory(categoryId: number): Category | undefined {
    if (this.categories) {
      return this.categories.find((category) => category.typoId === categoryId);
    }
    else {
      console.log("categories is null");
      return;
    }
  }

  getSubCategory(subCategoryId: number): SubCategory | undefined {
    return this.filteredSubCategories.find((subCategory) => subCategory.sousTypoId === subCategoryId);
  }
}
