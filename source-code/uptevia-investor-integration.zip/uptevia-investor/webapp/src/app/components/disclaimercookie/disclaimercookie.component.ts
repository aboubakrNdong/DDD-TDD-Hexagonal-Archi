import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { DISCLAIMER } from 'src/app/utils/const-vars';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'app-disclaimercookie',
  templateUrl: './disclaimercookie.component.html',
  styleUrls: ['./disclaimercookie.component.css']
})
export class DisclaimercookieComponent implements OnInit {

  showDisclaimer = true;
  constructor(private cookieService: CookieService) { }
  ngOnInit(): void {
    this.showDisclaimer = !this.cookieService.check(DISCLAIMER);

  }
  onClickAccept() {
    //TODO add behavior
    this.showDisclaimer = false; //Hide the disclaimer
    this.cookieService.set(DISCLAIMER, DISCLAIMER, environment.cookieLoginDuration)
  }

  onClickMore() {
    //TODO redirect to another page 
    console.log("button clicked");
  }

}
