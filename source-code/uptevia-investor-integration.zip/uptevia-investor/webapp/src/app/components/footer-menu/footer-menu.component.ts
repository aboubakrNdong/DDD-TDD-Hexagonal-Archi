import { Component, Input, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { Modules } from 'src/app/entity/module';
import { DASHBOARD_MENU } from 'src/app/utils/const-vars';
@Component({
  selector: 'footer-menu',
  templateUrl: './footer-menu.component.html',
  styleUrls: ['./footer-menu.component.css'],
})
export class FooterMenuComponent {
  public dashboard = DASHBOARD_MENU; 
  @Input() menu: Modules[] | null = [];
  openIndex: number | undefined;
  constructor(private router: Router) { }


  ngOnChanges(changes: SimpleChanges): void {
    if (this.menu) {
      this.menu = this.updateMenu(this.menu);
    }
  }

  updateMenu(menu: Modules[] | any) {

    return menu.map((element: Modules) => {
      const copiedModules: Modules = { ...element }
      if (element.sousModule && element.sousModule.length === 1) {
        let sousMenu = element.sousModule[0]
        copiedModules.groupeUrl = sousMenu.moduleUrl;
        delete copiedModules.sousModule
      }
      return copiedModules;
    });

  }
  toggleMenu(index: number) {

    if (this.openIndex === index) {
      this.openIndex = undefined
    } else {
      this.openIndex = index;
    }
    if (this.menu && !this.menu[index].sousModule) {
      this.router.navigate([this.menu[index].groupeUrl])
    }
  }  

}
