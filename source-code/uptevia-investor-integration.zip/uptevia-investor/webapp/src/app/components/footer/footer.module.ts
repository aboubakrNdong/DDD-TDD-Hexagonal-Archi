import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { FooterComponent } from './footer.component';
import { FooterMenuModule } from '../footer-menu/footer-menu.module';



@NgModule({
  declarations: [FooterComponent],
  imports: [
    CommonModule, UpteviaLibModule, FooterMenuModule
  ],
  exports: [FooterComponent]
})
export class FooterModule { }
