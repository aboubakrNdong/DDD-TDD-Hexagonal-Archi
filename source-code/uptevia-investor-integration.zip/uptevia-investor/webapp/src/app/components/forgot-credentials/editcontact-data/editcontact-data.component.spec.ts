import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditcontactDataComponent } from './editcontact-data.component';

describe('EditcontactDataComponent', () => {
  let component: EditcontactDataComponent;
  let fixture: ComponentFixture<EditcontactDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditcontactDataComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditcontactDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
