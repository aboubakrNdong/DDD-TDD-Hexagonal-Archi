import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Subject, takeUntil } from 'rxjs';
import { CheckIdentifiant } from 'src/app/entity/checkIdentifiant';
import { Profil } from 'src/app/entity/profil';
import { SignUpData } from 'src/app/entity/signup-data';
import { Titulaire } from 'src/app/entity/titulaire';
import { UserAccess } from 'src/app/entity/user';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { MessageService } from 'src/app/services/message.service';
import { sendEmail, setAncienPlsSuccess, setButtonChoice, setEmail, setUsername } from 'src/app/store/actions/app.action';
import { selectIsEdit, selectIsForgot, selectUser } from 'src/app/store/selectors/app.selector';
import { showModal } from 'src/app/utils/functions';


@Component({
  selector: 'app-editcontact-data',
  templateUrl: './editcontact-data.component.html',
  styleUrls: ['./editcontact-data.component.css']
})
export class EditcontactDataComponent {


  formName = 'identification';
  identification: FormGroup;
  submitted = false;
  updateSuccess = false;

  @Output() onClick = new EventEmitter<any>()

  @Output() event = new EventEmitter<string>()


  @Input() buttonChoice: any = null;
  messages: string[] = [];
  ngDestroyed$ = new Subject<void>();
  login: any;
  numberCode: any;
  titulaire: Titulaire;
  editVialink: boolean = false;

  profile: Profil;
  isInWhitelistS: boolean = true;
  userPhone: any = '';
  userMail: any = '';
  storeIsForgot: boolean = false;
  storeIsEdit: boolean = false;
  switchChoice: any;
  emetIden: any;
  actiIden: any;
  dob: any;
  nom: any;
  prenom: any;
  numPhone: any;
  email: any;
  phone: any;
  showId = false;



  constructor(
    public translate: TranslateService,
    private formBuilder: FormBuilder,
    private messageService: MessageService,
    private bffService: BffService,
    private modal: NgbModal,
    private store: Store,
    private cdr: ChangeDetectorRef,
    private loginService: LoginService
  ) { }

  ngOnInit(): void {
    this.initForm();
    this.retreiveUsernameFromStore();
    this.retrieveSignUpDataFromStore();
    this.getParamNumberCode();
    this.getTitulaires(this.login);
    if (this.buttonChoice == "forgotpassword") {
      this.showId = true;
    }
  }

  initForm() {
    this.identification = this.formBuilder.group({
      username: [this.login, [Validators.required, Validators.minLength(8)]],
      indicator: ['+33', Validators.required],
      telephone: ['', [Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(3), Validators.maxLength(20)], this.phoneprefixValidator()],
      email: ['', [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],

    });
  }

  private phoneprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const telephone = this.identification.get("telephone")?.value;
      const indicator = this.identification.get("indicator")?.value;
      return new Promise((resolve, reject) => {
        if (telephone && !telephone.startsWith('06') && !telephone.startsWith('07')
          && indicator === '+33') {
          resolve({ invalidPhoneNumber: true });
        } else {
          resolve(null);
        }
      });
    }
  }

  updateForm() {
    this.phone = '0' + this.profile.numMobilePerso.substring(3, this.profile.numMobilePerso.length);
    this.identification.controls['indicator'].setValue(this.profile.numMobilePerso.substring(0, 3));
    this.identification.controls['telephone'].setValue(this.phone);
    this.identification.controls['email'].setValue(this.profile.emailPerso);
    this.identification.controls['username'].setValue(this.login);
    this.userPhone = this.phone;
    this.userMail = this.profile.emailPerso;
  }


  private retreiveUsernameFromStore() {
    this.store.select(selectUser)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        if (data.user) {
          console.log("login from store", data);
          this.profile = data.user;
          this.login = data.login;
        } else {
          console.error("ERROR Lgin or TiTULAIRE not FOUND");

        }
      });
    this.updateForm()

  }

  private retrieveSignUpDataFromStore() {

    this.store
      .select(selectIsForgot)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        this.storeIsForgot = data.isforgot;
      });

    this.store
      .select(selectIsEdit)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        this.storeIsEdit = data.isEdit;
      });
  }


  getTitulaires(userLogin: string) {
    this.login = userLogin.toString();
    this.loginService.getTitulaire(this.login).subscribe((titulaires: Profil) => {
      if (titulaires) {
        this.profile = titulaires;
        this.dob = this.profile.tituNaisDate;
        this.numPhone = this.profile.numMobilePerso;
        this.email = this.profile.emailPerso;
      } else {
        this.messages = this.messageService.messages;
      }
    })
  }

  /**
  * Vialink upload check if mail and number not null
  */
  onclickUpload() {
    this.submitted = true;
  }
  /**
   * on vialink score is valid >90%
   */

  onSuccess(event: boolean) {
    // event ==true=> score Vialink >90%
    // event = false ==>score Vialink < 90%
    if (event) {
      this.sendMailtoConfirm();
      console.log("event called Once");
      this.updateUpiuserData()

    } else {
      // 
      setTimeout(() => {
        showModal('general.warning.error', ['Vos demandes de modifications seront traitées sous 24 à 48h ouvrées'], 'general.bouton.fermer', this.modal, 'login')
      }, 500)
    }
  }




  onFormSubmit() {
    this.submitted = true;
    this.messageService.clear();
    if (this.identification.invalid) {
      console.log(this.identification.value);
      console.log("invalid", this.identification.valid);
      return;
    }

    //Verify Identity of User  

    this.messageService.clear();
    this.messages = [];
    //TODO test later 

    //TODO Dev en back en cours

    this.store.dispatch(setUsername({ username: this.login }))
    this.onClick.emit();

  }

  sendMailtoConfirm() {
    this.bffService.sendEmailWithToken(this.login, this.buttonChoice)
      .subscribe((response) => {
        if (response) {

          this.store.dispatch(sendEmail({ email: response }))
          this.onClick.emit();
        }
        else {
          this.messages = this.messageService.messages;
          showModal('general.warning.alert', ['form.field.validator.submit'], 'general.bouton.fermer', this.modal);
        }
      })
  }
  getParamNumberCode() {
    const paramName = "TEL_INDICATIF_AUTORISE";
    const isConnected = this.loginService.isAuthenticated() ? this.profile.emetIden : 0;
    //handle cache
    let key = 'numberCode';
    this.bffService.getParametreSite(isConnected, paramName).subscribe(
      (reponse) => {
        this.numberCode = reponse;
        //Save Data to cache
        sessionStorage.setItem(key, JSON.stringify(reponse))
      })
  }

  onChangeIndic(event: any) {
    if (event.target.value) {
      this.identification.get("telephone")?.setValue("");
    }
  }


  onSendEmail() {
    this.updateUpiuserData();
    this.sendMailtoConfirm();
    console.log("on envoi l'email");
    this.store.dispatch(setEmail({ email: this.identification.get('email')?.value }));
    this.store.dispatch(setButtonChoice({ buttonchoice: this.buttonChoice }));
    this.switchChoice = "yourspace"
    this.event.emit(this.switchChoice);
  }

  updateUpiuserData() {
    this.cdr.detectChanges();
    const newEmail = this.identification.value.email
    const newPhone = this.identification.value.telephone
    const indicator = this.identification.get('indicator')?.value
    //this.store.dispatch(sendEmail({ email: newEmail }))
    console.log(this.identification.value);
    const formatted = newPhone.replace(/^0+/, '');
    const user: any = {
      login: this.login,
      mail: newEmail,
      telephone: indicator + formatted
    }
    console.log('user', user);
    this.store.dispatch(setEmail({ email: newEmail }))
    this.bffService.UpdateUpiMailPhone(user).subscribe(res => {
      if (res) {
        console.log('user up to date ', res);

      } else {
        console.error('phone and email not updated ')
      }

    })

  }
  getChange() {
    console.log(this.identification.value);
    this.cdr.detectChanges();

  }

  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }
}