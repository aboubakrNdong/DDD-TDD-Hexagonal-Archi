import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotSecretQComponent } from './forgot-secretq.component';

describe('SecretQComponent', () => {
  let component: ForgotSecretQComponent;
  let fixture: ComponentFixture<ForgotSecretQComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForgotSecretQComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ForgotSecretQComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
