import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Titulaire } from 'src/app/entity/titulaire';
import { UserAccess } from 'src/app/entity/user';
import { Store } from '@ngrx/store';
import { Subject, map, takeUntil } from 'rxjs';
import { fetchSecretQuestions, sendEmail, setIsForgot } from 'src/app/store/actions/app.action';
import { Observable } from 'rxjs';
import { FetchSecretQuestions } from 'src/app/entity/fetchsecret-questions';
import { BffService } from 'src/app/services/bff.service';
import { selectAppState, selectIsEdit, selectUserAccess } from 'src/app/store/selectors/app.selector';
import { MessageService } from 'src/app/services/message.service';
import { SecretQuestions } from 'src/app/entity/secret-questions';
import { SignUpData } from 'src/app/entity/signup-data';
import { showModal } from 'src/app/utils/functions';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';



@Component({
  selector: 'app-forgot-secretq',
  templateUrl: './forgot-secretq.component.html',
  styleUrls: ['./forgot-secretq.component.css']
})
export class ForgotSecretQComponent implements OnInit {
  formName = 'forgotsecretq';
  forgotsecretq: FormGroup;
  selectedNames1: string[] = [];
  selectedNames2: string[] = [];
  secretQuestions: any[];
  submitted = false;
  hide: boolean = true;

  @Input() buttonChoice: any = null;

  ngDestroyed$ = new Subject<void>();

  @Output() onClick = new EventEmitter<any>()

  @Output() event = new EventEmitter<string>()


  cacheData: any;
  updateSuccess: boolean;
  messages: string[] = [];
  formatUsername: any;
  formatPassword: any;
  titulaire: Titulaire;
  user: UserAccess;
  loginError: boolean = false;
  storeUsername: any;
  storePassword: any;
  userDataStore?: UserAccess;

  secretquestions$: Observable<FetchSecretQuestions[]>;


  switchChoice: any;
  storeEmail: any;
  storeIsForgot: any;
  storeIsEdit: any;

  idQuestion1: any;
  idQuestion2: any;

  editVialink: boolean = true;


  constructor(private formBuilder: FormBuilder,
    private store: Store,
    private bffService: BffService,
    private messageService: MessageService,
    private modal: NgbModal,

  ) { }
  ngOnInit(): void {
    this.retrieveSignUpDataFromStore();
    this.createForm();
    this.getSecret();
  }

  private retrieveSignUpDataFromStore() {
    this.store
      .select(selectAppState)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        this.storeUsername = data.username;
        this.storeEmail = data.email;
        this.storeIsForgot = data.isForgot;
        this.storeIsEdit = data.isEdit;

        console.log("user", data.username + "email", data.email + "isForgot", data.isForgot);
      });

  
  }


  onSelectChange(questionKey: string, controlName: string) {
    this.secretquestions$
      .pipe(
        map((questions: FetchSecretQuestions[]) => questions.find(question => question.questionKey === questionKey))
      )
      .subscribe((selectedQuestion: FetchSecretQuestions | undefined) => {
        if (selectedQuestion) {
          this.handleSelectedQuestion(selectedQuestion, controlName);
        }
      });
  }

  private handleSelectedQuestion(selectedQuestion: FetchSecretQuestions, controlName: string) {
    if (controlName === 'questionOneList') {
      this.idQuestion1 = selectedQuestion.idQuestion;
    } else if (controlName === 'questionTwoList') {
      this.idQuestion2 = selectedQuestion.idQuestion;
    }
    this.forgotsecretq.get(controlName)?.setValue(selectedQuestion.questionKey);
  }

  createForm() {
    this.forgotsecretq = this.formBuilder.group({
      questionOneList: ['', Validators.required],
      responseOne: ['', [Validators.required, Validators.minLength(3)]],
      questionTwoList: ['', Validators.required],
      responseTwo: ['', [Validators.required, Validators.minLength(3)]],
    });
  }

  getSecret() {
    this.store.dispatch(fetchSecretQuestions());
    this.secretquestions$ = this.store.select((state: any) => state.form.questions);
  }

  onForgotQuestion() {
    this.store.dispatch(setIsForgot({ isForgot: true }));
    this.onClick.emit();
   }

  onFormSubmit() {
    this.submitted = true;
    if (this.forgotsecretq.invalid) {
      return;
    }

    this.messageService.clear();

    const checkSecret: SecretQuestions = {
      login: this.storeUsername,
      firstQuestion: this.idQuestion1,
      firstAnswer: this.forgotsecretq.value.responseOne,
      secondQuestion: this.idQuestion2,
      secondAnswer: this.forgotsecretq.value.responseTwo,
      buttonChoice: this.buttonChoice,
    };

    this.bffService.checkQuestionAnswer(checkSecret).subscribe((response) => {
      if (response) {
        this.updateSuccess = true;
        if (this.storeIsEdit) { 
          this.onClick.emit();
        } else {
          this.sendEmailWithToken();
        }
      } else {
        this.messages = this.messageService.messages;
      }
    });

  }

  private sendEmailWithToken() {
    this.updateSuccess = true;
    this.bffService.sendEmailWithToken(this.storeUsername, this.buttonChoice)
      .subscribe((response) => {
        if (response) {
          this.store.dispatch(sendEmail({email:response}))

          this.event.emit("yourspace");
        }else {
          this.messages = this.messageService.messages;
        }
      });
  }

  sendMailtoConfirm() {
    this.bffService.sendEmailWithToken(this.storeUsername, this.buttonChoice)
      .subscribe((response) => {
        if (response) {
          console.log("sendEmailWithToken");
          this.store.dispatch(sendEmail({email:response}))

          this.onClick.emit()
        }
        else {
          this.messages = this.messageService.messages;
          showModal('general.warning.alert', ['form.field.validator.submit'], 'general.bouton.fermer', this.modal);
        }
      })
  }



  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }
}
