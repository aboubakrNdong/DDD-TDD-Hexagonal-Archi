import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { BffService } from 'src/app/services/bff.service';
import { MessageService } from 'src/app/services/message.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { setEmail } from 'src/app/store/actions/app.action';
import { LoginService } from 'src/app/services/login.service';
import { Titulaire } from 'src/app/entity/titulaire';
import { Profil } from 'src/app/entity/profil';
import { whiteListSms } from 'src/app/utils/functions';



@Component({
  selector: 'app-forgotidentification',
  templateUrl: './forgotidentification.component.html',
  styleUrls: ['./forgotidentification.component.css']
})
export class ForgotidentificationComponent {

  formName = 'forgotidentification';
  forgotidentification: FormGroup;
  submitted = false;
  updateSuccess = false;
  @Output() onClick = new EventEmitter<any>();

  @Output() event = new EventEmitter<string>();

  @Input() buttonChoice: any = null;
  messages: string[] = [];
  ngDestroyed$ = new Subject<void>();
  storeUsername: any;
  isForgot = false;
  isNotInList = false;
  titulaireData: Titulaire;
  isInWhitelistS:boolean=true;

  profile: any;
  numPhone = "";
  emailUser = "";
  dobUser = "";
  isDataNull = false;
  isNotvalid = false;
  isInRegistrar = true;
  isInWhitelistSms = true;
  isInWhitelistMail = true;
  isGood = false;
  editVialink:boolean=true;
  numberCode: any;
  login: any;


  constructor(
    public translate: TranslateService,
    private formBuilder: FormBuilder,
    private messageService: MessageService,
    private bffService: BffService,
    private store: Store,
    private loginService: LoginService,
  ) { }

  ngOnInit(): void {

    if (this.buttonChoice == "forgotpassword") {
      this.isForgot = true;
      this.storeUsername = ""
    }
    if (this.buttonChoice === "forgotidentifiant") {
      this.storeUsername = "username";
    }
    this.initForm();
    this.getParamNumberCode();

  }

  getParamNumberCode() {
    const paramName = "TEL_INDICATIF_AUTORISE";
    const isConnected = this.loginService.isAuthenticated() ? this.profile.emetIden : 0;
    //handle cache
    let key = 'numberCode';
    this.bffService.getParametreSite(isConnected, paramName).subscribe(
      (reponse) => {
        this.numberCode = reponse;
        //Save Data to cache
        sessionStorage.setItem(key, JSON.stringify(reponse))
      })
  }

  initForm() {
    this.forgotidentification = this.formBuilder.group({
      username: [this.login, [Validators.required, Validators.minLength(8)]],
      indicator: ['+33', Validators.required ],
      telephone: ['', [Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(3), Validators.maxLength(20)], this.phoneprefixValidator()],
      email: ['', [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],

    });
  }

  private phoneprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const telephone = control.value;
      return new Promise((resolve, reject) => {
        if (telephone && !telephone.startsWith('06') && !telephone.startsWith('07')) {
          resolve({ invalidPhoneNumber: true });
        } else {
          resolve(null);
        }
      });
    }
  }

  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }

  onChangeIndic(event: any) {
    if (event.target.value) {
      this.forgotidentification.get("telephone")?.setValue("");
    }
  }

  editContactData(){
    this.editVialink =false;
  }

  getTitulaire(theLogin: string) {
    let login = theLogin.toString();
    this.loginService.getTitulaire(login).subscribe((titulaires: Profil) => {
      if (titulaires) {
        this.profile = titulaires;
        this.numPhone = this.profile.numMobilePerso;
        this.emailUser = this.profile.emailPerso;
        this.dobUser = this.profile.tituNaisDate;
        console.log("number is" + this.numPhone);
        this.checkNull(this.numPhone, this.emailUser, this.dobUser);
      } else {
        this.messages = this.messageService.messages;
      }
    })
  }


  onCallForVialink() {
    this.event.emit("upload");
  }


  //check if number, mail or dob are null
  checkNull(aNum: string, aEmail: string, aDob: string) {
    if (aNum == null || aEmail == null || aDob == null) {
      console.log("Data missing");
      this.isInRegistrar = false;
      return;
    }
    this.checkSmSNull(aNum);
  }

  //check whitelist sms
  checkSmSNull(oPhone: string) {
    if (!(whiteListSms.includes(oPhone))) {
      this.isInWhitelistSms = false;
      console.log("number not in whitelist");
      return;
    }
  

    if (this.buttonChoice === "forgotidentifiant") {
      // dispatch email to store
      this.store.dispatch(setEmail({ email: this.forgotidentification.value.email }));
      this.onClick.emit()
      console.log(this.forgotidentification.value);
    }
  }

  onFormSubmit() {
    this.submitted = true;
    this.messageService.clear();
    this.messages = [];

    if (this.forgotidentification.invalid) {
      console.log("invalid");
      return;
    }

    //Verify Identity of User  
    if (this.buttonChoice === "forgotpassword") {

      this.getTitulaire(this.forgotidentification.value.username);

    }
  }
}
