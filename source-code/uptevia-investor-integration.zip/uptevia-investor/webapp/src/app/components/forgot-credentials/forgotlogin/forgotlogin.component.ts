import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { BffService } from 'src/app/services/bff.service';
import { MessageService } from 'src/app/services/message.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { showModal } from 'src/app/utils/functions';
import { LoginService } from 'src/app/services/login.service';
import { CheckIdentifiant } from 'src/app/entity/checkIdentifiant';
import { setEmail, setProfile } from 'src/app/store/actions/app.action';
import { Profil } from 'src/app/entity/profil';
import { Router } from '@angular/router';
import { selectUser } from 'src/app/store/selectors/app.selector';



@Component({
  selector: 'app-forgotlogin',
  templateUrl: './forgotlogin.component.html',
  styleUrls: ['./forgotlogin.component.css']
})
export class ForgotloginComponent {

  formName = 'forgotidentification';
  forgotidentification: FormGroup;
  submitted = false;
  updateSuccess = false;
  @Output() onClick = new EventEmitter<any>()
  @Input() buttonChoice: any = null;
  firstCnxLogin: string;
  messages: string[] = [];
  ngDestroyed$ = new Subject<void>();
  storeUsername: any;
  isForgot = false;
  profile: any;
  numPhone = "";
  emailUser = "";
  numberCode: any;

  constructor(
    public translate: TranslateService,
    private formBuilder: FormBuilder,
    private messageService: MessageService,
    private bffService: BffService,
    private modal: NgbModal,
    private store: Store,
    private loginService: LoginService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.createIdentificationForm();
    this.retreiveFromStore();
    this.checkAccess();
  }


  createIdentificationForm() {
    this.forgotidentification = this.formBuilder.group({
      nomFamille: ['', Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(32)])],
      prenom: ['', Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(32)])],
      dateNaissance: ['', Validators.compose([Validators.required])],
      emetFirstname: ['', Validators.compose([Validators.required])],
      numCpte: ['', Validators.required],
    });
  }

  private phoneprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const telephone = control.value;
      return new Promise((resolve, reject) => {
        if (telephone && !telephone.startsWith('06') && !telephone.startsWith('07')) {
          resolve({ invalidPhoneNumber: true });
        } else {
          resolve(null);
        }
      });
    }
  }

  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }

  onFormSubmit() {
    this.submitted = true;
    this.messageService.clear();
    this.messages = [];

    if (this.forgotidentification.invalid) {
      console.log("invalid");
      return;
    }
    this.verifyData();

  }

  getTitulaire() {

    this.loginService.getTitulaire(this.storeUsername).subscribe((titulaires: Profil[]) => {
      if (titulaires) {
        this.profile = titulaires;
        this.numPhone = this.profile.numMobilePerso;
        this.emailUser = this.profile.emailPerso;

        console.log("number is ", this.numPhone);
        console.log("email is ", this.emailUser);
        this.store.dispatch(setProfile({ profil: this.profile, username: this.storeUsername }));
        this.store.dispatch(setEmail({ email: this.emailUser }));

        this.onClick.emit();

      } else {
        this.messages = this.messageService.messages;
      }
    })
  }

  private verifyData() {

    let verifyDataIdentifiant: CheckIdentifiant = {} as CheckIdentifiant;

    verifyDataIdentifiant.p_acti_Iden = this.forgotidentification.value.numCpte;
    verifyDataIdentifiant.p_nom = this.forgotidentification.value.nomFamille;
    verifyDataIdentifiant.p_prenom = this.forgotidentification.value.prenom;
    verifyDataIdentifiant.p_date_nais = this.forgotidentification.value.dateNaissance;

    this.bffService.verifyIdentifiant(verifyDataIdentifiant).subscribe(
      (response) => {
        if (response) {

          this.updateSuccess = true;

          this.storeUsername = response;
          if (this.firstCnxLogin) { 
            if (this.firstCnxLogin == response && this.buttonChoice === 'firstconnexion') {
              this.onClick.emit();
            } else { 
               showModal('general.warning.alert', ['form.field.validator.submit'], 'general.bouton.fermer', this.modal);
            }
          } else {
            this.getTitulaire();

          }
        } else {
          this.messages = this.messageService.messages;
          showModal('general.warning.alert', ['form.field.validator.submit'], 'general.bouton.fermer', this.modal);
          console.log("messages" + this.messages);

        }
      },
    )

  }

  checkAccess() {
    setTimeout(() => {
      if (!this.firstCnxLogin && this.buttonChoice === 'firstconnexion') {
        this.router.navigateByUrl('login', { replaceUrl: true })
      }
    }, 400)
  }
  goToContact() {
    this.router.navigate([`contact-us/form-call`]);
  }

  retreiveFromStore() {
    this.store.select(selectUser).subscribe(data => {
      console.log('data from store ', data);

      if (data?.login) {
        this.firstCnxLogin = data.login

      }
    })
  }
}
