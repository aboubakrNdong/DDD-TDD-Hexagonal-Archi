import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewidentifiantComponent } from './newidentifiant.component';

describe('NewidentifiantComponent', () => {
  let component: NewidentifiantComponent;
  let fixture: ComponentFixture<NewidentifiantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewidentifiantComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NewidentifiantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
