import { Component, Input } from '@angular/core';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { selectEmail } from 'src/app/store/selectors/app.selector';
import { Router } from '@angular/router';
import { hideEmail } from 'src/app/utils/functions';


@Component({
  selector: 'app-newidentifiant',
  templateUrl: './newidentifiant.component.html',
  styleUrls: ['./newidentifiant.component.css']
})
export class NewidentifiantComponent {

  finalEmail: any;
  storeEmail: any;
  ngDestroyed$ = new Subject<void>();
  result: any;
  isForgot= false;

  @Input() buttonChoice: any = null;


  ngOnInit(): void {
    this.retreiveEmailFromStore();
    this.finalEmail = hideEmail(this.storeEmail);
    console.log(" new Id buttonChoice" + this.buttonChoice);
    if(this.buttonChoice=="forgotpassword"){
      this.isForgot= true;
    }
  }

  constructor(private store: Store,
    private router: Router,) {
  }

  private retreiveEmailFromStore() {
    this.store.select(selectEmail)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        console.log("storeEmail", data.email);
        this.storeEmail = data.email;
      });
  }

  goToProfil() {
    this.router.navigate(['login']);
  }


  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }

}
