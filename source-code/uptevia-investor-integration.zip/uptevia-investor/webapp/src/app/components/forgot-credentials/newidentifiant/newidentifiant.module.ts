import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppCalendarModule } from 'src/app/components/calendar/calendar.module';
import { DirectiveModule } from 'src/app/directives/directives.modules';
import { NewidentifiantComponent } from './newidentifiant.component';
import { UpteviaLibModule } from '../../uptevia-lib.module';



@NgModule({
  declarations: [NewidentifiantComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    UpteviaLibModule,
    AppCalendarModule,
    DirectiveModule
  ],
  exports:[NewidentifiantComponent],
  bootstrap:[NewidentifiantComponent]
})
export class NewIdentifiantModule { }
