import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowcontactDataComponent } from './showcontact-data.component';

describe('ShowcontactDataComponent', () => {
  let component: ShowcontactDataComponent;
  let fixture: ComponentFixture<ShowcontactDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowcontactDataComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowcontactDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
