import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { MessageService } from 'src/app/services/message.service';
import { Profil } from 'src/app/entity/profil';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { setAncienPlsSuccess, setProfile } from 'src/app/store/actions/app.action';
import { UserAccessPls } from 'src/app/entity/userAccessPls';

@Component({
  selector: 'app-writeidentifiant',
  templateUrl: './writeidentifiant.component.html',
  styleUrls: ['./writeidentifiant.component.css']
})
export class WriteidentifiantComponent {

  writeidentifiant: FormGroup;

  messages: string[] = [];

  submitted = false;
  updateSuccess = false;
  login: any;
  @Output() onClick = new EventEmitter<any>();
  @Output() event = new EventEmitter<string>();
  @Input() buttonChoice: any = null;

  isForgot: boolean = true;
  profile: any;
  numPhone = "";
  emailUser = "";
  numberCode: any;

  constructor(
    public translate: TranslateService,
    private formBuilder: FormBuilder,
    private messageService: MessageService,
    private bffService: BffService,
    private modal: NgbModal,
    private store: Store,
    private loginService: LoginService,
  ) { }

  ngOnInit(): void {
    this.initForm();

  }


  initForm() {
    this.writeidentifiant = this.formBuilder.group({
      username: ['', [Validators.required, Validators.minLength(8)]],
    });
  }



  getTitulaire() {
    this.login = this.writeidentifiant.get("username")?.value

    this.loginService.getTitulaire(this.login).subscribe((titulaire: Profil) => {
      if (titulaire) {
        const user: UserAccessPls = {
          loginUpi: this.login,
          actiIden: titulaire.actiIden,
          emetIden: titulaire.emetIden,
          tituNume: 1,//TODO to be verified dans api /api/v1/titulaire
          email: titulaire.emailPerso,
          numMobile: titulaire.numMobilePerso

        }
        this.store.dispatch(setAncienPlsSuccess({ ancienPls: user }));
        this.profile = titulaire;
        this.numPhone = this.profile.numMobilePerso;
        this.emailUser = this.profile.emailPerso;
        console.log("number is ", this.numPhone);
        console.log("email is ", this.emailUser);
        this.store.dispatch(setProfile({ profil: this.profile, username: this.login }));
        this.onClick.emit();
      } else {
        this.messages = this.messageService.messages;
      }
    })
  }


  onFormSubmit() {
    this.submitted = true;

    if (this.writeidentifiant.invalid) {
      console.log("invalid");
      return;
    }
    this.getTitulaire();
  }
}