import { Component, Input, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { Logo } from 'src/app/entity/logo';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  @Input() user: any = null;
  link = "";
  thumbnail: any;
  logoUptevia = 'assets/images/logo-uptevia.svg'
  iconContact = "assets/pictos/icone_information.svg";
  iconMessage = "assets/pictos/icone-mail.svg";
  urlUptevia = "";

  constructor(
    public translate: TranslateService,
    private router: Router,
    private loginService: LoginService,
    private bffService: BffService,
    private sanitizer: DomSanitizer) {

  }
  ngOnInit(): void {
    this.translate.get('logo.text.00000000').subscribe((translated: string) => {
      // You can call instant() here
      this.urlUptevia = 'https://'.concat(translated);
    });
  
 
  }

  onLogout() {
    this.loginService.logout();
  }

  onChangeLang(lang: any) {
    localStorage.setItem('lang', lang);
    this.translate.use(lang); 
  }

 

  navigateTo(route: string) {
    if (!this.isConnected) {
      this.router.navigate(['contact-us']);
    } else {
      this.router.navigate([route]);

    }

  }

  get isConnected() {
    return this.loginService.isAuthenticated();
  }

  toggleMenu() { 
    let sideMenu = document.getElementById("side-menu");
    if (sideMenu) {
      sideMenu.classList.toggle("hidden-xs")
    }
  }
}
