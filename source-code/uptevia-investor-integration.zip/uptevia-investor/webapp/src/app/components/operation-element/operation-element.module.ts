import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { DirectiveModule } from 'src/app/directives/directives.modules';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { OperationComponent } from './operation-element.component';



@NgModule({
  declarations: [OperationComponent],
  imports: [
    CommonModule, UpteviaLibModule, DirectiveModule
  ],
  exports: [OperationComponent]
})
export class OperationComponentModule { }
