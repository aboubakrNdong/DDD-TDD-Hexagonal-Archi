import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { ErrorApi } from 'src/app/entity/erreur.api';
import { LoginRequest } from 'src/app/entity/login-request';
import { UserAccess } from 'src/app/entity/user';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { MessageService } from 'src/app/services/message.service';

@Component({
  selector: 'app-carte-bancaire',
  templateUrl: './carte-bancaire.component.html',
  styleUrls: ['./carte-bancaire.component.css']
})
export class CarteBancaireComponent {
  @Input() url: string;
  @Output() getRef = new EventEmitter<number>();
  @ViewChild('iframe') iframe: ElementRef;
  password = ''
  error = false;
  passwordValid = false;
  isEmpty = false;
  iFrameResult = '';
  constructor(
    private bffService: BffService,
    private loginService: LoginService,
    public messageService: MessageService) { }

  ngOnInit(): void {
    console.log("ngOnInit CarteBancaire Component");
    this.handlePaiementStatus()

  }


  handlePaiementStatus() {
    //eventlistner for d1 posted bu OLIS CB
    window.addEventListener('message', this.receiveMessage.bind(this), false);
  }

  private receiveMessage(event: MessageEvent) {
    if (event.data !== this.iFrameResult && typeof (event.data) === 'string') {
      this.iFrameResult = event.data;
      this.bffService.decryptParams(event.data).subscribe((result: any) => {
        if (result && result.params.ocb_idTransaction) {
          this.getRef.emit(result.params.ocb_idTransaction);
          window.removeEventListener('message', this.receiveMessage);
        }

      })
    }
  }


  submit() {
    console.log("sumbit");
    this.messageService.clear();
    if (this.password.length > 0) {
      this.isEmpty = false;
      const user: UserAccess = JSON.parse(localStorage.getItem("user") || '{}');
      const loginRequest: LoginRequest = {
        login: user.login,
        password: this.password,
        operation: true
      }


      this.loginService.authenticate(loginRequest)
        .subscribe((user: UserAccess) => {
          if (user) {
            this.loginService.user = user;
            this.passwordValid = true;
            this.error = false;
          } else {
            this.error = true;

            console.log('Authentification échouée', this.messageService.messages);

          }
        })
    } else {
      this.isEmpty = true;
    }

  }

  ngOnDestroy() {
    console.log("ngOnDestroy");

    window.removeEventListener('message', this.receiveMessage);

  }
}