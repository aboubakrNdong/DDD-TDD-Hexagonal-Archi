import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { iFrameParams } from 'src/app/entity/iframe-data';
import { BffService } from 'src/app/services/bff.service';
import { TranslationService } from 'src/app/services/translation.service';
import { setIsAchat } from 'src/app/store/actions/app.action';
import { OPERATIONS_ACHAT_RECAP_LABEL, OPERATIONS_ACHAT_SIMULATION_LABEL } from 'src/app/utils/trads.maps';
import { PasswordModalComponent } from '../../../password-modal/password-modal.component';
import { Router } from '@angular/router';
import { HabilitationService } from 'src/app/services/habilitation-service';
import { MODULES_PRELEVEMENT, MODULE_CB } from 'src/app/utils/const-vars';

@Component({
  selector: 'app-achat-paiement',
  templateUrl: './paiement.component.html',
  styleUrls: ['./paiement.component.css']
})
export class PaiementComponent implements OnInit {
  @Output() onback = new EventEmitter<any>();
  @Output() onSubmit = new EventEmitter<any>();
  @Input() recapInfo: any;
  @Input() simulationInfo: any;
  @Input() iframeData: iFrameParams;
  iFrameUrl: any;
  carteForm: FormGroup;

  currentTab = 6;
  buttonLabel = 'layout.sousmenu.achat';
  reference: number;
  showSimulator = false;
  constructor(
    private bffService: BffService,
    private router: Router,
    private store: Store,
    private modal: NgbModal,
    private sanitizer: DomSanitizer,
    private habilitationService: HabilitationService,
    private translate: TranslationService) { }
    
  ngOnInit(): void {
    console.log('estimationInfo achat', this.simulationInfo);

    this.recapInfo = Object.values(this.recapInfo);
    this.getUrl(this.iframeData)
  }
  modePaiement(id: number) {
    console.log(id);

  }
  get lang() {
    return localStorage.getItem('lang') || 'fra'
  }
  get getTradsRecap() {
    const trads: string[] = this.translate.getTranslation(OPERATIONS_ACHAT_RECAP_LABEL)
    return Object.values(trads)
  }
  get getTradsSimu() {
    const trads: string[] = this.translate.getTranslation(OPERATIONS_ACHAT_SIMULATION_LABEL)
    return Object.values(trads);
  }

  // en cas de paiement accepté: recuperer refrence
  getRef(ocb_idTransaction: number) {
    const data = { ocb_idTransaction: ocb_idTransaction, modeReglt: this.currentTab }
    this.onSubmit.emit(data)
    this.reference = data.ocb_idTransaction
  }

  //verifier l'habilitation de paiment par carte bancaire
  get habilitCB() {
    return this.habilitationService.checkHabilitation(MODULE_CB)
  }
  //verifier l'habilitation de paiment par carte bancaire
  get habilitPrelevement() {
    return this.habilitationService.checkHabilitation(MODULES_PRELEVEMENT)
  }


  submitForm() {
    const modalRef = this.modal.open(PasswordModalComponent);
    modalRef.componentInstance.type = 1
    modalRef.result.then(_ => { }, (reason) => {

      if (reason === 'valid') {
        const data = { ocb_idTransaction: 1, modeReglt: this.currentTab }

        this.onSubmit.emit(data)
      }

    })

  }
  onEdit() {
    this.router.navigate(['profil']);
  }

  backAchat() {
    this.onback.emit(true);
    // hilight safe back to achat, dispatch flag to store
    this.store.dispatch(setIsAchat({ isAchat: true }));
  }

  getUrl(iFrameParams: iFrameParams) {
    if (iFrameParams) {
      this.bffService.getiFrame(iFrameParams).subscribe((res: any) => {
        if (res) {
          this.iFrameUrl = this.sanitizer.bypassSecurityTrustResourceUrl(res.urlPaiement);
        }
      })
    }

  }


}
