import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { UpteviaLibModule } from '../../../uptevia-lib.module';
import { CarteBankModule } from '../carte-bancaire/carte-bancaire.module';
import { PrelevementModule } from '../prelevement/prelevement.module';
import { PaiementComponent } from './paiement.component';
import { DirectiveModule } from 'src/app/directives/directives.modules';
@NgModule({
  declarations: [PaiementComponent ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    UpteviaLibModule,
    PrelevementModule,
    CarteBankModule,
    DirectiveModule
  ],
  exports:[PaiementComponent],
  bootstrap:[PaiementComponent]
})
export class PaiementModule { }
