import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { PrelevementComponent } from './prelevement.component';
import { UpteviaLibModule } from '../../../uptevia-lib.module';
 



@NgModule({
  declarations: [PrelevementComponent ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    UpteviaLibModule,
  ],
  exports:[PrelevementComponent],
  bootstrap:[PrelevementComponent]
})
export class PrelevementModule { }
