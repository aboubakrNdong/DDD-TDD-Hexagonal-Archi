import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PasswordModalComponent } from '../../../password-modal/password-modal.component';

import { Router } from '@angular/router';
import { OperationData } from 'src/app/entity/achat.demande';
import { Profil } from 'src/app/entity/profil';
import { RecapVente } from 'src/app/entity/recap-vente';
import { Titulaire } from 'src/app/entity/titulaire';
import { UserAccess } from 'src/app/entity/user';
import { TranslationService } from 'src/app/services/translation.service';
import { convertDate, convertToNumber, hideIBAN } from 'src/app/utils/functions';
import { OPERATIONS_ACHAT_SIMULATION_LABEL, OPERATIONS_VENTE_RECAP_LABEL } from 'src/app/utils/trads.maps';
@Component({
  selector: 'app-vente-paiement',
  templateUrl: './vente-paiement.component.html',
  styleUrls: ['./vente-paiement.component.css'],
})
export class VentePaiementComponent implements OnInit {
  @Output() onback = new EventEmitter<any>();
  @Output() onSubmit = new EventEmitter<any>();
  @Input() recapInfo: RecapVente;
  recapList: any;
  carteForm: FormGroup; 
  currentTab = 1;
  prelevementForm: FormGroup;
  estimationInfo: any;
  showSimulator = false
  profil: Profil = JSON.parse(sessionStorage.getItem("profile") || '{}');
  iban: string
  isShowIban = true;
  eyeIcone = 'bi bi-eye';
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private modal: NgbModal,
    private translate: TranslationService) { }

  ngOnInit(): void {

    console.log("this.recapInfo VentePaiementComponent", this.recapInfo);
    this.estimationInfo = this.recapInfo.estimationInfo
    this.recapList = Object.values(this.recapInfo.recapData);
    this.iban = this.profil?.ribIban
    this.initForm();
  }

  get ModeReglement() {
    return this.profil.tituModeReglement === "VIREMENT";
  }

  get getTradsSimu() {
    const trads: string[] = this.translate.getTranslation(OPERATIONS_ACHAT_SIMULATION_LABEL)
    return Object.values(trads)
  }

  get getTradsRecap() {
    const trads: string[] = this.translate.getTranslation(OPERATIONS_VENTE_RECAP_LABEL)
    return Object.values(trads)
  }


  private initForm() {
    this.prelevementForm = this.fb.group({
      banque: [this.profil.ribeBankNom],
      titulaire: new FormControl(this.profil.tituBene),
      iban: [hideIBAN(this.profil.ribIban)]
    });
  }

  get lang() {
    return localStorage.getItem('lang')
  }

  submitForm() {

    const modalRef = this.modal.open(PasswordModalComponent);
    modalRef.componentInstance.type = 2; //1 type achat, 2 type vente, 3tye levee

    modalRef.result.then(_ => { }, (reason) => {

      if (reason === 'valid' && this.recapInfo.titresAvendre.total > 0) {
        const titulaire: Titulaire = JSON.parse(localStorage.getItem("titulaire") || '{}');
        const user: UserAccess = JSON.parse(localStorage.getItem("user") || '{}');
        // TODO if password is correct modal return "valid" 
        // emit OperationData to VentePage 
        let data: OperationData = {
          emetIden: titulaire.emetIden,
          actiIden: titulaire.actiIden,
          tituNume: titulaire.tituNume,
          login: user.login,
          natureDemande: 4, //8 type Achat , 4 typeVente
          typeVente: this.recapInfo.modalite,
          valeIden: this.recapInfo.recapData.valeur,
          nbActions: this.recapInfo.recapData.quantity,
          coursLimite: this.convertCourslimite(this.recapInfo.recapData.coursLimite),
          dateFinValidite: convertDate(this.recapInfo.recapData.dateValidite),
          regltAttendu: 0, // que pour l'achat
          modeReglt: this.currentTab, //  Renseigner ‘1’ si virement, ‘9’ si CB, ‘6’ si prélèvement
          titres: this.recapInfo.titresAvendre.list

        };
        this.onSubmit.emit({ isValid: true, data });
      } else {
        this.onSubmit.emit({ isValid: false });

      }

    })

  }
  private convertCourslimite(coursLimite: any) {

    let converted = null;
    if (coursLimite !== undefined) {
      converted = convertToNumber(coursLimite);

      console.log("converted ", coursLimite, converted);

    }
    return converted;

  }

  backAchat() {
    this.onback.emit(true);
  }

  onEdit() {
    this.router.navigate(['profil']);
  }

  toggleIban() {
    this.isShowIban = !this.isShowIban
    if (this.isShowIban) {
      this.eyeIcone = 'bi bi-eye';
      this.prelevementForm.get('iban')?.setValue(hideIBAN(this.iban));
    } else {
      this.eyeIcone = 'bi bi-eye-slash';
      this.prelevementForm.get('iban')?.setValue(this.iban);
    }
  }
}
