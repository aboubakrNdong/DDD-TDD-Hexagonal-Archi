import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { UpteviaLibModule } from '../../../uptevia-lib.module';
import { VentePaiementComponent } from './vente-paiement.component';
import { DirectiveModule } from 'src/app/directives/directives.modules';
 
@NgModule({
  declarations: [VentePaiementComponent ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    UpteviaLibModule, 
    DirectiveModule,

  ],
  exports:[VentePaiementComponent],
  bootstrap:[VentePaiementComponent]
})
export class VentePaiementModule { }
