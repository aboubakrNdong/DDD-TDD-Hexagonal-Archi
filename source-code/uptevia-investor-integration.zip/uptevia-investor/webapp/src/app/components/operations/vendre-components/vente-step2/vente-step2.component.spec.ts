import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VenteStep2Component } from './vente-step2.component';

describe('VenteStep2Component', () => {
  let component: VenteStep2Component;
  let fixture: ComponentFixture<VenteStep2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VenteStep2Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VenteStep2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
