import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { CguComponent } from 'src/app/components/cgu/cgu.component';
import { Bareme } from 'src/app/entity/bareme';
import { PasCotation } from 'src/app/entity/pas-cotation';
import { StockCount } from 'src/app/entity/stock-count';
import { Titulaire } from 'src/app/entity/titulaire';
import { Valeur } from 'src/app/entity/valeur';
import { ValeurDetail } from 'src/app/entity/valeur-detail';
import { VenteType } from 'src/app/entity/vente-type.ts';
import { BffService } from 'src/app/services/bff.service';
import { ServerTimeService } from 'src/app/services/server-time.service';
import { TranslationService } from 'src/app/services/translation.service';
import { clearAvoirsaVendre } from 'src/app/store/actions/app.action';
import { BACKUP_BAREM_PAS_COTATION } from 'src/app/utils/const-vars';
import { checkTimeRange, countDecimal, getFrais, getMaxDayMonth, getMinMaxFrais, showModal, truncAmount } from 'src/app/utils/functions';
import { LIST_ORDERS, LIST_TYPE_STOCKS, OPERATIONS_ACHAT_SIMULATION_LABEL } from 'src/app/utils/trads.maps';


@Component({
  selector: 'app-vente',
  templateUrl: './vente.component.html',
  styleUrls: ['./vente.component.css'],
  providers: [DatePipe]
})
export class VenteComponent implements OnInit {
  @Input() valeurs: Valeur[];
  @Input() disabledDates: string[];
  @Output() onSubmit = new EventEmitter<any>();
  isStockClicked = false;
  valeurDetail: any;
  venteForm: FormGroup;
  selectedValeur: Valeur | undefined;
  listOrdre = LIST_ORDERS;
  stocks = LIST_TYPE_STOCKS;
  isCours: boolean = false;
  tick = 0.1;
  bareme: Bareme;
  amountNet = 0;
  nbrTitres = 0;
  stock: VenteType = { dispo: 0 };
  titresAvendre: StockCount;
  isWarningTime: boolean = false;
  ngDestroyed$ = new Subject<void>();

  constructor(
    private modal: NgbModal,
    private serverTimeService: ServerTimeService,
    private bffService: BffService,
    private datepipe: DatePipe,
    private store: Store,
    private translate: TranslateService,
    private translation: TranslationService) {
  }

  ngOnInit(): void {
    this.initForm();
    this.checkTimeWarnig();
    if (this.valeurs.length === 1) {
      this.selectedValeur = this.valeurs[0];
      this.onClickAction(this.selectedValeur)
    }
  }
  private initForm() {
    this.venteForm = new FormGroup({
      modalite: new FormControl(null, Validators.required),
      dateValidite: new FormControl(getMaxDayMonth(this.disabledDates), Validators.required),
      conditionsGen: new FormControl(false, Validators.requiredTrue)
    });
  }
  private checkTimeWarnig() {
    //Time of vente 17:30
    this.serverTimeService.serverTime$.subscribe((time) => {
      this.isWarningTime = checkTimeRange(time);
    })
  }

  onSelectModalite(id: number, courrsLimite?: number): void {
    if (id === 1) {
      let value = courrsLimite ? courrsLimite : '';
      this.venteForm.addControl("cours", new FormControl(value, [Validators.required]));
      this.isCours = true;

    } else {
      this.venteForm.removeControl('cours');
      this.isCours = false;
    }

  }

  countDecimal() {
    return countDecimal(this.tick)
  }

 

  get showSimulator() {
    const modalite: FormControl = this.venteForm.get('modalite') as FormControl;
    const isValidValeur: boolean = modalite.valid && this.bareme !== undefined && this.titresAvendre?.total > 0;
    
    if (this.isCours) {
      const cours: FormControl = this.venteForm.get('cours') as FormControl;
      return isValidValeur && cours.valid;
    } else {
      return isValidValeur;
    }
  }

  get getTrads() {
    const trads: string[] = this.translation.getTranslation(OPERATIONS_ACHAT_SIMULATION_LABEL)
    return Object.values(trads)
  }
  get lang() {
    return localStorage.getItem('lang')
  }
  get isfrench() {
    return this.lang === 'fr'
  }

  submitForm() {
    //If priorité renseigné et n'est pas identique
    if (!this.priorityIsDifferent()) {
      showModal('general.warning.error', ['operation.vente.errorPriorite'], 'general.bouton.fermer', this.modal)
      console.error("errror priority");
      return;
    }
    if (this.venteForm.valid && this.selectedValeur) {
      const dateValidite: FormControl = this.venteForm.get('dateValidite') as FormControl;
      const modaliteCtrl: FormControl = this.venteForm.get('modalite') as FormControl;

      const recapData = {
        date: this.datepipe.transform(new Date(), 'dd/MM/yyyy, HH:mm:ss'),
        reference: undefined,
        valeur: this.selectedValeur?.valeIden,
        typeAvoir: this.selectedValeur.valeNatu,
        quantity: this.titresAvendre.total,
        modalite: this.getModaliteTrans(modaliteCtrl.value),
        coursLimite: this.getCoursLimite(modaliteCtrl.value),
        dateValidite: this.datepipe.transform(dateValidite.value, 'dd/MM/yyyy')
      }
      const data = {
        recapData,
        modalite: modaliteCtrl.value,
        titresAvendre: this.titresAvendre,
        estimationInfo: { simulation: this.SimulationList, devise: this.selectedValeur.deviseNego }
      }
      this.onSubmit.emit(data);
    } else {
      this.onSubmit.emit('FORM NOT VALID');
    }
  }


  private getModaliteTrans(modaliteCtrl: number) {
    let modalite: any = this.listOrdre.find(order => order.orderId === modaliteCtrl);
    return this.translate.instant(modalite?.orderKey)
  }

  private getCoursLimite(modaliteCtrl: number): string | undefined {
    const cours: FormControl = this.venteForm.get('cours') as FormControl;
    let coursLimite;
    if (modaliteCtrl === 1) {
      console.log("coursvalue ", cours.value);
      let coursValue = cours.value.replace(',', '.');

      coursLimite = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(coursValue);
    }
    return coursLimite;
  }

  onClickAction(valeur: any) {
    this.selectedValeur = valeur;
    console.log('this.selectedValeur ', this.selectedValeur);

    //TODO: check in store  if bareme not null
    const titulaire: Titulaire = JSON.parse(localStorage.getItem("titulaire") || '{}');
    if (!this.valeurDetail && this.selectedValeur) {
      this.bffService.getValeurDetails(titulaire.emetIden, this.selectedValeur.valeIden, this.selectedValeur.valeNatu)
        .subscribe((valeurDetail: ValeurDetail) => {
          if (valeurDetail) {
            this.valeurDetail = valeurDetail
            this.handleValeurDetails(valeurDetail, valeur);
          }
        });
    } else {
      this.handleValeurDetails(this.valeurDetail, valeur);
    }

  }

  onTypeClicked(stock: any): void {
    if (stock.type !== '1' && this.selectedValeur) {//vente "un titre" stock.type ===1 
      console.log("onTypeClicked select ", stock);
      this.stock.dispo = this.selectedValeur.disponible;
      this.stock.indispo = this.selectedValeur.repartie;
      this.stock.title = stock.title;
      this.stock.type = stock.type
      this.isStockClicked = true
    }
  }

  handleValeurDetails(valeurDet: ValeurDetail, valeur: Valeur) {
    let valeurDetail = BACKUP_BAREM_PAS_COTATION;
        if (valeurDet?.bareme && valeurDet.pasCotation.length > 0) {
          valeurDetail = valeurDet;
        }
    const pasCotation: any = valeurDetail.pasCotation.find((pasCotation: PasCotation) => valeur.dernierCours < pasCotation.tranMax && valeur.dernierCours >= pasCotation.tranMin)
    this.tick = pasCotation.eche;
    this.bareme = valeurDetail.bareme;

  }

  onEditValeur() {
    this.selectedValeur = undefined;
    /* clear selecred selected Valeur from store  */
    this.store.dispatch(clearAvoirsaVendre())
    this.isStockClicked = false;
  }
  onEditTitre() {
    this.isStockClicked = false;
    if (this.titresAvendre) {
      this.titresAvendre.total = 0;
      this.titresAvendre.list = []
    }
    this.initForm();
  }

  get SimulationList(): number[] {
    const modalite: FormControl = this.venteForm.get('modalite') as FormControl;
    const cours: FormControl = this.venteForm.get('cours') as FormControl;
    let values: any = [1, 2]
    if (this.bareme !== undefined) {
      let mBrut = 0;
      /* Si modalité saisie = 'cours limite' , [montant estimé brut] = [quantité]  * [cours limite]
          Sinon [montant estimé brut] = [quantité] * [cours actuel] */

      if (this.titresAvendre && this.titresAvendre.total) {
        if (modalite.value === 1) {
          let coursValue = cours.value.replace(',', '.');

          mBrut = this.titresAvendre.total * coursValue;
        } else if (this.selectedValeur) {
          mBrut = this.titresAvendre.total * this.selectedValeur.dernierCours
        }
      }
      const calculatedFrais = getFrais(mBrut, this.bareme);
      const reelFrais = getMinMaxFrais(calculatedFrais, this.bareme);
      if (this.selectedValeur) {
        let amount = (mBrut - reelFrais) < 0 ? 0 : (mBrut - reelFrais);
        this.amountNet = truncAmount(amount)
      }
      mBrut = truncAmount(mBrut)
      values = [mBrut, undefined, reelFrais, this.amountNet];
    }

    return values
  }



  getTitresCount(data: any) {
    this.titresAvendre = data;
    const prioriteList = this.titresAvendre?.list
      .filter(titre => titre.priorite !== undefined && titre.priorite !== null && titre.priorite > 0)
      .map(titre => titre.priorite)
  }


  get allPriorities(): boolean {
    const prioriteList = this.titresAvendre?.list
      .filter(titre => titre.priorite !== undefined && titre.priorite !== null && titre.priorite > 0)
      .map(titre => titre.priorite)
    return this.titresAvendre?.list.length > 0 && (prioriteList?.length === this.titresAvendre?.list.length);
  }

  priorityIsDifferent() {
    const prioriteList = this.titresAvendre?.list
      .filter(titre => titre.priorite !== undefined && titre.priorite !== null && titre.priorite > 0)
      .map(titre => titre.priorite)
    const uniqueTitres = new Set(prioriteList);

    return uniqueTitres?.size === this.titresAvendre?.list.length;
  }

  openCGU() {
    console.log("open cgu clicked");
    this.modal.open(CguComponent, { size: 'xl' });

  }
}





