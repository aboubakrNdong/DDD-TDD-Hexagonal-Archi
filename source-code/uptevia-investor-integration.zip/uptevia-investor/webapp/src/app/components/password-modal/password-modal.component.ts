import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ErrorApi } from 'src/app/entity/erreur.api';
import { LoginRequest } from 'src/app/entity/login-request';
import { UserAccess } from 'src/app/entity/user';
import { LoginService } from 'src/app/services/login.service';
import { MessageService } from 'src/app/services/message.service';
import { isPasswordLimit } from 'src/app/utils/functions';

@Component({
  selector: 'app-password-modal',
  templateUrl: './password-modal.component.html',
  styleUrls: ['./password-modal.component.css'],
})
export class PasswordModalComponent implements OnInit {
  @Input() type = 1;
  password: any;
  error: boolean = false;
  buttonLabel = 'layout.sousmenu.achat';
  constructor(
    public messageService: MessageService,
    private loginService: LoginService,
    public activeModal: NgbActiveModal) { }
  ngOnInit(): void {
    switch (this.type) {
      case 2:
        this.buttonLabel = 'layout.sousmenu.vente';
        break;
      case 3:
        this.buttonLabel = 'layout.sousmenu.levee';
        break;
      default:
        this.buttonLabel = 'layout.sousmenu.achat';
        break;
    }
  }


  close() {
    this.activeModal.dismiss();
  }


  submit() {
    const user: UserAccess = JSON.parse(localStorage.getItem("user") || '{}');
    const loginRequest: LoginRequest = {
      login: user.login,
      password: this.password,
      operation: true
    } 
    
    this.loginService.authenticate(loginRequest)
      .subscribe((user: UserAccess) => {
        if (user) {
          this.loginService.user = user;
          this.activeModal.dismiss("valid");
        }
        else {
          this.error = true;
          const essai:number =this.messageService.getValueParam('essai')
          if(isPasswordLimit(essai) ){
            this.activeModal.close()
            this.loginService.logout();
          }

        }
      }, (error: ErrorApi) => {
        this.error = true;
        console.log(error, this.messageService.messages);

      })


  }
}
