import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ListOrigines } from 'src/app/entity/avoir-origin';
import { AvoirTitre } from 'src/app/entity/avoir-titre';
import { AvoirValeur } from 'src/app/entity/avoir-valeur';
import { TITRES_PORTEFEUILLE_BACKGROUND_COLORS } from 'src/app/utils/colors.map';

@Component({
  selector: 'app-titres-detail',
  templateUrl: './titres-detail.component.html',
  styleUrls: ['./titres-detail.component.css']
})
export class TitresDetailComponent implements OnInit {

  @Input() titreDetail: AvoirValeur;
  @Input() valeur: any;
  @Output() back = new EventEmitter<any>();
  public colorMap = TITRES_PORTEFEUILLE_BACKGROUND_COLORS;
  isFilter: number = 0;
  filtredTitres: AvoirTitre[] = []
  listTitres: AvoirTitre[] = []
  selectedOrigine: any

  ngOnInit(): void {

  }

  onClickOrigine(selctedTitre: ListOrigines) {
    console.log("select by origin", selctedTitre);
    this.selectedOrigine = selctedTitre
    this.filtredTitres = selctedTitre.listTitres
    this.listTitres = selctedTitre.listTitres
  }


  editOrigin() {
    console.log("edit origine clicked", this.selectedOrigine);
    this.selectedOrigine = undefined
  }

  TitresCountDetails(item: ListOrigines) {
    return item.listTitres.reduce((acc, titre) => {
      titre.disponible ? acc.dispo += titre.quantite : acc.indispo += titre.quantite
      acc.montant += titre.valorisation;
      acc.total = acc.dispo + acc.indispo;
      return acc
    }, { dispo: 0, indispo: 0, montant: 0, total: 0 })

  }

  filter(type: number) {
    if (this.isFilter !== type) {
      this.isFilter = type
    } else {
      this.isFilter = 0;
    }
    console.log("this.titreDetail ", this.titreDetail);
    switch (this.isFilter) {
      case 1:
        this.filtredTitres = this.listTitres.filter(titre => titre.disponible)
        break;
      case 2:
        this.filtredTitres = this.listTitres.filter(titre => !titre.disponible)
        break;
      default:
        this.filtredTitres = this.listTitres
        break;
    }
  }

  get OperationData(): (titre: AvoirTitre) => any {
    return (titre: AvoirTitre) => {
      let data = {};
      switch (titre.categorie) {
        case 'PUR':
        case 'ADMINISTRE':
          data = { date: titre.dateAcquisition, operation: titre.coursAcquisition, isReglement: false, quickAccess: true }
          break;
        //ISSUS AGA ISSUS BSPCE
        case 'PES':
          data = { date: titre.dateSouscription, operation: titre.prixSouscription, isReglement: true, quickAccess: true }
          break;
        case 'PEE':
          data = { date: titre.dateLevee, operation: titre.coursLevee, isReglement: false, quickAccess: false }
          break;
        case 'VALEUR':
        case 'PAGA':
          data = { date: titre.dateAcquisition, operation: titre.coursAcquisition, isReglement: true, quickAccess: true }
          break;
        default:
          data = { date: titre.dateLevee, operation: titre.coursLevee, isReglement: true, quickAccess: true }
          break;
      }

      return data;
    }
  }

  get getTrad() {

    let data;
    switch (this.selectedOrigine.origine) {
      case 'PES':
        data = { date: 'portefeuille.detail.dateSouscription', operation: 'portefeuille.detail.prixSouscription', isValid: true }

        break;
      case 'PEE':
      case 'SO':
      case 'BCE':
        data = { date: 'portefeuille.detail.dateLevee', operation: 'portefeuille.detail.coursLevee', isValid: false }

        break;
      default:
        data = { date: 'portefeuille.detail.dateAcquisition', operation: 'portefeuille.detail.coursAcquisition', isValid: true }
        break;
    }

    return data
  }
  get lang() {
    return localStorage.getItem('lang')
  }

  get backgroundColor(): (type: any) => string | undefined {
    return (type: string) => {
      const mapping = this.colorMap.find((cat: { title: string; color: string; }) => cat.title === type)
      return mapping?.color
    }
  }

  get borderColor(): (type: any) => string | undefined {
    return (type: string) => {
      const mapping = this.colorMap.find((cat: { title: string; border: string }) => cat.title === type)
      return mapping?.border
    }
  }


}
