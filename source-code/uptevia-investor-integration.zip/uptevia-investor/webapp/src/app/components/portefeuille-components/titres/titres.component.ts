import { Component, Input, Output, EventEmitter } from '@angular/core';
import { GroupTitre } from 'src/app/entity/group-titre';
import { TITRES_PORTEFEUILLE_BACKGROUND_COLORS } from 'src/app/utils/colors.map';



@Component({
  selector: 'app-titres-global',
  templateUrl: './titres.component.html',
  styleUrls: ['./titres.component.css']
})
export class TitresGlobalComponent {
  @Input() titresGlobal: any[];
  @Output() select = new EventEmitter<any>();
  public colorMap = TITRES_PORTEFEUILLE_BACKGROUND_COLORS;

  selectTitre(titre: any) {
    this.select.emit(titre);
  }

  get backgroundColor(): (type: any) => string | undefined {
    return (type: string) => {
      const mapping = this.colorMap.find((cat: { title: string; color: string;}) => cat.title === type)
      return mapping?.color
    }
  }

  get borderColor(): (type: any) => string | undefined {
    return (type: string) => {
      const mapping = this.colorMap.find((cat: { title: string; border: string;}) => cat.title === type)
      return mapping?.border
    }
  }

  get lang() { return localStorage.getItem('lang') }

}
