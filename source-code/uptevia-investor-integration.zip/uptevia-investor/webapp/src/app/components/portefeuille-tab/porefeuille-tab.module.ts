import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { DonutComponent } from '../donut-titres/donut.component';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { PortefeuilleTabComponent } from './portefeuille.component';



@NgModule({
  declarations: [PortefeuilleTabComponent, DonutComponent],
  imports: [
    CommonModule,UpteviaLibModule
  ],
  exports:[PortefeuilleTabComponent]
})
export class PortefeuilleTabModule { }
