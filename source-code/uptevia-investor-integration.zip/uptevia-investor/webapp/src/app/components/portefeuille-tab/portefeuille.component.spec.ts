import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PortefeuilleTabComponent } from './portefeuille.component';

describe('PortefeuilleTabComponent', () => {
  let component: PortefeuilleTabComponent;
  let fixture: ComponentFixture<PortefeuilleTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PortefeuilleTabComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PortefeuilleTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
