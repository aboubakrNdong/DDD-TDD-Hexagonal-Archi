import { Component, Input } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { CodeIso2 } from 'src/app/entity/codeiso2';
import { DonneesBancaire } from 'src/app/entity/donneesBancaire';
import { Titulaire } from 'src/app/entity/titulaire';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'profil-bancaire',
  templateUrl: './profil-bancaire.component.html',
  styleUrls: ['.././profil-tab.component.css']
})
export class ProfilBancaireComponent {

  @Input() profile: any = null;

  @Input() codeIso2: any = null;

  form: FormGroup;
  initialValues: any;
  cssFormControl = true;
  editable = false;
  styleDisabledField = true;
  submitted = false;
  submittedTwo = false;
  isButtonVisible = true;
  clickModifyButton = false;
  clickRollbackButton = false;
  numberCode: any;
  cacheData: any;
  paysSefa: any;
  iClicked = false;
  phone: any;
  checkIso2: true;
  showModeReglement = false;
  oldRibePaysIden: any;
  oldRibIban: any;
  oldRibeBic: any;
  oldRibDomi: any;
  oldRibeAgence: any;
  oldRibCompte: any;
  profilTituDevise: any;
  profilModeR: any;
  ribFiscaleLabel: any;

  constructor(
    private loginService: LoginService,
    private bffService: BffService,
    private formBuilder: FormBuilder,
    private translate: TranslateService
  ) {
  }

  ngOnInit(): void {
    this.createRibPaysIden();
    this.createModeDeReglement();
    this.createTituDevise();
    this.createProfilBancaire();
    this.getSefaCountries();
    this.getCodeIso2(this.profile.ribePaysIden);
    this.getOldValues();
  }


  getlabelForCountry(value: string): string {
    switch (value) {
      case 'FRA':
        return 'FRANCAIS';
      case 'ITA':
        return 'ITALIE';
      case 'ESP':
        return 'ESPAGNE';
      case 'DEU':
        return 'ALLEMAGNE';
      case 'ATF':
        return 'TERRE_AUSTRALE_FRANCAISE';
      case 'GLP':
        return 'GUADELOUPE';
      case 'GUF':
        return 'GUYANNE';
      case 'MAF':
        return 'SAINT_MARTIN';
      case 'MCO':
        return 'MONACO';
      case 'MTQ':
        return 'MARTINIQUE';
      case 'MYT':
        return 'MAYOTTE';
      case 'PYF':
        return 'POLYNESIE_FRANCAISE';
      case 'REU':
        return 'REUNION';
      case 'REU':
        return 'SAINT_PIERRE_MIQUELON';
      case 'SPM':
        return 'SAINT_PIERRE_MIQUELON';
      case 'WLF':
        return 'WALLIS_ET_FUTUNA';
      default:
        return value;
    }
  }

  getOldValues() {
    this.oldRibePaysIden = this.profile.ribePaysIden;
    this.oldRibIban = this.profile.ribIban;
    this.oldRibeBic = this.profile.ribeBic;
    this.oldRibDomi = this.profile.ribDomi;
    this.oldRibeAgence = this.profile.ribeBankAdre;
    this.oldRibCompte = this.profile.ribCompte;
  }
  createTituDevise() {
    if (this.profile.tituDevise === "EUR") {
      this.profilTituDevise = "EUROS";
    }
  }

  createRibPaysIden() {
    let ribFiscaleKey = 'general.pays.' + this.profile.ribePaysIden;
    this.ribFiscaleLabel = this.translate.instant(ribFiscaleKey);
  }

  createProfilBancaire() {
    this.form = this.formBuilder.group({

      ribePaysIden: [this.profile.ribePaysIden, [Validators.required], this.paysprefixValidator()],
      ribePays: this.ribFiscaleLabel,
      ribIban: [this.profile.ribIban, [Validators.required, Validators.minLength(22), Validators.maxLength(27)], this.ibanprefixValidator()],
      ribeBic: [this.profile.ribeBic, [Validators.required, Validators.pattern("[A-Za-z]{4}[A-Za-z]{2}[A-Za-z0-9]{2}([A-Za-z0-9]{3})?")], this.bicprefixValidator()],
      ribDomi: [this.profile.ribDomi, [Validators.required]],
      ribeBankAdre: this.profile.ribeBankAdre,
      ribeAgence: this.profile.ribeAgence,
      ribCompte: this.profile.ribCompte,
      tituBene: [this.profile.tituBene, [Validators.required]],
      tituMode: this.profilModeR,
      tituDevise: this.profilTituDevise,
      ribeBankCode: [],
      controlef: [],
    })
  }

  createModeDeReglement(){
    if(this.profile.tituModeReglement === "LITIGES"){
      this.profilModeR = "A COMPLETER"
    }
    this.profilModeR = this.profile.tituModeReglement;
  }


  modeReglement(): void {
    if (this.profile.tituModeReglement === "CHEQUE") {
      this.showModeReglement = true;
    }
  }

  private ibanprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const ribIban = control.value;
      return new Promise((resolve, reject) => {
        if (ribIban && !ribIban.startsWith(this.codeIso2)) {
          resolve({ invalidPrefix: true });
        } else {
          resolve(null);
        }
        if (ribIban.length != 22 && ribIban.length != 27) {
          resolve({ invalidPrefixIbAN: true });
        } else {
          resolve(null);
        }
      });
    }
  }

  private paysprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const ribePaysIden = control.value;
      this.getCodeIso2(ribePaysIden);
      this.codeIso2 = this.getCodeIso2(ribePaysIden);
      return new Promise((resolve, reject) => {
        if (ribePaysIden) {
          // resolve({ invalidPrefixPays: false });
        } else {
          resolve(null);
        }
      });
    }
  }

  private bicprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const ribeBic = control.value;
      const codeIso2Bic = ribeBic.slice(4, 6);
      return new Promise((resolve, reject) => {
        if (ribeBic && (codeIso2Bic != this.codeIso2)) {
          resolve({ invalidPrefixBic: true });
        } else {
          resolve(null);
        }

        if (ribeBic.length != 8 && ribeBic.length != 11) {
          resolve({ invalidPrefixBicLength: true });
        } else {
          resolve(null);
        }
      });
    }
  }

  getCodeIso2(paysIden: string): string {
    this.bffService.getCodeIso2(paysIden).subscribe(
      (codeiso2: CodeIso2) => {
        this.codeIso2 = codeiso2.paysIso2;
      })
    return this.codeIso2;
  }

  onModify() {
    this.clickModifyButton = true;
    this.clickRollbackButton = true;
    this.submitted = true;
    this.editable = true;
    this.styleDisabledField = false;
    this.initialValues = this.form.value;
    this.modeReglement();
  }

  onRollback() {
    this.clickModifyButton = false;
    this.clickRollbackButton = false;
    this.submitted = false;
    this.editable = false;
    this.styleDisabledField = true;
    this.form.reset(this.initialValues);
  }

  getSefaCountries() {
    const titulaire: Titulaire = JSON.parse(localStorage.getItem("titulaire") || '{}');
    const ParamName = "MAJ_COORD_BANK_PAYS_AUTORISE";
    const isConnected = this.loginService.isAuthenticated() ? titulaire.emetIden : 0;
    //handle cache
    let key = 'paysSefa';
    this.cacheData = sessionStorage.getItem(key);
    if (this.cacheData) {
      this.paysSefa = JSON.parse(this.cacheData);
    }
    else {
      this.bffService.getPaysSepa(isConnected, ParamName).subscribe(
        (reponse) => {
          this.paysSefa = reponse;
          //Save Data to cache
          sessionStorage.setItem(key, JSON.stringify(reponse))
        })
    }
  }

  onFormSubmit() {
    this.submitted = true;
    this.submittedTwo = true;
    const titulaire: Titulaire = JSON.parse(localStorage.getItem("titulaire") || '{}');
    const user = JSON.parse(localStorage.getItem("user") || '{}');
    const createPuser = "UP_" + user.login;

    if (this.form.invalid) {
      return;
    }

    if ((user === undefined || titulaire === undefined)) {
      console.error("user or titulaire undefined")
      return;
    }

    const data: DonneesBancaire = {
      p_login: user.login,
      p_emet: titulaire.emetIden,
      p_acti: titulaire.actiIden,
      p_titu_nume: titulaire.tituNume,
      p_user: createPuser,
      p_devise_old: this.profile.tituDevise,
      p_pays_old: this.oldRibePaysIden,
      p_reglement_old: this.profile.tituModeReglement,
      p_bic_old: this.oldRibeBic,
      p_iban_old: this.oldRibIban,
      p_domiciliation_old: this.oldRibDomi,
      p_devise: this.profile.tituDevise,
      p_pays: this.form.get('ribePaysIden')?.value,
      p_reglement: this.profile.tituModeReglement,
      p_bic: this.form.get('ribeBic')?.value,
      p_iban: this.form.get('ribIban')?.value,
      p_domiciliation: this.form.get('ribDomi')?.value,

    };
    // Send the old bic, iban,  and new rib, iban and ...
    this.sendDataToServer(data);
  }

  sendDataToServer(data: DonneesBancaire) {
    this.bffService.createDemandeUpdateBancaire(data).subscribe(
      (response: any) => {
        if (response) {
          //TODO display a popin when submit is success
          console.log('Demande crée avec succés!!', response);
        }
      },
      (error: any) => {
        console.error('Erreur lors de l\'enregistrement', error);
      });
  }
}


