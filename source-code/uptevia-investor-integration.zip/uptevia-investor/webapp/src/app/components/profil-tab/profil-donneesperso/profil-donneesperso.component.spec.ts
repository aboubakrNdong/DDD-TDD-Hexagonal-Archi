import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProfilDonneespersoComponent } from './profil-donneesperso.component';


describe('DonneespersoComponent', () => {
  let component: ProfilDonneespersoComponent;
  let fixture: ComponentFixture<ProfilDonneespersoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProfilDonneespersoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProfilDonneespersoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
