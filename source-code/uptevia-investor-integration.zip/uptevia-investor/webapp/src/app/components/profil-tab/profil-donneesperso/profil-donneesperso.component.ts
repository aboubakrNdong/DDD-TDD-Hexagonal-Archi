import { Component, Input, OnInit } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { DonneesPerso } from 'src/app/entity/donneesPerso';
import { Titulaire } from 'src/app/entity/titulaire';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { TranslateService } from '@ngx-translate/core';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'profil-donneesperso',
  templateUrl: './profil-donneesperso.component.html',
  styleUrls: ['.././profil-tab.component.css'],
  providers: [DatePipe]
})
export class ProfilDonneespersoComponent implements OnInit {

  @Input() profile: any = null;

  form: FormGroup;
  initialValues: any;
  cssFormControl = true;
  editable = false;
  editableFixe = false;
  styleDisabledField = true;
  styleDisabledFieldFixe = true;
  submitted = false;
  submittedTwo = false;
  isButtonVisible = true;
  clickModifyButton = false;
  clickRollbackButton = false;
  numberCode: any;
  cacheData: any;
  addContact = false;
  deleteContact = false;
  inputTelFixe = false;
  paysNaissanceLabel: any;
  paysFiscaleLabel: any;

  constructor(private formBuilder: FormBuilder,
    private loginService: LoginService, private bffService: BffService,
    private datepipe: DatePipe,
    private translate: TranslateService,
  ) {
  }

  ngOnInit(): void {
    this.createFiscalePays();
    this.createPaysNaissance();
    this.createProfilDonneesperso();
    this.initialValues = this.form.value;
    this.getIndicatifAutorise();
    //this.addAnotherPhone();
    this.deleteContactButton();
    this.addContactButton();
  }

  createProfilDonneesperso() {
    this.form = this.formBuilder.group({
      civilite: this.profile.qualite,
      nom: this.profile.nom,
      nomJF: this.profile.nomJF,
      prenom: this.profile.prenom,
      prenomTwo: this.profile.prenomTwo,
      dob: this.datepipe.transform(this.profile.tituNaisDate, 'dd/MM/yyyy'),
      dept: this.profile.tituNaisDept,
      lieu: this.profile.tituNaisComu,
      paysnaissance: this.paysNaissanceLabel,
      emailperso: [this.profile.emailPerso, [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],
      emailPro: [this.profile.emailPro, [Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],
      selectphone: ['+33', Validators.required],
      telMobilePerso: [this.profile.numMobilePerso, [Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(3), Validators.maxLength(10)], this.phoneprefixValidator()],
      telMobilePro: [this.profile.numMobilePerso, [Validators.pattern("^[0-9]*$"), Validators.minLength(3), Validators.maxLength(10)]],
      telFixePerso: [this.profile.numFixePerso, [Validators.pattern("^[0-9]*$"), Validators.minLength(3), Validators.maxLength(10)]],
      telFixePro: [this.profile.numFixePro, [Validators.pattern("^[0-9]*$"), Validators.minLength(3), Validators.maxLength(10)]],
      fiscaleBat: [this.profile.adreFiscInfoBati],
      adresseRue: [this.profile.adreInfoRue, [Validators.required]],
      complement: [this.profile.adreComplement],
      adresseFiscale: [this.profile.adreCodp, [Validators.required]],
      fiscaleVille: [this.profile.adreFiscNomCommune, [Validators.required]],
      fiscalePays: this.paysFiscaleLabel,
      postaleBat: [this.profile.adreInfoBati],
      postaleAdresseRue: [this.profile.adreInfoRue, [Validators.required]],
      postaleComplement: [this.profile.adreComplement],
      adressePostale: this.profile.adreCodp,
      postaleVille: [this.profile.adreNomCommune, [Validators.required]],
      postalePays: this.profile.adrePaysIden,
    })
  }

  createPaysNaissance() {
    let paysNaissanceKey = 'general.pays.' + this.profile.tituNaisPaysIden;
    this.paysNaissanceLabel = this.translate.instant(paysNaissanceKey);
  }

  createFiscalePays() {
    let paysFiscaleKey = 'general.pays.' + this.profile.adreFiscPaysIden;
    this.paysFiscaleLabel = this.translate.instant(paysFiscaleKey);
  }


  private phoneprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const telephone = control.value;
      return new Promise((resolve, reject) => {
        if (telephone && !telephone.startsWith('06') && !telephone.startsWith('07')) {
          resolve({ invalidPrefix: true });
        } else {
          resolve(null);
        }
      });
    }
  }

  onModify() {
    this.clickModifyButton = true;
    this.clickRollbackButton = true;
    this.submitted = true;
    this.editable = true;
    this.styleDisabledField = false;
    this.initialValues = this.form.value;
  }

  onRollback() {
    this.clickModifyButton = false;
    this.clickRollbackButton = false;
    this.submitted = false;
    this.editable = false;
    this.editableFixe = false;
    this.styleDisabledField = true;
    this.styleDisabledFieldFixe = true;
    this.inputTelFixe = false;
    this.form.reset(this.initialValues);
  }

  getIndicatifAutorise() {
    const titulaire: Titulaire = JSON.parse(localStorage.getItem("titulaire") || '{}');
    const ParamName = "TEL_INDICATIF_AUTORISE";
    const isConnected = this.loginService.isAuthenticated() ? titulaire.emetIden : 0;
    //handle cache
    let key = 'numberCode';
    this.cacheData = sessionStorage.getItem(key);
    if (this.cacheData) {
      this.numberCode = JSON.parse(this.cacheData);
    }
    else {
      this.bffService.getParametreSite(isConnected, ParamName).subscribe(
        (reponse) => {
          this.numberCode = reponse;
          //Save Data to cache
          sessionStorage.setItem(key, JSON.stringify(reponse))
        })
    }
  }

  deleteContactButton() {
    if ((this.profile.numMobilePerso && this.profile.numMobilePro && this.profile.numFixePro && this.profile.numFixePerso && this.profile.emailPerso && this.profile.emailPro) == null) {
      this.deleteContact = true;
      this.addContact = false;
    }
  }

  deleteContactButton2() {
    if ((this.profile.numMobilePerso || this.profile.numMobilePro || this.profile.numFixePro || this.profile.numFixePerso || this.profile.emailPerso || this.profile.emailPro) != "") {
      this.deleteContact = false;
    }
  }

  addContactButton() {
    if ((this.profile.numMobilePerso && this.profile.numMobilePro && this.profile.numFixePro && this.profile.numFixePerso && this.profile.emailPerso && this.profile.emailPro) != "") {
      //this.addContact = false;
    }
  }

  showTelFixeInput() {
    this.inputTelFixe = true;
    this.clickModifyButton = true;
    this.clickRollbackButton = true;
    this.submitted = true;
    this.editableFixe = true;
    this.styleDisabledFieldFixe = false;
    this.initialValues = this.form.value;
    console.log("show fixe input");
  }

  onFormSubmit() {
    this.submitted = true;
    this.submittedTwo = true;

    const titulaire: Titulaire = JSON.parse(localStorage.getItem("titulaire") || '{}');
    const user = JSON.parse(localStorage.getItem("user") || '{}');
    const createPuser = "UP_" + user.login;

    if (this.form.invalid) {
      return;
    }

    if ((user === undefined || titulaire === undefined)) {
      console.error("user or titulaire undefined")
      return;
    }

    const data: DonneesPerso = {
      pUser: createPuser,
      pOrig: user.login,
      pEmetIden: titulaire.emetIden,
      pActiIden: titulaire.actiIden,
      pTituNume: titulaire.tituNume,
      pTituEMail: this.form.get('emailperso')?.value,
      pTituEMail2: this.form.get('emailPro')?.value,
      pTituNumMobilePerso: this.form.get('telMobilePerso')?.value,
      pTituNumMobilePro: this.form.get('telMobilePro')?.value,
      pTituNumeTel: this.form.get('telFixePerso')?.value,
      pTituNumeTel2: this.form.get('telFixePro')?.value,
      pAdreFiscInfoBati: this.form.get('fiscaleBat')?.value,
      pAdreFiscInfoRue: this.form.get('adresseRue')?.value,
      pAdreFiscComp: this.form.get('complement')?.value,
      pAdreFiscCodp: this.form.get('adresseFiscale')?.value,
      pAdreFiscNomComu: this.form.get('fiscaleVille')?.value,
      pAdreInfoBati: this.form.get('postaleBat')?.value,
      pAdreInfoRue: this.form.get('postaleAdresseRue')?.value,
      pAdreComp: this.form.get('postaleComplement')?.value,
      pAdreCodp: this.form.get('adressePostale')?.value,
      pAdreNomComu: this.form.get('postaleVille')?.value,
    };
    // Send user info update  ...
    this.sendDataToServer(data);
  }

  sendDataToServer(data: DonneesPerso) {
    this.bffService.createDemandeUpdatePerso(data).subscribe(
      (response: any) => {
        if (response) {
          //TODO display a popin when submit is success
          console.log('Demande crée avec succés!!', response);
        }
      },
      (error: any) => {
        console.error('Erreur lors de l\'enregistrement', error);
      });
  }
}