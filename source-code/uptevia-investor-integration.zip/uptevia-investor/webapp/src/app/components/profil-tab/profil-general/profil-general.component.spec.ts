import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfilGeneralComponent } from './profil-general.component';

describe('GeneralComponent', () => {
  let component: ProfilGeneralComponent;
  let fixture: ComponentFixture<ProfilGeneralComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProfilGeneralComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProfilGeneralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
