import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';
import { BffService } from 'src/app/services/bff.service';

@Component({
  selector: 'profil-general',
  templateUrl: './profil-general.component.html',
  styleUrls: ['.././profil-tab.component.css'],
  providers: [DatePipe]
})
export class ProfilGeneralComponent implements OnInit {
  form: FormGroup;

  submitted: any;
  initialValues: any;
  concatNumCompte: string;
  @Input() profile: any = null;
  cacheData: any;
  concatEmetteur: string;
  clickModifyButton = false;
  clickRollbackButton = false;
  submittedTwo = false;
  profilLangue: string;
  styleDisabledField = true;
  cssFormControl = true;
  editable = false;
  classProLabel: any;
  classTypeLabel: any;
  format: string;
  theFinal: any;
  allLangues: any;

  constructor(private formBuilder: FormBuilder,
    private datepipe: DatePipe,
    private translate: TranslateService,
    private bffService: BffService,) {
  }

  ngOnInit(): void {
    this.getLangues();
    this.createActiTypeCpte();
    this.createClassPro();
    this.createTituDevise();
    this.createConvCompteTitre();
    this.createProfilGeneral();
  }

  getLangues() {
    this.bffService.getLangues("FRA")
    .subscribe((reponse) => {
        if(reponse){
        this.allLangues = reponse;
      }else {
        console.log("Error in get request");
      }
      },
    );
  }

  createProfilGeneral() {
    this.form = this.formBuilder.group({
      emetteur: this.createEmeteur(),
      numcompte: this.profile.actiIden,
      classmif: [this.profile.actiMifClass, [Validators.required]],
      classpro: this.profile.classProLabel,
      convcompttitre: this.profile.convcompttitre,
      dateenvoi: this.datepipe.transform(this.profile.actiConvDateEnvoi, 'dd/MM/yyyy'),
      datereception: this.datepipe.transform(this.profile.actiConvDateRecept, 'dd/MM/yyyy'),
      daterelance: this.datepipe.transform(this.profile.actiConvDateRelance, 'dd/MM/yyyy'),
      typecpte: this.classTypeLabel,
      actiRefeScte: this.profile.actiRefeSala,
      libellesociete: this.profile.drhRattachement,
      referencesociete: this.profile.actiRefeScte,
      languedescom: [this.profilLangue, [Validators.required]],
    })
  }

  createEmeteur(): string {
    this.concatEmetteur = this.profile.emetIden + "-" + this.profile.emetLibelle;
    return this.concatEmetteur;
  }

  createClassPro() {
    let classProKey = 'general.csp.' + this.profile.tituCsp;
    this.classProLabel = this.translate.instant(classProKey);
  }

  createActiTypeCpte() {

    let classTypeCpte = 'general.typecpte.' + this.profile.actiTypeCpte;
    let lastIndex = classTypeCpte.lastIndexOf(".");
    classTypeCpte = classTypeCpte.substring(0, lastIndex);
    let classTypeCpteToLower = classTypeCpte.toLowerCase();
    let classTypeCpteTransform = classTypeCpteToLower.split(" ").join("");
    this.classTypeLabel = this.translate.instant(classTypeCpteTransform);

  }

  createTituDevise() {
    if (this.profile.tituLanguage === "FR") {
      this.profilLangue = "FRANCAIS";
    }
  }

  getLangueForCountry(value: string): string {
    switch (value) {
      case 'FRA':
        return 'FRANCAIS';
      case 'PRT':
        return 'PORTUGAIS';
      case 'ITA':
        return 'ITALIEN';
      case 'NLD':
        return 'NEERLANDAIS';
      case 'ESP':
        return 'ESPAGNOL';
      case 'DEU':
        return 'ALLEMAND';
      case 'ENG':
        return 'ANGLAIS';
      default:
        return value;
    }
  }

  createConvCompteTitre() {
    if ((this.profile.actiConvIndiExclu === "O") || (this.profile.actiConvDateRecept != null)) {
      this.profile.convcompttitre = this.translate.instant('profil.compte.convcompttitre.complete');
    } else if (this.profile.actiConvIndiIncomp === "O") {
      this.profile.convcompttitre = this.translate.instant('profil.compte.convcompttitre.incomplete');
    } else if (this.profile.actiConvDateEnvoi != null) {
      this.profile.convcompttitre = this.translate.instant('profil.compte.convcompttitre.nonrecue');
    }
  }

  onFormSubmit() {
    this.submitted = true;
    this.submittedTwo = true;

    if (this.form.invalid) {
      console.log("invalid");
      return;
    }
    console.log(this.form.value);
  }

  onModify() {
    this.clickModifyButton = true;
    this.clickRollbackButton = true;
    this.submitted = true;
    this.editable = true;
    this.styleDisabledField = false;
    this.initialValues = this.form.value;
    //this.modeReglement();
  }

  onRollback() {
    this.clickModifyButton = false;
    this.clickRollbackButton = false;
    this.submitted = false;
    this.editable = false;
    this.styleDisabledField = true;
    this.form.reset(this.initialValues);
  }

  //TODO mettre l'api qui va combiner les 2 parametresite et libelle de codeiso2 

}

