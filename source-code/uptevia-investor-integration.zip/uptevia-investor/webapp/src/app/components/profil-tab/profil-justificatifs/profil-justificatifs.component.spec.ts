import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfilJustificatifsComponent } from './profil-justificatifs.component';

describe('ProfilJustificatifsComponent', () => {
  let component: ProfilJustificatifsComponent;
  let fixture: ComponentFixture<ProfilJustificatifsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProfilJustificatifsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProfilJustificatifsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
