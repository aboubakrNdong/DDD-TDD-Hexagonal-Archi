import { Component, Input } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'profil-justificatifs',
  templateUrl: './profil-justificatifs.component.html',
  styleUrls: ['.././profil-tab.component.css'],
  providers: [DatePipe]

})
export class ProfilJustificatifsComponent {


  form: FormGroup;
  natioLabel: any;
  profilLangue: any;

  @Input() profile: any = null;

  constructor(private formBuilder: FormBuilder,
    private datepipe: DatePipe,
    ) {
  }

  ngOnInit(): void {
    this.createNatioIso3();
    this.createProfilJustificatif();
  }
  createProfilJustificatif(){
    this.form = this.formBuilder.group({
    pjType: this.profile.pjTypeLib,
    idDocNumber: this.profile.idDocNumber,
    pjDateDeliv: this.datepipe.transform(this.profile.pjDateDeliv, 'dd/MM/yyyy'),
    pjDateExpir:this.datepipe.transform(this.profile.pjDateExpir, 'dd/MM/yyyy'),  
    natioIso3: this.profilLangue,
    pjNume: this.profile.pjNume,
    acceptTerms: []
  })

}

createNatioIso3() {
  if (this.profile.natioIso3 === "FRA") {
    this.profilLangue = "FRANCE";
  }
}

  onFormSubmit(){
    console.log(this.form.value);
  }}
