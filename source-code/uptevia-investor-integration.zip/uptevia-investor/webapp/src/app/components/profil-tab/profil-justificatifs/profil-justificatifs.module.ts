import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfilJustificatifsComponent } from './profil-justificatifs.component';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    ProfilJustificatifsComponent
  ],
  imports: [CommonModule, UpteviaLibModule,
    FormsModule,
    ReactiveFormsModule],
  exports: [ProfilJustificatifsComponent],
})
export class ProfilJustificatifsModule { }
