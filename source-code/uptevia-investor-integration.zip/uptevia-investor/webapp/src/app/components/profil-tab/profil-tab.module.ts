import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProfilBancaireModule } from './profil-bancaire/profil-bancaire.module';
import { ProfilTabComponent } from './profil-tab.component';
import { ProfilJustificatifsModule } from './profil-justificatifs/profil-justificatifs.module';
import { ProfilDonneesPersoModule } from './profil-donneesperso/profil-donneesperso.module';
import { ProfilGeneralModule } from './profil-general/profil-general.module';



@NgModule({
  declarations: [ProfilTabComponent],
  imports: [
    CommonModule, UpteviaLibModule, ProfilGeneralModule, ReactiveFormsModule, FormsModule, ProfilBancaireModule, ProfilDonneesPersoModule, ProfilJustificatifsModule
  ],
  exports: [ProfilTabComponent]
})
export class ProfilTabModule { }
