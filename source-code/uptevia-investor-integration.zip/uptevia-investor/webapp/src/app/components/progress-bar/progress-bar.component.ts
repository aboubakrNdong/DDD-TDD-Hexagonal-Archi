import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { Subject, interval, takeUntil } from 'rxjs';

@Component({
    selector: 'app-progress-bar',
    templateUrl: './progress-bar.component.html',
    styleUrls: ['./progress-bar.component.css']
})
export class ProgressBarComponent implements OnInit {
    percentage = 100;
    progress = 0;
    alive = true;
    ngDestroyed$ = new Subject<void>();
    isDelay = false;
    constructor(
        private store: Store,
        public activeModal: NgbActiveModal) {
        interval(100)
            .subscribe(() => {
                if (!this.isDelay) {
                    this.progress = this.percentage;
                    this.close()
                } else {
                    this.percentage += 0.6;


                }
                this.progress++
            });

    }
    ngOnInit(): void {
        this.getDelay();

    }

    close() {
        setTimeout(() => { this.activeModal.dismiss() }, 800);
    }

    getDelay() {
        this.store.select((state: any) => state.form)
            .pipe(
                takeUntil(this.ngDestroyed$))
            .subscribe((res) => {
                this.isDelay = res.dalayModalProgress;
            })
    }


    ngOnDestroy() {
        this.ngDestroyed$.next();
        this.ngDestroyed$.complete();
        this.alive = false;
    }

}
