
    

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgbProgressbarModule } from '@ng-bootstrap/ng-bootstrap';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { ProgressBarComponent } from './progress-bar.component';
import '@angular/localize/init'


@NgModule({
  declarations: [ProgressBarComponent],
  imports: [
    CommonModule,UpteviaLibModule,NgbProgressbarModule,
     
  ],
  exports:[ProgressBarComponent]
})
export class ProgressbarModule { }
