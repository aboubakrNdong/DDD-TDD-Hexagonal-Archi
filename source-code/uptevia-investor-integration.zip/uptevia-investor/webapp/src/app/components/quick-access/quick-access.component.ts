import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Quick_ACESS_DASHBOARD } from 'src/app/utils/const-vars';

@Component({
  selector: 'app-quick-access',
  template: `<div class="links">
  <h4>{{access.groupeNom | translate}}</h4> 
  <img class="hidden-xs" src="{{access.groupeImgName}}" alt="">
  <div class="buttons" >
      <div class="button" *ngFor="let button of access.sousModule">
          <uptevia-ui-button *ngIf="button.show" icon="{{button.groupeImgName}}" label="{{button.moduleNom | translate}}" [size]="'large'"
              color="primary" (onClick)="navigateTo(button.moduleUrl)"></uptevia-ui-button>
      </div>
  </div>
</div>`,
  styleUrls: ['./quick-access.component.css']
})
export class QuickAccessComponent {
  groupeImgName  :   null
  groupeNom  :   "layout.general.options"
  groupeOrdre  :   0
    groupeUrl  :   "general"
  showMenu  :   false
  @Input() access:any;
  constructor(
    private router: Router) { }

  navigateTo(path: string) {
    this.router.navigate([path]);
  }



}
