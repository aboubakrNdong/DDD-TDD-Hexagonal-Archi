import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RubriqueComponent } from './rubrique.component';
import { UpteviaLibModule } from '../uptevia-lib.module';



@NgModule({
  declarations: [RubriqueComponent],
  imports: [
    CommonModule,
    UpteviaLibModule
  ],
  exports: [RubriqueComponent]
})
export class RubriqueModule { }