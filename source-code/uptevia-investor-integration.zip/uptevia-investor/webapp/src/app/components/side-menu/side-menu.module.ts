import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { SideBarComponent } from './side-menu.component';



@NgModule({
  declarations: [SideBarComponent],
  imports: [
    CommonModule,
    RouterModule,
    UpteviaLibModule
  ],
  exports:[SideBarComponent]
})
export class SideBarModule { }
