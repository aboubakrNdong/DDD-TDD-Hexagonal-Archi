import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { DetailConnexion } from 'src/app/entity/detail-connexion';
import { BffService } from 'src/app/services/bff.service';
import { MessageService } from 'src/app/services/message.service';
import { setButtonChoice, setUsername } from 'src/app/store/actions/app.action';
import { showModal } from 'src/app/utils/functions';
import { Router } from '@angular/router';



@Component({
    selector: 'app-createpassword',
    templateUrl: './create-password.component.html',
    styleUrls: ['./create-password.component.css']
})
export class CreatePasswordComponent implements OnInit {
    @Output() onClick = new EventEmitter<any>();
    @Output() onSuccess = new EventEmitter<any>();

    @Input() token: string
    @Input() buttonChoice: any;
    formName = 'securing';
    securing: FormGroup;
    private ON_ERROR_ROUTE = 'login'; 
    ngDestroyed$ = new Subject<void>();

    submitted = false;
    formatUsername: any;
    formatEmail: any;
    loginPls: any;

    constructor(private formBuilder: FormBuilder,
        public messageService: MessageService,
        private bffService: BffService,
        private store: Store,
        private modal: NgbModal, 
        private router: Router,

    ) {


    }

    ngOnInit(): void {

        //Check if url contains the key word sd
        this.createForm();
        this.checkValidToken();
    }

    //checktoken 
    checkValidToken(): void {
        this.bffService.verifyToken(this.token)
            .subscribe((response) => {
                if (response) {
                    console.log("token is good");
                    this.loginPls = response.login; //response is login
                  
                    this.onSuccess.emit(response)
                    console.log("login is " + response);
                } else {
                    console.log("bad token");
                    showModal('general.warning.error', ['form.field.validator.mail.invalid'], 'general.bouton.fermer', this.modal, this.ON_ERROR_ROUTE)
                }
            });
    }

    createForm() {
        this.securing = this.formBuilder.group({
            inputPassword: [null,
                Validators.compose([
                    Validators.required,
                    // check whether the entered password has a number
                    this.patternValidator(/\d/, {
                        hasNumber: true
                    }),
                    // check whether the entered password has upper case letter
                    this.patternValidator(/[A-Z]/, {
                        hasCapitalCase: true
                    }),
                    // check whether the entered password has a lower case letter
                    this.patternValidator(/[a-z]/, {
                        hasSmallCase: true
                    }),
                    // check whether the entered password has a special character
                    this.patternValidator(
                        /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/,
                        {
                            hasSpecialCharacters: true
                        }
                    ),
                    Validators.minLength(12),
                    Validators.maxLength(16)])],
            inputPasswordConfirm: ['', Validators.compose([Validators.required])]
        },
            {
                // check whether our new password and confirm new password match
                validator: this.passwordMatchValidator
            }
        );
    }

    patternValidator(regex: RegExp, error: ValidationErrors): ValidatorFn {
        return (control: AbstractControl): { [key: string]: any } => {
            if (!control.value) {
                // if control is empty return no error
                return null as any;
            }
            // test the value of the control against the regexp supplied
            const valid = regex.test(control.value);
            // if true, return no error (no error), else return error passed in the second parameter
            return valid ? null as any : error;
        };
    }

    passwordMatchValidator(control: AbstractControl) {
        const password: string = control.get('inputPassword')?.value; // get password from our password form control
        const confirmPassword: string = control.get('inputPasswordConfirm')?.value; // get password from our confirmPassword form control
        // compare is the password match
        if (password !== confirmPassword) {
            // if they don't match, set an error in our confirmPassword form control
            control.get('inputPasswordConfirm')?.setErrors({ NoPassswordMatch: true });
        }
    }

    onFormSubmit() {
        this.submitted = true;

        if (this.securing.invalid) {
            console.log("invalid");
            return;
        }

        this.messageService.clear();
        let detailConnexion: DetailConnexion = {} as DetailConnexion;
        detailConnexion.newPassword = this.securing.get('inputPasswordConfirm')?.value;
        detailConnexion.login = this.loginPls;

        // dispatch data to store
        this.store.dispatch(setUsername({ username: this.loginPls })); 
        this.store.dispatch(setButtonChoice({ buttonchoice: this.buttonChoice }));



        this.bffService.savePassword(detailConnexion).subscribe(
            (data) => {
                if (data) {

                      if (this.buttonChoice === "forgotpassword") {
                         this.router.navigate(['resetsuccess']);
                       } 

                    this.onClick.emit();
                } else {
                    console.log("ERROR set passwoes");

                }
            })
    }
}
