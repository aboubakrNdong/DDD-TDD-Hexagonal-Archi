import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { UpteviaLibModule } from 'src/app/components/uptevia-lib.module';
import { DirectiveModule } from 'src/app/directives/directives.modules';
import { CreatePasswordComponent } from './create-password.component';


@NgModule({
  declarations: [CreatePasswordComponent],
  imports: [
    CommonModule,   
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    UpteviaLibModule, 
    DirectiveModule
  ],
  exports: [CreatePasswordComponent],
  bootstrap: [CreatePasswordComponent]
})
export class CreatePasswordModule { } 
