import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Subject, takeUntil } from 'rxjs';
import { Titulaire } from 'src/app/entity/titulaire';
import { UserAccessPls } from 'src/app/entity/userAccessPls';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { MessageService } from 'src/app/services/message.service';
import { sendEmail } from 'src/app/store/actions/app.action';
import { selecPlstUser } from 'src/app/store/selectors/app.selector';
import { hideEmail, hideTel, showModal, whiteListSms } from 'src/app/utils/functions';


@Component({
  selector: 'app-identification',
  templateUrl: './identification.component.html',
  styleUrls: ['./identification.component.css']
})
export class IdentificationComponent implements OnInit {

  formName = 'identification';
  identification: FormGroup;
  submitted = false;
  updateSuccess = false;

  @Output() onClick = new EventEmitter<any>()

  @Output() event = new EventEmitter<string>()


  @Input() buttonChoice: any = null;
  messages: string[] = [];
  ngDestroyed$ = new Subject<void>();
  login: any;
  numberCode: any;
  titulaire: Titulaire;
  editVialink: boolean = true;
  profile: UserAccessPls;
  isInWhitelistS: boolean = true;
  hiddenPhone: any = '';
  hiddenMail: any = '';

  constructor(
    public translate: TranslateService,
    private formBuilder: FormBuilder,
    private messageService: MessageService,
    private bffService: BffService,
    private modal: NgbModal,
    private store: Store,
    private router: Router,
    private loginService: LoginService
  ) { }

  ngOnInit(): void {
    this.initForm();
    this.getParamNumberCode();
    this.retreiveUsernameFromStore();
    this.checkForData()

  }

  initForm() {
    this.identification = this.formBuilder.group({
      username: [this.login, [Validators.required, Validators.minLength(8)]],
      indicator: ['+33', Validators.required],
      telephone: ['', [Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(3), Validators.maxLength(20)], this.phoneprefixValidator()],
      email: ['', [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],

    });
  }

  private phoneprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const telephone = this.identification.get("telephone")?.value;
      const indicator = this.identification.get("indicator")?.value;
      return new Promise((resolve, reject) => {
        if (telephone && !telephone.startsWith('06') && !telephone.startsWith('07')
          && indicator === '+33') {
          resolve({ invalidPhoneNumber: true });
        } else {
          resolve(null);
        }
      });
    }
  }

  updateForm() {
    const phone = this.profile?.numMobile?.substring(3, this.profile.numMobile?.length);
    const phoneWithPref = phone ? '0' + phone : ''
    const indicator = phone ? this.profile?.numMobile?.substring(0, 3) : '+33';

    console.log(phone);
    console.log(phoneWithPref);
    console.log(indicator);

    this.identification.controls['indicator'].setValue(indicator);
    this.identification.controls['telephone'].setValue(phoneWithPref);
    this.identification.controls['email'].setValue(this.profile?.email);
    this.identification.controls['username'].setValue(this.login);
    this.hiddenPhone = hideTel(phoneWithPref);
    this.hiddenMail = hideEmail(this.profile?.email);
  }


  private retreiveUsernameFromStore() {
    this.store.select(selecPlstUser)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        console.log("login from store", data);

        if (data.user?.loginUpi) {
          this.profile = data.user;
          this.login = data.user.loginUpi;
          this.updateForm()
        } else {
          console.error("ERROR Lgin or TiTULAIRE not FOUND");
        }
      });
  }
  checkForData() {
    setTimeout(() => {
      if (!this.profile) {
        this.router.navigateByUrl('login',{replaceUrl:true})
      }
    }, 400)
  }
  /**
  * Vialink upload check if mail and number not null
  */
  onclickUpload() {
    this.submitted = true; 
    //update Store ancienPls Data

  }
  /**
   * on vialink score is valid >90%
   */

  onSuccess(event: boolean) {
    // event ==true=> score Vialink >90%
    // event = false ==>score Vialink < 90%
    if (event) {
      this.sendMailtoConfirm();
      this.updatePlsuserData();

    } else {
      // 
      setTimeout(() => {
        showModal('general.warning.error', ['Vos demandes de modifications seront traitées sous 24 à 48h ouvrées'], 'general.bouton.fermer', this.modal, 'login')
      }, 500)
    }
  }

  updatePlsuserData() {
    const newEmail = this.identification.get('email')?.value
    const newPhone = this.identification.get('telephone')?.value
    const indicator = this.identification.get('indicator')?.value
    const user: any = {
      login: this.profile.loginUpi,
      mail: newEmail,
      telephone: indicator + newPhone
    }
    //  this.store.dispatch(setAncienPlsSuccess({ ancienPls: user }))
    this.bffService.UpdateUpiMailPhone(user).subscribe(res => {
      if (res) {
        console.log('user up to date ', res);

      } else {
        console.error('phone and not updated ')
      }

    })

  }

  onFormSubmit() {
    this.submitted = true;
    this.messageService.clear();
    if (this.identification.invalid) {

      Object.keys(this.identification.controls).forEach(key => {
        const control = this.identification.get(key);

        console.log(`conrol ${key} validity ${control?.errors}`);
      })

      return;
    }
    //check whitelist sms
    if (this.profile?.numMobile == null || !(whiteListSms.includes(this.profile?.numMobile))) {
      this.isInWhitelistS = false;
      console.log("number not in whitelist");
      return;
    }

    //Verify Identity of User  

    this.messageService.clear();
    this.messages = [];
    //TODO test later 

    //TODO Dev en back en cours
    this.sendMailtoConfirm();

  }



  sendMailtoConfirm() {
    this.bffService.sendEmailWithToken(this.login, this.buttonChoice)
      .subscribe((response) => {
        if (response) {
          console.log("sendEmailWithToken");
          this.store.dispatch(sendEmail({email:response}))
          this.onClick.emit();
        }
        else {
          this.messages = this.messageService.messages;
          // showModal('general.warning.alert', ['form.field.validator.submit'], 'general.bouton.fermer', this.modal);
        }
      })
  }
  getParamNumberCode() {
    const paramName = "TEL_INDICATIF_AUTORISE";
    const isConnected = this.loginService.isAuthenticated() ? this.profile.emetIden : 0;
    //handle cache
    let key = 'numberCode';
    this.bffService.getParametreSite(isConnected, paramName).subscribe(
      (reponse) => {
        this.numberCode = reponse;
        //Save Data to cache
        sessionStorage.setItem(key, JSON.stringify(reponse))
      })
  }

  onChangeIndic(event: any) {
    if (event.target.value) {
      this.identification.get("telephone")?.setValue("");
    }
  }

  editContactData() {
    this.editVialink = false;
    const phone = this.profile?.numMobile ? this.profile.numMobile : '';
    this.identification.controls['telephone'].setValue('0' + phone?.substring(3, phone?.length));
    this.identification.controls['email'].setValue(this.profile?.email);
  }

  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }
}