import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppCalendarModule } from 'src/app/components/calendar/calendar.module';
import { DirectiveModule } from 'src/app/directives/directives.modules';
import { IdentificationComponent } from './identification.component';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { UploadModule } from '../upload/upload.module';



@NgModule({
  declarations: [IdentificationComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    UpteviaLibModule,
    AppCalendarModule,
    DirectiveModule,
    UploadModule,
    
  ],
  exports:[IdentificationComponent],
  bootstrap:[IdentificationComponent]
})
export class IdentificationModule { }
