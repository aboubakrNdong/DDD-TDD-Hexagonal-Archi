import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginidentificationComponent } from './loginidentification.component';

describe('LoginidentificationComponent', () => {
  let component: LoginidentificationComponent;
  let fixture: ComponentFixture<LoginidentificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginidentificationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoginidentificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
