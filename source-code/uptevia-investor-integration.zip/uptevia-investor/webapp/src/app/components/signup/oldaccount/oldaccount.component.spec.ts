import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OldaccountComponent } from './oldaccount.component';

describe('OldaccountComponent', () => {
  let component: OldaccountComponent;
  let fixture: ComponentFixture<OldaccountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OldaccountComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OldaccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
