import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { LoginRequest } from 'src/app/entity/login-request';
import { LoginRequestPls } from 'src/app/entity/login-requestpls';
import { UserAccess } from 'src/app/entity/user';
import { UserAccessPls } from 'src/app/entity/userAccessPls';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { MessageService } from 'src/app/services/message.service';
import { getAncienPls, sendEmail, setEmail, setUsername } from 'src/app/store/actions/app.action';
import { selecPlstUser } from 'src/app/store/selectors/app.selector';



@Component({
  selector: 'app-oldaccount',
  templateUrl: './oldaccount.component.html',
  styleUrls: ['./oldaccount.component.css']
})
export class OldaccountComponent implements OnInit {
  @Input() buttonChoice: any = null;
  @Output() onClick = new EventEmitter<any>();
  ngDestroyed$ = new Subject<void>();

  oldLoginForm!: FormGroup;
  showOldPls = false;
  messages: string[] = [];
  submitted = false;
  mockCode: any;
  user: UserAccess;
  userPls: UserAccessPls;

  isCredentials = false;

  constructor(private fb: FormBuilder,
    private store: Store,
    private loginService: LoginService,
    public messageService: MessageService,
    private bffService: BffService,) {

  }

  ngOnInit(): void {

    console.log("buttonchoice" + this.buttonChoice);
    if (this.buttonChoice === "oldolis") {
      this.mockCode = "K1171608F24";
    }
    if (this.buttonChoice === "oldpls") {
      this.showOldPls = true;
      this.mockCode = "";
    }
    this.createoldLoginForm();
  }

  verifyAncienOlisAccount() {
    const loginRequest: LoginRequest = {
      login: this.oldLoginForm.value.username,
      password: this.oldLoginForm.value.password
    }

    this.loginService.authenticateAncienOlis(loginRequest)
      .subscribe((user: UserAccess[]) => {
        if (user) {
          this.user = user[0];
          let userEmail = this.user.email;
          let userLogin = this.oldLoginForm.value.username
          localStorage.setItem('user', JSON.stringify(user));
          // dispatch old datas to store
          this.store.dispatch(setUsername({ username: userLogin }));
          this.store.dispatch(setEmail({ email: userEmail }));

          this.bffService.sendEmailWithToken(userLogin, this.buttonChoice)
            .subscribe((response) => {
              if (response) {
                console.log("sendEmailWithToken");
                this.store.dispatch(sendEmail({ email: response }))

                this.onClick.emit()
              }
            });
        } else {
          this.isCredentials = true;
          this.messages = this.messageService.messages;
          console.log('Authentification échouée');
        }
      });
  }

  verifyAncienPlsAccount() {
    let loginRequestPls: LoginRequestPls =
    {
      emetIden: this.oldLoginForm.value.username,
      accessCode: this.oldLoginForm.value.code,
      password: this.oldLoginForm.value.password
    }
    if (window.location.href.includes('localhost')) {
      loginRequestPls = {
        "emetIden": '01403',
        "accessCode": "G0000015N59",
        "password": "Mpfsam+0901"
      }
    }
    this.store.dispatch(getAncienPls({ loginRequestPls })) //Add action to handle failure
    this.handleSuccess();

  }

  handleSuccess() {
    this.store.select(selecPlstUser)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        if (data?.user) {
          this.onClick.emit();
          console.log("user Found", data);

        } else {
          console.error("TiTULAIRE NOT FOUND");

        }
      })
  }
  createoldLoginForm() {
    this.oldLoginForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(4)]],
      code: [this.mockCode, Validators.required],
      password: ['', Validators.required],
    });
  }

  submitLoginButton() {
    this.submitted = true;
    if (this.oldLoginForm.invalid) {
      console.log("invalid");
      return;
    }

    if (this.buttonChoice === "oldolis") {
      this.verifyAncienOlisAccount();
    }

    if (this.buttonChoice === "oldpls") {
      this.verifyAncienPlsAccount();
    }
  }

  get username(): AbstractControl {
    return this.oldLoginForm.get('username')!;
  }

  get code(): AbstractControl {
    return this.oldLoginForm.get('code')!;
  }



  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }

}
