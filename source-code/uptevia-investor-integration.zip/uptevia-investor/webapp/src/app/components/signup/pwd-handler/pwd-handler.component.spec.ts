import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PwdHandlerComponent } from './pwd-handler.component';

describe('PwdHandlerComponent', () => {
  let component: PwdHandlerComponent;
  let fixture: ComponentFixture<PwdHandlerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PwdHandlerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PwdHandlerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
