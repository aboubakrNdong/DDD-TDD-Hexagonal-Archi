import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, ValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { MessageService } from 'src/app/services/message.service';
import { DetailConnexion } from 'src/app/entity/detail-connexion';
import { BffService } from 'src/app/services/bff.service'; 
import { Store } from '@ngrx/store';
import { selectSignUpData } from 'src/app/store/selectors/app.selector';
import { Subject, takeUntil } from 'rxjs';


@Component({
  selector: 'app-pwd-handler',
  templateUrl: './pwd-handler.component.html',
  styleUrls: ['./pwd-handler.component.css']
})
export class PwdHandlerComponent implements OnInit {

  formName = 'securing';
  securing: FormGroup;
  messages: string[] = [];
  updateSuccess = false;
  @Output() onClick = new EventEmitter<any>();

  @Input() buttonChoice: any = null;
  ngDestroyed$ = new Subject<void>();

  submitted = false;
  formatUsername: any;
  formatEmail: any;
  showOldOlisOrPls = false;
  mockusername: any; //TODO few things
  storeUsername: any;
  storeEmail: any;
  storeOldPassword: any;

  constructor(private formBuilder: FormBuilder,
    private messageService: MessageService,
    private bffService: BffService,
    private store: Store,) { }

  ngOnInit(): void {
    console.log("buttonChoice" + this.buttonChoice);
    if (this.buttonChoice === "oldolis" || this.buttonChoice === "oldpls") {
      this.showOldOlisOrPls = true;
      this.mockusername = "";
    }
    if (this.buttonChoice === "firstconnexion") { 
      this.mockusername = "username";
    }
    
    //retrieve signupdata from store
    this.retreiveSignUpDataFromStore();
    this.createForm();
  }

  createForm() {
    this.securing = this.formBuilder.group({
      username: [this.mockusername, [Validators.required, Validators.minLength(8)]],
      inputPassword: [null,
        Validators.compose([
          Validators.required,
          // check whether the entered password has a number
          this.patternValidator(/\d/, {
            hasNumber: true
          }),
          // check whether the entered password has upper case letter
          this.patternValidator(/[A-Z]/, {
            hasCapitalCase: true
          }),
          // check whether the entered password has a lower case letter
          this.patternValidator(/[a-z]/, {
            hasSmallCase: true
          }),
          // check whether the entered password has a special character
          this.patternValidator(
            /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/,
            {
              hasSpecialCharacters: true
            }
          ),
          Validators.minLength(12),
          Validators.maxLength(16)])],
      inputPasswordConfirm: ['', Validators.compose([Validators.required])]
    },
      {
        // check whether our new password and confirm new password match
        validator: this.passwordMatchValidator
      }
    );
  }

  patternValidator(regex: RegExp, error: ValidationErrors): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!control.value) {
        // if control is empty return no error
        return null as any;
      }
      // test the value of the control against the regexp supplied
      const valid = regex.test(control.value);
      // if true, return no error (no error), else return error passed in the second parameter
      return valid ? null as any : error;
    };
  }

  passwordMatchValidator(control: AbstractControl) {
    const password: string = control.get('inputPassword')?.value; // get password from our password form control
    const confirmPassword: string = control.get('inputPasswordConfirm')?.value; // get password from our confirmPassword form control
    // compare is the password match
    if (password !== confirmPassword) {
      // if they don't match, set an error in our confirmPassword form control
      control.get('inputPasswordConfirm')?.setErrors({ NoPassswordMatch: true });
    }
  }

  private retreiveSignUpDataFromStore() {
    this.store.select(selectSignUpData)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        this.storeUsername = data.username;
        this.storeEmail = data.email; 
      });
  }


  onFormSubmit() { //TODO vérifier que l'identifiant saisie est le meme que celui recu par mail 
    this.submitted = true;

    if (this.securing.invalid) {
      console.log("invalid");
      return;
    }

    this.messageService.clear();
    this.messages = [];
    let detailConnexion: DetailConnexion = {} as DetailConnexion;
    detailConnexion.oldPassword = this.storeOldPassword;
    detailConnexion.newPassword = this.securing.get('inputPasswordConfirm')?.value;

    if (this.buttonChoice === "oldolis" || this.buttonChoice === "oldpls" ) {
       // dispatch newusername to store 
      detailConnexion.login = this.securing.value.username;
    }else {
      detailConnexion.login = this.storeUsername;
    }

    detailConnexion.email = this.storeEmail;
    this.onClick.emit();

      this.bffService.savePassword(detailConnexion).subscribe(
        (data) => {
          if (data) {
            this.updateSuccess = true; 
          } else {
            this.messages = this.messageService.messages;
          }
        }
      );
  }
}
