import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SecretQComponent } from './secret-q.component';

describe('SecretQComponent', () => {
  let component: SecretQComponent;
  let fixture: ComponentFixture<SecretQComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SecretQComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SecretQComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
