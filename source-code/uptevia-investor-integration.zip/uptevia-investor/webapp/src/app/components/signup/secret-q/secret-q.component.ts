import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable, Subject, map, takeUntil } from 'rxjs';
import { Email } from 'src/app/entity/email';
import { FetchSecretQuestions } from 'src/app/entity/fetchsecret-questions';
import { SecretQuestions } from 'src/app/entity/secret-questions';
import { Titulaire } from 'src/app/entity/titulaire';
import { TokenLogin } from 'src/app/entity/token-password';
import { UserAccess } from 'src/app/entity/user';
import { MessageService } from 'src/app/services/message.service';
import { fetchSecretQuestions, saveSecretQuestions } from 'src/app/store/actions/app.action';
import { selectAppState } from 'src/app/store/selectors/app.selector';



@Component({
  selector: 'app-secret-q',
  templateUrl: './secret-q.component.html',
  styleUrls: ['./secret-q.component.css']
})
export class SecretQComponent implements OnInit {

  formName = 'secretq';
  secretq: FormGroup;
  selectedNames1: string[] = [];
  selectedNames2: string[] = [];
  secretQuestions: any[];
  submitted = false;
  hide: boolean = true;

  @Output() onClick = new EventEmitter<any>()
  @Input() buttonChoice: any = null;
  @Input() tokenLogin:TokenLogin;

  ngDestroyed$ = new Subject<void>();

  cacheData: any;
  updateSuccess: boolean;
  messages: string[] = [];
  formatUsername: any;
  formatPassword: any;
  titulaire: Titulaire;
  user: UserAccess;
  loginError: boolean = false;
  storeUsername: any;

  idQuestion1: any;
  idQuestion2: any
  tokenLoginPls: TokenLogin

  secretquestions$: Observable<FetchSecretQuestions[]>;

  constructor(private formBuilder: FormBuilder, 
    private messageService: MessageService,
    private store: Store,) { }

  ngOnInit(): void {
    this.createForm();
    this.getSecret();
    console.log("buttonChoice" + this.buttonChoice);
    this.retreiveSignUpDataFromStore();
  }

  onSelectChange(questionKey: string, controlName: string) {
    this.secretquestions$
      .pipe(
        map((questions: FetchSecretQuestions[]) => questions.find(question => question.questionKey === questionKey))
      )
      .subscribe((selectedQuestion: FetchSecretQuestions | undefined) => {
        if (selectedQuestion) {
          this.handleSelectedQuestion(selectedQuestion, controlName);
        }
      });
  }

  private handleSelectedQuestion(selectedQuestion: FetchSecretQuestions, controlName: string) {
    if (controlName === 'questionOneList') {
      this.idQuestion1 = selectedQuestion.idQuestion;
    } else if (controlName === 'questionTwoList') {
      this.idQuestion2 = selectedQuestion.idQuestion;
    }
    this.secretq.get(controlName)?.setValue(selectedQuestion.questionKey);
  }


  private retreiveSignUpDataFromStore() {
    this.store.select(selectAppState)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        console.log('data store', data);

        this.storeUsername = data.username;
        this.buttonChoice = data.buttonchoice;
        if (data?.isOldPlsCompleted) {
          this.onClick.emit();
        }
      });
  }

  createForm() {
    this.secretq = this.formBuilder.group({
      questionOneList: ['', Validators.required],
      responseOne: ['', [Validators.required, Validators.minLength(3)]],
      questionTwoList: ['', Validators.required],
      responseTwo: ['', [Validators.required, Validators.minLength(3)]],
    });
  }

  getSecret() {
    this.store.dispatch(fetchSecretQuestions())
    this.secretquestions$ = this.store.select((state: any) => state.form.questions)
  }


  onFormSubmit() {
    this.submitted = true;
    if (this.secretq.invalid) {
      console.log("invalid");
      return;
    }

    this.messageService.clear();

    const saveSecret: SecretQuestions = {
      login: this.storeUsername,
      firstQuestion: this.idQuestion1,
      firstAnswer: this.secretq.value.responseOne,
      secondQuestion: this.idQuestion2,
      secondAnswer: this.secretq.value.responseTwo,
      buttonChoice: this.buttonChoice,
    };

    if (this.secretq.valid) {

      const email: Email = {
        "recipients": [this.tokenLogin.email ],
        "from": "no-reply@uptevia.com",
        "textBody": `Votre identifiant pour ce site est :   ${this.tokenLogin.login}.<br><br>Merci de le conserver précieusement pour vos connexions à venir .<br><br><br><br>`,
        "htmlBody": "",
        "subject": "Envoi de votre identifiant pour Uptevia Investors",
        "typeMail": "",
        "attachments": []
      }
      this.store.dispatch(saveSecretQuestions({ secretQuestions: saveSecret, email: email }))
    }

  }
}