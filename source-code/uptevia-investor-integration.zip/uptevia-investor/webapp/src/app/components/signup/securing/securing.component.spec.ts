import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SecuringComponent } from './securing.component';

describe('SecuringComponent', () => {
  let component: SecuringComponent;
  let fixture: ComponentFixture<SecuringComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SecuringComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SecuringComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
