import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { BffService } from 'src/app/services/bff.service';
import { setSmsCode } from 'src/app/store/actions/app.action';
import { TranslateService } from '@ngx-translate/core';
import { LoginService } from 'src/app/services/login.service';
import { Subject, takeUntil } from 'rxjs';
import { selectUsername } from 'src/app/store/selectors/app.selector';
import { Titulaire } from 'src/app/entity/titulaire';
import { Profil } from 'src/app/entity/profil';
import { MessageService } from 'src/app/services/message.service';
import { whiteListSms } from 'src/app/utils/functions';
import { smsData } from 'src/app/entity/smsData';



@Component({
  selector: 'app-securing',
  templateUrl: './securing.component.html',
  styleUrls: ['./securing.component.css']
})
export class SecuringComponent implements OnInit {

  isChooseValidation = true;
  isConfirmValidation = false;
  numPhone = "";
  storeUsername: any;
  ngDestroyed$ = new Subject<void>();
  titulaireData: Titulaire;
  profile: any;
  messages: string[] = [];
  isInWhitelistS = true;
  isInRegistrar = true;


  @Output() onClick = new EventEmitter<any>()

  ngOnInit(): void {
    this.retreiveUsernameFromStore();
    this.getTitulaire();
  }

  constructor(private bffService: BffService,
    private store: Store,
    private translate: TranslateService,
    private loginService: LoginService,
    private messageService: MessageService,

  ) { }

  onReceptionSMS() {

     //check if number or mail or dob are null
     if(this.numPhone == null ){
      console.log("Data missing");
      this.isInRegistrar = false;
      return;
    }

    let randomCode = Math.floor(100000 + Math.random() * 900000);

    const smsNumber: smsData = {
      text: this.translate.instant('form.field.sendsms') + randomCode,
      mobileNumbers: [this.numPhone]
    };

    if (whiteListSms.includes(this.numPhone)) {
      if (smsNumber) {
        this.bffService.sendSms(smsNumber).subscribe((res: any) => {
          if (res) {
            console.log("sms sent successfully", res);

            //Mettre à jour la base que le user a validé son OTP
            let login = this.storeUsername.toString();
            this.bffService.getValideOtp(login).subscribe(
              (reponse) => {
                if (reponse) {
                  console.log('Mise à jour statut OTP effectuée')

                } else {
                  console.log('Mise à jour statut OTP non effectuée')
                }
              },
              (error) => {
                console.log('can not get categories', error);
              }
            );
            this.store.dispatch(setSmsCode({ smscode: randomCode.toString() }));
            this.onClick.emit();
          } else {
            this.messages = this.messageService.messages;
            return;
          }
        })
      }
    } else {
      this.isInWhitelistS = false;
      console.log("number not in whitelist");
    }


  }

  private retreiveUsernameFromStore() {
    this.store.select(selectUsername)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        console.log("storeUserName ME", data.username);
        this.storeUsername = data.username;
      });
  }

  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }


  getTitulaire() {
    let login = this.storeUsername.toString();
    this.loginService.getTitulaire(login).subscribe((titulaires: Profil[]) => {
      if (titulaires) {
            this.profile = titulaires;
            this.numPhone = this.profile.numMobilePerso ;
            console.log("number is ", this.profile.numMobilePerso);
      } else {
        this.messages = this.messageService.messages;
      }
    })
  }

  onReceptionVocal() {
    //  this.onClick.emit()
  }

  onValidateSMS() {
  }
}
