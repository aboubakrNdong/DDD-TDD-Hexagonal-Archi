import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { selectSmsCode } from 'src/app/store/selectors/app.selector';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { Router } from '@angular/router';
import { showModal } from 'src/app/utils/functions';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { clearData } from 'src/app/store/actions/app.action';



@Component({
  selector: 'app-signup-completed',
  templateUrl: './signup-completed.component.html',
  styleUrls: ['./signup-completed.component.css']
})
export class SignupCompletedComponent implements OnInit {


  @Input() login: string;
  ON_ERROR_ROUTE = 'login'
  constructor(private router: Router,
    private modal: NgbModal,
    private store: Store,
  ) {

  }

  ngOnInit(): void {

    if (!this.login) {
      showModal('general.warning.error', ['form.field.validator.mail.invalid'], 'general.bouton.fermer', this.modal, this.ON_ERROR_ROUTE)
    }

  }


  gotoLogin() {
    this.store.dispatch(clearData());
    this.router.navigateByUrl('login', { replaceUrl: true })
  }



}
