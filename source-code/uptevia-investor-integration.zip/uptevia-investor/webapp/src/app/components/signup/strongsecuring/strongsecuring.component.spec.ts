import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StrongSecuringComponent } from './strongsecuring.component';

describe('SecuringPageComponent', () => {
  let component: StrongSecuringComponent;
  let fixture: ComponentFixture<StrongSecuringComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StrongSecuringComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StrongSecuringComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
