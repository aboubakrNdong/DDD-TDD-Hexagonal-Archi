import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { selectSmsCode } from 'src/app/store/selectors/app.selector';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';



@Component({
  selector: 'app-strongsecuring',
  templateUrl: './strongsecuring.component.html',
  styleUrls: ['./strongsecuring.component.css']
})
export class StrongSecuringComponent implements OnInit {

  formName = 'identificationPage';
  identificationPage: FormGroup;
  submitted = false;
  result = true;
  count = 0;
  decount = 3;
  finish = false;
  incorrect = false;
  storeSmsCode: any;
  @Output() onClick = new EventEmitter<any>()

  @Input() buttonChoice: any = null;

  ngDestroyed$ = new Subject<void>();

  timeCode: any = 0;
  isExpired = false;

  constructor(private formBuilder: FormBuilder,
    private store: Store
  ) {

  }

  ngOnInit(): void {
    this.retreiveSmsCodeFromStore();
    this.createForm();
    console.log("buttonChoice s" + this.buttonChoice);

    this.timeCode = setInterval(() => {
      this.isCodeExpired();
    }, 600000);  //after 10 min, code expired

  }

  isCodeExpired() {
    console.log("sms expired after 10 minutes");
    this.isExpired = true;
  }

  createForm() {
    this.identificationPage = this.formBuilder.group({
      code: ['', Validators.compose([Validators.required, Validators.minLength(6), Validators.pattern("^[0-9]*$"), Validators.maxLength(6)]), this.codeUserValidator()],
    });
  }

  private codeUserValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const code = control.value;
      return new Promise((resolve, reject) => {
        if (this.storeSmsCode != code) {
          //resolve({ invalidPrefix: true });
          this.result = false;
          console.log("code différent");
        } else {
          this.result = true;
          resolve(null);
        }
      });
    }
  }

  private retreiveSmsCodeFromStore() {
    this.store.select(selectSmsCode)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        this.storeSmsCode = data.smscode;
      });
  }

  onFormSubmit() {

    this.submitted = true;
    if (this.identificationPage.invalid) {
      console.log("invalid");
      return;
    }

    if (this.result == false) {
      this.count = this.count + 1;
      this.decount = this.decount - 1;
      this.incorrect = true;
      if (this.count == 3) {
        this.finish = true;
        return;
      }
    } else {
      this.incorrect = false;
      this.onClick.emit()
      return;
    }
  }

  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
    if (this.timeCode) {
      clearInterval(this.timeCode);
    }
  }

}
