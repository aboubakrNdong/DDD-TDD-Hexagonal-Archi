import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { Email } from 'src/app/entity/email';
import { UserAccessPls } from 'src/app/entity/userAccessPls';
import { ControlStatus } from 'src/app/entity/vialink/control-status';
import { FileType } from 'src/app/entity/vialink/enum-file-type';
import { createControlViaLink, sendEmail } from 'src/app/store/actions/app.action';
import { AppState } from 'src/app/store/reducers/app.reducer';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {
  
  @Output() onClick: EventEmitter<any> = new EventEmitter<any>()
  @Output() handlSuccess: EventEmitter<boolean> = new EventEmitter<boolean>()
  @Input() isValid: boolean = true;
  @Input() userMail: string;

  addressFile: File | null = null;
  ribFile: File | null = null;
  idFileFront: File | null = null;
  idFileBack: File | null = null;
  login: string;
  documentsList: any[] = [];
  currentId: string = FileType.PASSPORT;
  score: number;
  vialinkStatus: ControlStatus;
  modalRef: any
  ngDestroyed$ = new Subject<void>();
  attachement: any = []
  submit: boolean = false;
  constructor(
    private router: Router,
    private store: Store,
  ) { }
  ngOnInit(): void {
    this.getLogin();
  }

  onFormSubmit() {
    //navigate to contact form 
    this.router.navigate([`contact-us/form-call`]);

  }

  getLogin() {
    this.store.select((state: any) => state.form)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((result: AppState) => {
        if (result?.ancienPls?.loginUpi) {
          this.login = result.ancienPls.loginUpi;
        } 
        if (result?.controlViaLink) {
          this.vialinkStatus = result.controlViaLink
          this.score = result.controlViaLink.score;
          if (this.score > 90) {
            this.handlSuccess.emit(true);
            
            console.log("dispatch data ");

          } else { 

            this.handlSuccess.emit(false);

          }
          this.sendMailtoGrc();
        }
      })

  }

  sendMailtoGrc() {
    this.store.select((state: any) => state.form)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((result: AppState) => {
        if (result.controlViaLink) {

          /// TODO
          //CCN : ${userPls.} <br>
          //Type de compte : PP OU PM SANS REST <br>
          const userPls: UserAccessPls = result.ancienPls
          const control: ControlStatus = result.controlViaLink
          const email: Email = {
            attachments: this.attachement,
            //TODO replace mail 
            recipients: ['bk-crm-test@uptevia.com'],
            from: "no-reply@uptevia.com",
            textBody: `
          category: Gestion des accès <br>
          Subcategory : Problèmes accès au site<br><br>
          Nom : ${control.subscriber.lastName} <br>
          Prénom : ${control.subscriber.firstName} <br>
          Identifiant : ${userPls.loginUpi} <br>
          Code émetteur : ${userPls.emetIden} <br>
          
          Numéro du titulaire : ${userPls.tituNume} <br>
          Score Vialink : ${control.result.score} <br>
          Numéro du Dossier Vialink: ${control.spaceId} <br><br>
 
          En vous remerciant d’avance pour votre aide. <br><br>
 
          Cordialment,<br><br><br><br> 
          `,
            subject: result.controlViaLink.score < 90 ? 'UPI + KYC KO' : 'UPI + KYC OK',


          }

          this.store.dispatch(sendEmail({ email }));

        }
      })
  }


  uploadFile(event: any, file: string) {
    if (event.target.files && event.target.files.length > 0) {
      const inputElemnt = event.currentTarget;
      if (inputElemnt.files && inputElemnt.files.length > 0) {
        switch (file) {
          case 'idFileFront':
            //STATE_ID, PASSPORT, RESIDENCE_PERMIT
            this.idFileFront = inputElemnt.files[0] as File;
            break;
          case 'idFileBack':
            this.idFileBack = inputElemnt.files[0] as File;
            break;
          case 'ribFile':
            this.ribFile = inputElemnt.files[0] as File;
            break;
          default:
            this.addressFile = inputElemnt.files[0] as File;
            break;
        }
      }

    }
  }

  handleDocuments() {
    this.documentsList = [];
    this.attachement = [];
    this.submit = true;
    if (this.currentId === FileType.PASSPORT) {
      this.documentsList.push({ type: FileType.PASSPORT, file: this.idFileFront, file2: undefined })
    }
    if (this.currentId === FileType.STATE_ID) {
      this.documentsList.push({ type: FileType.STATE_ID, file: this.idFileFront, file2: this.idFileBack })
    }
    if (this.currentId === FileType.RESIDENCE_PERMIT) {
      this.documentsList.push({ type: FileType.RESIDENCE_PERMIT, file: this.idFileFront, file2: this.idFileBack })
    }

    if (this.idFileBack) {

      this.attachement.push(this.idFileBack);
    }
    if (this.idFileFront) {
      this.attachement.push(this.idFileFront);

    }
    if (this.ribFile) {
      this.documentsList.push({ type: FileType.BANK_ID, file: this.ribFile, file2: undefined });
      this.attachement.push(this.ribFile);
    }

    if (this.addressFile) {
      this.documentsList.push({ type: FileType.ADDRESS_PROOF, file: this.addressFile, file2: undefined });
      this.attachement.push(this.addressFile);
    }

  }

  viaLinkSubmit() {

    // emit on click to allow  validating form or control pn parent component 
    this.onClick.emit();
    if (this.isValid) {
      if (!this.checkBeforSubmit()) {
        return;
      }
      this.handleDocuments();

      //this action will create a viaLink controll and upload the list of document
      if (this.login) { 
         this.store.dispatch(createControlViaLink({ login: this.login, files: this.documentsList }));
      } else {
        console.error("ERROR no Login found", this.login);
        this.router.navigate(['login']);
      }
    }
  }

  get isDocumentValid(): (document: string) => boolean | undefined {
    return (document: string) => {
      const score = this.vialinkStatus?.result?.scores[document];
      return score ? score >= 90 : score;
    }

  }

  checkBeforSubmit(): boolean {
    this.submit = true;

    let status = true
    if (this.currentId === FileType.PASSPORT && (!this.idFileFront)) { status = false; }
    if (this.currentId !== FileType.PASSPORT && (!this.idFileBack || !this.idFileFront)) { status = false; }
    if (!this.addressFile) { status = false; }
    return status;
  }

  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }

}