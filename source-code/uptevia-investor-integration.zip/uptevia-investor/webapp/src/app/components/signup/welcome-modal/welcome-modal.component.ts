import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Titulaire } from 'src/app/entity/titulaire';
import { BffService } from 'src/app/services/bff.service';
import { EAbonnement } from 'src/app/entity/e-abonnement';
import { CguComponent } from '../../cgu/cgu.component';
import { CGU } from 'src/app/entity/cgu';


@Component({
  selector: 'app-welcome-modal',
  templateUrl: './welcome-modal.component.html',
  styleUrls: ['./welcome-modal.component.css']
})
export class WelcomeModalComponent implements OnInit {

  formName = 'welcome';
  welcome: FormGroup;
  submitted = false;
  userChoice = 0;
  acceptCgu = false;

  constructor(public activeModal: NgbActiveModal,
    private modal: NgbModal,
    private formBuilder: FormBuilder,
    private bffService: BffService,) {
  }

  ngOnInit(): void {
    this.createWelcomeForm();
  }

  createWelcomeForm() {
    this.welcome = this.formBuilder.group({
      slidereservice: [true],
      slidercondition: [false, Validators.requiredTrue]
    });
  }

  close() {
    if (this.welcome.valid) {
      this.activeModal.dismiss();

    }
  }

  openCGU() {
    console.log("open cgu clicked");
    this.modal.open(CguComponent, { size: 'l' });

  }
  onChangeChoice(event: Event) {
    const isChecked = (<HTMLInputElement>event.target).checked;
    console.log(isChecked)
    this.userChoice = 0;
    if (isChecked == true) {
      this.userChoice = 1;
    }
  }

  onFormSubmit() {
    this.submitted = true;
    if (this.welcome.invalid) {
      return;
    }

    this.activeModal.dismiss();

    //TODO implements la fonction qui va stocker l'info selon laquelle le user a accepté les conditions générales 
    //TODO mettre la fonction onChangeChoice pour le checkbox

    const titulaire: Titulaire = JSON.parse(localStorage.getItem("titulaire") || '{}');
    const user = JSON.parse(localStorage.getItem("user") || '{}');

    if ((user === undefined || titulaire === undefined)) {
      console.error("user or titulaire undefined")
      return;
    }


    const cgu: CGU = {
      login: user.login,
      emetIden: titulaire.emetIden.toString(),
      actiIden: titulaire.actiIden.toString(),
      tituNume: titulaire.tituNume,
      choix: this.userChoice.toString(),
    };
    this.acceptCGU(cgu);
    const eAbonnement: EAbonnement = {
      param_login: user.login,
      param_emet_iden: titulaire.emetIden.toString(),
      param_acti_iden: titulaire.actiIden.toString(),
      param_titu_nume: titulaire.tituNume,
      param_choix: this.userChoice.toString(),
    };

    // Send userChoice ...
    this.sendDataToServer(eAbonnement);
  }
  private acceptCGU(cgu: CGU) {
    //save CGU acceptance
    if (this.welcome?.value?.slidercondition) {
      this.bffService.cguAcceptance(cgu).subscribe(
        (response: any) => {
          if (response) {
            console.log('CGU traitée avec succées !!');
          }
        },
        (error: any) => {
          console.error('Erreur lors du traitement');
        });
    }
  }
  sendDataToServer(data:EAbonnement) {
    this.bffService.insertEabonnement(data).subscribe(
      (response: any) => {
        if (response) {
          console.log('Demande crée avec succés!!', response);
        }
      },
      (error: any) => {
        console.error('Erreur lors de l\'enregistrement', error);
      });
  }
}
