import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { selecPlstUser, selectEmail } from 'src/app/store/selectors/app.selector';
import { hideEmail } from 'src/app/utils/functions';

@Component({
  selector: 'app-yourspace',
  templateUrl: './yourspace.component.html',
  styleUrls: ['./yourspace.component.css']
})
export class YourSpaceComponent implements OnInit {

  finalEmail: any;
  @Output() onClick = new EventEmitter<any>()
  submitted = false;
  ngDestroyed$ = new Subject<void>();
  @Input() buttonChoice: any = null;


  ngOnInit(): void {
   
    if (this.buttonChoice == "forgotpassword") {
      this.retreiveUserEmail();
    }else {
      this.retreiveEmailFromStore();
    }
    
  }
  constructor(private store: Store) {
  }

  private retreiveEmailFromStore() {
    this.store.select(selecPlstUser)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        if (data?.user)
          console.log("storeEmail", data.user);
        this.finalEmail = hideEmail(data.user.email);

      });
  }

  private retreiveUserEmail() {
    this.store.select(selectEmail)
    .pipe(takeUntil(this.ngDestroyed$))
    .subscribe((data)=> {
      if(data){
        console.log("storeUserEmail", data.email);
        this.finalEmail = hideEmail(data.email);
      }
    })
   
  }

  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }
}
