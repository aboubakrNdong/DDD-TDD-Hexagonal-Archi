import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { TranslateModule } from '@ngx-translate/core';
import {
  AmountDetailModule, BlocModule, BlocProfilModule, ButtonModule,
  ButtonToggleModule,
  DonutModule,
  FileArianeModule,
  FooterModule,
  ImageModule,
  ItalicModule, LabelModule,
  ListBlocprofilModule, LoginModule, LogoModule, MenuModule, QresponseModule,
  RecapModule,
  SimulationModule,
  StepModule,
  StockTypeModule,
  SubMenuModule,
  TabModule, TabsModule, TimerModule, TitleModule,
  ValeurModule,
} from '@uptevia/ui';
import { PipesModule } from '../pipes/pipes.module';
@NgModule({
   
  imports: [
    CommonModule, 
    PipesModule
  ],
  exports: [
    CommonModule,
    FooterModule,
    ItalicModule,
    LoginModule,
    BlocModule,
    ButtonModule,
    MenuModule,
    SubMenuModule,
    LogoModule,
    BlocProfilModule,
    ListBlocprofilModule,
    TimerModule,
    DonutModule,
    LabelModule,
    TabsModule,
    TabModule,
    AmountDetailModule,
    TitleModule, 
    QresponseModule,
    PipesModule,
    FileArianeModule,
    ButtonToggleModule,
    StepModule,
    ValeurModule,
    SimulationModule,
    RecapModule,
    StockTypeModule,
    ImageModule,
    TranslateModule
  ]
})
export class UpteviaLibModule { }
