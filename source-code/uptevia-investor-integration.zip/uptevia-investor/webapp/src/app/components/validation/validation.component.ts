import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-validation',
    template: ` 
    <span *ngIf="isValid !==undefined">
        <i *ngIf="isValid" class="bi bi-check text-success"></i>
        <i *ngIf="!isValid"class="bi bi-x text-danger"></i>
        </span>`,
    styleUrls: ['./validation.component.css']
})
export class ValidationComponent  {

    @Input() isValid: boolean | undefined; 
   
}

