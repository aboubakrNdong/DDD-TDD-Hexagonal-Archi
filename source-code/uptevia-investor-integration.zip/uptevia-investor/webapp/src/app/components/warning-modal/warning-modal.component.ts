import { Component, EventEmitter, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-warning-modal',
  templateUrl: './warning-modal.component.html',
  styleUrls: ['./warning-modal.component.css'],
})
export class WarningModalComponent  implements OnInit{
  @Input() title: string;
  @Input() buttonLabel: string;
  @Input() description: string;
  @Input() route: string


  constructor(
    private router: Router,
    public activeModal: NgbActiveModal) { }
  ngOnInit(): void {
     console.log('route', this.route);
     console.log('buttonLabel', this.buttonLabel);
     console.log('description', this.description);
     
  }

  close() {
    if (this.route) {

      this.router.navigateByUrl(this.route, { replaceUrl: true })
    }
    console.log("close modal");

    this.activeModal.dismiss();
  }

  get motif(): (trad: string) => string | undefined {
    return (trad: string) => {
      return trad.split('.').pop()
    }
  }
}
