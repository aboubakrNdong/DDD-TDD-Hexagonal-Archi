
import { CurrencyPipe } from '@angular/common';
import { Directive, ElementRef, HostListener, Input, OnInit } from "@angular/core";

@Directive({ selector: "[currencyInput]" })
export class CurrencyInputDirective implements OnInit {

  // build the regex based on max pre decimal digits allowed
  private regexString(max: number, isFrench = true) {

    this.decimals = max;

    const decimalSeparator = isFrench ? ',' : '\\.';
    return `^(\\d{0,6}(${decimalSeparator}\\d{0,${max}})?|${decimalSeparator}\\d{0,${max}}|(\\d{1,3}(${isFrench ? '\\,' : '\\.'}\\d{3})*)(${decimalSeparator}\\d{0,${max}})?)$`;
  }

  private digitRegex: RegExp;
  private setRegex(maxDigits: number) {
    this.digitRegex = new RegExp(this.regexString(maxDigits, this.isFrench), 'g')
  }
  @Input()
  set maxDigits(max: number) {
    this.setRegex(max);
  }

  decimals = 0;
  @Input() isFrench: boolean = true;

  private el: HTMLInputElement;

  constructor(
    private elementRef: ElementRef,
    private currencyPipe: CurrencyPipe
  ) {
    this.el = this.elementRef.nativeElement;
    this.setRegex(0);
  }

  ngOnInit() {
    this.el.style.textAlign = 'right'
  }

  @HostListener("focus", ["$event.target.value"])
  onFocus(value: any) {
    // on focus remove currency formatting
    value = value.toString()
    if (value !== null && value.length > 0) {

      const numericValueWithPeriod = value.replace(/[^0-9d.,]/g, '')
      const valueFormatted: any = parseFloat(numericValueWithPeriod.replace(/[^0-9.]+/g, ''));
      this.el.value = numericValueWithPeriod
      this.el.select();
      //remove automatic text selection behavior
      setTimeout(() => {
        this.el.setSelectionRange(this.el.value.length, this.el.value.length)
      });
    }
  }

  @HostListener("blur", ["$event.target.value"])
  onBlur(value: any) {
    //value = value.toString()
    const valu = parseFloat(value.replace(/,/g, '.'))

    console.log('valu', valu);
    const numericValue = parseFloat(valu.toFixed(this.decimals)); // Extract numeric value
    const seperator = this.isFrench ?',':'.'
    
    if (value !== null && value.length > 0) { // On blur, manually format the value and append the currency symbol
      const formattedValue = this.currencyPipe.transform(numericValue, 'EUR', 'symbol', `1.${this.decimals}-${this.decimals}`)?.replace(',', seperator);
      this.el.value = `${formattedValue}`; // Append the currency symbol}
    }


  }
  // variable to store last valid input
  private lastValid = '';
  @HostListener('input', ['$event'])
  onInput(event: any) {
    // on input, run regex to only allow certain characters and format
    const cleanValue = (event.target.value.match(this.digitRegex) || []).join('')
    if (cleanValue || !event.target.value)
      this.lastValid = cleanValue
    this.el.value = cleanValue || this.lastValid
  }
}

