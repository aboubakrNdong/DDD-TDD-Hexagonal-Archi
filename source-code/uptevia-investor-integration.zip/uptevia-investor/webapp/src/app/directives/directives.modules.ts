import { NgModule } from '@angular/core';
import { TicksizeDirective } from './ticksize.directive';
import { TooltipDirective } from './tooltip.directive';
import { CurrencyInputDirective } from './currency-input.directive';


@NgModule({
  declarations: [TicksizeDirective, TooltipDirective, CurrencyInputDirective],
  exports: [TicksizeDirective,  TooltipDirective, CurrencyInputDirective],
})
export class DirectiveModule {}
