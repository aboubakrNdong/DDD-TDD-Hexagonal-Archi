


import {
  Directive, ElementRef, HostListener, Input, Renderer2
} from '@angular/core';

@Directive({
  selector: '[tooltips]',
})
export class TooltipDirective {

  @Input() tooltips: string;
  @Input() position: string;

  private tooltipElement: any;

  constructor(private el: ElementRef, private renderer: Renderer2) { }

  @HostListener('mouseenter')
  onMouseEnter() {
    this.showTooltip();
  }

  @HostListener('mouseleave')
  onMouseLeave() {
    this.hideTooltip();
  }
  
  private showTooltip() {
    if (!this.tooltipElement) {
      this.tooltipElement = this.renderer.createElement('span');
      this.renderer.addClass(this.tooltipElement, 'tooltip-text');
      this.renderer.addClass(this.tooltipElement, this.position);
      this.renderer.appendChild(this.tooltipElement, this.renderer.createText(this.tooltips));
      this.renderer.appendChild(this.el.nativeElement, this.tooltipElement);

      // Set a timeout to add a class for showing the tooltip
      setTimeout(() => {
        this.renderer.addClass(this.tooltipElement, 'show');
      }, 0);
    }
  }

  private hideTooltip() {
    if (this.tooltipElement) {
      this.renderer.removeClass(this.tooltipElement, 'show');
      setTimeout(() => {
        if (this.tooltipElement.parentElement === this.el.nativeElement) {
          this.renderer.removeChild(this.el.nativeElement, this.tooltipElement);
          this.tooltipElement = undefined;

        }
      }, 200); // Adjust this timing to match your CSS transition duration
    }
  }

  ngOnDestroy() {
    // Clean up any leftover tooltip elements when the directive is destroyed
    if (this.tooltipElement) {
      this.renderer.removeChild(this.el.nativeElement, this.tooltipElement);
      this.el.nativeElement = undefined;
    }
  }
}