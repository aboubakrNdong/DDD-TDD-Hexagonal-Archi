import { Titre } from "./titre";

export interface OperationData {
    emetIden: number;
    actiIden: number;
    tituNume: number;
    login: string;
    natureDemande: number;
    typeVente: number;
    valeIden: string;
    nbActions: number;
    coursLimite: number | null;
    dateFinValidite: any;
    modeReglt: number;
    regltAttendu?: number;
    titres?: Titre[];
    ocb_idTransaction?:number
}