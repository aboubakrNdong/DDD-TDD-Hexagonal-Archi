import { AvoirTitre } from "./avoir-titre";

export interface ListOrigines{
    listTitres:AvoirTitre[];
    origine:string
}