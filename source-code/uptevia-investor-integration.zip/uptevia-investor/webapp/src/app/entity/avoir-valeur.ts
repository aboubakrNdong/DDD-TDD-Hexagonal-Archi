import { ListOrigines } from "./avoir-origin";

export interface AvoirValeur {
    valeIden: string;
    valeLibe: string;
    dernierCours:number;
    listOrigines:ListOrigines[]

}