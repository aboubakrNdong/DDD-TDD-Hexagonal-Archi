export interface CGU {
    login:  string;
    emetIden:  string;
    actiIden: string;
    tituNume: number;
    choix: string;
  };