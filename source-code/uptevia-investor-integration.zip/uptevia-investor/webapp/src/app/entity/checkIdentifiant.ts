export interface CheckIdentifiant {

   //  p_emet_iden: string,
     p_acti_Iden: string,
     p_date_nais: string, //($date-time)
     p_nom?: string,
     p_prenom?: string,
}
