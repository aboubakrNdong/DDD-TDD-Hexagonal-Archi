export interface DetailConnexion {
    login : string;
    newPassword : string;
    oldPassword : string;
    email : string;
}