export interface DetailPlan {
    typePosition: string;
    qte: number;
    natureJuridique: string;
    devise: string;
    derniereMaj: string;
    valorisation: number;
    codeLibelle: string
}