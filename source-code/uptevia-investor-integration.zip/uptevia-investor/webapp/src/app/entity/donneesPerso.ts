
export interface DonneesPerso {

    pUser: string,
    pOrig: string
    pEmetIden: number,
    pActiIden: number,
    pTituNume: number,
    pTituEMail: string,
    pTituEMail2: number,
    pTituNumMobilePerso: string,
    pTituNumMobilePro : string
    pTituNumeTel: number,
    pTituNumeTel2: number,
    pAdreFiscInfoBati: string
    pAdreFiscInfoRue: string,
    pAdreFiscComp: string,
    pAdreFiscCodp: string,
    pAdreFiscNomComu: string,
    pAdreInfoBati: string,
    pAdreInfoRue: string,
    pAdreComp: string,
    pAdreCodp: string,
    pAdreNomComu: string,

}
