export interface EAbonnement {
    
    param_login: string,
    param_emet_iden: string,
    param_acti_iden: string,
    param_titu_nume: number,
    param_choix: string
}