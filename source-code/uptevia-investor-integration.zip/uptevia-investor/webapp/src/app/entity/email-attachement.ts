
export interface Attachement {
    filename: string;
    file: File;

}