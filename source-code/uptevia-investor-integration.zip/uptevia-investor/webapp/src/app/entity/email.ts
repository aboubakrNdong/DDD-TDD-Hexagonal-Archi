import { Attachement } from "./email-attachement";

export interface Email {
    recipients: string[];
    from:string;
    textBody: string;
    htmlBody?: string;
    subject: string;
    typeMail?: string;
    attachments: any[];
}
