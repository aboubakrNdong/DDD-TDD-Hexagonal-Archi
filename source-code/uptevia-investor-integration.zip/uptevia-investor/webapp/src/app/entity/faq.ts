import { DetailsFreqAskedQ } from "./details-freq-askedQ";

export interface FreqAskedQ {
    category: string;
    logoNameCategory: string;
    qresponses: DetailsFreqAskedQ[];
}