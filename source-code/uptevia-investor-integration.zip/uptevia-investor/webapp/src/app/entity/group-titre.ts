import { AvoirValeur } from "./avoir-valeur";

export interface GroupTitre {

    nomGroupe: string;
    valorisationGroupe: any
    nbreTitres: number;
    titresDispo: number;
    titresIndispo: number
    listValeurs: AvoirValeur[]
}