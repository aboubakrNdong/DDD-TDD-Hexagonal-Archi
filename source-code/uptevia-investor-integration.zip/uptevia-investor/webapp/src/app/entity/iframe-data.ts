export interface iFrameParams {
    login: string;
    emetIden: number
    actiIden: number;
    module: string;
    theme: string;
    langue: string;
    montant: number;
    modalite: number;
    coursLimite: number;
    typeValidite: string;
    dateValidite: string;
    moisValiditeMax: number;
    isDirect: true,
    isMontantReel: true,
    quantite: number;
}
