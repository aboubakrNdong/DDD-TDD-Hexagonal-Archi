export interface Lien {
    textToClick: string;
    target: string;
    url: string;
}