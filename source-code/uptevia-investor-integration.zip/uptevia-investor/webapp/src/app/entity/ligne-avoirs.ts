export interface LigneAvoir {
    natureJuridique: string;
    libePlan: string;
    valeIdenPlan: string;
    regptAvoir: number;
    rubCompta: string;
    nbActionDispo: number;
    nbActionAVendre: number;
    priorite: number;
    categorie: string;
    qualificatif: string;
    prixAcquisition: number;
    dateDispo: string;
    dateLevee: string;
    rictionJuridique: string;
    Plan: string;
    numAvoa: number;
    dateSouscription: string;
    dateSoaa: string;
    dateVoteDoubleBrut: string;
    dateDetentionBrut: string;
    dateCessFiscale: string;


}