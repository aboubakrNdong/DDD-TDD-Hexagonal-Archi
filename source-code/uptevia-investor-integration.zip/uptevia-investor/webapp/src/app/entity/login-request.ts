export interface LoginRequest {

    login: string;
    password: string;
    email?:string
    operation?: boolean

}