export interface LoginRequestPls {

    emetIden: string;
    accessCode: string;
    password: string;
   
}