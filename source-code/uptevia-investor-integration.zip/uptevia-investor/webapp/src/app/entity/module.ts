export interface Modules {
    groupeNom: string,
    groupeUrl: string,
    groupeOrdre: number,
    groupeIndicateur: boolean,
    groupeImgName: string,
    sousModule?: SousModule[];
    showMenu: boolean;
}

export interface SousModule {
    moduleNom: string,
    moduleUrl: string,
    moduleOrdre: number,
    moduleIndicateur: boolean,
    moduleImgName: string;
    habiliteActi: boolean;
    habiliteEmet: boolean;
    motifsBlocage: string[];
}

