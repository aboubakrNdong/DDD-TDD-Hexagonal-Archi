export interface Operation {
    idDemande: number;
    dateDemande: string;
    natureDemande: number;
    refDemande: string;
    statutDemande: string;
    statutExecution: string;
    nbActions: number;
    annulable: boolean
    montantNet: number;
    qteTrade: number;
}