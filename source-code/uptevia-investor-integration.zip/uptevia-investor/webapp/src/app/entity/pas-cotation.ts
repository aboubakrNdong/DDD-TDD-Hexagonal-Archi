export interface PasCotation {
    tickSize: number;
    tranMin: number;
    tranMax: number;
    eche: number;
}