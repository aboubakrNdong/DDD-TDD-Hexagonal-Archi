import { GroupTitre } from "./group-titre";

export interface PortefeuilleTitre {
    devise: string;
    valorisationTotal: number
    titresTotal: number;
    droitsVote: number;
    titresDispo: number;
    titresIndispo: number;
    groupeTitres: GroupTitre[];
    derniereMaj: string;

   
}