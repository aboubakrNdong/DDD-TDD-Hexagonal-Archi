import { Plan } from "./plan";

export interface Positions {
    titres:Plan,
     droits:Plan
    fonds:Plan,

}