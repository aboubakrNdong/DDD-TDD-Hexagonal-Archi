export interface SignUpData {
    username: any;
    email: any;
    isForgot: any;
}
