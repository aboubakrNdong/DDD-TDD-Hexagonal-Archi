export interface smsData {
    text: string;
    mobileNumbers: string [];
}
