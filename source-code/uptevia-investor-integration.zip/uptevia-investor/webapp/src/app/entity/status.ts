export interface ResultStatus {
    status: string
}