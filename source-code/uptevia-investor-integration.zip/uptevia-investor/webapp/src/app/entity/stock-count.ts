import { Titre } from "./titre";

export interface StockCount {
    total: number;
    list: Titre[];
}