export interface Titulaire {
  emetIden: number;
  actiIden: number;
  tituNume: number;
  themeId: number;
  nom: string;
  prenom: string;
  qualite: string;
  actiTypeCompte: string;
  typeCpte: string;
}
