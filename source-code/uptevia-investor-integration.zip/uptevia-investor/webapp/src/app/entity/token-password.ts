export interface TokenLogin {
    login: string;
    email: string;
}