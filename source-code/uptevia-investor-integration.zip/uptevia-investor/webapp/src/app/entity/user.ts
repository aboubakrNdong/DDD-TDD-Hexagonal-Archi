export interface UserAccess {
    login: string,
    email: string,
    dateAccess: string, //$date-time
    nbAcces: number,
    nbEssais: number,
    nbTotalEssais: number,
    dateValiditeDEB: string, //($date-time)
    dateValiditeFin: string, //($date-time)
    indiCompteBloque: boolean,
    indiPwdExpire: boolean;
    indiWillBePwdExpired: boolean;
    reponseQuestionSecurite1: string,
    reponseQuestionSecurite2: string,
    otpValidated: boolean,
    token: string
}
