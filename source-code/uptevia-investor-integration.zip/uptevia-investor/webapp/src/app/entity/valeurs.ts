import { Valeur } from "./valeur";

export interface Valeurs {
    serverDateTime: string;
    motifsBlocageAchat: string[];
    motifsBlocageVente: string[];
    peutAcheter: boolean;
    peutVendre: boolean;
    valeurs: Valeur[];
}    