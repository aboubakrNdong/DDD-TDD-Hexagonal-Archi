export interface VerifyIdentity{
     
     identifiant : string,
     nomFamille : string,
     prenom : string,
     dateNaissance : string, //($date-time)
     telephone : string,
     email : string,
     emetFirstname : string,
     numCpte : string,
     buttonChoice: string;

}
  