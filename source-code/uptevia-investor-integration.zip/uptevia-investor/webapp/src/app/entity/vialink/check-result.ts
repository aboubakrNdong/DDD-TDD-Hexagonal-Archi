import { Parametre } from "./parametre";
import { Source } from "./source";

export interface CheckResult {
    id: number;
    type: string;
    name: string;
    value: string;
    weight: number;
    critical: boolean;
    sources: Source[ ]
    parameters: Parametre[]
    public: boolean;

}