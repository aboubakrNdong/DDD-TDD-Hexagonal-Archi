export interface Completeness {
    type: string;
    number: number;
    side: 'BACK' | 'FRONT';
    available: boolean;
    status: any;
}
