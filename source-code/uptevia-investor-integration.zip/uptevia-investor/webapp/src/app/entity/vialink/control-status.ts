import { Completeness } from "./completeness"
import { Result } from "./result";
import { Subscriber } from "./subscriber"

export interface ControlStatus {
  id: string;
  spaceId: string;
  spaceName: string;
  status: string;
  controlProfileId: string;
  controlProfileName: string;
  subscriberId: string;
  subscriber: Subscriber
  createdAt: string;
  lastModified: string;
  removedAt: string;
  completeness: Completeness[]
  score: 0
  result: Result;
}