import { Sheet } from './sheet';

export interface DocumentSubmitted {
    id: number
    type: string;
    subType: any;
    number: number;
    status: string;
    data: any
    sheets: Sheet[]
    score: any;
    origin: string;
    createdAt: string;
}