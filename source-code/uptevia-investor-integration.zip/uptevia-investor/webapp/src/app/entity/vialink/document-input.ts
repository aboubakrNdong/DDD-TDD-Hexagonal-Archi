
export interface DocumentInput {
    controlId?: string;
    type: string;
    file: File | null;
    file2?: File | null;

}