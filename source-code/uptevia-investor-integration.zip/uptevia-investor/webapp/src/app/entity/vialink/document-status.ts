
export interface ControlDocument {

    id: number;
    type: string;
    documents: Document[];


}