import { Sheet } from './sheet';

export interface Docmuent {
    id: number,
    type: string,
    subType: any,
    number: 1,
    status: string;
    data: any,
    sheets: Sheet[],
    score: null,
    origin: string;
    createdAt: string;
}