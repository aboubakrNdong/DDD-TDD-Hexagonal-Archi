export interface Parametre {
    name: string;
    value: string;
}
