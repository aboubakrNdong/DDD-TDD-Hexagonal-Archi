import { CheckResult } from "./check-result";

export interface Result {
    status: string
    score: number;
    checkResults: CheckResult[];
    nbPerformedChecks: number;
    nbConfiguredChecks: number;
    scores: any;
    scoresPerDocument: any;
}