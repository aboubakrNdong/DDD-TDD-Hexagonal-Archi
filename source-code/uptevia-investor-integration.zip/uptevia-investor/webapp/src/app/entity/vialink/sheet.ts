export interface Sheet {
    id: number;
    side: string;
    fileName: string;
    hash: string;
    mimeType: string;
    size: number;
    subTypes: any;
    identifier: string;
}
