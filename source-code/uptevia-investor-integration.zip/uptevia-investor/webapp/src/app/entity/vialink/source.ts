export interface Source {

    type: string;
    documentId: number
    documentType: string;
    number: number;
    value: string;

}