import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { TranslateLoader, TranslateModule, TranslateService } from '@ngx-translate/core';
import { environment } from 'src/environments/environment';
import { MultiTranslateHttpLoader } from './multi-translate-http-loader';

@NgModule({
  imports: [
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (translateLoaderFactory),
        deps: [HttpClient]
      }
    }),
  ],
  exports: [TranslateModule]
})
export class I18nModule {
  constructor(translate: TranslateService) {
    translate.addLangs(['en', 'fr', 'de', 'es', 'pt', 'it', 'nl']);//, 'Nl']);

    if (localStorage.getItem("lang") != null) {
      let lang = '';
      lang = localStorage.getItem("lang")  || '';
      translate.setDefaultLang(lang);
      translate.use(lang);
    } else {
      const browserLang = translate.getBrowserLang();
      
      translate.setDefaultLang(browserLang.toLocaleLowerCase());
      translate.use(browserLang.toLocaleLowerCase());
      localStorage.setItem('lang', browserLang.toLocaleLowerCase())
    }
   
  }
}

export function translateLoaderFactory(httpClient: HttpClient) {
  return new MultiTranslateHttpLoader(httpClient, `${environment.apiGateWayUrl + environment.apiResourceBaseUrl}/api/v1/traduction/`, '/1');
}