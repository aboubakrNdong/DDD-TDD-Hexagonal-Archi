import { HttpClient } from "@angular/common/http";
import { TranslateLoader } from "@ngx-translate/core";
import { Observable, merge, of } from 'rxjs';
import { catchError, map, reduce } from 'rxjs/operators';
import { LANG_LIST } from "../utils/const-vars";


export class MultiTranslateHttpLoader implements TranslateLoader {
    constructor(private http: HttpClient, public prefix: string, public suffix: string) { }
    public  getTranslation(lang: string): Observable<any> {
        let mylang=LANG_LIST;
       return  this.http.get(`${this.prefix}` + mylang[lang] + `${this.suffix}`)
       .pipe(map((translations:any)=>{
        const translationData:any={}
        for(const translation of translations){
            translationData[translation.key] =translation.libelle
        }
        return translationData;
       }),catchError(()=>{
        return of({});
       }))
         
    } 

}

