import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactUsComponent } from './contact-us.component';

const routes: Routes = [
  {
    path: '',
    component: ContactUsComponent,
    data: { breadcrumb: 'footer.item.faq' },
    children: [
      {
        path: 'faq-details', loadChildren: () => import('./faqdetails/faq-list.module').then(d => d.FaqDetailsModule),
      },
      { path: 'form-call', loadChildren: () => import('../contact-us/form-call/form-call.module').then(d => d.FormCallModule) },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContactUsRoutingModule { }
