import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { BreadcrumbService } from 'src/app/services/breadcrumb.service';
import { LoginService } from 'src/app/services/login.service';
import { getFaq } from 'src/app/store/actions/app.action';

@Component({
  selector: 'contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {
  showOutlet = false;
  routerSub: Subscription;
  cacheData: any;
  faq: any
  constructor(
    private loginService: LoginService,
    public breadcrumbService: BreadcrumbService,
    private router: Router,
    private store: Store,
    public translate: TranslateService) { }

  ngOnInit(): void {
    
    this.routerSub = this.router.events.subscribe((events: any) => {
        if (events.routerEvent) {
        this.showOutlet = events.routerEvent.url.includes('contact/') ||events.routerEvent.url.includes('contact-us/')
      }
      if (events?.url) {
        this.showOutlet = events.url.includes('contact/') ||events.url.includes('contact-us/');;
      }  
    })

    this.getFaq();

  }



  get isConnected() {
    return this.loginService.isAuthenticated();
  }

  getFaq() {
    const isConnected = this.loginService.isAuthenticated() ? 'O' : 'N';
    this.store.dispatch(getFaq({ piLoggedFaq: isConnected }))
    this.store.select((state: any) => state.form).subscribe(res => {
      if (res) {
        this.faq = res.faq
      }
    })

  }

  ngOnDestroy() {
    this.routerSub.unsubscribe();
  }

  goToProfil() {
    this.router.navigate(['login']);
  }
}
