import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContactUsRoutingModule } from './contact-routing.module';
import { ContactUsComponent } from './contact-us.component';
import { ComponentsModule } from 'src/app/components/components.module';


@NgModule({
  declarations: [ContactUsComponent  ],
  imports: [
    CommonModule,
    ContactUsRoutingModule,
    ComponentsModule,
     
  ],
  exports:[ContactUsComponent]
})
export class ContactUsModule { }
