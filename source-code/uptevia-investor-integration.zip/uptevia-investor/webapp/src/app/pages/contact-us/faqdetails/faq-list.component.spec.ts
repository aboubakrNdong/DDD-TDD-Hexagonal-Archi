import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FaqdetailsComponent } from './faq-list.component';

describe('FaqComponent', () => {
  let component: FaqdetailsComponent;
  let fixture: ComponentFixture<FaqdetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FaqdetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FaqdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
