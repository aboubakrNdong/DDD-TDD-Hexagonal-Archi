import { Location } from '@angular/common';
import { Component, OnInit, } from '@angular/core';
import { ActivatedRoute, NavigationEnd, NavigationExtras, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { BreadcrumbService } from 'src/app/services/breadcrumb.service';


@Component({
  selector: 'app-faq-list',
  templateUrl: './faq-list.component.html',
  styleUrls: ['./faq-list.component.css']
})
export class FaqdetailsComponent implements OnInit {
  qReponseList: any;
  isOutlet = false;
  routerSub: Subscription;

  constructor(
    public router: Router,
    private breadcrumbService: BreadcrumbService,
    private route: ActivatedRoute,
    private location: Location) { }


  ngOnInit(): void {
    this.getFaqs();
    this.routerSub = this.router.events.subscribe(events => {
      if (events instanceof NavigationEnd) {
        this.isOutlet = this.route.firstChild !== null;
      }
    })
  }

  async getFaqs() {

    const state: any = this.location.getState();
    if (state?.category) {
      this.qReponseList = state?.category?.qresponses;

    } else {
      this.router.navigate(['contact'])
    }
  }
 
  onClickQuestion(question: any) {
    const navExtras: NavigationExtras = {
      state: {
        question
      },
      relativeTo: this.route
    }
    this.breadcrumbService.levelTwo = question.faqQuestionKey
    this.router.navigate([`question`], navExtras);

  }

}