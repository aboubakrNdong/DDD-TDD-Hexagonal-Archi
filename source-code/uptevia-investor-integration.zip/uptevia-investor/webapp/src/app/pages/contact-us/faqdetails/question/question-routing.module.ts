import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { QuestionComponent } from './question.component';
import { RubriqueResolver } from 'src/app/services/resolvers/rubrique.resolver';

const routes: Routes = [
  {
    path:'', component:QuestionComponent,
    resolve: { question: RubriqueResolver },
    data: { breadcrumb: '@question',hasTowLevels:true },
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class QuestionRoutingModule { }
