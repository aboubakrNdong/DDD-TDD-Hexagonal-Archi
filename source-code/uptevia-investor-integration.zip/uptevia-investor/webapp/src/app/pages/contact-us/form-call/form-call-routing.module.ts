import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormCallComponent } from './form-call.component';

const routes: Routes = [
  {
    path: '',
    component: FormCallComponent,
    data: { breadcrumb: 'faq.text.contactUptevia' },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FormCallRoutingModule {}
