import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'form-call',
  templateUrl: './form-call.component.html',
  styleUrls: ['./form-call.component.css'],
})
export class FormCallComponent implements OnInit {

  qReponseList: any;
  showForm = true;
  iconForm = 'assets/images/pictos/enveloppe-not-active.svg';
  iconTelephone = 'assets/images/pictos/phone-not-active.svg';
  showTelephone = false;
  showQReponseBloc = false;
 


  constructor(
    public router: Router,
    private loginService: LoginService,
    public translate: TranslateService) { }

  ngOnInit(): void {
    this.qReponseList = this.getShortListOfFaqs;
  }

  onClickQuestion(question: any) {
    /*TODO : Naviguer vers la page QR*/
  }

  showBottomBloc(clickedBtn: string) {
    if (clickedBtn == 'formulaire') {
      this.showForm = true;
      this.iconForm = 'assets/images/pictos/enveloppe-bleue-clair.svg';
      this.showTelephone = false;
      this.iconTelephone = 'assets/images/pictos/phone-not-active.svg';
    }

    if (clickedBtn == 'telephone') {
      this.showForm = false;
      this.showTelephone = true;
      this.iconTelephone = 'assets/pictos/tel-bleu-clair.svg';
      this.iconForm = 'assets/images/pictos/enveloppe-not-active.svg'
    }

    this.showQReponseBloc = false;
  }

  get getShortListOfFaqs() {
    /* 
    Liste des 3 question réponses à afficher selon si le user est connecté ou non. 
    Peut devenir un service quand la règle de sélection va évoluer.
    */
    if (this.isConnected) {
      return [
        {
          faqQuestionKey: 'faq.category.parameters.question.3',
          faqAnswerKey: 'faq.category.parameters.answer.3',
        },
        {
          faqQuestionKey: 'faq.category.customer.question.4',
          faqAnswerKey: 'faq.category.customer.answer.4',
        },
        {
          faqQuestionKey: 'faq.category.operations.question.1',
          faqAnswerKey: 'faq.category.operations.answer.1',
        },
      ];
    } else {
      return [
        {
          faqQuestionKey: 'faq.category.generalInformation.question.1',
          faqAnswerKey: 'faq.category.generalInformation.answer.1',
        },
        {
          faqQuestionKey: 'faq.category.connection.question.1',
          faqAnswerKey: 'faq.category.connection.answer.1',
        },
        {
          faqQuestionKey: 'faq.category.rgpd.question.2',
          faqAnswerKey: 'faq.category.rgpd.answer.2',
        },
      ];
    }
  }

  get isConnected() {
    return this.loginService.isAuthenticated();
  }
}
