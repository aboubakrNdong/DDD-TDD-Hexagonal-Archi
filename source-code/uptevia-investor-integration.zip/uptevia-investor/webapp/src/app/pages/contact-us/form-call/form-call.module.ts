import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormCallRoutingModule } from './form-call-routing.module';
import { FormCallComponent } from './form-call.component';
import { ComponentsModule } from 'src/app/components/components.module';
import { UpteviaLibModule } from 'src/app/components/uptevia-lib.module';
import { ContactformConnectedModule } from 'src/app/components/contactformconnected/contactformconnected.module';
import { ContactformModule } from 'src/app/components/contactform/contactform.module';

@NgModule({
  declarations: [FormCallComponent],
  imports: [CommonModule, UpteviaLibModule,ContactformModule, ContactformConnectedModule,FormCallRoutingModule, ComponentsModule, ],

  exports: [FormCallComponent],
})
export class FormCallModule {}
