import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { UserIdleService } from 'angular-user-idle';
import { PrimeNGConfig } from 'primeng/api';
import { Observable, Subscription } from 'rxjs';
import { TimeoutComponent } from 'src/app/components/timer/timer.component';
import { Modules } from 'src/app/entity/module';
import { Profil } from 'src/app/entity/profil';
import { UserAccess } from 'src/app/entity/user';
import { BffService } from 'src/app/services/bff.service';
import { BreadcrumbService } from 'src/app/services/breadcrumb.service';
import { LoginService } from 'src/app/services/login.service';
import { fetchOpsData, fetchPortefeuilleTitres, fetchRessources, setPortefeuilleData } from 'src/app/store/actions/app.action';
import { environment } from 'src/environments/environment';
import { Titulaire } from '../../entity/titulaire';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit {

  titulaire: Titulaire;
  isTimeOutModal = false;
  lienPicto = "assets/pictos/illustration-popin.svg";
  iconSource = "assets/pictos/profil.svg";
  cacheData: any;
  timerSub: Subscription;
  modalRef: any
  menu: Modules[];
  modules$: Observable<Modules[]>;
  profile: any;

  constructor(
    private store: Store,
    private modal: NgbModal,
    private bffService: BffService,
    public route: ActivatedRoute,
    public breadcrumbService: BreadcrumbService,
    public loginService: LoginService,
    private userIdle: UserIdleService,
    private config: PrimeNGConfig,
    public translate: TranslateService) { }


  getProfilData() {
    //handle cache
    let key = 'profile';
    this.cacheData = sessionStorage.getItem(key);
    if (this.cacheData) {
      this.profile = JSON.parse(this.cacheData);
    }
    else {
      this.bffService.getProfile(this.titulaire).subscribe(
        (reponse: Profil) => {
          this.profile = reponse;
          //Save Data to cache
          sessionStorage.setItem(key, JSON.stringify(reponse));
          this.cacheData = { key: JSON.stringify(reponse) }
        }
      );
    }
  }

  ngOnInit(): void {
    this.titulaire = JSON.parse(localStorage.getItem("titulaire") ?? '{}');

    //getMenu
    this.getMenu();
    this.getOpsData();
    //set Default Url to file d'ariane component
    this.breadcrumbService.setBreadcrubs([{ label: "dashboard.item.title", url: "/dashboard" }]);
    this.getProfilData();
    this.handleUserIdle();

    const lang: string = localStorage.getItem('lang') ?? ''
    this.translate.use(lang);

  }


  showModal() {
    this.modalRef = this.modal.open(TimeoutComponent, { backdrop: 'static', keyboard: false, });
    this.modalRef.result.then((res: any) => {
      if (res) {
        this.userIdle.stopTimer();
        this.userIdle.resetTimer();
      }
    })
  }

  handleUserIdle() {
    this.configIDLE();
    //Start watching for user inactivity.
    this.userIdle.startWatching();
    // Start watching when user idle is starting.
    //display modal for 2 minutes
    this.timerSub = this.userIdle.onTimerStart().subscribe(res => {
      //display toumeOut modal after 2sec
      if (res === 1) {
        this.showModal();
      }
      this.isTimeOutModal = true;

    })
    // Stop watch when time is up.
    this.userIdle.onTimeout().subscribe((res) => {
      //Ontimeout disconnect and stopwatching()
      this.loginService.logout()
      this.userIdle.stopWatching();
      this.userIdle.stopTimer();
      this.isTimeOutModal = false;
      this.timerSub.unsubscribe();
      if (this.modalRef) {
        this.modalRef.close();
      }

    });
  }

  configIDLE() {
    //stopWatching before set Config
    this.userIdle.stopWatching();
    //set IDLE Config 
    this.userIdle.setConfigValues({
      idle: environment.idle,
      timeout: environment.sessionTimout,
      ping: 600
    })
  }
  stayConnected() {
    this.userIdle.stopTimer();
    this.userIdle.resetTimer();
    this.isTimeOutModal = false;
  }

  getMenu() {
    this.store.dispatch(fetchRessources({ titulaire: this.titulaire }))
    this.modules$ = this.store.select((state: any) => state.form.modules)

  }
  getOpsData() {
    const user: UserAccess = JSON.parse(localStorage.getItem("user") ?? '{}');
    this.store.dispatch(fetchOpsData({ user }));
    this.store.dispatch(fetchPortefeuilleTitres())
  }
  ngOnDestroy() {
    this.timerSub.unsubscribe();

  }

  

}
