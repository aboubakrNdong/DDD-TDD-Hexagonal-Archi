import { Component, Input } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'documentations-tab',
  templateUrl: './documentations-tab.component.html',
  styleUrls: ['./documentations-tab.component.css']
})
export class DocumentationsTabComponent {

  documentationForm: FormGroup;

  @Input() titulaire: any = null;

  //profilForm: FormGroup;

  //concatNumCompte: any;

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.createProfilForm();
  }

  createProfilForm(): void {

    this.documentationForm = this.fb.group({
      generalite: this.fb.group({
        tituMode: [],
        tituDevise: [],
      })
    });
  }
}
