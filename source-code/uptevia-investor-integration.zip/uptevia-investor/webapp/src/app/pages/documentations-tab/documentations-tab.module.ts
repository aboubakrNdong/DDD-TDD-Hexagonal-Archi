import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DocumentationsTabComponent } from './documentations-tab.component';
import { UpteviaLibModule } from 'src/app/components/uptevia-lib.module';
import { DocumentationGeneraliteComponent } from 'src/app/components/documentation-generalite/documentation-generalite.component';



@NgModule({
  declarations: [DocumentationsTabComponent, DocumentationGeneraliteComponent],
  imports: [
    CommonModule, UpteviaLibModule, ReactiveFormsModule, FormsModule,
  ],
  exports: [DocumentationsTabComponent]
})
export class DocumentationsTabModule { }
