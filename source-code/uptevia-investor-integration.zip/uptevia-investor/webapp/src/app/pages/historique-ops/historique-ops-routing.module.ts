import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HistoriqueOpsPage } from './historique-ops.component';

const routes: Routes = [
  { path: '', component: HistoriqueOpsPage, data: { breadcrumb: 'layout.menu.suivi' } }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HistoriqueOpsRoutingModule { }
