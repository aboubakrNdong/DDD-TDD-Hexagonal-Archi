import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HistoriqueOpsComponent } from './historique-ops.component';

describe('HistoriqueOpsComponent', () => {
  let component: HistoriqueOpsComponent;
  let fixture: ComponentFixture<HistoriqueOpsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HistoriqueOpsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HistoriqueOpsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
