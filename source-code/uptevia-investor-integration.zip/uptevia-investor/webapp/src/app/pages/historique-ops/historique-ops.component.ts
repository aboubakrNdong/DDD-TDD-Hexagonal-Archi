import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { Operation } from 'src/app/entity/operation';
import { UserAccess } from 'src/app/entity/user';
import { getOperationHisto } from 'src/app/store/actions/app.action';
import { OPERTOINS_LIST_COLORS } from 'src/app/utils/colors.map';

@Component({
  selector: 'app-historique-ops',
  templateUrl: './historique-ops.component.html',
  styleUrls: ['./historique-ops.component.css']
})
export class HistoriqueOpsPage implements OnInit {
  public operations: Operation[];
  operationsColors = OPERTOINS_LIST_COLORS;
  ngDestroyed$ = new Subject<void>();
  p: any = 1;
  constructor(
    private store: Store
  ) { }
  ngOnInit(): void {
    this.getHistorique();
    this.retreiveStoreData();
  }

  private getHistorique() {
    const user: UserAccess = JSON.parse(localStorage.getItem('user') ?? '')
    this.store.dispatch(getOperationHisto(user))
  }

  private retreiveStoreData() {
    this.store.select((state: any) => state.form)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        if (data && data.operationHisto) {
          this.operations = data.operationHisto
        }
      })
  }



  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }
}
