import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { NgxPaginationModule } from 'ngx-pagination';
import { ComponentsModule } from 'src/app/components/components.module';
import { HistoriqueOpsRoutingModule } from './historique-ops-routing.module';
import { HistoriqueOpsPage } from './historique-ops.component';


@NgModule({
  declarations: [HistoriqueOpsPage],
  imports: [
    CommonModule,
    HistoriqueOpsRoutingModule,
    ComponentsModule,
    NgxPaginationModule

  ]
})
export class HistoriqueOpsModule { }
