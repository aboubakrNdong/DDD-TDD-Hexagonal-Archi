import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { Valeur } from 'src/app/entity/valeur';
import { selectOptData } from 'src/app/store/selectors/app.selector';

@Component({
  selector: 'app-cours-valeur',
  template: `
  <div class="cours-container" *ngIf="valeur">
    <div class="cours-title">
      <h4>{{'operation.achat.coursValeur' | translate}} </h4>  
      <span>{{'general.valeur.update' | translate}} {{valeur?.coursDate | datePipe}}</span>
    </div>
    <div class="cours-value">
      <span>{{valeur?.dernierCours | currencyPipe:lang:valeur.deviseCours }}</span>
      <span>{{valeur?.valeIden}}</span>
      <span>{{valeur?.valeLibe}}</span>
      <uptevia-ui-image [source]="imageSrc" width= "67px" height= "67px" ></uptevia-ui-image>
    </div>
</div>`,
  styleUrls: ['./cours-valeur.component.css']
})
export class CoursValeursComponent implements OnInit {
  ngDestroyed$ = new Subject<void>();
  valeur: Valeur | any;
  //Vérifier selon l'évolution du cours de la valeur, le système affiche un flèche vers le haut 
  //ou vers le bas ou deux lignes parallèles pour dire que le cours stagne
  imageSrc = 'assets/images/valeur-up.svg'
  list = [];
  constructor(
    private store: Store) {

  }
  ngOnInit(): void {
    this.getData();
  }
  getData() {
    this.store.select(selectOptData)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        if (data && data.valeurs) {
          this.valeur = this.getValeur(data.valeurs.valeurs)

        }
      });
  }
  private getValeur(listValeur: Valeur[]) {
    return listValeur.find(valeur => valeur.isValeurPrincipale);
  }
  get lang() {
    return localStorage.getItem('lang');
  }

  //TODO hors MVP
  selected(event: any) {
    console.log(event);
  }

  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }
}

