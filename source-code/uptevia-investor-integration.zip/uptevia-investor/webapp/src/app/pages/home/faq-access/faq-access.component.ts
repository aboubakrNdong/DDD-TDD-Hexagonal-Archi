import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-faq-access',
  template: ` <div class="faq">
  <div class="white-container-component">
    <div>
      <div class="text-center label">
          <h4>{{ 'contact.text.mostAsked' | translate }}</h4>
      </div>
      <div *ngFor="let question of listFaq">
        <p class="question">{{question.key | translate}}</p>
      </div>
    </div>
    <div class="button">
        <uptevia-ui-button size="small" color="secondary" label="{{'general.button.voirFaq' | translate}}" (onClick)="navigateToFAQ()"></uptevia-ui-button>
    </div>
  </div>
</div>`,
  styleUrls: ['./faq-access.component.css']
})
export class FaqAccessComponent {
  listFaq:any = [
    { key: 'faq.category.parameters.question.3', }, 
    { key: 'faq.category.customer.question.4', },
    { key: 'faq.category.operations.question.1', }
  ]
  constructor(private router: Router) { }

  navigateToFAQ() {
    this.router.navigate(['contact']);
  }
 
}
