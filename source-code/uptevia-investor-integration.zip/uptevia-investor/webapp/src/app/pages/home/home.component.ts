import { Component, Input, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { Modules } from 'src/app/entity/module';
import { Notification } from 'src/app/entity/notification';
import { UserAccess } from 'src/app/entity/user';
import { BffService } from 'src/app/services/bff.service';
import { selectRessources } from 'src/app/store/selectors/app.selector';
import { Quick_ACESS_DASHBOARD } from 'src/app/utils/const-vars';
import { Logo } from 'src/app/entity/logo';
import { LoginService } from 'src/app/services/login.service';
import { TranslateService } from '@ngx-translate/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Titulaire } from 'src/app/entity/titulaire';
import { AppState } from 'src/app/store/reducers/app.reducer';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { WelcomeModalComponent } from 'src/app/components/signup/welcome-modal/welcome-modal.component';


@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  quickAccess = Quick_ACESS_DASHBOARD;
  titulaire: any;
  news!: any
  user: UserAccess;
  link = "";
  thumbnail: any;
  urlUptevia = "";
  private ngUnsubscribe = new Subject<void>();
  isCguOpen =false;

  notification: Notification;

  constructor(
    private store: Store,
    private bffService: BffService,
    private modal: NgbModal,
    public translate: TranslateService,
    private sanitizer: DomSanitizer,) { }


  ngOnInit(): void {

    this.titulaire = JSON.parse(localStorage.getItem("titulaire") ?? '{}');
    if (this.titulaire) {
      this.refreshNews();
      this.user = JSON.parse(localStorage.getItem("user") ?? '{}');
      if (this.user.indiWillBePwdExpired) {
        this.notification = {
          message: "login.info.password.will.be.expired",
          srcImage: "assets/images/logo-uptevia.svg",
          buttonLabel: "parametres.general.bouton.title",
          notificationNavigateRoute: "maj_password"
        };

      }
    }
    this.UpdatequickAccess()
    this.getLogo();
  }

  refreshNews() {
    this.bffService.getActualites(this.titulaire).subscribe(
      (reponse) => {
        if (reponse) {
          this.news = reponse.actus;
        }
      }
    );
  }

  UpdatequickAccess() {
    this.store.select((state: any) => state.form)
    .pipe(takeUntil(this.ngUnsubscribe))
    .subscribe((data: AppState) => {
      if (data.modules) {
        const menu: any = data.modules.find((module: Modules) => module.groupeUrl === 'passage_operations')

        this.quickAccess?.sousModule.forEach((sousmenu) => {
          const foundAccess = menu?.sousModule.find((menu: any) => menu.moduleUrl === sousmenu.moduleUrl)
          sousmenu.show = foundAccess !== undefined
        });
      }
      if (data?.profil?.acceptCGU === false) {
        
        this.openCguPopin();
      }
    })
  }
  private openCguPopin() {
    if (!this.isCguOpen) {
      this.isCguOpen = true;
      this.modal.open(WelcomeModalComponent, { backdrop: 'static', keyboard: true, centered: true, });

    }
  }
  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  getLogo() {
    this.bffService.getLogo(this.titulaire.emetIden)
      .subscribe((logo: Logo) => {
        if (logo && logo.display) {
          let objectURL = `data:image/${logo.format};base64,` + logo.file;
          this.thumbnail = this.sanitizer.bypassSecurityTrustUrl(objectURL);

          this.link = logo.url;
        }
      });
  }

}
