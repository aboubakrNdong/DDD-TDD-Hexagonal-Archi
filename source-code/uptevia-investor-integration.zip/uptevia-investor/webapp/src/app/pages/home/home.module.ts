import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { ComponentsModule } from 'src/app/components/components.module';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { QuickAccessComponent } from '../../components/quick-access/quick-access.component';
import { FaqAccessComponent } from './faq-access/faq-access.component';
import { ProfilAccessComponent } from './profil-access/profil-access.component';
import { CoursValeursComponent } from './cours-valeur/cours-valeur.component';
import { TutoAccessComponent } from './tuto-access/tuto-access.component';


@NgModule({
  declarations: [
    HomeComponent,  
    FaqAccessComponent, ProfilAccessComponent,
    CoursValeursComponent, TutoAccessComponent],
  imports: [
    CommonModule,
    HomeRoutingModule,
    ComponentsModule,

  ],
  exports: [HomeComponent]
})
export class HomeModule { }
