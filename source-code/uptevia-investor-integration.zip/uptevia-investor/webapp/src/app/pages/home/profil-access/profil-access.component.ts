import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-profil-access',
  template: `<div class="gray-container profil-access">
  <div class="white-container-component">
    <div>
      <div class="title label">
          <h4>{{ 'contact.text.myAccount' | translate }}</h4>
      </div>
        <p class="question">{{'general.input.identifiant' | translate }} : {{user.login}}</p>
        <p class="question">{{'general.input.codeEmet' | translate }} : {{concatNumCompte}}</p>
        <p class="question">{{'general.input.typeCpte' | translate }} : {{classTypeLabel | translate}}</p>
        <p class="question">{{'general.input.titunume' | translate }} : {{titulaire.tituNume}}</p>

    </div>
  </div>
</div>`,
  styleUrls: ['./profil-access.component.css']
})
export class ProfilAccessComponent implements OnInit {

  concatNumCompte: any;
  classTypeLabel: any;

  ngOnInit(): void {
    this.createActiTypeCpte();
    this.createNumCompte();
  }

  titulaire = JSON.parse(localStorage.getItem("titulaire") ?? '{}');
  user = JSON.parse(localStorage.getItem("user") || '{}');

  createNumCompte(): string {
     this.concatNumCompte = this.titulaire.emetIden + "/" + this.titulaire.actiIden;
     return this.concatNumCompte;
   }


   createActiTypeCpte() {
    let classTypeCpte = 'general.typecpte.' + this.titulaire.actiTypeCompte;
    let lastIndex = classTypeCpte.lastIndexOf(".");
    classTypeCpte = classTypeCpte.substring(0, lastIndex);
    let classTypeCpteToLower = classTypeCpte.toLowerCase();
    this.classTypeLabel = classTypeCpteToLower.split(" ").join("");
  }

 
}
