import { Component } from '@angular/core';


@Component({
  selector: 'app-tuto-access',
  template: `<div class="tuto">
  <div class="text-center label">
      <h4>{{'dashboard.operation.tuto' | translate}}</h4>
  </div>
  <div class="flex-container">
    <img src="assets/images/video.svg" alt="">
    <div class="subtitle">
        <uptevia-ui-label size="small" label="{{'general.soon.available' | translate}}"></uptevia-ui-label>
    </div>
  </div>
</div>`,
  styleUrls: ['./tuto-access.component.css']
})
export class TutoAccessComponent {

  titulaire = JSON.parse(localStorage.getItem("titulaire") ?? '{}');



}
