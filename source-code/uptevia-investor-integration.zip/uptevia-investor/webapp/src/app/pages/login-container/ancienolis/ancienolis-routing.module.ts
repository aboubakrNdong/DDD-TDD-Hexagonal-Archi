import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AncienOlisComponent} from './ancienolis.component';

const routes: Routes = [
  { path: '', component: AncienOlisComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AncienOlisRoutingModule { }
