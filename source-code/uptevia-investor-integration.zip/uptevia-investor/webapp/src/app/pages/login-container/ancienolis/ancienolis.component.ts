import { Component, OnInit } from '@angular/core';
import { TranslationService } from 'src/app/services/translation.service';
import { SIGNUP_STEPS } from 'src/app/utils/trads.maps';

@Component({
  selector: 'app-ancienolis',
  templateUrl: './ancienolis.component.html',
  styleUrls: ['./ancienolis.component.css']
})
export class AncienOlisComponent  implements OnInit {

  public step: number = 0;

  currentStep = "old";

  buttonChoice = "oldolis"

  constructor(private translate: TranslationService){}

  ngOnInit(): void {}

  navigateTo(nextStep: string){
    this.currentStep = nextStep;

    if(this.currentStep == "pwd"){
     this.step = 1;
    }
    if(this.currentStep == "securing" || this.currentStep == "securingPage" ){
      this.step = 2;
     }
     if(this.currentStep == "secretQuestions" || this.currentStep == "upload" ){
      this.step = 3;
     }
  }

  get getTrads() {
    const trads: string[] = this.translate.getTranslation(SIGNUP_STEPS)
    return Object.values(trads)
  }
}
