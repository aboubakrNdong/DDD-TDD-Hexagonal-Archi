import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComponentsModule } from 'src/app/components/components.module';
import { AncienOlisComponent  } from './ancienolis.component';
import { AncienOlisRoutingModule } from './ancienolis-routing.module';


@NgModule({
  declarations: [AncienOlisComponent],
  imports: [
    CommonModule,
    AncienOlisRoutingModule,
    ComponentsModule
  ],
  exports:[AncienOlisComponent]
})
export class AncienOlisModule { }
