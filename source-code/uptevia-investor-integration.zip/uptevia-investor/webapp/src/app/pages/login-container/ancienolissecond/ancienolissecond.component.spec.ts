import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AncienolissecondComponent } from './ancienolissecond.component';

describe('AncienolissecondComponent', () => {
  let component: AncienolissecondComponent;
  let fixture: ComponentFixture<AncienolissecondComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AncienolissecondComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AncienolissecondComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
