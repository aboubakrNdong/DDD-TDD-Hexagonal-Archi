import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AncienPlsComponent} from './ancienpls.component';

const routes: Routes = [
  { path: '', component: AncienPlsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AncienPlsRoutingModule { }
