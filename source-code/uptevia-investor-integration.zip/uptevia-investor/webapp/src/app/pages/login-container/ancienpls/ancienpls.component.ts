import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslationService } from 'src/app/services/translation.service';
import { RESET_PASSWORD_FROM_MAIL, SIGNUP_STEPS } from 'src/app/utils/trads.maps';

@Component({
  selector: 'app-ancienpls',
  templateUrl: './ancienpls.component.html',
  styleUrls: ['./ancienpls.component.css']
})
export class AncienPlsComponent implements OnInit {

  public step: number = 0;

  currentStep = "old";

  buttonChoice = "oldpls"

  constructor(
    private router:Router,
    private translate: TranslationService) { }

  ngOnInit(): void { }

  navigateTo(nextStep: string) {
    this.currentStep = nextStep; 
  }
  
  goToProfil(){
    this.router.navigateByUrl('ancienolisorpls', {replaceUrl:true})
  }
  get getTrads() {
    const trads: string[] = this.translate.getTranslation(RESET_PASSWORD_FROM_MAIL)
    return Object.values(trads)
  }
}
