import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComponentsModule } from 'src/app/components/components.module';
import { AncienPlsComponent  } from './ancienpls.component';
import { AncienPlsRoutingModule } from './ancienpls-routing.module';


@NgModule({
  declarations: [AncienPlsComponent],
  imports: [
    CommonModule,
    AncienPlsRoutingModule,
    ComponentsModule
  ],
  exports:[AncienPlsComponent]
})
export class AncienPlsModule { }
