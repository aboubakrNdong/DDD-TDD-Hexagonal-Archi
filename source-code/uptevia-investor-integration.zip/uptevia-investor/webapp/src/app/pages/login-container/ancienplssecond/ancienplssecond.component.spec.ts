import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AncienplssecondComponent } from './ancienplssecond.component';

describe('AncienplssecondComponent', () => {
  let component: AncienplssecondComponent;
  let fixture: ComponentFixture<AncienplssecondComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AncienplssecondComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AncienplssecondComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
