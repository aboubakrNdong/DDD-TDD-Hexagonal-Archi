import { Location } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { TokenLogin } from 'src/app/entity/token-password';
import { OnboardingSteps } from 'src/app/entity/vialink/onboarding-steps';
import { TranslationService } from 'src/app/services/translation.service';
import { selecPlstUser } from 'src/app/store/selectors/app.selector';
import { RESET_PASSWORD_FROM_MAIL } from 'src/app/utils/trads.maps';



@Component({
  selector: 'app-ancienplssecond',
  templateUrl: './ancienplssecond.component.html',
  styleUrls: ['./ancienplssecond.component.css']
})
export class AncienplssecondComponent {

  public step: number = 1;
  token: string;

  currentStep: string = OnboardingSteps.ONBOARDING_STEP_PSW;
  tokenLogin: TokenLogin;
  buttonChoice = "oldolis"

  constructor(
    private location: Location,
    private store: Store,
    private translate: TranslationService,
    private activatedRoute: ActivatedRoute,
  ) {
    this.getQueryParam()


  }

  ngOnInit(): void {

    const extras: any = this.location.getState();
    console.log('extras', extras?.status);
    if (extras?.status) {
      this.currentStep = extras.status;
      console.log('current step', this.currentStep);
      if (this.currentStep === OnboardingSteps.ONBOARDING_STEP_QUESTION) {
        this.step = 2;
      }
    }
    this.getPlsData()
  }
  //TODO call on boarding to check status 

  getQueryParam() {
    this.activatedRoute.queryParams.subscribe(params => {
      if (params['sd']) {
        this.buttonChoice = "forgotpassword";
        this.token = params['sd'];
      } else if (params['dt']) {
        this.buttonChoice = "firstconnexion";
        this.token = params['dt'];
      }
      else if (params['ol']) {
        this.buttonChoice = "oldolis";
        this.token = params['ol'];
      }
      else if (params['pl']) {
        this.buttonChoice = "oldpls";
        this.token = params['pl'];
      }
      console.log(this.token); // Print the token to the console. 
    });
  }

  getPlsData() {
    this.store.select(selecPlstUser).subscribe(result => {
      if (result?.user?.loginUpi) {
        console.log('get PLs data')
        this.tokenLogin = { email: result.user.email, login: result.user.loginUpi }

      }
    }

    )
  }
  onStepsIndicator(nextStep: string) {
    this.currentStep = nextStep;
    if (this.currentStep === OnboardingSteps.ONBOARDING_STEP_QUESTION) {
      this.step = 2;
    }
    // test for KYC incomplete

  }
  getLogin(data: TokenLogin) {
    this.tokenLogin = data
  }
  get getTrads() {
    const trads: string[] = this.translate.getTranslation(RESET_PASSWORD_FROM_MAIL)
    return Object.values(trads)
  }

  get isCompleted() {
    return this.currentStep === OnboardingSteps.ONBOARDING_COMPLETED
  }
}