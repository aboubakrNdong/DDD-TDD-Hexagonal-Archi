import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ComponentsModule } from 'src/app/components/components.module';
import { AncienPlsSecondRoutingModule } from './ancienplssecond-routing.module';
import { AncienplssecondComponent } from './ancienplssecond.component';
import { CreatePasswordModule } from 'src/app/components/signup/create-password/create-password.module';
import { SignuCompletedModule } from 'src/app/components/signup/signup-completed/signup-completed.module';


@NgModule({
  declarations: [AncienplssecondComponent],
  imports: [
    CommonModule,
    AncienPlsSecondRoutingModule,
    ComponentsModule,
    CreatePasswordModule,
    SignuCompletedModule
  ],
  exports:[AncienplssecondComponent]
})
export class AncienPlsSecondModule { }
