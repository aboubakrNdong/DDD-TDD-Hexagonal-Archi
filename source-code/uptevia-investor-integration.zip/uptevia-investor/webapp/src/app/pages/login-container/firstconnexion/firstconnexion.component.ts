import { Component, OnInit } from '@angular/core';
import { TranslationService } from 'src/app/services/translation.service';
import { RESET_PASSWORD_FROM_MAIL, SIGNUP_STEPS } from 'src/app/utils/trads.maps';
import { Router } from '@angular/router';

@Component({
  selector: 'app-firstconnexion',
  templateUrl: './firstconnexion.component.html',
  styleUrls: ['./firstconnexion.component.css']
})
export class FirstConnexionComponent  implements OnInit {

  public step: number = 0;

  currentStep = "verif_data_step1";

  buttonChoice = "firstconnexion";

  switchChoice: any;

  constructor(
    private translate: TranslationService,
    private router: Router
  ) { }

  ngOnInit(): void {}

  navigateTo(nextStep: string){
    this.currentStep = nextStep;

  }

  get getTrads() {
    const trads: string[] = this.translate.getTranslation(RESET_PASSWORD_FROM_MAIL)
    return Object.values(trads)
  }

  onSwitchChoice(event: any) {
    this.switchChoice = event;
    this.navigateTo(this.switchChoice);
  }

  goToProfil() {
    this.router.navigate(['login']);
  }
}
