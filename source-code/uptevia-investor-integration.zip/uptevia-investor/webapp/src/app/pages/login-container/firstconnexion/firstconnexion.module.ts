import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComponentsModule } from 'src/app/components/components.module';
import { FirstConnexionComponent,  } from './firstconnexion.component';
import { FirstConnexionRoutingModule } from './firstconnexion-routing.module';


@NgModule({
  declarations: [FirstConnexionComponent],
  imports: [
    CommonModule,
    FirstConnexionRoutingModule,
    ComponentsModule
  ],
  exports:[FirstConnexionComponent]
})
export class FirstConnexionModule { }
