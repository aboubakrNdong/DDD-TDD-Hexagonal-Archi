import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FirstconnexionsecondComponent } from './firstconnexionsecond.component';

const routes: Routes = [
  { path: '', component: FirstconnexionsecondComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FirstConnexionSecondRoutingModule { }
