import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FirstconnexionsecondComponent } from './firstconnexionsecond.component';

describe('FirstconnexionsecondComponent', () => {
  let component: FirstconnexionsecondComponent;
  let fixture: ComponentFixture<FirstconnexionsecondComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FirstconnexionsecondComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FirstconnexionsecondComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
