import { Component, OnInit } from '@angular/core';
import { TranslationService } from 'src/app/services/translation.service';
import { SIGNUP_STEPS } from 'src/app/utils/trads.maps';
import { Store } from '@ngrx/store'; 
import { Subject, takeUntil } from 'rxjs';


@Component({
  selector: 'app-firstconnexionsecond',
  templateUrl: './firstconnexionsecond.component.html',
  styleUrls: ['./firstconnexionsecond.component.css']
})
export class FirstconnexionsecondComponent {


  public step: number = 0;

  currentStep = "notif";

  buttonChoice = "firstconnexion"

  ngDestroyed$ = new Subject<void>();
 


  constructor(private translate: TranslationService,
    private store: Store,){}

  ngOnInit(): void { 

  }


  
 

  navigateTo(nextStep: string){
    this.currentStep = nextStep;

    if(this.currentStep == "pwd"){
     this.step = 1;
    }
    if(this.currentStep == "securing" || this.currentStep == "securingPage" ){
      this.step = 2;
     }
     if(this.currentStep == "secretQuestions" || this.currentStep == "upload" ){
      this.step = 3;
     }

  }

  get getTrads() {
    const trads: string[] = this.translate.getTranslation(SIGNUP_STEPS)
    return Object.values(trads)
  }

  
  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }

}
