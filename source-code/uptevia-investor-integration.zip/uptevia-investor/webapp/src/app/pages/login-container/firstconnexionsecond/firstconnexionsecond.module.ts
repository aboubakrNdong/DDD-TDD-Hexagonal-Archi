import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComponentsModule } from 'src/app/components/components.module';
import { FirstconnexionsecondComponent } from './firstconnexionsecond.component';
import { FirstConnexionSecondRoutingModule } from './firstconnexionsecond-routing.module';



@NgModule({
  declarations: [FirstconnexionsecondComponent],
  imports: [
    CommonModule,
    FirstConnexionSecondRoutingModule,
    ComponentsModule
  ],
  exports:[FirstconnexionsecondComponent]
})
export class FirstConnexionSecondModule { }
