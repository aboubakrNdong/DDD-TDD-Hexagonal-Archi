import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForgotIdentifiantComponent } from './forgot-identifiant.component';

const routes: Routes = [
  { path: '', component: ForgotIdentifiantComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ForgotIdentifiantRoutingModule { }
