import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotIdentifiantComponent } from './forgot-identifiant.component';

describe('ForgotIdentifiantComponent', () => {
  let component: ForgotIdentifiantComponent;
  let fixture: ComponentFixture<ForgotIdentifiantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForgotIdentifiantComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ForgotIdentifiantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
