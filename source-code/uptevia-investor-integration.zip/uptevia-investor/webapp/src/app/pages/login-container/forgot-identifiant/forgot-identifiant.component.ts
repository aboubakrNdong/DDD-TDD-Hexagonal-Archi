import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-identifiant',
  templateUrl: './forgot-identifiant.component.html',
  styleUrls: ['./forgot-identifiant.component.css']
})
export class ForgotIdentifiantComponent {

  public step: number = 0;

  currentStep = "notif";

  buttonChoice = "forgotidentifiant"

  switchChoice: any;

  constructor(
    private router: Router
  ) { 
    
  }

  ngOnInit(): void {
  }

  navigateTo(nextStep: string) {
    this.currentStep = nextStep;
  }

  onSwitchChoice($event: any) {
    this.switchChoice = $event;
    this.navigateTo(this.switchChoice);
  }

  goToProfil() {
    this.router.navigate(['login']);
  }

}
