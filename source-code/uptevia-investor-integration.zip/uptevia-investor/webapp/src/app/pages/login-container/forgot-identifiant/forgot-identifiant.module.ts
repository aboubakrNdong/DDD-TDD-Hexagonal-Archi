import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComponentsModule } from 'src/app/components/components.module';
import { ForgotIdentifiantComponent } from './forgot-identifiant.component';
import { ForgotIdentifiantRoutingModule } from './forgot-identifiant-routing.module';


@NgModule({
  declarations: [ForgotIdentifiantComponent],
  imports: [
    CommonModule,
    ForgotIdentifiantRoutingModule,
    ComponentsModule
  ],
  exports:[ForgotIdentifiantComponent]
})
export class ForgotIdentifiantModule { }
