import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ForgotcredentialsComponent } from './forgotcredentials.component';

const routes: Routes = [
  { path: '', component: ForgotcredentialsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ForgotCredentialsRoutingModule { }
