import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-forgotcredentials',
  templateUrl: './forgotcredentials.component.html',
  styleUrls: ['./forgotcredentials.component.css']
})
export class ForgotcredentialsComponent implements OnInit{

  enabledPwd: boolean;
  constructor(private router: Router,private location: Location){}

  ngOnInit(): void {
    const state: any = this.location.getState();
    this.enabledPwd = state.enabledPwd;
  }

  onForgotId(){
    this.router.navigate(['forgotidentifiant']);
  }

  
  onForgotPassword(){
    this.router.navigate(['forgotpassword']);
  }

  goToProfil() {
    this.router.navigate(['login']);
  }
}
