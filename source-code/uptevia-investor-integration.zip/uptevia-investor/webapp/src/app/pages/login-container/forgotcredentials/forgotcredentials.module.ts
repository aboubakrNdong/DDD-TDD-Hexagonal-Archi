import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComponentsModule } from 'src/app/components/components.module';
import { ForgotCredentialsRoutingModule } from './forgotcredentials-routing.module';
import { ForgotcredentialsComponent } from './forgotcredentials.component';


@NgModule({
  declarations: [ForgotcredentialsComponent],
  imports: [
    CommonModule,
    ForgotCredentialsRoutingModule,
    ComponentsModule
  ],
  exports:[ForgotcredentialsComponent]
})
export class ForgotCredentialsModule { }
