import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoginContainerRoutingModule } from './login-container-routing.module';
import { LoginContainerComponent } from './login-container.component';
import { ComponentsModule } from 'src/app/components/components.module';


@NgModule({
  declarations: [LoginContainerComponent],
  imports: [
    CommonModule,
    LoginContainerRoutingModule,
    ComponentsModule, 
  ],
  exports:[LoginContainerComponent]
})
export class LoginContainerModule { }
