import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavigationExtras, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { ReCaptchaV3Service } from 'ngx-captcha';
import { CookieService } from 'ngx-cookie-service';
import { LoginRequest } from 'src/app/entity/login-request';
import { Profil } from 'src/app/entity/profil';
import { smsData } from 'src/app/entity/smsData';
import { ResultStatus } from 'src/app/entity/status';
import { UserAccess } from 'src/app/entity/user';
import { OnboardingSteps } from 'src/app/entity/vialink/onboarding-steps';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { MessageService } from 'src/app/services/message.service';
import { TranslationService } from 'src/app/services/translation.service';
import { setAncienPlsSuccess, setNumMobilePro, setProfile, setSmsCode, setUserAcces, setUsername } from 'src/app/store/actions/app.action';
import { getLang, showModal, whiteListSms } from 'src/app/utils/functions';
import { LOGIN_COMPONENT_LABELS } from 'src/app/utils/trads.maps';
import { environment } from 'src/environments/environment';
import { Titulaire } from '../../../entity/titulaire';
import { UserAccessPls } from 'src/app/entity/userAccessPls';
import { WelcomeModalComponent } from 'src/app/components/signup/welcome-modal/welcome-modal.component';




@Component({
  selector: 'upi-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [TranslationService]
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  loginError: boolean = false;
  login = "";

  titulaire: Titulaire;
  profile: any;
  numPhone = "";
  messages: string[] = [];
  trad: any//=LOGIN_COMPONENT_LABELS;
  submitted = false;
  siteKey = environment.siteKeyCaptchaV3;
  siteKeyV2 = environment.siteKeyCaptchaV2;

  @ViewChild('onglet-connexion', { read: TemplateRef }) ongletConnexion: TemplateRef<any>;
  @ViewChild('firstConnexionTab', { read: TemplateRef }) firstConnexionTab: TemplateRef<any>;
  enabledPwd = true;
  isInWhitelistSms = true;
  dataUser: UserAccess;

  constructor(
    private translate: TranslateService,
    private modal: NgbModal,
    private bffService: BffService,
    private loginService: LoginService,
    private messageService: MessageService,
    private router: Router,
    private fb: FormBuilder,
    private cookieService: CookieService,
    private translateService: TranslationService,
    private store: Store,) { }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      username: [
        this.cookieService.get('rememberedUsername') || '',
        [Validators.required, Validators.minLength(8)]
      ],
      password: ['', Validators.required],
      rememberMe: [false],
    });
    const lang: string = localStorage.getItem('lang') || ''
    this.translate.use(lang);

  }

  get username(): AbstractControl {
    return this.loginForm.get('username')!;
  }



  get lang() {
    return getLang()
  }

  getTitulaires(userLogin: string) {
    this.login = userLogin.toString();
    this.loginService.getTitulaire(this.login).subscribe((titulaires: Profil) => {
      if (titulaires) {
        this.profile = titulaires;
        this.numPhone = this.profile.numMobilePerso;
        this.store.dispatch(setProfile({ profil: this.profile, username: this.login }));
        this.checkNull(this.numPhone);
      } else {
        this.messages = this.messageService.messages;
      }
    })
  }


  //check if number is null
  checkNull(phone: string) {
    if (phone == null) {
      console.log("Data missing in registrar");
      showModal('general.warning.alert', ['form.field.validator.phonenotinregistrar'], 'general.bouton.fermer', this.modal);
      this.router.navigate(['loginwithoutsms']);
      //return;
    } else {
      this.checkAndSendSmS(phone);
    }
  }

  //check whitelist sms and send
  checkAndSendSmS(mobileNum: string) {

    let randomCode = Math.floor(100000 + Math.random() * 900000);

    const smsNumber: smsData = {
      text: this.translate.instant('form.field.sendsms') + randomCode,
      mobileNumbers: [mobileNum]
    };
  
    if (whiteListSms.includes(mobileNum)) {
      if (smsNumber) {
        this.bffService.sendSms(smsNumber).subscribe((res: any) => {
          if (res) {
            console.log("sms sent successfully", res);

            //Mettre à jour la base que le user a validé son OTP
            let loginUser = this.login;
            this.bffService.getValideOtp(loginUser).subscribe(
              (reponse) => {
                if (reponse) {
                  console.log('Mise à jour statut OTP effectuée')

                } else {
                  console.log('Mise à jour statut OTP non effectuée')
                }
              },
              (error) => {
                console.log('can not get categories', error);
              }
            );
            this.store.dispatch(setSmsCode({ smscode: randomCode.toString() }));
            this.store.dispatch(setUsername({ username: this.login }));
            this.store.dispatch(setUserAcces({ user: this.dataUser }));
            this.store.dispatch(setNumMobilePro({ nummobilepro: mobileNum }));


            this.router.navigate(['loginwithsms']);
          } else {
            this.messages = this.messageService.messages;
          }
        })
      }
    } else {
      this.isInWhitelistSms = false;
      console.log("number not in whitelist");
    }


  }

  submitLogin() {
    this.submitted = true;
    this.messageService.clear();


    if (this.loginForm.valid) {
      const formData = this.loginForm.value;

      if (formData.rememberMe) {
        this.cookieService.set('rememberedUsername', formData.username, environment.cookieLoginDuration); // Stockez l'identifiant dans un cookie pour 1 an
      } else {
        this.cookieService.delete('rememberedUsername'); // Supprimez le cookie si "Se souvenir de moi" n'est pas coché
      }

      const loginRequest: LoginRequest = {
        login: formData.username.trim(),
        password: formData.password
      }

      this.loginService.authenticate(loginRequest)
        .subscribe((user: UserAccess) => {
          if (user) {
            //Controles onboarding
            console.log(user);
            this.dataUser = user;
            this.store.dispatch(setUserAcces({ user }))
            if (!user.reponseQuestionSecurite1 || !user.reponseQuestionSecurite2) {
              console.log("redirect to Question step");
              let keyTrad = 'onboarding.error.nextStep.ONBOARDING_STEP_QUESTION';
              //Etre plus précis sur la step
              showModal('general.warning.error', [keyTrad], 'general.bouton.fermer', this.modal);
              const navExtras: NavigationExtras = {
                state: {
                  status: OnboardingSteps.ONBOARDING_STEP_QUESTION
                }
              }
              this.firstConnexionProfile(user.login, 'setpassword', navExtras);

            } else {
              localStorage.setItem('token', user.token);
              this.getTitulaires(user.login);

            }
          } else {
            this.messages = this.messageService.messages;
            console.log('Authentification échouée');
            this.loginError = true;
          }
        });
    } else {
      console.log("form login Invalid", this.loginForm.value);

    }
  }

  get getTrads() {
    return this.translateService.getTranslation(LOGIN_COMPONENT_LABELS)
  }

  handleReset() {
    console.log('handleExpire');

  }


  handleSuccess(event: any) {
    console.log('handleSuccess');
  }

  beginSignUp() {
    this.submitted = true;
    // dispatch username to store
    const login = this.loginForm.value.username
    if (login == '') {
      return;
    }
    //Vérifier s'il a déja fait son parcours

    this.loginService.getOnboardingStatus(login).subscribe((res: ResultStatus) => {
      if (res) {
        this.store.dispatch(setUsername({ username: login }));

        let keyTrad = 'onboarding.error.nextStep.' + res.status;
        //Controles onboarding
        console.log(res.status === OnboardingSteps.OK);
        if (res.status === OnboardingSteps.OK) {
          //get user infor and update store 
          this.firstConnexionProfile(login, 'firstconnexion');
        }

        else if (res.status === OnboardingSteps.ONBOARDING_STEP_QUESTION) {
          showModal('general.warning.error', [keyTrad], 'general.bouton.fermer', this.modal);
          const navExtras: NavigationExtras = {
            state: {
              status: res.status
            }
          }
          console.log(" state", navExtras);

          this.firstConnexionProfile(login, 'setpassword', navExtras);


        } else {
          showModal('general.warning.error', [keyTrad], 'general.bouton.fermer', this.modal);
        }

      } else {
        //Etre plus précis sur la step
        console.error('errro get getOnboardingStatus');

      }
    });

  }



  firstConnexionProfile(login: string, route: string, navExtras?: NavigationExtras) {
    this.loginService.getTitulaire(login).subscribe((titulaire: Profil) => {
      if (titulaire) {
        const user: UserAccessPls = {
          loginUpi: login,
          actiIden: titulaire.actiIden,
          emetIden: titulaire.emetIden,
          tituNume: 1,//TODO to be verified dans api /api/v1/titulaire
          email: titulaire.emailPerso,
          numMobile: titulaire.numMobilePerso

        }

        this.store.dispatch(setAncienPlsSuccess({ ancienPls: user }));
        this.router.navigate([route], navExtras);

      } else {
        this.messages = this.messageService.messages;
        console.error('Error get Profile data ');
      }

    })
  }
  OldOlisOrPls() {
    this.router.navigate(['ancienolisorpls']);
  }



  onForgotIdentifier() {
    const navExtras: NavigationExtras = {
      state: {
        enabledPwd: false
      }
    }
    this.router.navigate(['forgotcredentials'], navExtras);
  }


  onForgotCredentials() {
    const navExtras: NavigationExtras = {
      state: {
        enabledPwd: true
      }
    }
    this.router.navigate(['forgotcredentials'], navExtras);
  }
}
