import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginwithoutsmsComponent } from './loginwithoutsms.component';

const routes: Routes = [
  { path: '', component: LoginwithoutsmsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LoginWithoutSmsRoutingModule { }
