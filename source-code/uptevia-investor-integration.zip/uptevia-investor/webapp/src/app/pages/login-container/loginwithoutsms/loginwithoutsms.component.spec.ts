import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginwithoutsmsComponent } from './loginwithoutsms.component';

describe('LoginwithoutsmsComponent', () => {
  let component: LoginwithoutsmsComponent;
  let fixture: ComponentFixture<LoginwithoutsmsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginwithoutsmsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LoginwithoutsmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
