# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/3.0.4/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/3.0.4/maven-plugin/reference/html/#build-image)
* [Spring Reactive Web](https://docs.spring.io/spring-boot/docs/3.0.4/reference/htmlsingle/#web.reactive)
* [OAuth2 Client](https://docs.spring.io/spring-boot/docs/3.0.4/reference/htmlsingle/#web.security.oauth2.client)
* [Spring Security](https://docs.spring.io/spring-boot/docs/3.0.4/reference/htmlsingle/#web.security)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a Reactive RESTful Web Service](https://spring.io/guides/gs/reactive-rest-service/)
* [Securing a Web Application](https://spring.io/guides/gs/securing-web/)
* [Spring Boot and OAuth2](https://spring.io/guides/tutorials/spring-boot-oauth2/)
* [Authenticating a User with LDAP](https://spring.io/guides/gs/authenticating-ldap/)
* [spring doc swagger](https://springdoc.org/)
* [DDD or Hexagonal architecture](https://medium.com/@rabarijaona/dune-architecture-en-couche-classique-vers-une-architecture-hexagonale-avec-spring-boot-8622964ef572)

### Stack

This project uses the following frameworks and libraries:

- JAVA 17
- Spring boot 2.7.10
- Jakarta 8
- Maven 3.3.9
- Wildfly 26.1.3

### Git flow
L:\CACEIS-CARAR$\GR-IT\ADM\ISSUERS\General\OLIS Team\Secteur OLIS\10- Uptevia\01 - REFONTE OLIS\stream olis investisseur\dev\convention git.docx

### Features

- Java 17 source compatibility
- Spring runtime environment
- Executable JAR/WAR file format
- Standard acuators enabled
- Standards based implementations
    - JPA (Hibernate)
    - JDBC
- Pragmatic resource expansion capabilities (see below)
- Standardized mapping of exceptions to responses


## @todo Caching

This project **does not** implement nor enable caching. Instead, it is proposed that one should make use of web cache (web server, web proxy, load balancer, etc) as it will almost certainly be more effience and performant than any service based cache.

## Structure

The project is implemented as a Maven multi-module project with the following modules

### /
Project parent.



### /app
Api gateway Zuul



### How to work

1. clone the projet
git clone https://git.caceis.group.gca/UPI/uptevia-api-gateway.git
git checkout integration

2. mvn clean install
3. run wildfly 
cd C:\Public\SOFTWARE\wildfly-26.1.3.Final\bin
standalone.bat
4. deploy the war on the wildly with mvn plugin (org.wildfly.plugins) or with
console : http://localhost:8080/

