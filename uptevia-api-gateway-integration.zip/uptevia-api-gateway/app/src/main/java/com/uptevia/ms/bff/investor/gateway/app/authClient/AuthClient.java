package com.uptevia.ms.bff.investor.gateway.app.authClient;

import com.uptevia.ms.bff.investor.gateway.app.model.LogOutRequestDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "ms-investor-auth-app", url = "${zuul.routes.backAuth.url}")
public interface AuthClient {

    @GetMapping("/api/v1/restricted/updateLoggedOutUsers")
    public ResponseEntity<List<LogOutRequestDTO>> updateLoggedOutTokens();
}
