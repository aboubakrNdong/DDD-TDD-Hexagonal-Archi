package com.uptevia.ms.bff.investor.gateway.app.configuration;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;
import com.uptevia.ms.bff.investor.gateway.app.authClient.AuthClient;
import com.uptevia.ms.bff.investor.gateway.app.jwt.JwtUtils;
import com.uptevia.ms.bff.investor.gateway.app.model.LogOutRequestDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.List;


@Component
public class LogOutFilter extends ZuulFilter {

    @Autowired
    private AuthClient authClient;

    @Autowired
    private JwtUtils jwtUtils;

    private static Logger log = LoggerFactory.getLogger(LogOutFilter.class);
    @Override
    public String filterType() {
        return "pre";
    }

    @Override
    public int filterOrder() {
        return 1;
    }

    @Override
    public boolean shouldFilter() {
        return true;
    }

    @Override
    public Object run() throws ZuulException {
        log.info("Begin gateway run filter ...");
        RequestContext ctx = RequestContext.getCurrentContext();
        HttpServletRequest request = ctx.getRequest();

        return null;
    }

    @Scheduled(fixedRate = 180000)
    @Order(1)
    public void updateLoggedOutUsers() {
        log.info("Update logged out users every 3 minutes");
        List<LogOutRequestDTO> updatedLoggedOutTokens = this.authClient.updateLoggedOutTokens().getBody();
        log.info("We have {} updated tokens", updatedLoggedOutTokens.size());
        if (updatedLoggedOutTokens != null && !updatedLoggedOutTokens.isEmpty())
            this.jwtUtils.updateLoggedOutTokens(updatedLoggedOutTokens);
    }
}