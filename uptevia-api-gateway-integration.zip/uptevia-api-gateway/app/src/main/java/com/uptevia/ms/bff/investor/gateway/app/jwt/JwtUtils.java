package com.uptevia.ms.bff.investor.gateway.app.jwt;


import com.netflix.zuul.exception.ZuulException;
import com.uptevia.ms.bff.investor.gateway.app.model.LogOutRequestDTO;
import io.jsonwebtoken.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import java.security.Key;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Component
@Slf4j
public class JwtUtils {

    @Value("${gateway.app.jwtSecret}")
    private String secretKey;
    private final List<LogOutRequestDTO> loggedOutUsers = new CopyOnWriteArrayList<>();

    private static final SignatureAlgorithm algorithm = SignatureAlgorithm.HS256;

    //generate secure key from java.security to sign jwt token
    private Key key() {
        return new SecretKeySpec(secretKey.getBytes(), algorithm.getJcaName());
    }

    //Extract subject as username  from JWT  token
    public String getUserNameFromJwtToken(final String token) {
        return Jwts.parser().setSigningKey(key()).build()
                .parseClaimsJws(token).getBody().getSubject();
    }

    public boolean validateJwtToken(final String authToken) {
        try {
            log.info("Begin gateway parsing JWT token ...");
            Jwts.parser().setSigningKey(key()).build().parse(authToken);
            validateTokenIsNotForALoggedOutDevice(authToken);
            return true;
        } catch (MalformedJwtException e) {
            log.error("Invalid JWT token: {}", e.getMessage());
        } catch (ExpiredJwtException e) {
            log.error("JWT token is expired: {}", e.getMessage());
        } catch (UnsupportedJwtException e) {
            log.error("JWT token is unsupported: {}", e.getMessage());
        } catch (IllegalArgumentException e) {
            log.error("JWT claims string is empty: {}", e.getMessage());
        } catch (ZuulException e) {
            log.error("Token already expired, Please login with new one: {}", e.getMessage());
        }
        log.error("Begin parsing jwt token");
        return false;
    }

    public String resolveToken(final HttpServletRequest req) {
        String bearerToken = req.getHeader("Authorization");
        if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7, bearerToken.length());
        }
        if (bearerToken != null) {
            return bearerToken;
        }
        return null;
    }

    public Claims getAllClaimsFromToken(String bearerToken) {
        if (bearerToken != null && bearerToken.startsWith("Bearer "))
            bearerToken = bearerToken.substring(7, bearerToken.length());
        return Jwts.parser().verifyWith((SecretKey) key()).build().parseSignedClaims(bearerToken).getPayload();
    }

    /**
     * get the expiration date from the JWT token
     *
     * @param token
     * @return Date
     */
    public Date getTokenExpiryFromJWT(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(key())
                .build()
                .parseSignedClaims(token)
                .getBody();

        return claims.getExpiration();
    }


    /**
     * add a check to validate a JWT Token to perform an extra check to see if the incoming token is present in the blacklist or not
     * @param authToken
     */

    private void validateTokenIsNotForALoggedOutDevice(final String authToken) throws ZuulException {

        if (authToken != null && !this.loggedOutUsers.isEmpty()
                && this.loggedOutUsers.stream().anyMatch(token -> token.getToken().equals(authToken))) {
            throw new ZuulException("Token already expired, Please login with new one", HttpStatus.FORBIDDEN.value(), "");
        }
    }


    /**
     * update the logged-out user's list every some minutes
     *
     * @param revokedTokens
     */
    public void updateLoggedOutTokens(List<LogOutRequestDTO> revokedTokens) {
        log.info("Clearing blacklist of tokens");
        this.loggedOutUsers.clear();
        this.loggedOutUsers.addAll(revokedTokens.stream()
                .map(myRevokedToken -> new LogOutRequestDTO(myRevokedToken.getUsername(), myRevokedToken.getToken(), myRevokedToken.getRevokeDate()
                        , myRevokedToken.getValidityEndDate())).toList());
        log.info("blacklist of tokens successfully been updated");
    }
}
