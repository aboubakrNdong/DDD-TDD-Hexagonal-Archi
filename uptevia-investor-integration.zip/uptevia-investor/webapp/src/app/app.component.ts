import { Component, OnInit } from '@angular/core';
import { NavigationErrorService } from './services/error-handler.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [NavigationErrorService]
})
export class AppComponent implements OnInit {
  constructor(private NavigationError: NavigationErrorService) { }
  ngOnInit(): void {
    //hide logs in prod && pre-prod build
    if (environment.production && !window.location.href.includes('localhost')) {
      window.console.log = () => { }
      window.console.warn = () => { }
      window.console.error = () => { }
    }

  }
  loadReCaptchaScript() {
    const script = document.createElement('script');
    script.src = ' https://www.google.com/recaptcha/api.js?render=' + environment.siteKeyCaptchaV3;
    document.head.appendChild(script);
  }

}
