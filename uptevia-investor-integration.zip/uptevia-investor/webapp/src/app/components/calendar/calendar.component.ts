import { Component, Input, OnInit } from '@angular/core';
import { getMaxDate, getMinDate } from 'src/app/utils/functions';
import { PrimeNGConfig } from 'primeng/api';
import { TranslateService } from '@ngx-translate/core';
import { PRIME_CALENDAR_TRANSLATIONS } from 'src/app/utils/trads.maps';


@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css']
})
export class CalendarComponent implements OnInit {

  @Input() dateControl: any;
  minDate: Date = new Date();
  @Input() disabledDates: string[] | undefined;
  maxDate: Date;
  closedDates: Date[]

  constructor(
    private config: PrimeNGConfig,
    private translate: TranslateService) { }

  ngOnInit() {
    if (this.disabledDates) {
      this.closedDates = this.disabledDates?.map((date: any) => new Date(date));
      this.minDate = getMinDate(this.closedDates);
      this.maxDate = getMaxDate(this.closedDates);
    }
    this.setCalendarLanguage();
  }


  setCalendarLanguage() {
    let translation: any = PRIME_CALENDAR_TRANSLATIONS
    this.translate.stream('primeng').subscribe(data => {
      const lang: any = this.translate.currentLang
      this.config.setTranslation(translation[lang]);
    });
  }


}
