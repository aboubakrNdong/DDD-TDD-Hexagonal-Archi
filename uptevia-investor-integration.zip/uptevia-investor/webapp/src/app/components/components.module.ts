import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { ReactiveFormsModule } from '@angular/forms';
import { ContactSupportModule } from './contact-support/contact-support.module';
import { ContactformModule } from './contactform/contactform.module';
import { FooterModule } from './footer/footer.module';
import { HeaderModule } from './header/header.module';
import { PortefeuilleTabModule } from './portefeuille-tab/porefeuille-tab.module';
import { RubriqueModule } from './rubrique-aide/rubrique.module';
import { UpteviaLibModule } from './uptevia-lib.module';

import { DisclaimerCookieModule } from './disclaimercookie/disclaimercookie.module';
import { NotificationModule } from './notification/notification.module';
import { AchatModule } from './operations/acheter-components/achat/achat.module';
import { ConfirmationModule } from './operations/acheter-components/confirmation/confirmation.module';
import { PaiementModule } from './operations/acheter-components/paiement/paiement.module';
import { VenteComponetModule } from './operations/vendre-components/vente/vente.module';
import { ProfilTabModule } from './profil-tab/profil-tab.module';
import { SideBarModule } from './side-menu/side-menu.module';

import { CguModule } from './cgu/cgu.module';
import { ForgotSecretQModule } from './forgot-credentials/forgot-secretq/forgot-secretq.module';
import { ForgotIdentificationModule } from './forgot-credentials/forgotidentification/forgotidentification.module';
import { ForgotLoginModule } from './forgot-credentials/forgotlogin/forgotlogin.module';
import { ForgotQuestionsModule } from './forgot-credentials/forgotquestions/forgotquestions.module';
import { NewIdentifiantModule } from './forgot-credentials/newidentifiant/newidentifiant.module';
import { ShowcontactDataModule } from './forgot-credentials/showcontact-data/showcontact-data.module';
import { WriteIdentifiantModule } from './forgot-credentials/writeidentifiant/writeidentifiant.module';
import { OperationComponentModule } from './operation-element/operation-element.module';
import { VenteConfirmationModule } from './operations/vendre-components/confirmation/confirmation.module';
import { VentePaiementModule } from './operations/vendre-components/vente-paiement/vente-paiement.module';
import { PortefeuilleModule } from './portefeuille-components/porefeuille-components.module';
import { QuickAccessModule } from './quick-access/quick-access.module';
import { IdentificationModule } from './signup/identification/identification.module';
import { LoginIdentificationModule } from './signup/loginidentification/loginidentification.module';
import { OldAccountModule } from './signup/oldaccount/oldaccount.module';
import { SecretQModule } from './signup/secret-q/secret-q.module';
import { YourSpaceModule } from './signup/yourspace/yourspace.module';
import { SmartUploadContainerModule } from './smart-upload/container/container.module';
import { ValidationFailedModule } from './smart-upload/doc-validation-fail/doc-validation-failed.module';
import { DocValidationModule } from './smart-upload/doc-validation/doc-validation.module';
import { FileListModule } from './smart-upload/file-list/file-list.module';
import { FilePreviewModule } from './smart-upload/file-preview/file-preview.module';
import { UploadBoxModule } from './smart-upload/upload-box/upload-box.module';
import { BonASavoirModule } from './tutos/tutos-faq/bon-a-savoir/bon-a-savoir.module';
import { StickerModule } from './tutos/tutos-faq/sticker/sticker.module';
import { TutoStepsModule } from './tutos/tutos-faq/tuto-steps/tuto-steps.module';
import { UploadModule } from './upload/upload.module';

@NgModule({

  imports: [
    CommonModule,
    ReactiveFormsModule,
  ],
  exports: [
    CommonModule,
    ReactiveFormsModule,
    UpteviaLibModule,
    SideBarModule,
    PortefeuilleTabModule,
    HeaderModule,
    FooterModule,
    RubriqueModule,
    ContactSupportModule,
    ContactformModule,
    ProfilTabModule,
    AchatModule,
    PaiementModule,
    ConfirmationModule,
    DisclaimerCookieModule,
    VenteComponetModule,
    NotificationModule,
    VentePaiementModule,
    VenteConfirmationModule,
    IdentificationModule,
    SecretQModule,
    YourSpaceModule,
    UploadModule,
    QuickAccessModule,
    PortefeuilleModule,
    OldAccountModule,
    NewIdentifiantModule,
    ForgotQuestionsModule,
    ForgotSecretQModule,
    ForgotIdentificationModule,
    CguModule,
    OperationComponentModule,
    LoginIdentificationModule,
    WriteIdentifiantModule,
    ShowcontactDataModule,
    ForgotLoginModule,
    BonASavoirModule,
    StickerModule,
    TutoStepsModule,
    UploadBoxModule,
    FileListModule,
    FilePreviewModule,
    DocValidationModule,
    SmartUploadContainerModule,
    ValidationFailedModule,
  ],
  declarations: [
  ],
})
export class ComponentsModule { }
