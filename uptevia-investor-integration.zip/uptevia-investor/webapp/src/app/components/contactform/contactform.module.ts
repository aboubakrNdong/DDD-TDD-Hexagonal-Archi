import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ContactformComponent } from './contactform.component';
import { CalendarModule } from 'primeng/calendar';

@NgModule({
  declarations: [ContactformComponent],
  imports: [CommonModule, UpteviaLibModule,
    FormsModule,
    ReactiveFormsModule,
    CalendarModule],
  exports: [ContactformComponent],
})
export class ContactformModule { }
