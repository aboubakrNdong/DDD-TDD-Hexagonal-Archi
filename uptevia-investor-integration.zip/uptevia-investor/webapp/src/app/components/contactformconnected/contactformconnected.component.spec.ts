import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ContactFormConnectedComponent } from './contactformconnected.component';


describe('ConnectedformComponent', () => {
  let component: ContactFormConnectedComponent;
  let fixture: ComponentFixture<ContactFormConnectedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContactFormConnectedComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ContactFormConnectedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
