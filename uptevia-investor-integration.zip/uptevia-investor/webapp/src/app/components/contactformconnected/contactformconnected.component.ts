import { DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, Renderer2, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Category, SubCategory } from 'src/app/entity/categories';
import { Profil } from 'src/app/entity/profil';
import { UserAccess } from 'src/app/entity/user';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { selectAppState } from 'src/app/store/selectors/app.selector';
import { showModal } from 'src/app/utils/functions';

@Component({
  selector: 'app-contactformconnected',
  templateUrl: './contactformconnected.component.html',
  styleUrls: ['./contactformconnected.component.css']
})
export class ContactFormConnectedComponent {

  formName = 'form'
  categories: Category[] = []; // Data containing categories and subcategories
  selectedCategoryId: number;
  filteredSubCategories: SubCategory[] = [];
  cacheData: any;
  submitted = false;
  maxChars = 5;
  characters: any;
  isCategorySelected: boolean = false;

  @ViewChild("text") text: ElementRef;
  @ViewChild('nameField') nameField!: ElementRef;


  form: FormGroup;
  varPhone: any;

  profil: Profil;

  constructor(private formBuilder: FormBuilder,
    public translate: TranslateService,
    private loginService: LoginService,
    private bffService: BffService,
    private renderer: Renderer2,
    private store: Store,
    private modal: NgbModal,
    private datePipe: DatePipe,
    private Translate: TranslateService,) { }

  ngOnInit(): void {
    this.createEditFormGroup()
    this.getTitulaireInfos();
    this.getCategories();
    this.charactersCounter();
  }

  ngAfterViewInit(): void {
    if (this.text) {
      this.text.nativeElement.addEventListener('input', () => {
        this.charactersCounter();
      })
    }
  }


  getTitulaireInfos() {
    this.store.select(selectAppState).subscribe(data => {
      if (data.profil !== undefined) {
        this.profil = data.profil;

        this.updateForm();

      }
    })
  }


  createEditFormGroup(): void {
    this.form = this.formBuilder.group({
      category: ['', Validators.required],
      subCategory: [null, Validators.required],
      identifiant: '',
      emetteur: '',
      ccn: '',
      firstName: '',
      lastName: '',
      selectphone: '',
      telephone: '',
      email: '',
      pays: '',
      dob: '',
      message: ['', Validators.required],
      acceptTerms: [false, Validators.requiredTrue]
    });
  }

  updateForm() {
    const user: UserAccess = JSON.parse(localStorage.getItem("user") ?? '{}');
    this.form = this.formBuilder.group({
      category: ['', Validators.required],
      subCategory: [null, Validators.required],
      identifiant: user.login,
      emetteur: this.profil?.emetIden,
      ccn: this.profil?.actiIden,
      firstName: this.profil?.prenom,
      lastName: this.profil?.nom,
      selectphone: this.getTelephoneValue().slice(0, 3), //TODO bug
      telephone: this.getTelephoneValue(),
      email: this.profil?.emailPerso !== null ? this.profil?.emailPerso : this.profil?.emailPro,
      pays: this.profil?.adreFiscPaysIden,
      dob: this.datePipe.transform(this.profil?.tituNaisDate, 'dd/MM/yyyy'),
      message: ['', Validators.required],
      acceptTerms: [false, Validators.requiredTrue]
    })
    this.onChangeCategory();

  }

  onChangeCategory() {
    this.isCategorySelected = false;

    this.form.get('category')?.valueChanges.subscribe((selectedCategory: Category) => {
      this.filteredSubCategories = [];
      setTimeout(() => {
        this.isCategorySelected = true;
        this.filteredSubCategories = selectedCategory
          ? selectedCategory.sousCategories : [];
      }, 100)

    })

  }

  getTelephoneValue(): string {
    console.log(this.profil.numMobilePerso);
    if (this.profil.numMobilePerso !== null) {
      return this.profil.numMobilePerso.toString();
    } else if (this.profil.numMobilePro !== null) {
      return this.profil.numMobilePro.toString();
    } else if (this.profil.numFixePerso !== null) {
      return this.profil.numFixePerso.toString();
    } else if (this.profil.numFixePro !== null) {
      this.varPhone = this.profil.numFixePro.toString();
    }
    return ''; //TODO to be cleaned
  }

  

 

  charactersCounter() {
    this.characters = this.text ? this.text.nativeElement.value.length : 0;
  }

  onFormSubmit() {
    let lang: string = localStorage.getItem('lang') ?? 'fr'
    this.submitted = true;
    if (this.form.invalid) {
      this.renderer.selectRootElement(this.nameField.nativeElement).scrollIntoView({ behavior: 'smooth' });
      return;
    }
    const category: Category = this.form.get('category')?.value;
    const translated = this.translate.instant(category?.typoTraductionKey)

    const selectedCategory = translated;
    const selectedSubCategory = this.form.get('subCategory')?.value;
    const identifiant = this.form.get('identifiant')?.value;
    const emetteur = this.form.get('emetteur')?.value;
    const ccn = this.form.get('ccn')?.value;
    const firstName = this.form.get('firstName')?.value;
    const lastName = this.form.get('lastName')?.value;
    const selectphone = this.form.get('selectphone')?.value;
    const telephone = this.form.get('telephone')?.value;
    const email = this.form.get('email')?.value;
    const pays = this.form.get('pays')?.value;
    const dob = this.form.get('dob')?.value;
    const message = this.form.get('message')?.value;
    const acceptTerms = this.form.get('acceptTerms')?.value;

    const data = {
      category: selectedCategory,
      subCategory: selectedSubCategory,
      identifiant: identifiant,
      emetIden: emetteur,
      tituNume: "",
      actiIden: ccn,
      firstName: firstName,
      lastName: lastName,
      selectphone: selectphone,
      telephone: telephone,
      email: email,
      pays: pays,
      dob: dob,
      message: message,
      acceptTerms: acceptTerms,
      lang: lang
    }

    // Send the selected category, the typoTraductionKey and the name and ...
    this.sendDataToServer(data);


  }


  getCategories() {
    const isConnected = this.loginService.isAuthenticated() ? 'O' : 'N';
    //handle cache
    let key = 'categories';
    this.cacheData = sessionStorage.getItem(key);
    if (this.cacheData) {
      this.categories = JSON.parse(this.cacheData);
    }
    else {
      this.bffService.getCategories(isConnected).subscribe(
        (reponse) => {
          if (reponse) {
            this.categories = reponse;
            //Save Data to cache
            sessionStorage.setItem(key, JSON.stringify(reponse))
          } else {
            console.log('reponse from server is null')
          }
        },
        (error) => {
          console.log('can not get categories', error);
        }
      );
    }
  }


  sendDataToServer(data: any) {
    this.bffService.createDemande(data).subscribe(() => {

      showModal('general.warning.alert', ['faq.request.success'], 'general.bouton.fermer', this.modal, 'contact');

      this.submitted = false;

    },
      (error: HttpErrorResponse) => {
        console.log(`Erreur de création de la requete: ${error.message}`);
      }
    );
  }


  
}
