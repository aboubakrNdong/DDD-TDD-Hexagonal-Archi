import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { ContactFormConnectedComponent } from './contactformconnected.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [ContactFormConnectedComponent],
  imports: [CommonModule, UpteviaLibModule, FormsModule,
    ReactiveFormsModule,],
  providers: [DatePipe],
  exports: [ContactFormConnectedComponent],
})
export class ContactformConnectedModule { }
