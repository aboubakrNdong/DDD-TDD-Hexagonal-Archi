import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisclaimercookieComponent } from './disclaimercookie.component';

describe('DisclaimercookieComponent', () => {
  let component: DisclaimercookieComponent;
  let fixture: ComponentFixture<DisclaimercookieComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisclaimercookieComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DisclaimercookieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
