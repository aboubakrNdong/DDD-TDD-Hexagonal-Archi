import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { DisclaimercookieComponent } from './disclaimercookie.component';



@NgModule({
  declarations: [DisclaimercookieComponent],
  imports: [
    CommonModule,UpteviaLibModule,
  ],
  exports:[DisclaimercookieComponent]
})
export class DisclaimerCookieModule { }
