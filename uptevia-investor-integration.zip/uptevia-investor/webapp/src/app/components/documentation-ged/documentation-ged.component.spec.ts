import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentationGedComponent } from './documentation-ged.component';

describe('DocumentationGedComponent', () => {
  let component: DocumentationGedComponent;
  let fixture: ComponentFixture<DocumentationGedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentationGedComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DocumentationGedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
