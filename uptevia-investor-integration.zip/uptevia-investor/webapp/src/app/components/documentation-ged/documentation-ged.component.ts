import { Component, Input } from '@angular/core';
import { File } from 'src/app/entity/file';
import { UserDocs } from 'src/app/entity/ged';
import { BffService } from 'src/app/services/bff.service';
import { StorageService } from 'src/app/services/storage-service';

@Component({
  selector: 'documentation-ged',
  templateUrl: './documentation-ged.component.html',
  styleUrls: ['./documentation-ged.component.css']
})


export class DocumentationGedComponent {

  titulaire: any;
  cacheData: any;
  docsByCateg: any;
  userDocsGed: UserDocs[] = [];
  @Input() category: any = null;
  @Input() data: any ;



  constructor(private bffService: BffService,private   storageService:StorageService
  ) {
  }

  ngOnInit(): void {
    this.titulaire = JSON.parse(this.storageService.getItem("titulaire") ?? '{}');
    this.userDocsGed = this.data;
    console.log('data ', this.data);
    

    this.docsByCateg = this.userDocsGed.find((doc: { categorieDoc: string; }) => doc.categorieDoc === this.category);
  }

  getFilePdf(uuid: string, action: string) {
    this.bffService.downloadDocGed(uuid).subscribe(
      (file: File) => {
        if (file) {

          const docFilename = file.documentFileName + file.documentContentType

          const binaryString = atob(file.documentContent);
          const length = binaryString.length;
          const bytes = new Uint8Array(length);

          for (let i = 0; i < length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }

          const blob = new Blob([bytes], { type: 'application/pdf' });

          // Créer un objet URL à partir du blob
          const pdfUrl = URL.createObjectURL(blob);

          // Créer un lien pour le téléchargement ou l'affichage
          const downloadLink = document.createElement('a');
          downloadLink.href = pdfUrl;
          downloadLink.download = docFilename;
          downloadLink.target = '_blank';

          if (action === 'show') {
            window.open(pdfUrl, '_blank');
          }

          if (action === 'download') {
            // Simuler le clic sur le lien
            const event = new MouseEvent('click');
            downloadLink.dispatchEvent(event);
            URL.revokeObjectURL(pdfUrl);
          }
        }
      },
    );
  }

}
