import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DocumentationGedComponent } from './documentation-ged.component';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    DocumentationGedComponent
  ],
  imports: [
    CommonModule, UpteviaLibModule,
    FormsModule,
    ReactiveFormsModule],
  exports: [DocumentationGedComponent]

})
export class DocumentationGedModule { }
