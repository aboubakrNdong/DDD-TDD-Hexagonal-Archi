import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentationGeneraliteComponent } from './documentation-generalite.component';

describe('DocumentationGeneraliteComponent', () => {
  let component: DocumentationGeneraliteComponent;
  let fixture: ComponentFixture<DocumentationGeneraliteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentationGeneraliteComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DocumentationGeneraliteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
