import { Component } from '@angular/core';
import { TypeDocument } from 'src/app/entity/typeDocument';
import { BffService } from 'src/app/services/bff.service';
import { Buffer } from 'buffer';
import { File } from 'src/app/entity/file';
import { UserDocs } from 'src/app/entity/ged';
import { StorageService } from 'src/app/services/storage-service';


@Component({
  selector: 'documentation-generalite',
  templateUrl: './documentation-generalite.component.html',
  styleUrls: ['./documentation-generalite.component.css']
})
export class DocumentationGeneraliteComponent {

  titulaire: any;
  pdfBlobUrl: string;
  safeUrl: any;
  blobContent: any;
  cacheData: any;
  versionLanguage: any;
  langueDoc: any;
  typeDocument: any;
  userDocsGed: UserDocs[] = [];

  constructor(private bffService: BffService, private storageService: StorageService) { }

  ngOnInit(): void {
    this.titulaire = JSON.parse(this.storageService.getItem("titulaire") ?? '{}');
    this.getTypeDocument();
    this.getUserDocsGed();
  }

  getTypeDocument() {
    //handle cache
    let key = 'typeDocument';
    this.cacheData = sessionStorage.getItem(key);
    if (this.cacheData) {
      this.typeDocument = JSON.parse(this.cacheData);
    }
    else {
      this.bffService.getTypeDocument()
        .subscribe((reponse: Array<TypeDocument>) => {
          if (reponse) {
            this.typeDocument = reponse;
            //Save Data to cache
            sessionStorage.setItem(key, JSON.stringify(reponse))
          } else {
            console.log('reponse from server is null')
          }
        },
        );
    }
  }

  getUserDocsGed() {

    //TODO: Use effects
    this.bffService.getDocsGed()
      .subscribe((reponse: Array<UserDocs>) => {
        if (reponse) {
          this.userDocsGed = reponse;
        } else {
          console.log('Any user Docs from Ged')
          this.userDocsGed = [];
        }
      },
      );

  }



  showOrDownloadPdf(docId: any, docLangue: any, downloadOrNot: any, openInNewTab: any) {
    this.bffService.getFiles(docId, docLangue).subscribe(
      (files: Array<File>) => {
        if (files) {
          const blobContent = files[0].documentContent;
          const byteArray = this.base64ToArrayBuffer(blobContent);
          const blob = new Blob([byteArray], { type: files[0].documentContentType });
          const pdfUrl = URL.createObjectURL(blob);

          if (openInNewTab) {
            window.open(pdfUrl, '_blank');
          }

          if (downloadOrNot) {
            this.downloadFile(blob, 'document.pdf');
          }
        }
      },
    );
  }

  private base64ToArrayBuffer(base64: string): Uint8Array {
    const binaryString = Buffer.from(base64, 'base64').toString('binary')
    const length = binaryString.length;
    const bytes = new Uint8Array(length);

    for (let i = 0; i < length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    return bytes;
  }

  private downloadFile(blob: Blob, filename: string) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(a.href);
  }
}
