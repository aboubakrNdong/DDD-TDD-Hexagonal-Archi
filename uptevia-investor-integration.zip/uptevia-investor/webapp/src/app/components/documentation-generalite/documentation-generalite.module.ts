import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DocumentationGeneraliteComponent } from './documentation-generalite.component';



@NgModule({
  declarations: [
    DocumentationGeneraliteComponent
  ],
  imports: [CommonModule, UpteviaLibModule,
    FormsModule,
    ReactiveFormsModule],
  exports: [DocumentationGeneraliteComponent],
})
export class DocumentationGeneraliteModule { }
