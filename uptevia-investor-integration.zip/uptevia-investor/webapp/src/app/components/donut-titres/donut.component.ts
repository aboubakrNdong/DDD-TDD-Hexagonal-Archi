import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Plan } from 'src/app/entity/plan';
import { TITRES_BACKGROUND_COLORS } from 'src/app/utils/colors.map';
@Component({
  selector: 'app-donut',
  templateUrl: './donut.component.html',
  styleUrls: ['./donut.component.css']
})
export class DonutComponent implements OnInit {
  public colorMap = TITRES_BACKGROUND_COLORS;
  @Input() titres: Plan;
  @Output() titreClick = new EventEmitter<Object>();
  public dounghutData: number[] = [];
  public dounghutColors: string[] = [];
  ngOnInit(): void {
    if (this.titres.details) {
      this.getDounghutData(this.titres.details);
    }
  }
  getDounghutData(data: any[]) {
    data.forEach(element => {
      const natureJuridique = this.colorMap.find((cat: { title: string; color: string; }) => cat.title === element.natureJuridique);
      if (natureJuridique) {
        this.dounghutData.push(element.qte);
        this.dounghutColors.push(natureJuridique.color);
      }
    });

  }

  public chartClicked(e: any): void {
    const index = e.index;
    const selectedTitre = this.titres.details[index];
    const details = {
      index,
      selectedTitre
    }
    this.titreClick.emit(details)
  }


}
