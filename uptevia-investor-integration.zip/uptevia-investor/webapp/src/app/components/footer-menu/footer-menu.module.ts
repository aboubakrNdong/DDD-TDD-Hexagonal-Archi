import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FooterMenuComponent } from './footer-menu.component';
import { UpteviaLibModule } from '../uptevia-lib.module';



@NgModule({
  declarations: [FooterMenuComponent],
  imports: [
    CommonModule, UpteviaLibModule
  ],
  exports: [FooterMenuComponent]
})
export class FooterMenuModule { }
