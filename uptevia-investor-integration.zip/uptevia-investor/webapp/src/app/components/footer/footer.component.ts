import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Lien } from 'src/app/entity/lien';
import { Modules } from 'src/app/entity/module';
import { DASHBOARD_MENU } from 'src/app/utils/const-vars';

import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css'],
})
export class FooterComponent implements OnInit {
  public dashboard = DASHBOARD_MENU;
  @Input() user: any = null;

  logoUptevia = 'assets/images/logo-uptevia.svg';
  isConnected = false;

  //For fixed bottom menu
  liens: Lien[] = [
    {
      textToClick: 'footer.item.cgu',
      target: '_blank',
      url: 'https://www.uptevia.com/legal/mentions-legales/',
    },
    {
      textToClick: 'footer.item.cgu',
      target: '_blank',
      url: 'https://www.uptevia.com/legal/mentions-legales/',
    },
    {
      textToClick: 'footer.item.securite',
      target: '_blank',
      url: 'https://www.uptevia.com/wp-content/uploads/2023/12/Securite-Uptevia_FR.pdf',
    },
    {
      textToClick: 'footer.item.dataProtect',
      target: '_blank',
      url: 'https://www.uptevia.com/legal/notice-protection-des-donnees/',
    },
    {
      textToClick: 'footer.item.accessibilite',
      target: '_blank',
      url: 'https://www.uptevia.com/legal/declaration-accessibilite/',
    },

    {
      textToClick: 'footer.item.conformite',
      target: '_blank',
      url: 'https://www.uptevia.com/legal/conformite/',
    },
  ];


  @Input() menusBottom: Modules[] | null = [];


  constructor(
    public translate: TranslateService,
    public loginService: LoginService
  ) { }
  ngOnInit(): void {
    this.isConnected = this.loginService.isAuthenticated();
  }

}
