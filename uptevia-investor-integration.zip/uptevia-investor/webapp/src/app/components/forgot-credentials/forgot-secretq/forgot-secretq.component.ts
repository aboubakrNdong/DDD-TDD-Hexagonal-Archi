import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable, Subject, distinctUntilChanged, map, takeUntil } from 'rxjs';
import { FetchSecretQuestions } from 'src/app/entity/fetchsecret-questions';
import { SecretQuestions } from 'src/app/entity/secret-questions';
import { UserAccess } from 'src/app/entity/user';
import { UserAccessPls } from 'src/app/entity/userAccessPls';
import { BffService } from 'src/app/services/bff.service';
import { MessageService } from 'src/app/services/message.service';
import { fetchSecretQuestions, setAncienPlsSuccess, setIsForgot } from 'src/app/store/actions/app.action';
import { selectAppState } from 'src/app/store/selectors/app.selector';



@Component({
  selector: 'app-forgot-secretq',
  templateUrl: './forgot-secretq.component.html',
  styleUrls: ['./forgot-secretq.component.css']
})
export class ForgotSecretQComponent implements OnInit {
  formName = 'forgotsecretq';
  forgotsecretq: FormGroup;
  selectedNames1: string[] = [];
  selectedNames2: string[] = [];
  secretQuestions: any[];
  submitted = false;
  hide: boolean = true;

  @Input() buttonChoice: any = null;

  ngDestroyed$ = new Subject<void>();

  @Output() onClick = new EventEmitter<any>()

  @Output() event = new EventEmitter<string>()


  cacheData: any;
  updateSuccess: boolean;
  messages: string[] = [];
  formatUsername: any;
  formatPassword: any;
  user: UserAccess;
  loginError: boolean = false;
  storeUsername: any;
  storePassword: any;
  userDataStore?: UserAccess;

  secretquestions$: Observable<FetchSecretQuestions[]>;


  switchChoice: any;
  storeEmail: any;
  storeIsForgot: any;
  storeIsEdit: any;

  idQuestion1: any;
  idQuestion2: any;

  editVialink: boolean = true;
  vialinkUser: UserAccessPls;

  constructor(private formBuilder: FormBuilder,
    private store: Store,
    private bffService: BffService,
    private messageService: MessageService,

  ) { }
  ngOnInit(): void {
    this.retrieveSignUpDataFromStore();
    this.createForm();
    this.getSecret();
  }

  private retrieveSignUpDataFromStore() {
    this.store
      .select(selectAppState)
      .pipe(
        takeUntil(this.ngDestroyed$),
        distinctUntilChanged()
      )
      .subscribe((data) => {
        this.storeUsername = data.username;
        this.storeEmail = data.email;
        this.storeIsForgot = data.isForgot;
        this.storeIsEdit = data.isEdit;
        if (data.user) {
          this.vialinkUser = {
            loginUpi: data.user.login,
            actiIden: data.profil.actiIden,
            emetIden: data.profil.emetIden,
            tituNume: 1,//TODO to be verified dans api /api/v1/data.profil
            email: data.profil.emailPerso,
            numMobile: data.profil.numMobilePerso
          }
        }
      });
  }

  onSelectChange(questionKey: string, controlName: string) {
    this.secretquestions$
      .pipe(
        map((questions: FetchSecretQuestions[]) => questions.find(question => question.questionKey === questionKey))
      )
      .subscribe((selectedQuestion: FetchSecretQuestions | undefined) => {
        if (selectedQuestion) {
          this.handleSelectedQuestion(selectedQuestion, controlName);
        }
      });
  }

  private handleSelectedQuestion(selectedQuestion: FetchSecretQuestions, controlName: string) {
    if (controlName === 'questionOneList') {
      this.idQuestion1 = selectedQuestion.idQuestion;
    } else if (controlName === 'questionTwoList') {
      this.idQuestion2 = selectedQuestion.idQuestion;
    }
    this.forgotsecretq.get(controlName)?.setValue(selectedQuestion.questionKey);
  }

  createForm() {
    this.forgotsecretq = this.formBuilder.group({
      questionOneList: ['', Validators.required],
      responseOne: ['', [Validators.required, Validators.minLength(3)]],
      questionTwoList: ['', Validators.required],
      responseTwo: ['', [Validators.required, Validators.minLength(3)]],
    });
  }

  getSecret() {
    this.store.dispatch(fetchSecretQuestions());
    this.secretquestions$ = this.store.select((state: any) => state.form.questions);
  }

  onForgotQuestion() {
    this.store.dispatch(setIsForgot({ isForgot: true }));
    //In case user can't answer questions
    //navigate to edit data with Vialink
    //default user Object used is ancienPls
    if (this.vialinkUser) {
      this.store.dispatch(setAncienPlsSuccess({ ancienPls: this.vialinkUser }));

    }
    this.event.emit("edit_data");
  }

  onFormSubmit() {
    this.submitted = true;
    if (this.forgotsecretq.invalid) {
      return;
    }

    this.messageService.clear();

    const checkSecret: SecretQuestions = {
      login: this.storeUsername,
      firstQuestion: this.idQuestion1,
      firstAnswer: this.forgotsecretq.value.responseOne,
      secondQuestion: this.idQuestion2,
      secondAnswer: this.forgotsecretq.value.responseTwo,
      buttonChoice: this.buttonChoice,
    };

    this.bffService.checkQuestionAnswer(checkSecret).subscribe((response) => {
      if (response) {
        this.updateSuccess = true;
        //edit data without Vialink
        this.store.dispatch(setIsForgot({ isForgot: false }));
        console.log("rseponse quest sec- ", response);
        this.onClick.emit();

      } else {

        this.messages = this.messageService.messages;
      }
    });

  }




  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }
}
