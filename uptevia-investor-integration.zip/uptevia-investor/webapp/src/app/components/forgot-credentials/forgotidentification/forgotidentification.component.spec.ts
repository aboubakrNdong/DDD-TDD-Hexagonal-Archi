import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotidentificationComponent } from './forgotidentification.component';

describe('ForgotidentificationComponent', () => {
  let component: ForgotidentificationComponent;
  let fixture: ComponentFixture<ForgotidentificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForgotidentificationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ForgotidentificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
