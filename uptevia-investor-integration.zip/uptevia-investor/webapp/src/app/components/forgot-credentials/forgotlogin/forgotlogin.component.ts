import { DatePipe, Location } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { ReCaptchaV3Service } from 'ngx-captcha';
import { Subject, Subscription, debounceTime } from 'rxjs';
import { ReCAPTCHA } from 'src/app/entity/captcha-v3';
import { CheckIdentifiant } from 'src/app/entity/checkIdentifiant';
import { UserData } from 'src/app/entity/user-data';
import { UserAccessPls } from 'src/app/entity/userAccessPls';
import { OnboardingSteps } from 'src/app/entity/vialink/onboarding-steps';
import { BffService } from 'src/app/services/bff.service';
import { ExternalsService } from 'src/app/services/externals.service';
import { MessageService } from 'src/app/services/message.service';
import { StorageService } from 'src/app/services/storage-service';
import { setAncienPlsSuccess, setProfile, setUserData } from 'src/app/store/actions/app.action';
import { LIST_EMETTEUR } from 'src/app/utils/const-vars';
import { dateOfBithValidator, getFormValidationErrors, noWitespaceValidator, showModal } from 'src/app/utils/functions';
import { environment } from 'src/environments/environment';



@Component({
  selector: 'app-forgotlogin',
  templateUrl: './forgotlogin.component.html',
  styleUrls: ['./forgotlogin.component.css'],
  providers: [DatePipe]
})
export class ForgotloginComponent {

  formName = 'forgotidentification';
  forgotidentification: FormGroup;
  submitted = false;
  updateSuccess = false;
  @Output() onClick = new EventEmitter<any>()
  @Input() buttonChoice: any = null;
  firstCnxLogin: string;
  messages: string[] = [];
  ngDestroyed$ = new Subject<void>();
  storeUsername: any;
  isForgot = false;
  profile: any;
  numPhone = "";
  emailUser = "";
  numberCode: any;
  emet_list = LIST_EMETTEUR;
  clickSubject = new Subject<void>();
  clickSubscription = new Subscription();

  constructor(
    public translate: TranslateService,
    private formBuilder: FormBuilder,
    private messageService: MessageService,
    private bffService: BffService,
    private modal: NgbModal,
    private store: Store,
    private location: Location,
    private router: Router,
    private storageService: StorageService,
    private reCaptchaV3Service: ReCaptchaV3Service,
    private externalsService: ExternalsService,
    private datePipe: DatePipe,
  ) { }

  ngOnInit(): void {
    this.createIdentificationForm();
    this.getNavigationExtras();
    this.debounceSubmit()
  }

  //waiting 400ms before click submit again
  debounceSubmit() {
    this.clickSubscription = this.clickSubject.pipe(
      debounceTime(400))
      .subscribe(() => {
        this.submitForm();
      })

  }

  createIdentificationForm() {
    this.forgotidentification = this.formBuilder.group({
      nomFamille: ['', Validators.required, noWitespaceValidator(),],
      prenom: ['', Validators.required, noWitespaceValidator()],
      dateNaissance: ['', Validators.required, dateOfBithValidator()],
      actiIden: ['', Validators.required, noWitespaceValidator()],
      emetIden: ['', Validators.required],
    });
  }
  public onFormSubmit() {
    this.clickSubject.next();
  }
  private submitForm() {
    this.submitted = true;
    this.messageService.clear();
    this.messages = [];
    //user for logs 

    if (this.forgotidentification.invalid) {
      getFormValidationErrors(this.forgotidentification);

      return;
    }

    this.reCaptchaV3Service.execute(environment.siteKeyCaptchaV3, 'OldAccount', (token) => {
      if (token) {
        this.verifyRecaptcha(token, 'v3');
      } else {
        console.error('Échec de recupération du Token');
      }
    }, {
      useGlobalDomain: false
    });

  }

  verifyRecaptcha(token: string, version: string): void {
    this.externalsService.verifyRecaptcha(token, version).subscribe(
      (response: ReCAPTCHA) => {
        if (response?.success) {
          // Le reCAPTCHA est valide, utilisez le score  
          this.verifyData();
        }
        else {
          showModal('general.warning.error', ['captcha.v3.error'], 'general.bouton.fermer', this.modal, 'login');
        }
      }
    );

  }

  onSelectDate(date: Date): any {
    return this.datePipe.transform(date, 'yyyy-MM-dd')
  }


  private verifyData() {
    let verifyDataIdentifiant: CheckIdentifiant = {} as CheckIdentifiant;

    verifyDataIdentifiant.p_acti_Iden = this.forgotidentification.value.actiIden;
    verifyDataIdentifiant.p_emet_Iden = this.extractActiIden(this.forgotidentification.value.emetIden);
    verifyDataIdentifiant.p_nom = this.forgotidentification.value.nomFamille;
    verifyDataIdentifiant.p_prenom = this.forgotidentification.value.prenom;
    verifyDataIdentifiant.p_date_nais = this.onSelectDate(this.forgotidentification.value.dateNaissance);

    this.bffService.verifyIdentifiant(verifyDataIdentifiant).subscribe(
      (response) => {
        if (response) {
          this.updateSuccess = true;
          this.storeUsername = response;
          this.storageService.setItem('controlData', JSON.stringify(response));
          this.store.dispatch(setUserData({ userData: response }))
          if (this.firstCnxLogin == response.login && this.buttonChoice === 'firstconnexion') {
            this.onBoardingStatus(response, response.onBoardingStatus);
          } else if (this.buttonChoice === 'forgotidentifiant') {
            this.setTitulaires(response);
          }
          else {
            showModal('general.warning.alert', ['form.field.validator.submit'], 'general.bouton.fermer', this.modal);
          }

        } else {
          showModal('general.warning.alert', ['form.field.validator.submit'], 'general.bouton.fermer', this.modal);

        }
      },
    )

  }

  onBoardingStatus(userData: UserData, status?: OnboardingSteps) {
    let keyTrad = 'onboarding.error.nextStep.' + status;
    //Controles onboarding
    console.log(status === OnboardingSteps.OK);
    if (status === OnboardingSteps.OK) {
      //get user infor and update store 
      this.setTitulaires(userData)
    }

    else if (status === OnboardingSteps.ONBOARDING_STEP_QUESTION) {
      showModal('general.warning.alert', [keyTrad], 'general.bouton.fermer', this.modal, 'login');
    } else {
      showModal('general.warning.alert', [keyTrad], 'general.bouton.fermer', this.modal);
    }
  }




  setTitulaires(userData: UserData) {
    const user: UserAccessPls = {
      loginUpi: userData.login,
      email: userData.email,
      numMobile: userData.numTel
    }
    this.store.dispatch(setProfile({ profil: this.profile, username: userData.login }));
    this.store.dispatch(setAncienPlsSuccess({ ancienPls: user }));
    if (this.buttonChoice === 'forgotidentifiant') {
      //set for forgot login parcours

      let lang: string = localStorage.getItem('lang') ?? 'fr'

      this.bffService.sendEmailWithToken(user.loginUpi, this.buttonChoice, lang).subscribe(res => {
        if (res) {
          console.log('set user Pls', user);

        }
      })
    }
    this.onClick.emit()
  }



  goToContact() {
    this.router.navigate([`contact-us/form-call`]);
  }

  getNavigationExtras() {

    const state: any = this.location.getState();
    if (state?.login) {
      this.firstCnxLogin = state.login.trim()

    }



  }

  extractActiIden(actiIden: string): string {
    let part = actiIden.split(' ');
    return part[0]

  }


  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
    this.clickSubscription.unsubscribe();
  }
}
