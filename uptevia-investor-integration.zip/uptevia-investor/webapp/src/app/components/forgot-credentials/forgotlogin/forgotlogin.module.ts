import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CalendarModule } from 'primeng/calendar';
import { AppCalendarModule } from 'src/app/components/calendar/calendar.module';
import { DirectiveModule } from 'src/app/directives/directives.modules';
import { UploadModule } from '../../upload/upload.module';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { ForgotloginComponent } from './forgotlogin.component';
import { UploadBoxModule } from '../../smart-upload/upload-box/upload-box.module';



@NgModule({
  declarations: [ForgotloginComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    UpteviaLibModule,
    AppCalendarModule,
    DirectiveModule,
    UploadModule,
    CalendarModule, 
  ],
  exports: [ForgotloginComponent],
  bootstrap: [ForgotloginComponent]
})
export class ForgotLoginModule { }
