import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotquestionsComponent } from './forgotquestions.component';

describe('ForgotquestionsComponent', () => {
  let component: ForgotquestionsComponent;
  let fixture: ComponentFixture<ForgotquestionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ForgotquestionsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ForgotquestionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
