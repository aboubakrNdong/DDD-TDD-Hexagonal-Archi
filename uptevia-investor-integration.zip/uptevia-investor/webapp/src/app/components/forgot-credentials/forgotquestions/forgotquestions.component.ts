import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Store} from '@ngrx/store';
import { setIsForgot } from 'src/app/store/actions/app.action';


@Component({
  selector: 'app-forgotquestions',
  templateUrl: './forgotquestions.component.html',
  styleUrls: ['./forgotquestions.component.css']
})
export class ForgotquestionsComponent {

  @Output() onClick = new EventEmitter<any>()


  @Input() buttonChoice: any = null;

  constructor( private store: Store,
    ){}

  onFormSubmit() {
    // dispatch isForgot to store
    this.store.dispatch(setIsForgot({isForgot: true}))

    this.onClick.emit();
  }

}
