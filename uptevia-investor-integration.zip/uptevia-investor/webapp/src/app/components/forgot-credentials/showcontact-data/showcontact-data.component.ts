import { Component, EventEmitter, Input, Output } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Subject, takeUntil } from 'rxjs';
import { Profil } from 'src/app/entity/profil';
import { Titulaire } from 'src/app/entity/titulaire';
import { UserData } from 'src/app/entity/user-data';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { MessageService } from 'src/app/services/message.service';
import { setIsEdit, setIsForgot } from 'src/app/store/actions/app.action';
import { selectAppState } from 'src/app/store/selectors/app.selector';
import { hideEmail, hideTel, showModal } from 'src/app/utils/functions';


@Component({
  selector: 'app-showcontact-data',
  templateUrl: './showcontact-data.component.html',
  styleUrls: ['./showcontact-data.component.css']
})
export class ShowcontactDataComponent {
  formName = 'identification';
  identification: FormGroup;
  submitted = false;
  updateSuccess = false;

  @Output() onClick = new EventEmitter<any>()

  @Output() event = new EventEmitter<string>()
  @Input() buttonChoice: any = null;
  messages: string[] = [];
  ngDestroyed$ = new Subject<void>();
  numberCode: any;
  titulaire: Profil;
  editVialink: boolean = true;

  editData: boolean = true;
  profile: Profil;
  isInWhitelistS: boolean = true;
  hiddenPhone: any = '';
  hiddenMail: any = '';
  storeIsForgot: any;
  storeIsEdit: any;


  showId = false;
  userData: UserData

  constructor(
    public translate: TranslateService,
    private formBuilder: FormBuilder,
    private messageService: MessageService,
    private bffService: BffService,
    private modal: NgbModal,
    private store: Store,
    private loginService: LoginService
  ) { }

  ngOnInit(): void {
    this.initForm();
    this.retrieveSignUpDataFromStore();
    this.getParamNumberCode();

    if (this.buttonChoice == "forgotpassword") {
      this.showId = true;
    }

    console.log("le button" + this.buttonChoice);

  }

  initForm() {
    this.identification = this.formBuilder.group({
      username: [this.userData?.login, [Validators.required, Validators.minLength(8)]],
      indicator: ['+33', Validators.required],
      telephone: ['', [Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(3), Validators.maxLength(20)], this.phoneprefixValidator()],
      email: ['', [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],

    });
  }

  private phoneprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const telephone = this.identification.get("telephone")?.value;
      const indicator = this.identification.get("indicator")?.value;
      return new Promise((resolve, reject) => {
        if (telephone && !telephone.startsWith('06') && !telephone.startsWith('07')
          && indicator === '+33') {
          resolve({ invalidPhoneNumber: true });
        } else {
          resolve(null);
        }
      });
    }
  }

  updateForm() {
    const phone = '0' + this.userData.numTel.substring(3, this.userData.numTel.length);
    this.identification.controls['indicator'].setValue(this.userData.numTel.substring(0, 3));
    this.identification.controls['telephone'].setValue(phone);
    this.identification.controls['email'].setValue(this.userData.email);
    this.identification.controls['username'].setValue(this.userData?.login);
    this.hiddenPhone = hideTel(phone);
    this.hiddenMail = hideEmail(this.userData.email)
  }


 

  private retrieveSignUpDataFromStore() {
    this.store
      .select(selectAppState)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        console.log('data store ', data);
        this.storeIsForgot = data.isForgot;
        this.storeIsEdit = data.isEdit;
        this.userData = data.userData;
        this.updateForm();

      });


  }


  /**
  * Vialink upload check if mail and number not null
  */
  onclickUpload() {
    this.submitted = true;
  }
  /**
   * on vialink score is valid >90%
   */

  onSuccess(event: boolean) {
    // event ==true=> score Vialink >90%
    // event = false ==>score Vialink < 90%
    if (event) {
      this.sendMailtoConfirm();
    }

  }

  editContactData() {
    this.store.dispatch(setIsEdit({ isEdit: true }))
    console.log("buttonChoice", this.buttonChoice);

    if (this.buttonChoice == "forgotidentifiant") {
      this.store.dispatch(setIsForgot({ isForgot: true }));
      this.event.emit("forgotSecretq");
    } else {
      this.onClick.emit();

    }
  }


  onFormSubmit() {
    this.submitted = true;
    this.messageService.clear();
    this.store.dispatch(setIsEdit({ isEdit: false }))

    if (this.identification.invalid) {
      console.log("invalid", this.identification.valid);
      return;
    }

    if (this.buttonChoice == "forgotidentifiant") {
      this.sendMailtoConfirm();
      return;
    }

    this.sendMailtoConfirm();
    this.event.emit("yourspace");

  }

  sendMailtoConfirm() {

    let lang: string = localStorage.getItem('lang') ?? 'fr'

    this.bffService.sendEmailWithToken(this.userData.login, this.buttonChoice, lang)
      .subscribe((response) => {
        if (response) {
          console.log("sendEmailWithToken");

          this.onClick.emit()
        }
        else {
          this.messages = this.messageService.messages;
          showModal('general.warning.alert', ['form.field.validator.submit'], 'general.bouton.fermer', this.modal);
        }
      })
  }
  getParamNumberCode() {
    const paramName = "TEL_INDICATIF_AUTORISE";
    const isConnected = this.loginService.isAuthenticated() ? this.profile.emetIden : 0;
    //handle cache
    let key = 'numberCode';
    this.bffService.getParametreSite(isConnected, paramName).subscribe(
      (reponse) => {
        this.numberCode = reponse;
        //Save Data to cache
        sessionStorage.setItem(key, JSON.stringify(reponse))
      })
  }

  onChangeIndic(event: any) {
    if (event.target.value) {
      this.identification.get("telephone")?.setValue("");
    }
  }


  onSendEmail() {
    this.sendMailtoConfirm();
    console.log("on envoi l'email");
    this.event.emit("yourspace");
  }


  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }
}