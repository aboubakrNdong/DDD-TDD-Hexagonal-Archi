import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WriteidentifiantComponent } from './writeidentifiant.component';

describe('WriteidentifiantComponent', () => {
  let component: WriteidentifiantComponent;
  let fixture: ComponentFixture<WriteidentifiantComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WriteidentifiantComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WriteidentifiantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
