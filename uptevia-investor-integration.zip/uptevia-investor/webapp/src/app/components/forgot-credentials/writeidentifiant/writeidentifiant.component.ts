import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { BffService } from 'src/app/services/bff.service';

@Component({
  selector: 'app-writeidentifiant',
  templateUrl: './writeidentifiant.component.html',
  styleUrls: ['./writeidentifiant.component.css']
})
export class WriteidentifiantComponent {

  writeidentifiant: FormGroup;

  messages: string[] = [];

  submitted = false;
  updateSuccess = false;
  login: any;
  @Output() onClick = new EventEmitter<any>();
  @Output() event = new EventEmitter<string>();
  @Input() buttonChoice: any = null;

  isForgot: boolean = true;
  profile: any;
  numPhone = "";
  emailUser = "";
  numberCode: any;

  constructor(
    public translate: TranslateService,
    private formBuilder: FormBuilder,
    private router: Router,
    private bffService: BffService,
  ) { }

  ngOnInit(): void {
    this.initForm();

  }


  initForm() {
    this.writeidentifiant = this.formBuilder.group({
      username: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(10)]],
    });
  }




  onFormSubmit() {
    this.submitted = true;
    this.login = this.writeidentifiant.get("username")?.value

    if (this.writeidentifiant.invalid) {
      console.log("invalid");
      return;
    }
    this.setMailtoConfirm();
  }

  //TODO call should be done in backend
  setMailtoConfirm() {
    this.onClick.emit();

    let lang: string = localStorage.getItem('lang') ?? 'fr'

    this.bffService.sendEmailWithToken(this.login, this.buttonChoice, lang)
      .subscribe((response) => {
        if (response) {

        }
      })
  }
  goToForgotPassword() {

    this.router.navigate(['forgotidentifiant']);
  }
}