import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AppCalendarModule } from 'src/app/components/calendar/calendar.module';
import { DirectiveModule } from 'src/app/directives/directives.modules';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { UploadModule } from '../../upload/upload.module';
import { WriteidentifiantComponent } from './writeidentifiant.component';



@NgModule({
  declarations: [WriteidentifiantComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    UpteviaLibModule,
    AppCalendarModule,
    DirectiveModule,
    UploadModule   
  ],
  exports:[WriteidentifiantComponent],
  bootstrap:[WriteidentifiantComponent]
})
export class WriteIdentifiantModule { }
