import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { NotificationComponent } from './notification.component';



@NgModule({
  declarations: [NotificationComponent],
  imports: [
    CommonModule, UpteviaLibModule
  ],
  exports: [NotificationComponent]
})
export class NotificationModule { }
