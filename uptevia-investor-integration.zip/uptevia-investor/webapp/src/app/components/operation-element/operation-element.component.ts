import { Component, Input, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Lien } from 'src/app/entity/lien';
import { Modules } from 'src/app/entity/module';
import { Operation } from 'src/app/entity/operation';

import { LoginService } from 'src/app/services/login.service';
import { OPERTOINS_LIST_COLORS } from 'src/app/utils/colors.map';

@Component({
  selector: 'app-operation',
  templateUrl: './operation-element.component.html',
  styleUrls: ['./operation-element.component.css'],
})
export class OperationComponent implements OnInit {

  @Input() operation: Operation;

  operationsColors = OPERTOINS_LIST_COLORS;
  constructor() { }

  ngOnInit() {

  }

  get backgroundColor(): (type: any) => string | undefined {
    return (type: string) => {
      const mapping = this.operationsColors.find((cat) => cat.trad === type)
      return mapping?.color
    }
  }

  get operationTrad(): (id: number) => string {
    return (id: number) => {
      let trad = 'operation.suivi.achat';
      switch (id) {
        case 4:
          trad = 'operation.suivi.vente'
          break;

        default:
          trad = 'operation.suivi.achat'
          break;
      }
      return trad;
    }
  }
/**
 * Explication des statuts 

* Exécuté : Votre ordre a bien été exécuté sur le marché dans sa totalité

* Exécuté partiellement :  Votre ordre a été exécuté en partie sur le marché . Une partie reste à exécuter ou tombera à la date d'échéance.

* En attente d'exécution : Votre ordre est sur le marché mais n'a pas pour l'heure été exécuté.

* Aucune exécution : Votre ordre n'a pas été exécuté à la date que vous aviez fixé. Vous pouvez le renouveler.

 */
  get tootlipText(): (key: string) => string {
    return (key: string) => {
      let trad = 'operation.suivi.tooltip.complete';
      if (key === 'operation.histo.statutExecution.4') { trad = 'operation.suivi.tooltip.aucune' }
      if (key === 'operation.histo.statutExecution.2'   ) { trad = 'operation.suivi.tooltip.partielle' }
      if(key === 'operation.histo.statutExecution.1') { trad =  'operation.suivi.tooltip.partiellementComplete'}
      return trad;
    }
  }
  
  get lang() {
    return localStorage.getItem('lang')
  }

}
