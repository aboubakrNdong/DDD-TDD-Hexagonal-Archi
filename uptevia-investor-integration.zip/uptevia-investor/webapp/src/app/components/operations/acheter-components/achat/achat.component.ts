import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Subject, takeUntil } from 'rxjs';
import { CguComponent } from 'src/app/components/cgu/cgu.component';
import { Bareme } from 'src/app/entity/bareme';
import { iFrameParams } from 'src/app/entity/iframe-data';
import { PasCotation } from 'src/app/entity/pas-cotation';
import { Profil } from 'src/app/entity/profil';
import { UserAccess } from 'src/app/entity/user';
import { Valeur } from 'src/app/entity/valeur';
import { ValeurDetail } from 'src/app/entity/valeur-detail';
import { BffService } from 'src/app/services/bff.service';
import { ServerTimeService } from 'src/app/services/server-time.service';
import { StorageService } from 'src/app/services/storage-service';
import { TranslationService } from 'src/app/services/translation.service';
import { setFormData, setIsAchat } from 'src/app/store/actions/app.action';
import { selectFormData } from 'src/app/store/selectors/app.selector';
import { LANG_LIST } from 'src/app/utils/const-vars';
import { checkTimeRange, convertDate, countDecimal, getFrais, getMaxDayMonth, getMinMaxFrais, truncAmount } from 'src/app/utils/functions';
import { LIST_ORDERS, OPERATIONS_ACHAT_SIMULATION_LABEL } from 'src/app/utils/trads.maps';
import { BACKUP_BAREM_PAS_COTATION } from '../../../../utils/const-vars';
@Component({
  selector: 'app-achat',
  templateUrl: './achat.component.html',
  styleUrls: ['./achat.component.css'],
  providers: [DatePipe]
})
export class AchatComponent implements OnInit {
  @Input() valeurs: Valeur[];
  @Input() disabledDates: string[] | undefined;
  @Output() onSubmit = new EventEmitter<any>();
  actionForm: FormGroup;
  date: any;
  selectedValeur: Valeur | undefined;
  listOrdre = LIST_ORDERS;
  isCours: boolean = false;
  tick = 0.01;
  private ngUnsubscribe = new Subject<void>();
  public isWarningTime = false;
  bareme: Bareme;
  amountNet = 0
  constructor(
    private serverTimeService: ServerTimeService,
    private bffService: BffService,
    private store: Store,
    private datepipe: DatePipe,
    private translate: TranslateService,
    private storageService: StorageService,
    private translation: TranslationService,
    private modal: NgbModal) {
  }

  ngOnInit(): void {
    this.initForm();
    this.checkTimeWarnig();
    //si 
    if (this.valeurs.length === 1) {
      this.selectedValeur = this.valeurs[0];
      this.onClickAction(this.selectedValeur)
    }

  }

  countDecimal() {
    return countDecimal(this.tick);
  }

  private initForm() {
    //Store retreive data 
    this.store.select(selectFormData)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe((data) => {
        const selectedValeur: any = data.selectedValeur;
        const form = data.formData;
        if (data.isAchat) {
          this.selectedValeur = selectedValeur;
          this.actionForm = new FormGroup({
            quantity: new FormControl(form.quantity, [Validators.required, Validators.min(1)]),
            modalite: new FormControl(form.modalite, Validators.required),
            dateValidite: new FormControl(form.dateValidite, Validators.required),
            conditionsGen: new FormControl(form.conditionsGen, Validators.requiredTrue)
          });
          this.onSelectModalite(form.modalite, form.cours);
          this.onClickAction(selectedValeur)
        } else {
          this.actionForm = new FormGroup({
            quantity: new FormControl(null, [Validators.required, Validators.min(1)]),
            modalite: new FormControl(null, Validators.required),
            dateValidite: new FormControl(getMaxDayMonth(this.disabledDates), Validators.required),
            conditionsGen: new FormControl(false, Validators.requiredTrue)
          });
        }

      });
  }


  private checkTimeWarnig() {
    this.serverTimeService.serverTime$.subscribe((time) => {
      this.isWarningTime = checkTimeRange(time);
    })
  }


  onSelectModalite(id: number, courrsLimite?: number): void {
    if (id === 1) {
      let value = courrsLimite ? courrsLimite : ''
      this.actionForm.addControl("cours", new FormControl(value, [Validators.required]));
      this.isCours = true;
    } else {
      this.actionForm.removeControl('cours');
      this.isCours = false;
    }

  }


  get showSimulator() {
    const quantity: FormControl = this.actionForm.get('quantity') as FormControl;
    const cours: FormControl = this.actionForm.get('cours') as FormControl;
    if (cours) {
      return quantity.valid && cours.valid;
    }
    return quantity.valid;
  }

  get getTrads() {
    const trads: string[] = this.translation.getTranslation(OPERATIONS_ACHAT_SIMULATION_LABEL)
    return Object.values(trads)
  }
  get lang() {
    return localStorage.getItem('lang')
  }

  get isfrench() {
    return this.lang === 'fr'
  }
  submitForm() {
    if (this.actionForm.valid && this.selectedValeur) {
      const quantity: FormControl = this.actionForm.get('quantity') as FormControl;
      const dateValidite: FormControl = this.actionForm.get('dateValidite') as FormControl;
      const modaliteCtrl: FormControl = this.actionForm.get('modalite') as FormControl;
      const cours: FormControl = this.actionForm.get('cours') as FormControl;

      const recapData = {
        date: this.datepipe.transform(new Date(), 'dd/MM/yyyy, HH:mm:ss'),
        reference: undefined,
        valeur: this.selectedValeur?.valeIden,
        quantity: quantity.value,
        modalite: this.getModalite(modaliteCtrl.value),
        coursLimite: this.getCoursLimite(modaliteCtrl.value),
        dateValidite: this.datepipe.transform(dateValidite.value, 'dd/MM/yyyy')
      }
      const iFrameParams = this.handleiFrameParams(modaliteCtrl.value, recapData);
      const data = {
        recapData, modalite: modaliteCtrl.value,
        coursLimite: cours ? cours.value.replace(',', '.') : null,
        iFrameParams,
        simulationInfo: {
          simulation: this.SimulationList,
          devise: this.selectedValeur.deviseNego
        }
      }
      this.onSubmit.emit(data);
      // dispatch data to store
      this.dispatchData();
    } else {
      this.onSubmit.emit('FORM NOT VALID');
    }
  }



  getModalite(modaliteCtrl: number) {
    console.log("get modalite ", modaliteCtrl);
    let modalite: any = this.listOrdre.find(order => order.orderId === modaliteCtrl);
    return this.translate.instant(modalite?.orderKey)
  }

  private getCoursLimite(modaliteCtrl: number): string | undefined {
    const cours: FormControl = this.actionForm.get('cours') as FormControl;
    let coursLimite;
    if (modaliteCtrl === 1) {
      let coursValue = cours.value.replace(',', '.')

      coursLimite = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' }).format(coursValue);
    }
    return coursLimite;
  }

  onClickAction(valeur: Valeur) {

    this.selectedValeur = valeur; 

    this.bffService.getValeurDetails(this.selectedValeur.valeIden, this.selectedValeur.valeNatu)
      .subscribe((response: ValeurDetail) => {
        let valeurDetail = BACKUP_BAREM_PAS_COTATION;
        if (response?.bareme && response.pasCotation.length > 0) {
          valeurDetail = response;
        }
        this.bareme = valeurDetail.bareme
        const pasCotation: any = valeurDetail.pasCotation.find((pasCotation: PasCotation) => valeur.dernierCours < pasCotation.tranMax && valeur.dernierCours >= pasCotation.tranMin)
        this.tick = pasCotation.eche;
        console.log("echelon", this.tick);

      })
  }

  onEdit() {
    this.selectedValeur = undefined
  }

  get SimulationList(): number[] {
    const quantity: FormControl = this.actionForm.get('quantity') as FormControl;
    const modalite: FormControl = this.actionForm.get('modalite') as FormControl;
    const cours: FormControl = this.actionForm.get('cours') as FormControl;
    let mBrut = 0;
    let values: number[] = [1, 2]
    /* Si modalité saisie = 'cours limite' , [montant estimé brut] = [quantité]  * [cours limite]

      Sinon [montant estimé brut] = [quantité] * [cours actuel] */
    if (modalite.value === 1) {
      let coursValue = cours.value.replace(',', '.')
      coursValue = coursValue.replace(/[^0-9.]/g, '');
      mBrut = quantity.value * coursValue;

    } else if (this.selectedValeur) {
      mBrut = quantity.value * this.selectedValeur?.dernierCours
    }
    if (this.bareme !== undefined) {
      const calculatedFrais = getFrais(mBrut, this.bareme);
      const reelFrais = getMinMaxFrais(calculatedFrais, this.bareme);
      let ttf = 1;
      if (this.selectedValeur) {
        //[ttf] = [montant estimé brut] * [taux TTF]
        ttf = mBrut * this.selectedValeur.tauxTtf;

        let amount = mBrut + ttf + reelFrais;
        this.amountNet = truncAmount(amount)
      }
      mBrut = truncAmount(mBrut)
      values = [mBrut, ttf, reelFrais, this.amountNet];
    }
    return values
  }

  handleiFrameParams(modalite: number, inputs: any): iFrameParams {
    const titulaire: Profil = JSON.parse(this.storageService.getItem("titulaire") ?? '{}');
    const user: UserAccess = JSON.parse(localStorage.getItem("user") ?? '{}');
    const lang = localStorage.getItem('lang') ?? 'fra'
    let data: iFrameParams = {
      module: "ACHAT",
      theme: "UPTEVIA",
      langue: LANG_LIST[lang],
      montant: this.amountNet,
      modalite: modalite,
      coursLimite: inputs.courrsLimite,
      typeValidite: "JOUR",
      dateValidite: convertDate(inputs.dateValidite),
      moisValiditeMax: 1,
      isDirect: true,
      isMontantReel: true,
      quantite: inputs.quantity
    }
    return data
  }
  dispatchData() {
    const formData = this.actionForm.value;
    const selectedValeur = this.selectedValeur;
    const amountNet = this.amountNet;
    this.store.dispatch(setFormData({ formData, selectedValeur, amountNet }))
  }

  openCGU() {
    console.log("open cgu clicked");
    this.modal.open(CguComponent, { size: 'xl' });

  }

  ngOnDestroy() {
    this.store.dispatch(setIsAchat({ isAchat: false }));
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }




}



