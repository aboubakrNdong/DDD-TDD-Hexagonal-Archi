import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { UpteviaLibModule } from '../../../uptevia-lib.module';
import { AchatComponent } from './achat.component';
import { AppCalendarModule } from 'src/app/components/calendar/calendar.module';
import { DirectiveModule } from 'src/app/directives/directives.modules';



@NgModule({
  declarations: [AchatComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    UpteviaLibModule,
    AppCalendarModule,
    DirectiveModule
  ],
  exports:[AchatComponent],
  bootstrap:[AchatComponent]
})
export class AchatModule { }
