import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CalendarModule } from 'primeng/calendar';
import { UpteviaLibModule } from '../../../uptevia-lib.module';
import { CarteBancaireComponent } from './carte-bancaire.component';


@NgModule({
  declarations: [CarteBancaireComponent ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    UpteviaLibModule,
    CalendarModule, 
       
  ],
  exports:[CarteBancaireComponent],
  bootstrap:[CarteBancaireComponent]
})
export class CarteBankModule { }
