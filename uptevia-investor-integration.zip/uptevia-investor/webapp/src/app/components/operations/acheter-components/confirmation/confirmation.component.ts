import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Profil } from 'src/app/entity/profil';
import { StorageService } from 'src/app/services/storage-service';
import { TranslationService } from 'src/app/services/translation.service';
import { OPERATIONS_ACHAT_RECAP_LABEL, OPERATIONS_ACHAT_SIMULATION_LABEL } from 'src/app/utils/trads.maps';

@Component({
  selector: 'app-achat-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.css']
})
export class ConfirmationComponent implements OnInit {
  @Input() recapInfo: any;
  @Input() simulationInfo: any;
  @Input() refDemande: string;
  @Input() modePaiement: number
  date: string;
  time: string;
  profil: Profil;
  showSimulator = false;
  constructor(
    private translate: TranslateService,
    private router: Router,
    private storageService: StorageService,
    private translation: TranslationService) { }
  ngOnInit(): void {
    this.profil = JSON.parse(this.storageService.getItem('titulaire') ?? '');
     
    console.log(this.profil);
    
    this.recapInfo.reference = this.refDemande;
    this.recapInfo.modeReglement = this.getModeReglementTrads();
    this.recapInfo = Object.values(this.recapInfo);

    console.log('recapInfobefore ', this.recapInfo);

    [this.date, this.time] = this.recapInfo[0].split(',');
    console.log('recapInfoafter ', this.recapInfo);


  }

  getModeReglementTrads() {
    let title = 'operation.achat.paiement.virement'
    switch (this.modePaiement) {
      case 6:
        title = this.translate.instant('operation.achat.paiement.prelevement')
        break;
      case 9:
        title = this.translate.instant('operation.achat.paiement.carteBancaire')
        break;

      default:
        title = this.translate.instant('operation.achat.paiement.virement')
        break;
    }
    return title;
  }

  get lang() {
    return localStorage.getItem('lang') || 'fra'
  }
  get getTradsRecap() {
    const listRecapTrads: any = OPERATIONS_ACHAT_RECAP_LABEL;
    listRecapTrads.modeReglement = 'operation.achat.modePaiement'

    const trads: string[] = this.translation.getTranslation(listRecapTrads)
    return Object.values(trads)
  }
  get getTradsSimu() {
    const trads: string[] = this.translation.getTranslation(OPERATIONS_ACHAT_SIMULATION_LABEL)
    return Object.values(trads)
  }


  public goHome() {
    this.router.navigate(['/']);
  }

}
