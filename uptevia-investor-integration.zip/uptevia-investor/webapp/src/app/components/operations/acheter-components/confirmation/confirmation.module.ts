import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DirectiveModule } from 'src/app/directives/directives.modules';
import { UpteviaLibModule } from '../../../uptevia-lib.module';
import { ConfirmationComponent } from './confirmation.component';




@NgModule({
  declarations: [ConfirmationComponent],
  imports: [
    CommonModule,
    FormsModule,
    UpteviaLibModule,
    DirectiveModule
  ],
  exports: [ConfirmationComponent],
  bootstrap: [ConfirmationComponent]
})
export class ConfirmationModule { }
