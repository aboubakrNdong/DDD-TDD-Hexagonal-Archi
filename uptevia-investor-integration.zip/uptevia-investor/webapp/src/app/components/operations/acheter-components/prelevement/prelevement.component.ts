import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Profil } from 'src/app/entity/profil';
import { StorageService } from 'src/app/services/storage-service';
import { hideIBAN } from 'src/app/utils/functions';

@Component({
  selector: 'app-prelevement',
  templateUrl: './prelevement.component.html',
  styleUrls: ['./prelevement.component.css']
})
export class PrelevementComponent implements OnInit {
  @Output() onSubmit = new EventEmitter<any>();
  prelevementForm: FormGroup;
  profil: Profil; 
  eyeIcone = 'bi bi-eye';
  isShowIban: boolean = true;
  constructor(
    private storageService:StorageService,
    private fb: FormBuilder,) {

  }
  ngOnInit(): void {
    this.profil = JSON.parse(this.storageService.getItem('titulaire') ?? '');

    this.initForm();

  }
  private initForm() {
    this.prelevementForm = this.fb.group({
      banque: [this.profil.ribeBankNom],
      titulaire: new FormControl(this.profil.tituBene ),
      iban: [hideIBAN(this.profil?.ribIban)],
      bic: [this.profil.ribeBic],
      numMandat: [this.profil.ribeBic2],
    });
  }
  toggleIban() {
    this.isShowIban = !this.isShowIban
    if (this.isShowIban) {
      this.eyeIcone = 'bi bi-eye';
      this.prelevementForm.get('iban')?.setValue(hideIBAN(this.profil?.ribIban));
    } else {
      this.eyeIcone = 'bi bi-eye-slash';
      this.prelevementForm.get('iban')?.setValue(this.profil?.ribIban);
    }
  }

  
}
