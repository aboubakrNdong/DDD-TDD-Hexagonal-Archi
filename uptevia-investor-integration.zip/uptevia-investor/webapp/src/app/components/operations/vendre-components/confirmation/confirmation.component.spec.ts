import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmationVenteComponent } from './confirmation.component';

describe('ConfirmationVenteComponent', () => {
  let component: ConfirmationVenteComponent;
  let fixture: ComponentFixture<ConfirmationVenteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfirmationVenteComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ConfirmationVenteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
