import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Profil } from 'src/app/entity/profil';
import { RecapVente } from 'src/app/entity/recap-vente';
import { StorageService } from 'src/app/services/storage-service';
import { TranslationService } from 'src/app/services/translation.service';
import { OPERATIONS_ACHAT_SIMULATION_LABEL, OPERATIONS_VENTE_RECAP_LABEL } from 'src/app/utils/trads.maps';

@Component({
  selector: 'app-vente-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.css']
})
export class ConfirmationVenteComponent implements OnInit {
  @Input() recapInfo: RecapVente;
  @Input() refDemande: string;
  date: string;
  time: string;
  profil: Profil;
  recapList = [];
  showSimulator = false;
  estimationInfo: any;

  constructor(
    private router: Router,
    private translate: TranslateService,
    private storageService: StorageService,
    private translationService: TranslationService) { }
  ngOnInit(): void {
    this.profil = JSON.parse(this.storageService.getItem('titulaire') ?? '');

    [this.date, this.time] = this.recapInfo.recapData.date.split(',');
    this.estimationInfo = this.recapInfo.estimationInfo
    console.log("ConfirmationVenteComponent", this.recapInfo);
    this.recapInfo.recapData.reference = this.refDemande;
    this.recapInfo.recapData.modeReglement = this.getModeReglementTrads()
    this.recapList = Object.values(this.recapInfo.recapData);
  }

  getModeReglementTrads() {
    if (this.modeReglement) {
      return this.translate.instant('type.reglementMode.virement')
    } else {
      return this.translate.instant('type.reglementMode.cheque')
    }

  }


  get modeReglement() {
    return this.profil?.tituModeReglement === "VIREMENT";
  }

  get getTrads() {
    const listRecapTrads: any = OPERATIONS_VENTE_RECAP_LABEL;
    listRecapTrads.modeReglement = 'operation.achat.recap.modeReception'
    const trads: string[] = this.translationService.getTranslation(listRecapTrads);
    return Object.values(trads)
  }

  get getTradsSimu() {
    const trads: string[] = this.translationService.getTranslation(OPERATIONS_ACHAT_SIMULATION_LABEL)
    return Object.values(trads)
  }

  get lang() {
    return localStorage.getItem('lang')
  }

  public goHome() {
    this.router.navigate(['/']);
  }

}
