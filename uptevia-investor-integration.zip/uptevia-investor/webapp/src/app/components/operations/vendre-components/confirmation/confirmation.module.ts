import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UpteviaLibModule } from '../../../uptevia-lib.module';
import { ConfirmationVenteComponent } from './confirmation.component';




@NgModule({
  declarations: [ConfirmationVenteComponent],
  imports: [
    CommonModule,
    FormsModule,
    UpteviaLibModule,
  ],
  exports:[ConfirmationVenteComponent],
  bootstrap:[ConfirmationVenteComponent]
})
export class VenteConfirmationModule { }
