import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VentePaiementComponent } from './vente-paiement.component';

describe('VentePaiementComponent', () => {
  let component: VentePaiementComponent;
  let fixture: ComponentFixture<VentePaiementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VentePaiementComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VentePaiementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
