import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { LigneAvoir } from 'src/app/entity/ligne-avoirs';
import { listAvoir } from 'src/app/entity/liste-avoirs';
import { Titulaire } from 'src/app/entity/titulaire';
import { getAvoirsaVendre } from 'src/app/store/actions/app.action';
import { selectLigneAvoir } from 'src/app/store/selectors/app.selector';
import { TITRES_BACKGROUND_COLORS } from 'src/app/utils/colors.map';
@Component({
  selector: 'app-vente-step2',
  templateUrl: './vente-step2.component.html',
  styleUrls: ['./vente-step2.component.css'],
  providers: [DatePipe]
})


export class VenteStep2Component implements OnInit {
  @Input() valeur: any;
  @Input() valeIden: string;
  @Input() count: any;
  @Output() onEdit = new EventEmitter<any>();
  @Output() InputChange = new EventEmitter<any>();
  titres: listAvoir = {};
  ngDestroyed$ = new Subject<void>();

  public colorMap = TITRES_BACKGROUND_COLORS;
  detailsForm: FormGroup;
  constructor(
    private store: Store) { }

  ngOnInit(): void {
    this.detailsForm = new FormGroup({});
    this.getLigneAvoir();
console.log("input valeur" ,this.valeur );

  }

  getLigneAvoir() {
     
    this.store.dispatch(getAvoirsaVendre({valeIden: this.valeIden }))

    this.store.select(selectLigneAvoir)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe(res => {
        if (res.listAvoir) {
          this.titres = res.listAvoir;
          this.initForm()
        }
      })
  }



  initForm() {
    const totalTitres = Object.keys(this.titres);
    console.log("init form step2", this.titres);
    
    for (const titre of totalTitres) {

      //*S'il n' a qu'une unique ligne, la priorité sera préremplie à 1 
      const titreNumber = this.titres[titre].length;

      const initpriority = (titreNumber > 1 || totalTitres.length > 1) ? null : 1
      for (let i = 0; i < titreNumber; i++) {

        const formName = this.titres[titre][i].natureJuridique;
        this.detailsForm.addControl(`priority${formName}_${i}`, new FormControl(initpriority));

        if (this.valeur.type === "2") {
          // 2= vente plusieurs titres
          this.detailsForm.addControl(`${formName}_${i}`, new FormControl(null));

        } else if (this.valeur.type === "3") {
          const nbActionDispo = this.titres[titre][i].nbActionDispo;
          //3= Vente  tous mes titres
          this.detailsForm.addControl(`${formName}_${i}`, new FormControl(nbActionDispo));

          setTimeout(() => { this.onChnageQuantity(); }, 700)
        }  
      }
    }

  }
  get controlName(): (name: string, index: number) => string {
    return (name, i): string => `${name}_${i}`
  }

  get borderColor(): (type: any) => string | undefined {
    return (type: string) => {
      const mapping = this.colorMap.find((cat: { title: string; color: string; }) => cat.title === type)
      return mapping?.color
    }
  }
  /**
   * * NOMINATIF PUR      titres.nominatifs   => pas de date d’opération
* TITRES ISSUS AGA      titres.paga   =>date attribution
*TITRES ISSUS DE SO                    => date de levée
* TITRES ISSUS DE BSPCE            => date de levée
* TITRES ISSUS DE PEE                  => date de souscription

   */
  get TypeDateOperation(): (key: string) => any {
    return (key: string) => {
      let typeOp;
      switch (key) {
        case 'titres.paga':
          typeOp = 'operation.vente.tab.dateAttribution' //date attribution
          break;
        //ISSUS AGA ISSUS BSPCE
        case 'titres.plans.droits':
        case 'titres.bspce':
          typeOp = 'operation.vente.tab.dateLevee'; //date levee
          break;
        case 'titres.pee':
          typeOp = 'operation.vente.tab.dateSouscription' //date attribution
          break;
        default:
          break;
      }
      return typeOp;
    }
  }
  get dateOperation(): (key: string, item: LigneAvoir) => any {
    return (key: string, item: LigneAvoir) => {
      let date;
      switch (key) {
        case 'titres.paga':
          date = item.dateDetentionBrut //date attribution
          break;
        //ISSUS AGA ISSUS BSPCE
        case 'titres.plans.droits':
        case 'titres.bspce':
          date = item.dateLevee; //date levee
          break;
        case 'titres.pee':
          date = item.dateSouscription; //date attribution
          break;
        default:
          break;
      }
      return date;
    }
  }
  get sumQuantity(): number {
    let sum = 0
    for (const titre of Object.keys(this.titres)) {
      for (let i = 0; i < this.titres[titre].length; i++) {
        const formName = this.titres[titre][i].natureJuridique + '_' + i;
        const controlValue = this.detailsForm.controls[formName]?.value;
        if (!isNaN(controlValue)) {
          sum += controlValue;
          this.count = sum
        }
      }
    }
    return sum;

  }

  onChnageQuantity() {
    let sum = 0;
    let titresList: any[] = []
    for (const titre of Object.keys(this.titres)) {
      for (let i = 0; i < this.titres[titre].length; i++) {
        const formNameQuantity = this.titres[titre][i].natureJuridique + '_' + i;
        const formNamePriority = 'priority' + this.titres[titre][i].natureJuridique + '_' + i;

        const formControlPriority = this.detailsForm.controls[formNamePriority].value;
        const ControlQuatity = this.detailsForm.controls[formNameQuantity].value;
        if (!isNaN(ControlQuatity)) {
          sum += ControlQuatity;
          this.count = sum
          if (ControlQuatity > 0) {
            const updateTitles = { ...this.titres[titre][i], nbActionAVendre: ControlQuatity, priorite: formControlPriority }
            titresList.push(updateTitles);
          }

        }
      }
    }
    this.InputChange.emit({ total: sum, list: titresList })
  }



  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }

}