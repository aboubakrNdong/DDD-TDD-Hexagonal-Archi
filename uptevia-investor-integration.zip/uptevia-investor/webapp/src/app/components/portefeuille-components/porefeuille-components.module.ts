import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { TitresDetailComponent } from './titres-detail/titres-detail.component';
import { TitresValeurComponent } from './titres-valeur/titres-valeur.component';
import { TitresGlobalComponent } from './titres/titres.component';



@NgModule({
  declarations: [TitresGlobalComponent, TitresDetailComponent, TitresValeurComponent],
  imports: [
    CommonModule,UpteviaLibModule
  ],
  exports:[TitresGlobalComponent, TitresDetailComponent, TitresValeurComponent]
})
export class PortefeuilleModule { }
