import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TitresDetailComponent } from './titres-detail.component';

describe('TitresDetailComponent', () => {
  let component: TitresDetailComponent;
  let fixture: ComponentFixture<TitresDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TitresDetailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TitresDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
