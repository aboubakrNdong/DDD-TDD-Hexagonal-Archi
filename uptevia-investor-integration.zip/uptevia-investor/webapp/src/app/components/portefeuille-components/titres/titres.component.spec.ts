import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TitresGlobalComponent } from './titres.component';

describe('TitresGlobalComponent', () => {
  let component: TitresGlobalComponent;
  let fixture: ComponentFixture<TitresGlobalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TitresGlobalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TitresGlobalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
