import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Plan } from 'src/app/entity/plan';
import { Positions } from 'src/app/entity/positions';
import { BffService } from 'src/app/services/bff.service';
import { StorageService } from 'src/app/services/storage-service';
import { TITRES_BACKGROUND_COLORS } from 'src/app/utils/colors.map';
@Component({
  selector: 'app-portefeuille',
  templateUrl: './portefeuille.component.html',
  styleUrls: ['./portefeuille.component.css']
})
export class PortefeuilleTabComponent implements OnInit {
  devise: string = 'EUR';
  public colorMap = TITRES_BACKGROUND_COLORS;
  natureJuridique: string = '';

  public titres: Plan;
  labelColor: string = ''
  public titresQteTotale: number;
  public titresValorisationTotale: number;
  public libelleTitres: string = '';

  public libelleDroits: string;
  cacheData: any;

  constructor(
    private router: Router,
    private storageService: StorageService,
    public bffService: BffService,
    public translate: TranslateService) { }
  ngOnInit() {
    this.getPortefeuille();
  }


  handleTitreClick(event: any) {
    this.titresQteTotale = this.titres.details[event.index].qte;
    this.titresValorisationTotale = this.titres.details[event.index].valorisation;
    this.libelleTitres = this.titres.details[event.index].codeLibelle;
    this.natureJuridique = this.titres.details[event.index].natureJuridique

  }

  getPortefeuille() {
    //handle cache
    let key = 'positions';
    this.cacheData = sessionStorage.getItem(key);
    if (this.cacheData) {
      this.parseData(JSON.parse(this.cacheData));
    }
    else {

      this.bffService.getPositions().subscribe((result) => {

        this.parseData(result);
        sessionStorage.setItem(key, JSON.stringify(result));
      })
    }

  }
  get lang() {
    const lang = localStorage.getItem('lang')
    return lang
  }

  parseData(response: Positions) {
    if (response?.titres) {
      this.titres = response.titres;
      console.log("this.titres", this.titres);

      this.devise = this.titres.devise;
    }
    this.initData();


  }

  async initData() {
    console.log("init data");

    this.titresQteTotale = this.titres?.qteTotale;
    this.titresValorisationTotale = this.titres?.valorisationTotale;
    this.libelleTitres = '';
  }


  goToPorteFeuille() {
    this.router.navigate(['titres']);
  }

  get backgroundColor(): (type: any) => string | undefined {
    return (type: string) => {
      const mapping = this.colorMap.find((cat: { title: string; color: string; }) => cat.title === type)
      return mapping?.color
    }
  }
}