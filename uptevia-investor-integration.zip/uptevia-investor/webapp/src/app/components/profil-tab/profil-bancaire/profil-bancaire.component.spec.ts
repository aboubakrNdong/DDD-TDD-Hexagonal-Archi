import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfilBancaireComponent } from './profil-bancaire.component';

describe('ProfilBancaireComponent', () => {
  let component: ProfilBancaireComponent;
  let fixture: ComponentFixture<ProfilBancaireComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProfilBancaireComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProfilBancaireComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
