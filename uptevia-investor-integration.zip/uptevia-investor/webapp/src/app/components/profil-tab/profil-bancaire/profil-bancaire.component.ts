import { Component, Input } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { CodeIso2 } from 'src/app/entity/codeiso2';
import { DonneesBancaire } from 'src/app/entity/donneesBancaire';
import { Titulaire } from 'src/app/entity/titulaire';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { TranslateService } from '@ngx-translate/core';
import { MODE_REGLEMENT, MODE_REGLEMENT_CHEQUE, PARAM_TYPE } from 'src/app/utils/const-vars';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { showModal } from 'src/app/utils/functions';
import { MessageService } from 'src/app/services/message.service';
import { ResultStatus } from 'src/app/entity/status';
import { Profil } from 'src/app/entity/profil';
import { Store } from '@ngrx/store';
import { setProfile } from 'src/app/store/actions/app.action';
import { UserAccess } from 'src/app/entity/user';
import { StorageService } from 'src/app/services/storage-service';



@Component({
  selector: 'profil-bancaire',
  templateUrl: './profil-bancaire.component.html',
  styleUrls: ['.././profil-tab.component.css']
})
export class ProfilBancaireComponent {

  @Input() profile: any = null;

  @Input() codeIso2: any = null;

  form: FormGroup;
  initialValues: any;
  cssFormControl = true;
  editable = false;
  styleDisabledField = true;
  submitted = false;
  submittedTwo = false;
  isButtonVisible = true;
  clickModifyButton = false;
  clickRollbackButton = false;
  numberCode: any;
  cacheData: any;
  paysSefa: any;
  iClicked = false;
  phone: any;
  checkIso2: true;
  profilTituDevise: any;
  profilModeR: any;
  ribFiscaleLabel: any;
  messages: string[] = [];
  countries: any;
  listAllCountries: any;
  allDevise: any;
  newPaysValue: any;

  constructor(
    private store: Store,
    private loginService: LoginService,
    private bffService: BffService,
    private formBuilder: FormBuilder,
    private translate: TranslateService,
    private storageService: StorageService,
    private messageService: MessageService,
    private modal: NgbModal,
  ) {
  }

  ngOnInit(): void {
    this.getProfilData();
    this.createRibPaysIden(this.profile?.ribePaysIden);
    this.createModeDeReglement(this.profile?.tituModeReglement);
    this.createProfilBancaire();
    this.getAllCountries();
    this.getListDevise();
    this.getCodeIso2(this.profile.ribePaysIden);

  }



  createRibPaysIden(pays: string) {
    let ribFiscaleKey = 'general.pays.' + pays;
    this.ribFiscaleLabel = this.translate.instant(ribFiscaleKey);
  }

  createProfilBancaire() {
    this.form = this.formBuilder.group({

      ribePays: this.ribFiscaleLabel,
      ribIban: [this.profile.ribIban, [Validators.required], this.ibanprefixValidator()],
      ribeBic: [this.profile.ribeBic, [Validators.required, Validators.pattern("[A-Za-z]{4}[A-Za-z]{2}[A-Za-z0-9]{2}([A-Za-z0-9]{3})?")], this.bicprefixValidator()],
      ribDomi: [this.profile.ribDomi, [Validators.required]],
      ribeBankAdre: this.profile.ribeBankAdre,
      ribeAgence: this.profile.ribAgen,
      ribCompte: this.profile.ribCompte,
      tituBene: [this.profile.tituBene, [Validators.required]],
      tituMode: [this.profilModeR, [Validators.required]],
      bancaireValue: ['', [Validators.maxLength(10)]],
      tituDevise: [this.profile.tituDevise, [Validators.required]],
      ribeBankCode: this.profile.ribBank,
      ribCle: this.profile.ribCle,
      typeRevenue: PARAM_TYPE,
      newRibePays: ['', [Validators.required],this.paysprefixValidator()],
    })
  }

  createModeDeReglement(mode: string) {
    let modeDeR = mode;
    if (modeDeR === MODE_REGLEMENT_CHEQUE || modeDeR === MODE_REGLEMENT) {
      this.profilModeR = modeDeR;
    } else {
      this.profilModeR = this.translate.instant('general.profil.acompleter');
    }
  }


  private ibanprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const ribIban = control.value;
      return new Promise((resolve, reject) => {
        if (ribIban && !ribIban.startsWith(this.codeIso2)) {
          resolve({ invalidPrefix: true });
        } else {
          resolve(null);
        }      
      });
    }
  }

  onChangePays(event: any) {
    if (event.target.value) {
     this.newPaysValue = this.form.value?.newRibePays
    }
  }

  getListDevise() {
    const paramName = "DEVISE PARAMS";
    const isConnected = this.loginService.isAuthenticated() ? this.profile.emetIden : 0;
    this.bffService.getParametreSite(isConnected, paramName).subscribe(
      (reponse) => {
        if (reponse?.paramValue) {
          this.allDevise = reponse.paramValue;
        } else {
          console.log("Error in get All CSP from db");
        }
      })
  }

  private paysprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const newRibePays = control.value;
      this.codeIso2 = this.getCodeIso2(newRibePays);
      return new Promise((resolve, reject) => {
        if (newRibePays) {
          // resolve({ invalidPrefixPays: false });
        } else {
          resolve(null);
        }
      });
    }
  }

  private bicprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const ribeBic = control.value;
      const codeIso2Bic = ribeBic.slice(4, 6);
      return new Promise((resolve, reject) => {
        if (ribeBic && (codeIso2Bic != this.codeIso2)) {
          resolve({ invalidPrefixBic: true });
        } else {
          resolve(null);
        }

        if (ribeBic.length != 8 && ribeBic.length != 11) {
          resolve({ invalidPrefixBicLength: true });
        } else {
          resolve(null);
        }
      });
    }
  }

  getCodeIso2(paysIden: string): string {
    this.bffService.getCodeIso2(paysIden).subscribe(
      (codeiso2: CodeIso2) => {
        this.codeIso2 = codeiso2.paysIso2;
      })
    return this.codeIso2;
  }

  getAllCountries() {
    const titulaire: Profil = JSON.parse(this.storageService.getItem("titulaire") || '{}');
    const ParamName = "PAYS_ADRESSE_FISCALE_AUTORISE";
    const isConnected = this.loginService.isAuthenticated() ? titulaire.emetIden : 0;

    this.bffService.getParametreSite(isConnected, ParamName).subscribe(
      (reponse) => {
        if (reponse?.paramValue) {
          this.countries = reponse.paramValue;
          this.listAllCountries = this.countries.map((pays: string) => 'general.pays.' + pays.trim());
        } else {
          console.error("error in getAllCountries");
        }
      })
  }

  onModify() {
    this.clickModifyButton = true;
    this.clickRollbackButton = true;
    this.submitted = true;
    this.editable = true;
    this.styleDisabledField = false;
    this.initialValues = this.form.value;
  }

  onRollbackForm() {
    this.onRollback();
    this.form.reset(this.initialValues);
  }

  onRollback() {
    this.clickModifyButton = false;
    this.clickRollbackButton = false;
    this.submitted = false;
    this.editable = false;
    this.styleDisabledField = true;
  }

  getProfilData() {
    const user: UserAccess = JSON.parse(localStorage.getItem("user") ?? '{}');

    this.loginService.getTitulaire().subscribe(
      (reponse: Profil) => {
        if (reponse)
          this.profile = reponse;
        //Save Data to store
        this.store.dispatch(setProfile({ profil: reponse, username: user.login }))
      }
    );
  }

  verifyBic(): boolean {
    const ribeBic = this.form.get('ribeBic')?.value
    const codeIso2Bic = ribeBic.slice(4, 6);
    if (ribeBic && (codeIso2Bic != this.codeIso2)) {
      return false;
    } else if (ribeBic.length != 8 && ribeBic.length != 11) {
      return false;
    } else {
      return true;
    }
  }
  verifyIban(): boolean {
    const ribIban = this.form.get('ribIban')?.value
    if (ribIban && !ribIban.startsWith(this.codeIso2)) {
      return false;
    }
    return true;
  }

  onFormSubmit() {
    this.submitted = true;
    this.submittedTwo = true;
    const titulaire: Profil = JSON.parse(this.storageService.getItem("titulaire") || '{}');

    if (!this.verifyBic()) {
      showModal('general.warning.alert', ['form.field.error.bic'], 'general.bouton.fermer', this.modal);
      return;
    }
    if (!this.verifyIban()) {
      showModal('general.warning.alert', ['form.field.error.iban'], 'general.bouton.fermer', this.modal);
      return;
    }

    if (this.form.invalid) {
      return;
    }

    if ((titulaire === undefined)) {
      console.error(" titulaire undefined")
      return;
    }

    const dataBancaire: DonneesBancaire = {
      type: this.form.get('typeRevenue')?.value,
      sCodePaysReglement: this.form.value?.newRibePays,
      sDevise: this.form.get('tituDevise')?.value,
      sModeReglement: MODE_REGLEMENT,
      sAgence: this.form.get('ribeAgence')?.value ? this.form.get('ribeAgence')?.value : '',
      sBanque: this.profile.ribBank,
      sCle: this.form.get('ribCle')?.value ? this.form.get('ribCle')?.value : '',
      sCompte: this.form.get('ribCompte')?.value ? this.form.get('ribCompte')?.value : '',
      sDomiciliation: this.form.get('ribDomi')?.value ? this.form.get('ribDomi')?.value : '',
      sBeneficiaire: this.form.get('tituBene')?.value ? this.form.get('tituBene')?.value : '',
      sRibeBankCode: this.form.get('ribeBankCode')?.value ? this.form.get('ribeBankCode')?.value : '',
      sRibeAgen: this.form.get('ribeAgence')?.value ? this.form.get('ribeAgence')?.value : '',
      sRibCtrlInte: '',
      sRibCpt1: '',
      sRibCpt2: '',
      sRibCtrlFin: '',
      sRibBic: this.form.get('ribeBic')?.value,
      sRibBankNom: '',
      sRibBankAdress: this.form.get('ribeBankAdre')?.value ? this.form.get('ribeBankAdre')?.value : '',
      sRibIban: this.form.get('ribIban')?.value,
      sRibBicIntermediaire: '',
      sRibBicCouverture: '',
      sRibBankIntermediaireNom: '',
      sRibBankIntermediaireNomAdress: '',
      sRibeCptBankBenefChezBankIntermediaire: '',
      sRibeBankCouvertureNom: '',
      sRibeBankCouvertureNomAdre: '',
      sRibeCptBankInterChezBankCouverture: '',

    };
    // save new  data bancaire to registrar
    this.sendDataBancaireToServer(dataBancaire);
  }

  reLoadForm() {
    setTimeout(() => {
      this.createProfilBancaire();
      this.onRollback();
    }, 2000)
  }



  sendDataBancaireToServer(bankData: DonneesBancaire) {
    if (bankData) {
      this.bffService.UpdateUpiBancaireTitu(bankData).subscribe(
        (response: ResultStatus) => {
          if (response && response?.status === "OK") {
            console.log('Demande banquaire crée avec succés!!', response);
            this.submitted = false;
            showModal('general.warning.alert', ['form.field.success.virement'], 'general.bouton.fermer', this.modal);
            this.getProfilData();
            this.reLoadForm();  
            this.createRibPaysIden(this.newPaysValue);        
            this.createModeDeReglement(MODE_REGLEMENT);
          } else if (response && response?.status != "OK") {
            console.log('show bad response!!', response.status);
            let errorFromRegistrar = response.status;
            console.error('Erreur lors de l\'enregistrement' + this.messages);
            this.messages = this.messageService.messages;
            showModal('general.warning.alert', [errorFromRegistrar], 'general.bouton.fermer', this.modal);
            return;
          }
          else {
            this.messages = this.messageService.messages;
            console.error('Erreur lors de l\'enregistrement' + this.messages);
            showModal('general.warning.alert', ['form.field.validator.empty'], 'general.bouton.fermer', this.modal);
          }
        },);
    } else {
      this.messages = this.messageService.messages;
      console.log("error databnk is empty");
    }
  }

}
