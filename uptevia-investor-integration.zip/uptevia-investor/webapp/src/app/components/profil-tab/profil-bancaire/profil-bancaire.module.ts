import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfilBancaireComponent } from './profil-bancaire.component';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    ProfilBancaireComponent
  ],
  imports: [CommonModule, UpteviaLibModule,
    FormsModule,
    ReactiveFormsModule],
  exports: [ProfilBancaireComponent],
})
export class ProfilBancaireModule { }
