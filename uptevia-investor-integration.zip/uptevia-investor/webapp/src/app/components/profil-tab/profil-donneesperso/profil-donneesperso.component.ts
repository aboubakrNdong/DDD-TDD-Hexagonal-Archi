import { Component, Input, OnInit } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { DonneesPerso } from 'src/app/entity/donneesPerso';
import { Titulaire } from 'src/app/entity/titulaire';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { TranslateService } from '@ngx-translate/core';
import { DatePipe } from '@angular/common';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { showModal } from 'src/app/utils/functions';
import { PARAM_CONTACT, PARAM_FISCALE, PARAM_POSTALE } from 'src/app/utils/const-vars';
import { DonneesContact } from 'src/app/entity/donneesContact';
import { MessageService } from 'src/app/services/message.service';
import { ResultStatus } from 'src/app/entity/status';
import { UserAccess } from 'src/app/entity/user';
import { Profil } from 'src/app/entity/profil';
import { Store } from '@ngrx/store';
import { setProfile } from 'src/app/store/actions/app.action';
import { StorageService } from 'src/app/services/storage-service';





@Component({
  selector: 'profil-donneesperso',
  templateUrl: './profil-donneesperso.component.html',
  styleUrls: ['.././profil-tab.component.css'],
  providers: [DatePipe]
})
export class ProfilDonneespersoComponent implements OnInit {

  @Input() profile: any = null;

  form: FormGroup;
  initialValues: any;
  cssFormControl = true;
  editable = false;
  styleDisabledField = true;
  submitted = false;
  submittedTwo = false;
  isButtonVisible = true;
  clickModifyButton = false;
  clickRollbackButton = false;
  numberCode: any;
  addContact = false;

  userDataStore: UserAccess;

  paysNaissanceLabel: any;
  paysFiscaleLabel: any;
  paysPostaleLabel: any;
  phoneWithoutZeroPro: any;
  phoneWithoutZeroPerso: any;
  phoneWithZeroPerso: any;
  phoneWithZeroPro: any;
  messages: string[] = [];
  dataTosend: any;
  titulaire: Profil;

  dataPostale: DonneesPerso
  dataFiscale: DonneesPerso
  indicatorPro: any;

  login: any;
  countries: any;
  listAllCountries: any

  constructor(private formBuilder: FormBuilder,
    private store: Store,
    private storageService:StorageService,
    private loginService: LoginService,
    private bffService: BffService,
    private datepipe: DatePipe,
    private translate: TranslateService,
    private modal: NgbModal,
    private messageService: MessageService,
  ) {
  }

  ngOnInit(): void {
    this.getProfilData();

    this.createFiscalePays();
    this.createPaysNaissanceAndPhone();
    this.createProfilDonneesperso();
    this.initialValues = this.form.value;
    this.getIndicatifAutorise();
    this.getAllCountries();
  }

  createProfilDonneesperso() {
    this.form = this.formBuilder.group({
      civilite: this.profile.qualite,
      nom: this.profile.nom,
      nomJF: this.profile.nomJF,
      prenom: this.profile.prenom,
      prenomTwo: this.profile.prenom2,
      dob: this.datepipe.transform(this.profile.tituNaisDate, 'dd/MM/yyyy'),
      dept: this.profile.tituNaisDept,
      lieu: this.profile.tituNaisComu,
      paysnaissance: this.paysNaissanceLabel,

      emailperso: [this.profile.emailPerso, [Validators.email, Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],
      emailPro: [this.profile.emailPro, [Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],
      selectphone: ['+33'],
      telMobilePerso: [this.phoneWithZeroPerso, [Validators.pattern("^[0-9]*$"), Validators.minLength(3), Validators.maxLength(10), Validators.required], this.phoneprefixValidator()],
      telMobilePro: [this.phoneWithZeroPro, [Validators.pattern("^[0-9]*$"), Validators.minLength(3), Validators.maxLength(10),], this.phoneprefixValidator()],
      telFixePerso: [this.profile.numFixePerso, [Validators.pattern("^[0-9]*$"), Validators.minLength(3), Validators.maxLength(10),]],
      telFixePro: [this.profile.numFixePro, [Validators.pattern("^[0-9]*$"), Validators.minLength(3), Validators.maxLength(10)]],

      fiscaleBat: [this.profile.adreFiscInfoBati],
      adresseRue: [this.profile.adreFiscInfoRue,],
      complement: [this.profile.adreFiscComp],
      adresseFiscale: [this.profile.adreFiscCodp, [Validators.required]],
      fiscaleVille: [this.profile.adreFiscNomCommune, [Validators.required]],
      fiscalePays: [this.paysFiscaleLabel, [Validators.required]],
      fiscValue: ['', [Validators.maxLength(10)]],
      newfiscalePays: ['', Validators.required],

      postaleBat: [this.profile.adreInfoBati],
      postaleAdresseRue: [this.profile.adreInfoRue,],
      postaleComplement: [this.profile.adreComplement],
      adressePostale: [this.profile.adreCodp],
      postaleVille: [this.profile.adreNomCommune,],
      postalePays: [this.paysPostaleLabel, [Validators.required]],
      typeAdressPostale: PARAM_POSTALE,
      typeAdressFiscale: PARAM_FISCALE,
      typeContact: PARAM_CONTACT,
      newPostalePays: ['',Validators.required]

    })
  }

  createPaysNaissanceAndPhone() {
    let paysNaissanceKey = 'general.pays.' + this.profile.tituNaisPaysIden;
    this.paysNaissanceLabel = this.translate.instant(paysNaissanceKey);

    //phone
    const phonePerso = this.profile?.numMobilePerso?.substring(3, this.profile.numMobilePerso?.length);
    const phonePro = this.profile?.numMobilePro?.substring(3, this.profile.numMobilePro?.length);
    this.phoneWithZeroPerso = phonePerso ? '0' + phonePerso : ''
    this.phoneWithZeroPro = phonePro ? '0' + phonePro : ''
   

  }

  createFiscalePays() {
    let paysFiscaleKey = 'general.pays.' + this.profile.adreFiscPaysIden;
    this.paysFiscaleLabel = this.translate.instant(paysFiscaleKey);

    let paysPostaleKey = 'general.pays.' + this.profile.adreFiscPaysIden;
    this.paysPostaleLabel = this.translate.instant(paysPostaleKey);
  }

  private phoneprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const telephone = control.value;
      return new Promise((resolve, reject) => {
        if (telephone && !telephone.startsWith('06') && !telephone.startsWith('07')) {
          resolve({ invalidPrefix: true });
        } else {
          resolve(null);
        }
      });
    }
  }

  onModify() {
    this.clickModifyButton = true;
    this.clickRollbackButton = true;
    this.submitted = true;
    this.editable = true;
    this.styleDisabledField = false;
    this.initialValues = this.form.value;
  }

  onRollback() {
    this.clickModifyButton = false;
    this.clickRollbackButton = false;
    this.submitted = false;
    this.editable = false;
    this.styleDisabledField = true;
    this.form.reset(this.initialValues);
  }

  getProfilData() {
    const user: UserAccess = JSON.parse(localStorage.getItem("user") ?? '{}');

    this.loginService.getTitulaire().subscribe(
      (reponse: Profil) => {
        if (reponse)
        this.profile = reponse;
        this.login = user.login;
        //Save Data to store
      this.store.dispatch(setProfile({ profil: reponse, username: user.login }))
      }
    );
  }

  getAllCountries() {
    const titulaire: Profil = JSON.parse(this.storageService.getItem("titulaire") || '{}');
    const ParamName = "PAYS_ADRESSE_FISCALE_AUTORISE";
    const isConnected = this.loginService.isAuthenticated() ? titulaire.emetIden : 0;   
  
      this.bffService.getParametreSite(isConnected, ParamName).subscribe(
        (reponse) => {
          if(reponse?.paramValue){
          this.countries = reponse.paramValue;
          this.listAllCountries = this.countries.map((pays: string) => 'general.pays.'+ pays.trim());
          }else{
            console.error("error in getAllCountries");
          }
        })
  }

  getIndicatifAutorise() {
    const titulaire: Profil = JSON.parse(this.storageService.getItem("titulaire") || '{}');
    const ParamName = "TEL_INDICATIF_AUTORISE";
    const isConnected = this.loginService.isAuthenticated() ? titulaire.emetIden : 0;

      this.bffService.getParametreSite(isConnected, ParamName).subscribe(
        (reponse) => {
          if (reponse) {
            this.numberCode = reponse;         
          } else {
            console.error("error in getParametreSite")
          }

        })
  }

  onFormSubmit() {
    this.submitted = true;
    this.submittedTwo = true;

    const titulaire: Profil = JSON.parse(this.storageService.getItem("titulaire") || '{}');
    const user = JSON.parse(localStorage.getItem("user") || '{}');

    if ((user === undefined || titulaire === undefined)) {
      console.error("user or titulaire undefined")
      return;
    }

    const paysFisc = this.form.get('fiscalePays')?.value;
    const paysPost = this.form.get('postalePays')?.value;
    let codeIsoFisc = paysFisc.substring(0, 3);
    let codeIsoPost = paysPost.substring(0, 3);


    this.dataPostale = {
      emetIden: titulaire.emetIden,
      actiIden: titulaire.actiIden,
      tituNum: 1, // pas de multi-user pour mvp,
      typeAdre: this.form.get('typeAdressPostale')?.value ? this.form.get('typeAdressPostale')?.value : '',
      adreInfoRue: this.form.get('postaleAdresseRue')?.value ? this.form.get('postaleAdresseRue')?.value : '',
      adreComp: this.form.get('postaleComplement')?.value ? this.form.get('postaleComplement')?.value : '',
      adreCodp: this.form.get('adressePostale')?.value ? this.form.get('adressePostale')?.value : '',
      adreNomComu: this.form.get('postaleVille')?.value ? this.form.get('postaleVille')?.value : '',
      adrePaysIden: codeIsoPost,
      adreBati: this.form.get('postaleBat')?.value ? this.form.get('postaleBat')?.value : '',
      adreFiscDept: this.form.get('fiscValue')?.value,
      adreFiscCodeComu: this.form.get('fiscValue')?.value,
    };

    this.dataFiscale = {
      emetIden: titulaire.emetIden,
      actiIden: titulaire.actiIden,
      tituNum: 1, // pas de multi-user pour mvp,
      typeAdre: this.form.get('typeAdressFiscale')?.value ? this.form.get('typeAdressFiscale')?.value : '',
      adreInfoRue: this.form.get('adresseRue')?.value ? this.form.get('adresseRue')?.value : '',
      adreComp: this.form.get('complement')?.value ? this.form.get('complement')?.value : '',
      adreCodp: this.form.get('adresseFiscale')?.value ? this.form.get('adresseFiscale')?.value : '',
      adreNomComu: this.form.get('fiscaleVille')?.value ? this.form.get('fiscaleVille')?.value : '',
      adrePaysIden: codeIsoFisc,
      adreBati: this.form.get('fiscaleBat')?.value ? this.form.get('adresseFiscale')?.value : '',
      adreFiscDept: this.form.get('fiscValue')?.value,
      adreFiscCodeComu: this.form.get('fiscValue')?.value,
    };

    const validPhonePerso = this.form.get('telMobilePerso')?.value;
    this.phoneWithoutZeroPerso = validPhonePerso?.substring(1, validPhonePerso?.length);
    //console.log("phoneWithoutZeroPerso" + this.phoneWithoutZeroPerso);

    const validPhonePro = this.form.get('telMobilePro')?.value ? this.form.get('telMobilePro')?.value:'';
    this.phoneWithoutZeroPro = validPhonePro?.substring(1, validPhonePro?.length) ? validPhonePro?.substring(1, validPhonePro?.length) : '';
    console.log("phoneWithoutZeroPro" + this.phoneWithoutZeroPro);

    if(this.phoneWithoutZeroPro === ''){
      console.log("phone empty")
      this.indicatorPro = '';
    } else{
      this.indicatorPro = this.form.get('selectphone')?.value;
      console.log("we have number ")
    }
    

    const contactTituData: DonneesContact = {

      emetIden: titulaire.emetIden,
      actiIden: titulaire.actiIden,
      tituNum: 1, // pas de multi-user pour mvp,
      tituEmail: this.form.get('emailperso')?.value,
      tituEmail2: this.form.get('emailPro')?.value,
      tituNumMobilePerso: this.phoneWithoutZeroPerso,
      tituNumMobilePersoIndiPays: this.form.get('selectphone')?.value,
      tituNumMobilePro: this.phoneWithoutZeroPro, 
      tituNumMobileProIndiPays: this.indicatorPro,
      tituNumTel: '', 
      tituNumTelIndiPays: '', 
      tituNumTel2: '',
      tituNumTel2IndiPays:'', 
      typecontact: '',
      typeCoord: '',
      numFaxPro: '', 
      numFaxProIndiPays: '', 
      numFaxPerso: '', 
      numFaxPersoIndiPays: '', 
    };

    this.sendAdresseDataToServer(this.dataPostale).then(
      (val) => {
        //Send data contact update to server 
        console.log("save postale success" + val);
        this.sendAdresseDataToServer(this.dataFiscale).then(
          (val) => {
            console.log("save fiscale success" + val);
            this.sendContactDataToServer(contactTituData)
          },
          (err) => {
            console.error("error in saving fiscale adress " + err)
          },
        )
      },
      (err) => {
        console.error("error in saving postale adress" + err)
      },

    );

  }

  sendAdresseDataToServer(promiseInput: DonneesPerso): Promise<boolean> {
    const promise: Promise<boolean> = new Promise<boolean>((resolve, reject) => {
      this.bffService.UpdateUpiAdresseTitu(promiseInput).subscribe(
        (response: ResultStatus) => {
          if (response && response?.status === "OK") {
            console.log('Demande crée avec succés!!', response.status);
            let keyTrad = 'form.field.validator.success.' + promiseInput.typeAdre;
            //  showModal('general.warning.success', [keyTrad], 'general.bouton.fermer', this.modal);
            this.submitted = false;
            resolve(true);
          } else if (response && response?.status != "OK") {
            console.log('show bad response!!', response.status);
            let errorFromRegistrar = response.status;
            console.error('Erreur lors de l\'enregistrement' + this.messages);
            this.messages = this.messageService.messages;
            showModal('general.warning.alert', [errorFromRegistrar], 'general.bouton.fermer', this.modal);
            reject(false);
          }
          else {
            this.messages = this.messageService.messages;
            console.error('Erreur lors de l\'enregistrement' + this.messages);
            showModal('general.warning.alert', ['form.field.validator.empty'], 'general.bouton.fermer', this.modal);
            reject(false);
          }
        },);

    })
    return promise
  }

  sendContactDataToServer(contactData: DonneesContact) {
    this.bffService.UpdateUpiContactTitu(contactData).subscribe(
      (response: ResultStatus) => {
        if (response && response?.status === "OK") {
          console.log('Demande crée avec succés!!', response.status);
         this.updateDataInUpiUtil();
       
        } else if (response && response?.status != "OK") {
          console.log('show bad response!!', response.status);
          let errorFromRegistrar = response.status;
          console.error('Erreur lors de l\'enregistrement' + this.messages);
          this.messages = this.messageService.messages;
          showModal('general.warning.alert', [errorFromRegistrar], 'general.bouton.fermer', this.modal);
          return;
        }
        else {
          this.messages = this.messageService.messages;
          console.error('Erreur lors de l\'enregistrement' + this.messages);
          showModal('general.warning.alert', ['form.field.validator.emptycontact'], 'general.bouton.fermer', this.modal);
        }
      },);

  }

  
  updateDataInUpiUtil() {
    const newEmail = this.form.get('emailperso')?.value;
    const newPhone = this.form.get('telMobilePerso')?.value;
    const indicator = this.form.get('selectphone')?.value;
    console.log("les news"+ newEmail + newPhone + indicator);
    const formatted = newPhone.replace(/^0+/, '');
    const user: any = {
      login: this.login,
      mail: newEmail,
      telephone: indicator + formatted
    }

    console.log("new user", newEmail, newPhone);
    console.log("new user", user);

    this.bffService.UpdateUpiMailPhone(user).subscribe(res => {
      if (res) {
        console.log('user up to date ', res);
        this.submitted = false;
        showModal('general.warning.success', ['form.field.validator.success'], 'general.bouton.fermer', this.modal);        
        this.getProfilData();
      } else {
        console.error('phone and not updated ')
      }

    })

  }

}

