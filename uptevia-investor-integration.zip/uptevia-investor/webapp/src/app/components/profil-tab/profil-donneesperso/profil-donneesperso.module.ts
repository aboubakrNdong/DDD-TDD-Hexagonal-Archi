import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProfilDonneespersoComponent } from './profil-donneesperso.component';
import { UpteviaLibModule } from '../../uptevia-lib.module';

@NgModule({
  declarations: [ProfilDonneespersoComponent],
  imports: [CommonModule, UpteviaLibModule,
    FormsModule,
    ReactiveFormsModule],
  exports: [ProfilDonneespersoComponent],
})
export class ProfilDonneesPersoModule { }
