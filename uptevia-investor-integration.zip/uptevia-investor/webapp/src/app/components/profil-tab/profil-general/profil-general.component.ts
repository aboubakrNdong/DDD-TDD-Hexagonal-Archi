import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';
import { BffService } from 'src/app/services/bff.service';
import { Profil } from 'src/app/entity/profil';
import { LoginService } from 'src/app/services/login.service';
import { UserAccess } from 'src/app/entity/user';
import { Store } from '@ngrx/store';
import { setProfile } from 'src/app/store/actions/app.action';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { showModal } from 'src/app/utils/functions';
import { CodeIso2 } from 'src/app/entity/codeiso2';



@Component({
  selector: 'profil-general',
  templateUrl: './profil-general.component.html',
  styleUrls: ['.././profil-tab.component.css'],
  providers: [DatePipe]
})
export class ProfilGeneralComponent implements OnInit {
  form: FormGroup;

  submitted: any;
  initialValues: any;
  concatNumCompte: string;
  @Input() profile: Profil;
  cacheData: any;
  concatEmetteur: string;
  clickModifyButton = false;
  clickRollbackButton = false;
  submittedTwo = false;
  profilLangue: string;
  styleDisabledField = true;
  cssFormControl = true;
  editable = false;
  classProLabel: any;
  classTypeLabel: any;
  format: string;
  theFinal: any;
  allLangues: any;
  pConvcompttitre:any;
  allCsp: any;
  listAllCsp: any; //liste contenant toutes les classification socio professionnelles
  finalLang: any;
  finalCsp: any;

  constructor(private formBuilder: FormBuilder,
    private datepipe: DatePipe,
    private translate: TranslateService,
    private bffService: BffService,
    private loginService: LoginService,
    private store: Store,
    private modal: NgbModal,

    ) {
  }

  ngOnInit(): void {
    this.getLangues();
    this.createActiTypeCpte();
    this.getListCspCategory();
    this.createClassPro(this.profile?.tituCsp);
    this.createTituLangue(this.profile?.tituLanguage);
    this.createConvCompteTitre();
    this.createProfilGeneral();
  }


  createProfilGeneral() {
    this.form = this.formBuilder.group({
      emetteur: this.createEmeteur(),
      numcompte: this.profile.actiIden,
      classmif: [this.profile.actiMifClass, [Validators.required]],
      classpro: this.classProLabel,
      convcompttitre: this.pConvcompttitre,
      dateenvoi: this.datepipe.transform(this.profile.actiConvDateEnvoi, 'dd/MM/yyyy'),
      datereception: this.datepipe.transform(this.profile.actiConvDateRecept, 'dd/MM/yyyy'),
      daterelance: this.datepipe.transform(this.profile.actiConvDateRelance, 'dd/MM/yyyy'),
      typecpte: this.classTypeLabel,
      actiRefeScte: this.profile.actiRefeSala,
      libellesociete: this.profile.drhRattachement,
      referencesociete: this.profile.actiRefeScte,
      languedescom: [this.profilLangue, [Validators.required]],
      newLanguedescom: ['', [Validators.required]],
      newClassPro: [''],
    })
  }

  createEmeteur(): string {
    this.concatEmetteur = this.profile.emetIden + "-" + this.profile.emetLibelle;
    return this.concatEmetteur;
  }

  createClassPro(classPro: string) {
    let classProKey = 'general.csp.' + classPro;
    this.classProLabel = this.translate.instant(classProKey);
  }

  createActiTypeCpte() {

    let classTypeCpte = 'general.typecpte.' + this.profile.actiTypeCpte;
    let lastIndex = classTypeCpte.lastIndexOf(".");
    classTypeCpte = classTypeCpte.substring(0, lastIndex);
    let classTypeCpteToLower = classTypeCpte.toLowerCase();
    let classTypeCpteTransform = classTypeCpteToLower.split(" ").join("");
    this.classTypeLabel = this.translate.instant(classTypeCpteTransform);

  }

  getListCspCategory() {
    const paramName = "TITULAIRE_CSP";
    const isConnected = this.loginService.isAuthenticated() ? this.profile.emetIden : 0;
    this.bffService.getParametreSite(isConnected, paramName).subscribe(
      (reponse) => {
        if(reponse?.paramValue){
          this.allCsp = reponse.paramValue;
          this.listAllCsp  = this.allCsp.map((csp: string) => 'general.csp.'+ csp.trim());
        //  this.listAllCsp = concatCsp.map((csp: string) => this.translate.instant(csp));
        }else {
          console.log("Error in get All CSP from db");
        }
      })
  }


  getLangues() {
    this.bffService.getLangues()
    .subscribe((reponse) => {
        if(reponse){
        this.allLangues = reponse;
        //console.log("lang"+ this.allLangues[0].)
      }else {
        console.log("Error in get request");
      }
      },
    );
  }

  createTituLangue(codeIso3: string) { 
    let languagekey = 'general.lang.' + codeIso3
    this.profilLangue = this.translate.instant(languagekey);
  }


  createConvCompteTitre() {
    if ((this.profile.actiConvIndiExclu ) || (this.profile.actiConvDateRecept != null)) {
      this.pConvcompttitre = this.translate.instant('profil.compte.convcompttitre.complete');
    } else if (this.profile.actiConvIndiIncomp) {
      this.pConvcompttitre = this.translate.instant('profil.compte.convcompttitre.incomplete');
    } else if (this.profile.actiConvDateEnvoi != null) {
      this.pConvcompttitre = this.translate.instant('profil.compte.convcompttitre.nonrecue');
    }
  }

  getProfilData() {
    const user: UserAccess = JSON.parse(localStorage.getItem("user") ?? '{}');

    this.loginService.getTitulaire().subscribe(
      (reponse: Profil) => {
        if (reponse)
        this.profile = reponse;
        //Save Data to store
      this.store.dispatch(setProfile({ profil: reponse, username: user.login }));
      }
    );
  }

  getCodeIso2(paysIden: string): string {
    this.bffService.getCodeIso2(paysIden).subscribe(
      (codeiso2: CodeIso2) => {
        if(codeiso2?.paysIso2){
          this.finalLang = codeiso2.paysIso2;
        } else{
          console.log("codeIso2 not found for this country");
          this.finalLang = paysIden;
        }
        this.callAndSave();
      })
    return this.finalLang;
  }

  formatDataToSave(){
    this.finalLang = this.getCodeIso2(this.form.value.newLanguedescom);
    this.finalCsp = this.form.value.newClassPro?.split('.')[2] ? this.form.value.newClassPro?.split('.')[2] : this.profile?.tituCsp;    
  }

  callAndSave(){    
    const dataToSave: any = {
      csp: this.finalCsp,
      language:  this.finalLang,
    }

    this.bffService.UpdateCspLanguage(dataToSave).subscribe(res => {
      if (res) {
        console.log('user data up to date ', res);
        showModal('general.warning.success', ['form.field.validator.success'], 'general.bouton.fermer', this.modal);        
        this.getProfilData();
        this.createTituLangue(this.finalLang);
        this.createClassPro(this.finalCsp);
        this.createProfilGeneral();
        this.onRollback();
      } else {
        console.error('csp and  language not updated ')
      }

    })

  }


  onFormSubmit() {
    this.submitted = true;
    this.submittedTwo = true;

    if (this.form.invalid) {
      console.log("invalid");
      return;
    }
    this.formatDataToSave();
  }



  onModify() {
    this.clickModifyButton = true;
    this.clickRollbackButton = true;
    this.submitted = true;
    this.editable = true;
    this.styleDisabledField = false;
    this.initialValues = this.form.value;
  }

  onRollback() {
    this.clickModifyButton = false;
    this.clickRollbackButton = false;
    this.submitted = false;
    this.submittedTwo = false;
    this.editable = false;
    this.styleDisabledField = true;
  }

  onRollbackForm() {
    this.onRollback();
    this.form.reset(this.initialValues);
  }


  //TODO mettre l'api qui va combiner les 2 parametresite et libelle de codeiso2 

}

