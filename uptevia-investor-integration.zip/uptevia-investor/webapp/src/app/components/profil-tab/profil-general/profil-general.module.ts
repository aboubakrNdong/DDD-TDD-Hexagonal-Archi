import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProfilGeneralComponent } from './profil-general.component';

@NgModule({
  declarations: [ProfilGeneralComponent],
  imports: [CommonModule, UpteviaLibModule,
    FormsModule,
    ReactiveFormsModule],
  exports: [ProfilGeneralComponent],
})
export class ProfilGeneralModule { }
