import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfilTabComponent } from './profil-tab.component';

describe('ProfilTabComponent', () => {
  let component: ProfilTabComponent;
  let fixture: ComponentFixture<ProfilTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ProfilTabComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(ProfilTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
