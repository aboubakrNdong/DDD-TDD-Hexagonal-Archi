
import { Component, Input, OnInit } from '@angular/core';
@Component({
  selector: 'profil-tab',
  templateUrl: './profil-tab.component.html',
  styleUrls: ['./profil-tab.component.css'],
})
export class ProfilTabComponent implements OnInit {

  @Input() profile: any = null;

  @Input() codeIso2: any = null;

  constructor() { }

  ngOnInit(): void {
    console.log("profile tab ", this.profile);
    
  }

}

