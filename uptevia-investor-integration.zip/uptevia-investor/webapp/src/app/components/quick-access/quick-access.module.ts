import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { QuickAccessComponent } from './quick-access.component';
import { UpteviaLibModule } from '../uptevia-lib.module';



@NgModule({
  declarations: [QuickAccessComponent],
  imports: [
    CommonModule,  
    UpteviaLibModule
  ],
  exports: [QuickAccessComponent]
})
export class QuickAccessModule { }
