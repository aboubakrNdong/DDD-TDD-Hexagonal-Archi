import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { BffService } from 'src/app/services/bff.service';
import { BreadcrumbService } from 'src/app/services/breadcrumb.service';
import { LoginService } from 'src/app/services/login.service';


@Component({
  selector: 'app-rubrique',
  templateUrl: './rubrique.component.html',
  styleUrls: ['./rubrique.component.css'],
})
export class RubriqueComponent implements OnInit {
  @Input() user: any = null;

  @Input()  faq: any;

  logoUptevia = 'assets/images/logo-uptevia.svg'
  category = '';

  constructor(
    private router:Router,
    private loginService: LoginService,
    public translate: TranslateService,
    private bffService: BffService,
    public breadcrumbService: BreadcrumbService) {
  }

  ngOnInit(): void {
    this.breadcrumbService.levelOne = '';
  }

 

  onCategoryClick(category: any) {
    const navExtras: NavigationExtras = {
      state: {
        category
      },
    }
    this.breadcrumbService.levelOne = category['category'];
    let parent = this.loginService.isAuthenticated() ? 'contact' : 'contact-us'
    this.router.navigate([`${parent}/faq-details`], navExtras);
  }
}