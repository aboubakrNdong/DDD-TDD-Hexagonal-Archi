import { Component, Input, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { LogOutRequest } from 'src/app/entity/logout-request';
import { Modules, SousModule } from 'src/app/entity/module';
import { UserAccess } from 'src/app/entity/user';
import { LoginService } from 'src/app/services/login.service';
import { DASHBOARD_MENU, DOCUMENTATION_MENU, PROFIL_MENU, SUIVI_OPS_MENU } from 'src/app/utils/const-vars';
@Component({
  selector: 'side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.css'],
})
export class SideBarComponent {
  public dashboard = DASHBOARD_MENU;
  public suivi = SUIVI_OPS_MENU;
  public profil = PROFIL_MENU;
  public documentation = DOCUMENTATION_MENU;
  @Input() menu: Modules[] | null;

  openIndex: number | undefined;
  constructor(
    private router: Router,
    private loginService: LoginService) { }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.menu) {
      this.menu = this.updateMenu(this.menu)
    }
  }

  updateMenu(menu: Modules[] | any) {

    return menu.map((element: Modules) => {
      const copiedModules: Modules = { ...element }
      if (element.sousModule && element.sousModule.length === 1) {
        let sousMenu = element.sousModule[0]
        copiedModules.groupeUrl = sousMenu.moduleUrl;
        delete copiedModules.sousModule
      }
      return copiedModules;
    });

  }

  onLogout() {
    const user: UserAccess = JSON.parse(localStorage.getItem("user") || '{}');
    const logout:LogOutRequest = {
      token: user?.token
    }
    this.loginService.logout(logout);
  }

  get isActiveRoute(): (menu: Modules) => boolean {
    return (menu: any) => { return this.currentRoute === menu.groupeUrl || this.isSubmenu(menu.sousModule) };
  }
  get isDashboard(): boolean {
    return this.currentRoute === 'dashboard';
  }

  get currentRoute(): any {
    const url = this.router.url;
    const urlSegment = url.split('/');
    return urlSegment.pop();
  }

  isSubmenu(sousMenu: SousModule[]): boolean {
    const isExist = sousMenu?.some(element => { return element.moduleUrl === this.currentRoute })
    return isExist;
  }

  toggleMenu(index: number) {
    if (this.openIndex === index) {
      this.openIndex = undefined
    } else {
      this.openIndex = index;
    }
    if (this.menu && !this.menu[index].sousModule) {
      this.router.navigate([this.menu[index].groupeUrl]);
      this.hideMenuOnMobile();
    }
  }

  hideMenuOnMobile() {
    console.debug('hideMenuOnMobile clicked')
    let burgerMenu = document.getElementById("burger-menu");
    let sideMenu = document.getElementById("side-menu");

    if (burgerMenu != null && sideMenu != null) {
      sideMenu.classList.toggle("hidden-xs")
    };
  }


}
