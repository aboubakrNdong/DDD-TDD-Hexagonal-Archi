import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Subject, distinctUntilChanged, takeUntil } from 'rxjs';
import { Email } from 'src/app/entity/email';
import { UserAccessPls } from 'src/app/entity/userAccessPls';
import { ControlData } from 'src/app/entity/vialink/control';
import { BffService } from 'src/app/services/bff.service';
import { MessageService } from 'src/app/services/message.service';
import { StorageService } from 'src/app/services/storage-service';
import { setEmail } from 'src/app/store/actions/app.action';
import { selectAppState } from 'src/app/store/selectors/app.selector';
import { F_CONNEXION_FILES } from 'src/app/utils/const-vars';
import { hideEmail, hideTel, showModal } from 'src/app/utils/functions';


@Component({
  selector: 'app-identification',
  templateUrl: './identification.component.html',
  styleUrls: ['./identification.component.css']
})
export class IdentificationComponent implements OnInit {

  formName = 'identification';
  identification: FormGroup;
  submitted = false;
  updateSuccess = false;
  updatedInfo: any = {}
  @Output() onClick = new EventEmitter<any>()

  @Output() event = new EventEmitter<string>()


  @Input() buttonChoice: any = null;
  messages: string[] = [];
  ngDestroyed$ = new Subject<void>();
  login: any;
  numberCode: any;
  editVialink: boolean = true;
  profile: UserAccessPls;
  hiddenPhone: any = '';
  hiddenMail: any = '';
  indicator: any = '';
  requestedFiles = F_CONNEXION_FILES;
  controlData: ControlData = {
    login: '',
    email: '',
    phone: '',
    numTel: '',
    onBoardingStatus: '',
    verificationKey: '',
  };
  constructor(
    public translate: TranslateService,
    private formBuilder: FormBuilder,
    private messageService: MessageService,
    private bffService: BffService,
    private modal: NgbModal,
    private store: Store,
    private storageService: StorageService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    this.initForm();
    this.getParamNumberCode();
    this.retreiveUsernameFromStore();
    this.checkForData()
    this.onChange();
  }

  initForm() {
    this.identification = this.formBuilder.group({
      username: [this.login, [Validators.required, Validators.minLength(8)]],
      indicator: ['+33', Validators.required],
      telephone: ['', [Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(8), Validators.maxLength(20), this.phoneprefixValidator]],
      email: ['', [Validators.required, Validators.email, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]],

    });
    this.controlData = JSON.parse(this.storageService.getItem('controlData') ?? '');

  }

  private phoneprefixValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Promise<ValidationErrors | null> => {
      const telephone = this.identification.get("telephone")?.value;
      const indicator = this.identification.get("indicator")?.value;
      return new Promise((resolve, reject) => {
        if (telephone && !telephone.startsWith('06') && !telephone.startsWith('07')
          && indicator === '+33') {
          resolve({ invalidPhoneNumber: true });
        } else {
          resolve(null);
        }
      });
    }
  }

  updateForm() {
    const phone = this.profile?.numMobile?.trim().substring(3, this.profile.numMobile?.trim().length);
    const phoneWithPref = phone ? '0' + phone : ''
    const indicator = phone ? this.profile?.numMobile?.trim().substring(0, 3) : '+33';

    this.identification.controls['indicator'].setValue(indicator);
    this.identification.controls['telephone'].setValue(phoneWithPref);
    this.identification.controls['email'].setValue(this.profile?.email);
    this.identification.controls['username'].setValue(this.login);
    this.hiddenPhone = hideTel(phoneWithPref);
    this.hiddenMail = hideEmail(this.profile?.email);
    this.indicator = indicator;

  }
  //get form value 
  onChange() {
    this.updatedInfo = this.identification.value;
    const newPhone = this.updatedInfo?.telephone;
    const indicator = this.updatedInfo?.indicator;
    const formatted = newPhone.replace(/^0+/, '');
    this.updatedInfo.telephone = indicator + formatted
    if (this.controlData) {
      this.controlData.phone = this.updatedInfo.telephone;
      this.controlData.email = this.updatedInfo.email;
    }

  }

  private retreiveUsernameFromStore() {
    this.store.select(selectAppState)
      .pipe(takeUntil(this.ngDestroyed$), distinctUntilChanged())
      .subscribe((data) => {
        if (data.ancienPls?.loginUpi && !data.vialinkstatus) {
          this.profile = data.ancienPls;
          this.login = data.ancienPls.loginUpi;

          this.updateForm()
        } else {
          console.error("ERROR Login or TiTULAIRE not FOUND");
        }
      });

  }

  checkForData() {
    setTimeout(() => {
      if (!this.profile) {
        this.router.navigateByUrl('login', { replaceUrl: true })
      }
    }, 400)
  }
  /**
  * Vialink upload check if mail and number not null
  */
  onclickUpload() {
    this.submitted = true;
  }
  /**
   * on vialink score is valid >90%
   */

  onSuccess(event: boolean) {
    // event ==true=> score Vialink >90%
    // event = false ==>score Vialink < 90%     
    if (event) {
      console.log("event on Success ", event);

      this.sentMailToConfirm();

    }

    else {
      // 
      setTimeout(() => {
        showModal('general.warning.alert', ['general.warning.kyc.alert'], 'general.bouton.fermer', this.modal, 'login')
      }, 500)
    }
  }
  onFailureUpload() {
    //tur on submit to show form Errors
    this.submitted = true;

  }

  onFormSubmit() {
    if (this.isMailPhoneEdit) {
      this.submitted = true;
      this.messageService.clear();
      if (this.identification.invalid) {

        Object.keys(this.identification.controls).forEach(key => {
          const control = this.identification.get(key);

          console.log(`conrol ${key} validity ${control?.errors}`);
        })

        return;
      }      //Verify Identity of User  
      this.messageService.clear();
      this.messages = [];
      this.sentMailToConfirm();
    }


  }



  sentMailToConfirm() {

    let lang: string = localStorage.getItem('lang') ?? 'fr'
    this.bffService.sendEmailWithToken(this.login, this.buttonChoice, lang)
      .subscribe((response: Email) => {
        if (response) {
          this.storageService.setItem('login', this.login)
          this.onClick.emit();

        } else {
          console.error("no email were sent");

        }

      })
  }
  getParamNumberCode() {
    const paramName = "TEL_INDICATIF_AUTORISE";
    //handle cache
    let key = 'numberCode';
    this.bffService.getParametreSite(0, paramName).subscribe(
      (reponse) => {
        this.numberCode = reponse;
        //Save Data to cache
        sessionStorage.setItem(key, JSON.stringify(reponse))
      })
  }

  onChangeIndic(event: any) {
    if (event.target.value) {
      this.identification.get("telephone")?.setValue("");
    }
  }

  editContactData() {
    //HIDE ViaLink access
    // this.router.navigate(['contact-us/form-call'], { replaceUrl: true });
    if (this.buttonChoice !== 'firstconnexion') {
      this.router.navigate(['contact-us/form-call'], { replaceUrl: true });

    } else {
      this.editVialink = false;

    }
  }

  get isMailPhoneEdit(): boolean {
    return !!this.profile?.email && !!this.profile?.numMobile;
  }

  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }
}