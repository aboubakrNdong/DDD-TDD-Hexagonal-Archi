import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavigationExtras, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { ReCaptchaV3Service } from 'ngx-captcha';
import { Subject, takeUntil } from 'rxjs';
import { ReCAPTCHA } from 'src/app/entity/captcha-v3';
import { LoginRequestPls } from 'src/app/entity/login-requestpls';
import { UserAccess } from 'src/app/entity/user';
import { UserAccessPls } from 'src/app/entity/userAccessPls';
import { ExternalsService } from 'src/app/services/externals.service';
import { MessageService } from 'src/app/services/message.service';
import { StorageService } from 'src/app/services/storage-service';
import { getAncienPls } from 'src/app/store/actions/app.action';
import { AppState } from 'src/app/store/reducers/app.reducer';
import { getFormValidationErrors, noWitespaceValidator, showModal } from 'src/app/utils/functions';
import { environment } from 'src/environments/environment';



@Component({
  selector: 'app-oldaccount',
  templateUrl: './oldaccount.component.html',
  styleUrls: ['./oldaccount.component.css']
})
export class OldaccountComponent implements OnInit {
  @Input() buttonChoice: any = null;
  @Output() onClick = new EventEmitter<any>();
  ngDestroyed$ = new Subject<void>();

  oldLoginForm!: FormGroup;
  showOldPls = false;
  messages: string[] = [];
  submitted = false;
  mockCode: any;
  user: UserAccess;
  userPls: UserAccessPls;

  isCredentials = false;

  constructor(private fb: FormBuilder,
    private store: Store,
    private reCaptchaV3Service: ReCaptchaV3Service,
    public messageService: MessageService,
    private externalsService: ExternalsService,
    private modal: NgbModal,
    private router: Router,
    private storageService:StorageService
  ) { }

  ngOnInit(): void {

    console.log("buttonchoice" + this.buttonChoice);
    if (this.buttonChoice === "oldolis") {
      this.mockCode = "K1171608F24";
    }
    if (this.buttonChoice === "oldpls") {
      this.showOldPls = true;
      this.mockCode = "";
    }
    this.createoldLoginForm();
    this.handlePLSSuccess();

  }



  handlePLSSuccess() {
    this.store.select((state: any) => state.form)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data: AppState) => {
        console.log("data", data);
 
         if (data?.ancienPls) {
          this.storageService.setItem('controlData', JSON.stringify(data.ancienPls));
          this.onClick.emit();

        } else {
          console.error("data.user NOT FOUND");

        }
      })
  }

  createoldLoginForm() {
    this.oldLoginForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(9), Validators.pattern("^[0-9]*$"),], noWitespaceValidator()],
      code: [this.mockCode, Validators.required, noWitespaceValidator()],
      password: ['', Validators.required],
    });
  }

  submitLoginButton() {
    this.submitted = true;
    if (this.oldLoginForm.invalid) {
      getFormValidationErrors(this.oldLoginForm)
      return;
    }

    this.reCaptchaV3Service.execute(environment.siteKeyCaptchaV3, 'OldAccount', (token) => {
      if (token) {
        this.verifyRecaptcha(token, 'v3');
      } else {
        console.error('Échec de recupération du Token');
      }
    }, {
      useGlobalDomain: false
    });
  }


  verifyRecaptcha(token: string, version: string): void {
    this.externalsService.verifyRecaptcha(token, version).subscribe(
      (response: ReCAPTCHA) => {
        if (response?.success) {
          // Le reCAPTCHA est valide, utilisez le score  
          if (this.buttonChoice === "oldolis") {
            // this.verifyAncienOlisAccount();
          }
          if (this.buttonChoice === "oldpls") {
            this.verifyAncienPlsAccount();
          }
        }
        else {
          this.onError();
        }
      }
    );

  }


  verifyAncienPlsAccount() {
    let loginRequestPls: LoginRequestPls =
    {
      emetIden: this.oldLoginForm.value.username,
      accessCode: this.oldLoginForm.value.code.trim(),
      password: this.oldLoginForm.value.password
    }


    this.store.dispatch(getAncienPls({ loginRequestPls })) //Add action to handle failure

  }

  onError(route?: string) {
    showModal('general.warning.error', ['captcha.v3.error'], 'general.bouton.fermer', this.modal, route);
  }
  get username(): AbstractControl {
    return this.oldLoginForm.get('username')!;
  }

  get code(): AbstractControl {
    return this.oldLoginForm.get('code')!;
  }

  goBack() {
    const navExtras: NavigationExtras = {
      state: { activeTab: 'firstConnexion' },
      replaceUrl: true
    }
    this.router.navigate(['login'], navExtras)

  }


  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }

}
