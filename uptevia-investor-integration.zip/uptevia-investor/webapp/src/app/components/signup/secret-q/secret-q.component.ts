import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable, Subject, map, takeUntil } from 'rxjs';
import { FetchSecretQuestions } from 'src/app/entity/fetchsecret-questions';
import { Profil } from 'src/app/entity/profil';
import { SecretQuestions } from 'src/app/entity/secret-questions';
import { Titulaire } from 'src/app/entity/titulaire';
import { TokenLogin } from 'src/app/entity/token-password';
import { UserAccess } from 'src/app/entity/user';
import { OnboardingSteps } from 'src/app/entity/vialink/onboarding-steps';
import { BffService } from 'src/app/services/bff.service';
import { LoginService } from 'src/app/services/login.service';
import { MessageService } from 'src/app/services/message.service';
import { StorageService } from 'src/app/services/storage-service';
import { fetchSecretQuestions, saveSecretQuestions } from 'src/app/store/actions/app.action';
import { selectAppState } from 'src/app/store/selectors/app.selector';



@Component({
  selector: 'app-secret-q',
  templateUrl: './secret-q.component.html',
  styleUrls: ['./secret-q.component.css']
})
export class SecretQComponent implements OnInit {

  formName = 'secretq';
  secretq: FormGroup;
  selectedNames1: string[] = [];
  selectedNames2: string[] = [];
  secretQuestions: any[];
  submitted = false;
  hide: boolean = true;
  @Input() continueLogin: boolean;
  @Input() userInput: UserAccess;
  @Output() onClick = new EventEmitter<any>();
  @Output() onFailure = new EventEmitter<any>();
  @Input() buttonChoice: any = null;
  @Input() tokenLogin: TokenLogin;

  ngDestroyed$ = new Subject<void>();

  cacheData: any;
  updateSuccess: boolean;
  messages: string[] = [];
  formatUsername: any;
  formatPassword: any;
  titulaire: Profil;
  user: UserAccess;
  loginError: boolean = false;


  idQuestion1: any;
  idQuestion2: any
  tokenLoginPls: TokenLogin
  login: any;
  secretquestions$: Observable<FetchSecretQuestions[]>;
  mobileNum: any;
  constructor(private formBuilder: FormBuilder,
    private messageService: MessageService,
    private bffService: BffService,
    private loginService: LoginService,
    private storageService: StorageService,
    private router: Router,
    private store: Store,) { }

  ngOnInit(): void {
    this.login = this.storageService.getItem('login');

    this.createForm();
    this.getSecret();
    console.log("buttonChoice on init " , this.buttonChoice);
    this.retreiveSignUpDataFromStore();
  }

  onSelectChange(questionKey: string, controlName: string) {
    this.secretquestions$
      .pipe(
        takeUntil(this.ngDestroyed$),
        map((questions: FetchSecretQuestions[]) => questions.find(question => question.questionKey === questionKey))
      )
      .subscribe((selectedQuestion: FetchSecretQuestions | undefined) => {
        if (selectedQuestion) {
          this.handleSelectedQuestion(selectedQuestion, controlName);
        }
      });
  }

  private handleSelectedQuestion(selectedQuestion: FetchSecretQuestions, controlName: string) {
    if (controlName === 'questionOneList') {
      this.idQuestion1 = selectedQuestion.idQuestion;
    } else if (controlName === 'questionTwoList') {
      this.idQuestion2 = selectedQuestion.idQuestion;
    }
    this.secretq.get(controlName)?.setValue(selectedQuestion.questionKey);
  }


  private retreiveSignUpDataFromStore() {
    this.store.select(selectAppState)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {

        this.mobileNum = data?.ancienPls?.numMobile;
         
        if (data?.isOldPlsCompleted === true) {
          console.log("onClick");

          this.onClick.emit();
        } else if (data?.isOldPlsCompleted === false) {
          //KYC incomplete upload document
          console.log("onFailure");

          this.onFailure.emit(OnboardingSteps.ONBOARDING_COMPLETED);
        }
      });
  }

  createForm() {
    this.secretq = this.formBuilder.group({
      questionOneList: ['', Validators.required],
      responseOne: ['', [Validators.required, Validators.minLength(3)]],
      questionTwoList: ['', Validators.required],
      responseTwo: ['', [Validators.required, Validators.minLength(3)]],
    });
  }

  getSecret() {
    this.store.dispatch(fetchSecretQuestions());
    this.secretquestions$ = this.store.select((state: any) => state.form.questions);
  }


  onFormSubmit() {
    this.submitted = true;
    if (this.secretq.invalid) {
      console.log("invalid");
      return;
    }

    this.messageService.clear();

    let lang: string = localStorage.getItem('lang') ?? 'fr'

    const saveSecret: SecretQuestions = {
      login: this.login,
      firstQuestion: this.idQuestion1,
      firstAnswer: this.secretq.value.responseOne,
      secondQuestion: this.idQuestion2,
      secondAnswer: this.secretq.value.responseTwo,
      buttonChoice: this.buttonChoice,
      lang: lang,
    };

    
      if (this.continueLogin) {
        this.saveSecretQuestions(saveSecret);
        return;
      }

      this.store.dispatch(saveSecretQuestions({ secretQuestions: saveSecret }))
   

  }

 
  saveSecretQuestions(saveSecret: SecretQuestions) {
    // in case user missing secret question 
    //save question and continue login
    this.bffService.saveSecretQuestions(saveSecret).subscribe(res => {
      if (res) {

        this.checkAndSendSmS()

      }
    }
    )
  }

  checkAndSendSmS() {
    this.storageService.setItem('token', this.userInput.token);
    localStorage.setItem('user', JSON.stringify(this.userInput));

    this.loginService.getTitulaire( )
      .subscribe((titulaire: Profil) => {
        if (titulaire) {
          this.storageService.setItem('titulaire', JSON.stringify(titulaire));
          this.router.navigate(['dashboard'])

        }
      })
  }

  goToContact() {
    this.router.navigate([`contact-us/form-call`]);
  }

  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }
}