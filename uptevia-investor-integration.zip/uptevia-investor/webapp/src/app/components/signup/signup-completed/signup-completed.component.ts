import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { clearData } from 'src/app/store/actions/app.action';
import { showModal } from 'src/app/utils/functions';



@Component({
  selector: 'app-signup-completed',
  templateUrl: './signup-completed.component.html',
  styleUrls: ['./signup-completed.component.css']
})
export class SignupCompletedComponent implements OnInit {


  @Input() login: string;
  ON_ERROR_ROUTE = 'login'
  
  ngDestroyed$ = new Subject<void>();


  constructor(private router: Router,
    private modal: NgbModal,
    private store: Store,) { }

  ngOnInit(): void {

    if (!this.login) {
      showModal('general.warning.error', ['form.field.validator.mail.invalid'], 'general.bouton.fermer', this.modal, this.ON_ERROR_ROUTE)
    }
    // check if kyc is complete or not (kyc return from data base)
  }
 

  gotoLogin() {
    this.store.dispatch(clearData());
    this.router.navigateByUrl('login', { replaceUrl: true })
  }

 
  
 


  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }

}
