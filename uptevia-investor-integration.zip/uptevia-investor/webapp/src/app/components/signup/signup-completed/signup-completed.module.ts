import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { SignupCompletedComponent } from './signup-completed.component';



@NgModule({
  declarations: [SignupCompletedComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule, 
    UpteviaLibModule,
  
  ],
  exports:[SignupCompletedComponent],
  bootstrap:[SignupCompletedComponent]
})
export class SignuCompletedModule { }
