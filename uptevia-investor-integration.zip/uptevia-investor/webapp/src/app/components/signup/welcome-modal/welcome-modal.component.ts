import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Titulaire } from 'src/app/entity/titulaire';
import { BffService } from 'src/app/services/bff.service';
import { EAbonnement } from 'src/app/entity/e-abonnement';
import { CguComponent } from '../../cgu/cgu.component';
import { CGU } from 'src/app/entity/cgu';
import { StorageService } from 'src/app/services/storage-service';
import { Store } from '@ngrx/store';
import { getTitulaire } from 'src/app/store/actions/app.action';
import { AppState } from 'src/app/store/reducers/app.reducer';
import { Profil } from 'src/app/entity/profil';


@Component({
  selector: 'app-welcome-modal',
  templateUrl: './welcome-modal.component.html',
  styleUrls: ['./welcome-modal.component.css']
})
export class WelcomeModalComponent implements OnInit {

  formName = 'welcome';
  welcome: FormGroup;
  submitted = false;
  userChoice = 0;


  constructor(public activeModal: NgbActiveModal,
    private modal: NgbModal,
    private formBuilder: FormBuilder,
    private storageService: StorageService,
    private store: Store,
    private bffService: BffService,) {
  }

  ngOnInit(): void {
    this.createWelcomeForm();
    this.userChoice = this.welcome.get('slidereservice')?.value ? 1 : 0;
  }

  createWelcomeForm() {
    this.welcome = this.formBuilder.group({
      slidereservice: [true],
      slidercondition: [false, Validators.requiredTrue]
    });
  }

 

  openCGU() {
    console.log("open cgu clicked");
    this.modal.open(CguComponent, { size: 'xl' });
  }
  
  onChangeChoice(event: Event) {
    const isChecked = (<HTMLInputElement>event.target).checked;
    console.log(isChecked)
    this.userChoice = isChecked ? 1 : 0;
  }

  onFormSubmit() {
    this.submitted = true;
    if (this.welcome.invalid) {
      return;
    }

    this.activeModal.dismiss();

    const cgu: CGU = {
      choix: this.userChoice.toString(),
    };
    this.acceptCGU(cgu);
    const eAbonnement: EAbonnement = {
      param_choix: this.userChoice.toString(),
    };

    // Send userChoice ...
    this.sendDataToServer(eAbonnement);
  }
  private acceptCGU(cgu: CGU) {
    //save CGU acceptance
    if (this.welcome?.value?.slidercondition) {
      this.bffService.cguAcceptance(cgu).subscribe(
        () => {
          this.store.dispatch(getTitulaire());
        },
        (error: any) => {
          console.error('Erreur lors du traitement');
        });
    }
  }


  sendDataToServer(data: EAbonnement) {
    this.bffService.insertEabonnement(data).subscribe(
      (response: any) => {
        if (response) {
          console.log('Demande crée avec succés!!', response);
        }
      },
      (error: any) => {
        console.error('Erreur lors de l\'enregistrement', error);
      });
  }
}
