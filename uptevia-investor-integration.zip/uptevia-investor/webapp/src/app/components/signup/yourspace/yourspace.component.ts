import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-yourspace',
  templateUrl: './yourspace.component.html',
  styleUrls: ['./yourspace.component.css']
})
export class YourSpaceComponent {

  finalEmail: any;
  @Output() onClick = new EventEmitter<any>()
  submitted = false;
  ngDestroyed$ = new Subject<void>();
  @Input() buttonChoice: string;

  constructor(private router: Router) { }

  gotoContact() {
    this.router.navigateByUrl('contact-us/form-call', { replaceUrl: true });
  }

  ngOnDestroy() {
    this.ngDestroyed$.next();
    
    this.ngDestroyed$.complete();
  }
}
