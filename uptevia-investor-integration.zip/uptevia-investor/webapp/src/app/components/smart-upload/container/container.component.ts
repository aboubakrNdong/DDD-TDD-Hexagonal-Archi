import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ControlData } from 'src/app/entity/vialink/control';
import { FileListComponent } from '../file-list/file-list.component';
import { UploadBoxComponent } from '../upload-box/upload-box.component';

@Component({
  selector: 'smart-upload-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.css']
})
export class SmartUploadContainer {
  @Input() data: ControlData;
  //these input is used in file list component 
  @Input() requestedFiles: any[] = [];
  @Output() onSuccess: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() onFailure: EventEmitter<any> = new EventEmitter<any>();
  @Input() isUploadReady: boolean = false;
  @ViewChild('smartBox') smartBox: UploadBoxComponent;
  @ViewChild('smartList') smartList: FileListComponent;
  files: any;

  constructor(
    private router: Router
  ) { }

  onfileChange(event: any) {
    this.files = event;

  }
  onDeleteClick() {
    this.smartBox.deletedAndupload();
  }

  getFileType(event: any) {
    console.log("event ", event);

    if (event?.isSame) {
      this.smartList.isSameTypeError = event;

    }
  }

  onUploadFinished(event: boolean) {
    if (event) {
      console.log('event complete ', event);
      this.smartBox.uploadComplete = true;
      this.smartBox.uploadDone = false;
      this.smartBox.failed = false;
    }
  }
  goToContact() {
    this.router.navigate([`contact-us/form-call`]);
  }
  onSuccessEvent(event: any) {
    this.onSuccess.emit(event)
  }
  onFailureEvent() {
    this.onFailure.emit();
  }

}