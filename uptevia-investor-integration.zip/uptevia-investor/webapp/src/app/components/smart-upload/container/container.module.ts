import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { DirectiveModule } from 'src/app/directives/directives.modules';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { SmartUploadContainer } from './container.component';
import { UploadBoxModule } from '../upload-box/upload-box.module';
import { ValidationFailedModule } from '../doc-validation-fail/doc-validation-failed.module';
import { FileListModule } from '../file-list/file-list.module';



@NgModule({
    declarations: [SmartUploadContainer],
    imports: [
        CommonModule,
        FormsModule,
        RouterModule,
        UpteviaLibModule,
        DirectiveModule,
        UploadBoxModule,
        ValidationFailedModule,
        FileListModule
    ],
    exports: [SmartUploadContainer],
    bootstrap: [SmartUploadContainer]
})
export class SmartUploadContainerModule { }
