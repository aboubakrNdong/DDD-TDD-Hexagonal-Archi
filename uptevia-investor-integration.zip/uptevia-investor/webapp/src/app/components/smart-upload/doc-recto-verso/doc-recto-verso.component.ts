import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'smart-upload-recto-verso',
  template: `
  <div>
  <img src="assets/images/pictos/upload-doc-done.svg" alt="">
  <h3 [innerHTML]="'smartupload.file.uploaded' | translate"></h3>
  <div>
    <p [innerHtml]="trad | translate "> </p>
    <uptevia-ui-button size="medium" color="tertiary" (onClick)="onClick.emit()"
      label="{{buttonLabel | translate}}"></uptevia-ui-button>
  </div>
</div>
  `,
  styleUrls: ['./doc-recto-verso.component.css']
})
export class DocRectoVersoComponent implements OnInit {

  @Input() recto: boolean = false;
  @Output() onClick = new EventEmitter()
  trad: string = 'smartupload.missing.recto.add';
  buttonLabel = 'smartupload.button.recto.add';
  constructor(
  ) { }
  ngOnInit(): void {
    console.log('Input recto ', this.recto);
    
    if (this.recto) {
      this.trad = 'smartupload.missing.verso.add'
      this.buttonLabel = 'smartupload.button.verso.add';
    }
  }



}