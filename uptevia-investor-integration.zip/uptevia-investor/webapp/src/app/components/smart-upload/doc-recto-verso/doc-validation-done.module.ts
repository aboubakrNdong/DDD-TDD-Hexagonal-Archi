import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { DocRectoVersoComponent } from './doc-recto-verso.component';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { DirectiveModule } from 'src/app/directives/directives.modules';



@NgModule({
  declarations: [DocRectoVersoComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,  
    UpteviaLibModule,
    DirectiveModule
  ],
  exports:[DocRectoVersoComponent],
  bootstrap:[DocRectoVersoComponent]
})
export class DocRectoVersoModule { }
