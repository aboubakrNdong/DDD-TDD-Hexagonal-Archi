import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'smart-upload-validation-done',
  templateUrl: './doc-validation-done.component.html',
  styleUrls: ['./doc-validation-done.component.css']
})
export class DocValidationComponent {

  @Input() remain: number=1
  @Output() onClick = new EventEmitter();
  constructor(
  ) { }



}