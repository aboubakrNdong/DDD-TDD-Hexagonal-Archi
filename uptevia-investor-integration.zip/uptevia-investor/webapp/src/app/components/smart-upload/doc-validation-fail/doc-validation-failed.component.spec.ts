import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocValidationFailedComponent } from './doc-validation-failed.component';

describe('DocValidationFailedComponent', () => {
  let component: DocValidationFailedComponent;
  let fixture: ComponentFixture<DocValidationFailedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DocValidationFailedComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(DocValidationFailedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
