import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'smart-upload-validation-failed',
  templateUrl: './doc-validation-failed.component.html',
  styleUrls: ['./doc-validation-failed.component.css']
})
export class DocValidationFailedComponent implements OnInit {

  @Output() onClick = new EventEmitter<any>()
  @Input() isSameType: boolean = false
  title = 'smartupload.failed.upload';

  ngOnInit(): void {
    if (this.isSameType) {
      this.title = 'smartupload.doc.alreadyUploaded';
    }
  }


}