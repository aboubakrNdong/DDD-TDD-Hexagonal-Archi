import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { UpteviaLibModule } from '../../uptevia-lib.module';
import { DirectiveModule } from 'src/app/directives/directives.modules';
import { DocValidationFailedComponent } from './doc-validation-failed.component';



@NgModule({
  declarations: [DocValidationFailedComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    UpteviaLibModule,
    DirectiveModule
  ],
  exports: [DocValidationFailedComponent],
  bootstrap: [DocValidationFailedComponent]
})
export class  ValidationFailedModule { }
