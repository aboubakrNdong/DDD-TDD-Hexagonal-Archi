import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { DocValidationComponent } from './doc-validation.component';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { DirectiveModule } from 'src/app/directives/directives.modules';



@NgModule({
  declarations: [DocValidationComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,  
    UpteviaLibModule,
    DirectiveModule
  ],
  exports:[DocValidationComponent],
  bootstrap:[DocValidationComponent]
})
export class DocValidationModule { }
