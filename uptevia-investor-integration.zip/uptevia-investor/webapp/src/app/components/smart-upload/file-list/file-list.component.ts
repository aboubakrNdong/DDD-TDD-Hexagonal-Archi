import { Component, EventEmitter, Input, Output, OnInit, SimpleChanges } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { All_FILES_TYPES } from 'src/app/utils/const-vars';
import { FilePreviewComponent } from '../file-preview/file-preview.component';
import { Files } from 'src/app/entity/vialink/document-input';
import { FileType } from 'src/app/entity/vialink/enum-file-type';
import { DocumentUpload } from 'src/app/entity/vialink/docmuent-sumbitted';

@Component({
  selector: 'smart-upload-list',
  templateUrl: './file-list.component.html',
  styleUrls: ['./file-list.component.css']
})
export class FileListComponent implements OnInit {
  // data: DocumentUpload + fileList + file
  @Input() files: Files[] = [];
  @Input() isSameTypeError: any;//{ isSame: boolean , id: number }
  @Output() onDelete: EventEmitter<any> = new EventEmitter<any>();
  @Output() uploadDone: EventEmitter<any> = new EventEmitter<any>();

  @Input() requestedFiles: any[] = [];

  requestedFilesTemp: any = [];
  allFileTypes = All_FILES_TYPES;
  constructor(private modal: NgbModal
  ) { }
  ngOnInit(): void {
    this.requestedFilesTemp = this.requestedFiles;
    console.log("this.is same error", this.isSameTypeError);

  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.files?.currentValue) {
      this.onListCHange(changes.files?.currentValue);
    }
  }

  deleteFile() {
    this.onDelete.emit();
  }

  get isConform(): (file: any) => boolean {
    return (file: DocumentUpload) => {

      return this.allFileTypes.some(element => element.type === file.type || element.type === file.subType);
    }
  }

  get isFileComplete(): (file: Files) => boolean {

    return (file: Files) => {
      const items = this.files.filter(element => element.type === file.type)
      const needRectoVero = items.some(file => file.type === FileType.STATE_ID || file.type === FileType.RESIDENCE_PERMIT)
      if (!this.isConform(file) || !needRectoVero) {
        //no need to check recto verso when when file is not conform
        return true;
      }
      const hasRectoVerso = items.some(file => file.subType === `${file.type}_RECTO_VERSO`);
      return needRectoVero && hasRectoVerso
    }

  }

  get missingDoc(): (file: Files) => string {
    return (file: Files) => {
      let trad = 'smartupload.missing.recto'
      if (file.subType.includes('RECTO')) {
        trad = 'smartupload.missing.verso'
      }

      return trad;
    }
  }
  openPreview(element: Files) {
    const modalRef = this.modal.open(FilePreviewComponent, { windowClass: "custom-modal-size" });
    let filesPreview = [element.file];
    if (element.file2) {
      filesPreview.push(element.file2)
    }

    modalRef.componentInstance.fileToPreview = filesPreview;
  }

  onListCHange(fileList: Files[]) {
    const index = fileList[fileList.length - 1];
    if (fileList && this.isConform(index) && this.isFileComplete(index)) {
      this.requestedFilesTemp = this.requestedFilesTemp.filter((file: any) => !fileList.some((element: any) => file?.type.some((type: any) => type === element.type || type === element.subType)));
      if (this.requestedFilesTemp.length === 0) {
        this.uploadDone.emit(true);
      }
    }
  }

}