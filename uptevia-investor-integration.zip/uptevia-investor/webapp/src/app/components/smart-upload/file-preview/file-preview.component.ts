import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { PdfViewerComponent, PdfViewerModule } from 'ng2-pdf-viewer';

@Component({
  selector: 'smart-upload-file-preview',
  templateUrl: './file-preview.component.html',
  styleUrls: ['./file-preview.component.css'],
  providers: [PdfViewerModule]
})
export class FilePreviewComponent implements OnInit {
  @ViewChild(PdfViewerComponent, { static: false })
  private pdfComponent: PdfViewerComponent;
  @Input() fileToPreview: File[];
  files: string[];
  page: any = 1;
  hidePdf = true;
  constructor(
    private activeModal: NgbActiveModal
  ) { }
  ngOnInit(): void {

    this.readFiles(this.fileToPreview).then(res => {
      this.files = res;
    }, err => {
      console.error('ERROR CONVERTING IMAGES');
    });
  }

  close() {
    this.activeModal.dismiss();
  }


  readFiles(files: File[]) {
    let promises: Promise<string>[] = [];
    for (const file of files) {
      promises.push(this.readFile(file));
    }
    return Promise.all(promises);
  }

  private readFile(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event: any) => {
        resolve(event.target.result)
      }
      reader.onerror = (error: any) => {
        reject(error)
      }
      reader.readAsDataURL(file);

    })
  }



}