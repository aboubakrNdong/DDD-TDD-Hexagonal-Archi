import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { FilePreviewComponent } from './file-preview.component';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { NgxPaginationModule } from 'ngx-pagination';
import { UpteviaLibModule } from '../../uptevia-lib.module';


@NgModule({
  declarations: [FilePreviewComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule, 
    PdfViewerModule,
    UpteviaLibModule,
    NgxPaginationModule,

  ],
  exports:[FilePreviewComponent],
  bootstrap:[FilePreviewComponent]
})
export class FilePreviewModule { }
