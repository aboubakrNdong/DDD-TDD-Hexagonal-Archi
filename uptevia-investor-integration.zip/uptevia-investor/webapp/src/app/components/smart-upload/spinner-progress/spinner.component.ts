import { Component, OnInit } from '@angular/core';
import { Subject, Subscription, interval } from 'rxjs';

@Component({
    selector: 'smart-upload-spinner',
    template: `
    <div>
    <svg viewBox="-10 -10 120 120"  style="height:100px">
        <circle cx="50" cy="50" r="50" fill="none" stroke="#CED4DA" stroke-width="10"></circle>
        <circle cx="50" cy="50" r="50" fill="none" stroke="#95C11F" stroke-width="10" [style.strokeDasharray]="circumference"
            [style.strokeDashoffset]="dashOffset" transform="rotate(-90 50 50)"></circle>
        <text x="50" y="50" text-anchor="middle" alignment-baseline="central" font-size="20" fill="#00566F" font-weight="bold"> {{progress.toFixed(0) }}%</text>
    </svg>

</div>
  
  `,
})
export class SpinnerComponent implements OnInit {

    progress: number = 0;
    duration: number = 30;
    remainingTime: number = this.duration;
    circumference: number = Math.PI * 2 * 50; //circumference of circle
    dashOffset: number = this.circumference
    interval$: Subscription | undefined;
    ngDestroyed$ = new Subject<void>();
    constructor() { }
    ngOnInit(): void {

        this.interval$ = interval(100).subscribe(() => {
            this.updateProgress();
        })
         
    }
    updateProgress() {
        this.remainingTime -= 0.1;
        this.progress = ((this.duration - this.remainingTime) / this.duration) * 100
        if (this.progress >= 100) {
            this.progress = 100;
            if (this.interval$) {
                this.interval$.unsubscribe();
            }

        }
         
        this.dashOffset = this.circumference * (1 - this.progress / 100);
    }

   
    ngOnDestroy() {
        if (this.interval$) {
            this.interval$.unsubscribe();
            this.ngDestroyed$.unsubscribe();
        }

    }


}