import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { SpinnerComponent } from './spinner.component';


@NgModule({
    declarations: [SpinnerComponent],
    imports: [
        CommonModule,
        UpteviaLibModule,

    ],
    exports: [SpinnerComponent],
    bootstrap: [SpinnerComponent]
})
export class SpinnerModule { }
