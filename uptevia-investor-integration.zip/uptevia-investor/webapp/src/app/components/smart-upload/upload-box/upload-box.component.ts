import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { delay } from 'rxjs';
import { ControlData } from 'src/app/entity/vialink/control';
import { ControlStatus } from 'src/app/entity/vialink/control-status';
import { DocumentUpload } from 'src/app/entity/vialink/docmuent-sumbitted';
import { Files } from 'src/app/entity/vialink/document-input';
import { FileType } from 'src/app/entity/vialink/enum-file-type';

import { ExternalsService } from 'src/app/services/externals.service';
import { LoaderService } from 'src/app/services/loader.service';
import { controlViaLinkUpdate, submitControl, updateVialinkStatus } from 'src/app/store/actions/app.action';
import { selectAppState } from 'src/app/store/selectors/app.selector';
import { All_FILES_TYPES } from 'src/app/utils/const-vars';
import { showModal } from 'src/app/utils/functions';

@Component({
  selector: 'smart-upload-box',
  templateUrl: './upload-box.component.html',
  styleUrls: ['./upload-box.component.css']
})
export class UploadBoxComponent implements OnInit {
  files: Files[] = [];
  @Input() data: ControlData;
  @Output() onChange = new EventEmitter<any>();
  @Output() onSameType = new EventEmitter<any>();
  @Output() onSuccess = new EventEmitter<any>();
  @Output() onFailure: EventEmitter<any> = new EventEmitter<any>();
  @Input() isUploadReady: boolean = true;
  vialinkControl: ControlStatus;
  //flag to display upload done component  
  public uploadDone = false;
  public uploadComplete = false
  //flag to display loading component  
  public loading = false;
  public failed = false;
  newFile: any;
  allFileTypes = All_FILES_TYPES;
  nonConformFile: Files;
  isMissingSheet: boolean = false;
  isRecto = false;
  existingDoc: string;
  fileTypeExist: boolean = false;
  constructor(
    private store: Store,
    private modal: NgbModal,
    private externalsService: ExternalsService,
    private loaderService: LoaderService
  ) {
    this.loaderService.isVialink.subscribe((loading) => {
      this.loading = loading;
    });
  }
  ngOnInit(): void {
    this.store.select(selectAppState)
      .subscribe(result => {
        if (result?.controlViaLink) {
          if (result.controlViaLink?.status === "DONE") {
            this.onSuccess.emit(result?.controlViaLink?.score === 100);
            this.uploadComplete = false;
          }
          console.log("result from store ", result);

        }

      })
  }


  /**
     * on file drop handler
     */
  onFileDropped(file: any) {
    if (this.isUploadReady) {
      this.newFile = file[0];
      if (this.files.some((currentFile => this.isSameFile(file[0], currentFile.file)))) {
        console.error("FILE ALREADY EXIST");
        showModal('general.warning.alert', ['smartupload.doc.alreadyExist'], 'general.bouton.fermer', this.modal);
        return;
      }
      if (this.isFileSizeValid(file[0])) {
        console.error("FILE SIZE EXCEED LIMITS");

        return
      }

      if (this.files.length === 0 && !this.vialinkControl) {
        this.createVialinkControl(file);
      }
      else {
        this.smartUploadFile(file[0])
      }
    } else {
      this.onFailure.emit();
    }


  }

  prepareFilesList(event: any) {
    let file = event.target.files[0];
    if (event.target.files && event.target.files.length > 0) {
      const inputElemnt = event.currentTarget;
      this.newFile = file;
      //incase file already exist in list
      if (inputElemnt.files && inputElemnt.files.length > 0) {
        if (this.files.some((currentFile => this.isSameFile(file, currentFile.file)))) {
          console.error("FILE ALREADY EXIST");
          showModal('general.warning.alert', ['smartupload.doc.alreadyExist'], 'general.bouton.fermer', this.modal);
          return;

        }
        //in case file type is not allowed
        if (!this.isFileAlowed(file.type)) {
          console.error("FILE TYPE NOT ALLOWED");
          showModal('general.warning.alert', ['smartupload.error.fileConform'], 'general.bouton.fermer', this.modal);

          return;

        }
        if (this.isFileSizeValid(file)) {
          console.error("FILE SIZE EXCEED LIMITS");

          return
        }


        if (this.files.length === 0 && !this.vialinkControl) {

          this.createVialinkControl(inputElemnt.files)
        }
        else if (this.isMissingSheet) {
          this.smartUploadSheet(inputElemnt.files[0])
        } else {
          this.smartUploadFile(inputElemnt.files[0])
        }
      }
    }
  }



  /**
   * handle file from browsing
   */
  fileBrowseHandler(event: Event) {
    if (this.isUploadReady) {
      this.prepareFilesList(event);
    } else {
      //cannot start upload doc if  parent compoennt  not ready
      this.onFailure.emit();
    }

  }

  //compare two file 
  private isSameFile(file1: File, file2: any): boolean {
    return (file1.name === file2.name && file1.size === file2.size && file1.type === file2.type)
  }
  //compare tow type of file

  private isSameType(doc: DocumentUpload) {
    const identityFiles = ['STATE_ID', 'RESIDENCE_PERMIT', 'PASSPORT']
    let isSame = false;
    if (doc.type === FileType.PASSPORT || doc.type == FileType.ADDRESS_PROOF) {

      isSame = this.files.some((file) => identityFiles.includes(file.type) && file.id !== doc.id);
      console.log("type passport anothe exist ", isSame);

    }
    if (doc.type === FileType.STATE_ID || doc.type === FileType.RESIDENCE_PERMIT) {
      const passportExist = this.files.some(file => file.type === FileType.PASSPORT)
      const hasRectoVerso = this.files.some(file => file.subType === `${doc.type}_RECTO_VERSO` && file.id !== doc.id);
      isSame = passportExist || hasRectoVerso
      

    }
    if (doc.type === FileType.ADDRESS_PROOF) {
      isSame = this.files.some((file) => file.type === doc.type && file.id !== doc.id);
    }
    return isSame;
  }

  get isConform(): (file: any) => boolean {
    return (file: DocumentUpload) => {
      this.nonConformFile = file;

      return this.allFileTypes.some(element => element.type === file.type || element.type === file.subType);

    }
  }

  private isFileSizeValid(file: File): boolean {


    if (file.type === 'application/pdf' && file.size > 1024 * 1024 * 4) {
      showModal('general.warning.error', ['vialink.error.pdf'], 'general.bouton.fermer', this.modal);
      return true;
    }
    if (file.type.includes('image') && file.size > 1024 * 1024 * 12) {
      showModal('general.warning.error', ['vialink.error.image'], 'general.bouton.fermer', this.modal);
      return true;
    }
    return false;
  }

  private isFileAlowed(fileType: string) {
    const allowedFiles = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg'];
    return allowedFiles.includes(fileType);
  }

  private createVialinkControl(file: FileList) {

    this.externalsService.createControls(this.data.verificationKey, this.data.phone, this.data.email)
      .subscribe((result: any) => {
        if (result?.secondToken) {
          this.vialinkControl = result;
          this.smartUploadFile(file[0]);
        }
      }, (err: HttpErrorResponse) => {
        this.store.dispatch(updateVialinkStatus({ status: false }));
        showModal('general.warning.error', [err.error.errorCode], 'general.bouton.fermer', this.modal, 'firstconnexion');
      })
  }

  private smartUploadSheet(file: File) {
    if (this.vialinkControl?.secondToken) {
      this.externalsService.uploadDocumentSheet(this.vialinkControl.secondToken, this.existingDoc, this.isRecto, file)
        .subscribe((res: DocumentUpload) => {
          if (res) {
            this.getAllDoc(file);

          }
        })
    } else {
      console.error("UNVALID SECOND TOKEN");

    }
  }
  private smartUploadFile(file: File) {
    if (this.vialinkControl?.secondToken) {
      this.externalsService.smartUploadDoc(file, this.vialinkControl.secondToken)
        .subscribe((res: DocumentUpload) => {
          if (res?.status === 'UPLOADED' || res?.status === 'UPLOADING') {
            const data: any = res;
            data.file = file;
            this.isRecto = res.subType.includes('RECTO');
            this.files.push(data);
            // update binding to trigger onChanges on smart-upload-list component
            const tempList = [...this.files];
            this.files = tempList;
            //emmit files to be displayed in list
            this.onChange.emit(this.files);
            this.isFileValid(res);
          } else {
            console.error('ERROR WHILE UPLOADING DOC');

          }
        })
    } else {
      console.error("UNVALID SECONDTOKEN");

    }
  }

  private getAllDoc(file2: File) {
    this.externalsService.getControlsDocument(this.vialinkControl.secondToken)
      .subscribe((res: DocumentUpload[]) => {
        const index = this.serachFileBySheet(res, file2.name)
        console.log("adding missing recto or verso ", res[index].subType);

        this.isMissingSheet = !res[index].subType.includes('RECTO_VERSO');
        this.uploadDone = res[index].subType.includes('RECTO_VERSO');
        this.updateFileSheet(res[index], file2)

      })

  }

  serachFileBySheet(doc: DocumentUpload[], fileName: string) {
    for (let i = 0; i < doc.length; i++) {
      let item = doc[i];
      if (item.sheets) {
        for (let sheet of item.sheets) {
          if (sheet.fileName === fileName) {
            return i;
          }
        }
      }
    }
    return 0
  }

  updateFileSheet(fileSheet: DocumentUpload, file: File) {
    const index = this.files.findIndex(file => file.id === fileSheet.id);
    if (index !== -1) {
      this.files[index].sheets = fileSheet.sheets
      this.files[index].file2 = file;
      this.files[index].subType = fileSheet.subType;
      const tempList = [...this.files];
      this.files = tempList;
      //emmit files to be displayed in list 
      this.onChange.emit(this.files);
    }

  }
  private isFileValid(input: DocumentUpload) {

    if (this.isSameType(input)) {
      console.error('DOC TYPE ALREADY EXIST');
      this.fileTypeExist = true;
      this.failed = true;
      this.nonConformFile = input;
      this.onSameType.emit({ isSame: true, id: input.id });
    }
    //check if file exist in list of requested files
    else if (!this.isConform(input)) {
      console.error('DOC NON CONFORME');
      this.failed = true;
    }
    else if (!this.isFileComplete(input)) {
      console.error('MISSING RECTO or VERSO');
      this.uploadDone = false;
      this.failed = false;
      this.isMissingSheet = true;
      this.existingDoc = input.id.toString();
    } else {
      this.uploadDone = true;

    }

  }

  get isFileComplete(): (file: Files) => boolean {

    return (file: Files) => {
      const items = this.files.filter(element => element.type === file.type);
      const needRectoVero = items.some(file => file.type === FileType.STATE_ID || file.type === FileType.RESIDENCE_PERMIT);
      if (!this.isConform(file) || !needRectoVero) {
        //no need to check recto verso  when file is not conform
        return true;
      }

      const hasRectoVerso = items.some(file => file.subType === `${file.type}_RECTO_VERSO`);
      return needRectoVero && hasRectoVerso
    }

  }
  uploadMoreFiles() {
    this.uploadDone = false;

  }

  deletedAndupload() {
    this.externalsService.deleteDoc(this.nonConformFile.id, this.vialinkControl.secondToken)
      .subscribe(() => {
        this.files = this.files.filter(element =>
          element?.file?.name !== this.nonConformFile!.file!.name
        );
        this.onChange.emit(this.files);
        this.failed = false;
        this.uploadDone = false;
        this.fileTypeExist = false;
        this.isMissingSheet = false;
      })

  }

  startAnalyse() {
    console.log("start analyse");
    //this.store.dispatch(submitControl({ secondToken: this.vialinkControl.secondToken, lang: lang }))
    console.log();
    this.submitControl();

  }

  submitControl() {
    this.store.dispatch(updateVialinkStatus({ status: true }));

    this.externalsService.submitControl(this.vialinkControl.secondToken).pipe(
      delay(12000)
    )
      .subscribe((res: { status: string }) => {
        if (res?.status) {
          this.getControlStatus();
        }
      }, (err: HttpErrorResponse) => {
        this.store.dispatch(updateVialinkStatus({ status: false }));
        this.loading = false
        showModal('general.warning.error', [err.error.errorCode], 'general.bouton.fermer', this.modal, 'firstconnexion');
      })
  }

  getControlStatus() {
    let lang: string = localStorage.getItem('lang') ?? 'fr'

    this.externalsService.getControlsStatus(this.vialinkControl.secondToken, lang).pipe(
      delay(2000)
    )
      .subscribe((res: any) => {

        if (res?.status === 'ERROR' || res?.status === 'DONE') {
          this.store.dispatch(controlViaLinkUpdate({ control: res }))
        } else if (res?.status !== 'ERROR' && res?.status !== 'DONE') {
          this.getControlStatus();
        }
      }, (err: HttpErrorResponse) => {
        this.store.dispatch(updateVialinkStatus({ status: false }));
        showModal('general.warning.error', [err.error.errorCode], 'general.bouton.fermer', this.modal, 'firstconnexion');
      })
  }
}