import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { DirectiveModule } from 'src/app/directives/directives.modules';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { DocValidationModule } from '../doc-validation/doc-validation.module';
import { FileListModule } from '../file-list/file-list.module';
import { UploadBoxComponent } from './upload-box.component';
import { ValidationFailedModule } from '../doc-validation-fail/doc-validation-failed.module';
import { DocValidationDoneModule } from '../doc-validation-done/doc-validation-done.module';
import { DocRectoVersoModule } from '../doc-recto-verso/doc-validation-done.module';
import { UploadDoneDoneModule } from '../upload-done/upload-done.module';
import { FilePreviewModule } from '../file-preview/file-preview.module';



@NgModule({
  declarations: [UploadBoxComponent],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    UpteviaLibModule,
    DirectiveModule,
    FileListModule,
    DocValidationModule,
    ValidationFailedModule,
    DocValidationDoneModule,
    DocRectoVersoModule,
    UploadDoneDoneModule,
    FilePreviewModule


  ],
  exports: [UploadBoxComponent],
  bootstrap: [UploadBoxComponent]
})
export class UploadBoxModule { }
