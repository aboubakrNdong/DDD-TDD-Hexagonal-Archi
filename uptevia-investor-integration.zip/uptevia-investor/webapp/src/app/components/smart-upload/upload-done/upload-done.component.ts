import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { selectAppState } from 'src/app/store/selectors/app.selector';
import { MessageService } from 'src/app/services/message.service';

@Component({
  selector: 'smart-upload-done',
  templateUrl: './upload-done.component.html',
  styleUrls: ['./upload-done.component.css']
})
export class UploadDoneComponent implements OnInit {

  @Output() onClick = new EventEmitter();
  start: boolean = false;

  constructor(private store: Store, private messsageService: MessageService) { }
  ngOnInit(): void {
    this.getVialinkStatus();
  }

  startAnalyse() {
    this.onClick.emit();
   // this.start = true
  }

  getVialinkStatus() {
    this.store.select(selectAppState).pipe()
      .subscribe(result => {
        if (result?.vialinkstatus !== undefined) {
          this.start = result.vialinkstatus;
          console.log("vialink status ", result.vialinkstatus);

          console.log("messages", this.messsageService.messages);
        }


      })
  }


}