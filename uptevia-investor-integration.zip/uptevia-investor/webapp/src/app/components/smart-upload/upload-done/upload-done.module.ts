import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { DirectiveModule } from 'src/app/directives/directives.modules';
import { UpteviaLibModule } from '../../uptevia-lib.module';
import { UploadDoneComponent } from './upload-done.component';
import { SpinnerModule } from '../spinner-progress/spinner.module';



@NgModule({
  declarations: [UploadDoneComponent ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,  
    UpteviaLibModule,
    DirectiveModule,
     SpinnerModule
  ],
  exports:[UploadDoneComponent],
  bootstrap:[UploadDoneComponent]
})
export class UploadDoneDoneModule { }
