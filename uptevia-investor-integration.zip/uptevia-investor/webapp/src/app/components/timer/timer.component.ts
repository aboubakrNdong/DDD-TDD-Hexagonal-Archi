import { Component } from "@angular/core";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";

@Component({
    selector: 'app-timer',
    template:`<uptevia-ui-timer   (onClick)="stayConnected()" [pictoSource]="lienPicto"
    [title]="'general.popin.session.title' | translate" [description]="'general.popin.session.message' | translate "
    [iconSource]="iconSource" [buttonLabel]="'general.bouton.resterconnecte' | translate"></uptevia-ui-timer>`
  })

  export class TimeoutComponent {
    lienPicto = "assets/pictos/illustration-popin.svg";
    iconSource = "assets/pictos/profil.svg";
    constructor(private modalActive: NgbActiveModal){}

    stayConnected(){
        this.modalActive.close(true)
    }


  }
