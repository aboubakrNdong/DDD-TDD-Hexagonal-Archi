 
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { TimeoutComponent } from './timer.component';





@NgModule({
    declarations: [TimeoutComponent],
    imports: [
        CommonModule,
        UpteviaLibModule,
    ],
    exports: [TimeoutComponent],
})
export class TimerModule { }
