import { Component } from '@angular/core';
import { Input } from '@angular/core';

@Component({
  selector: 'app-bon-a-savoir',
  templateUrl: './bon-a-savoir.component.html',
  styleUrls: ['./bon-a-savoir.component.css']
})
export class BonASavoirComponent {
  @Input() text: string; 
}
