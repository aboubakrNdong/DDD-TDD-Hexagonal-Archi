import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BonASavoirComponent } from './bon-a-savoir.component';
import { UpteviaLibModule } from 'src/app/components/uptevia-lib.module';

@NgModule({
    declarations: [BonASavoirComponent],
    imports: [
        CommonModule,
        UpteviaLibModule
    ],
    exports: [BonASavoirComponent],
})
export class BonASavoirModule { }
