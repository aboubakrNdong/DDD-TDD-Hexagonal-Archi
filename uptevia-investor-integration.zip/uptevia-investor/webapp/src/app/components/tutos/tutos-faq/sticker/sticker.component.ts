import { Component } from '@angular/core';
import { Input } from '@angular/core';

@Component({
  selector: 'app-sticker',
  templateUrl: './sticker.component.html',
  styleUrls: ['./sticker.component.css']
})
export class StickerComponent {
  @Input() title: string; 
  @Input() text: any; 
}
