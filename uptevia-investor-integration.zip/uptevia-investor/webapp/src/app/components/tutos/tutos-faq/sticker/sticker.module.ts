 import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { StickerComponent } from './sticker.component';

@NgModule({
    declarations: [StickerComponent],
    imports: [
        CommonModule
    ],
    exports: [StickerComponent],
})
export class StickerModule { }
