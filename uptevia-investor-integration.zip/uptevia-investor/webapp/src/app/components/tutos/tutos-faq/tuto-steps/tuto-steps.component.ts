import { Component } from '@angular/core';
import { Input } from '@angular/core';

@Component({
  selector: 'app-tuto-steps',
  templateUrl: './tuto-steps.component.html',
  styleUrls: ['./tuto-steps.component.css']
})
export class TutoStepsComponent {
 @Input() backgroundColor : string;
 @Input() stepNumber : number;
 @Input() titreContent : string;
 @Input() lienImageCentrale? : string; 
 @Input() lienImageCentraleEN? : string;
 @Input() sizeImageCentrale: any;
 @Input() textContent: string;
 @Input() lienImageSite: string;
 @Input() lienImageSiteEN : string; 
 @Input() sizeImageSite : any; 
 @Input() lienImageSiteXL : string;
 @Input() lienImageSiteXLEN : string;
 @Input() lienImageSupplementaireEN : string;
 @Input() arrowLink: string;
 @Input() lienImageSupplementaire?: string; 
 @Input() maxHeight: string;
 @Input() sizeIllustration: string;

 @Input() visibility?: 'hidden' | 'hidden-xs' | 'hidden-lg' | 'visible' = 'visible'
 @Input() disposition : 'blocs' | 'flex-container' | 'flex-container-reversed' = 'blocs'

 public get classes(): string[] {
  let classes= [`${this.visibility}`]
  return classes;
}

// public get classesIllustration(): string[] {
//   let classesIllustration = [`${this.visibilityImageSite}`]
//   return classesIllustration;
// }

public get classesDisposition(): string[] {
  let classesDisposition = [`${this.disposition}`]
  return classesDisposition;
}


}
