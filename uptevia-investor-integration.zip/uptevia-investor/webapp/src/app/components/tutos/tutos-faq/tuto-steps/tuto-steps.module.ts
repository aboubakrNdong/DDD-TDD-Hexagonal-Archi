 
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TutoStepsComponent } from './tuto-steps.component';
import { UpteviaLibModule } from 'src/app/components/uptevia-lib.module';

@NgModule({
    declarations: [TutoStepsComponent],
    imports: [
        CommonModule, 
        UpteviaLibModule
    ],
    exports: [TutoStepsComponent],
})
export class TutoStepsModule { }
