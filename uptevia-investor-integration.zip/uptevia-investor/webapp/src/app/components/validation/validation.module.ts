 
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { UpteviaLibModule } from '../uptevia-lib.module';
import { ValidationComponent } from './validation.component';





@NgModule({
    declarations: [ValidationComponent],
    imports: [
        CommonModule,
        UpteviaLibModule,
    ],
    exports: [ValidationComponent],
})
export class ValidationModule { }