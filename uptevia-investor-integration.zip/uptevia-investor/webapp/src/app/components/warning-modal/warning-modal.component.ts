import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-warning-modal',
  templateUrl: './warning-modal.component.html',
  styleUrls: ['./warning-modal.component.css'],
})
export class WarningModalComponent  {
  @Input() title: string;
  @Input() buttonLabel: string;
  @Input() description: string;
  @Input() route: string


  constructor(
    private router: Router,
    public activeModal: NgbActiveModal) { }
 

  close() {
    if (this.route) {

      this.router.navigateByUrl(this.route, { replaceUrl: true })
    }
    console.log("close modal");

    this.activeModal.dismiss();
  }

  get motif(): (trad: string) => string | undefined {
    return (trad: string) => {
      return trad.split('.').pop()
    }
  }
}
