import { Directive, HostListener } from '@angular/core';

@Directive({
    selector: '[preventCopyPaste]'
})
export class ClipboardEventDirective {

    @HostListener('copy', ['$event'])
    onCopy(event: ClipboardEvent): void {
        event.preventDefault();
    }
    
    @HostListener('paste', ['$event'])
    onPaste(event: ClipboardEvent): void {
        event.preventDefault();
    }

    @HostListener('cut', ['$event'])
    onCut(event: ClipboardEvent): void {
        event.preventDefault();

    }
 

}
