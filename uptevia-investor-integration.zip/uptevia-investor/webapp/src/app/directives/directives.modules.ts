import { NgModule } from '@angular/core';
import { TicksizeDirective } from './ticksize.directive';
import { TooltipDirective } from './tooltip.directive';
import { CurrencyInputDirective } from './currency-input.directive';
import { ClipboardEventDirective } from './clipboard-events-directive';
import { DndDirective } from './drag-and-drop.directive';


@NgModule({
  declarations: [TicksizeDirective, TooltipDirective, CurrencyInputDirective, ClipboardEventDirective,DndDirective],
  exports: [TicksizeDirective,  TooltipDirective, CurrencyInputDirective, ClipboardEventDirective,DndDirective],
})
export class DirectiveModule {}
