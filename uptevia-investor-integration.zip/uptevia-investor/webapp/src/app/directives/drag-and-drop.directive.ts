


import {
  Directive,
  ElementRef,
  EventEmitter, HostBinding, HostListener,
  Output
} from '@angular/core';

@Directive({
  selector: '[appDnd]'
})

export class DndDirective {
  @HostBinding('class.drag-over') fileOver: boolean;
  @Output() fileDropped = new EventEmitter<any>();
  noDrop = false
  //list of accepted files 
  allowedFiles = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg'];

  constructor(private elementRef: ElementRef) { }
  // Dragover listener
  @HostListener('dragover', ['$event']) onDragOver(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.noDrop = Array.from(event.dataTransfer!.items).some(item => this.allowedFiles.includes(item.type))
    this.fileOver = true;
    if (!this.noDrop) {
      event.dataTransfer!.dropEffect = 'none'
    }

  }

  // Dragleave listener
  @HostListener('dragleave', ['$event']) public onDragLeave(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();

    if (!this.isCursorWithinElement(event)) {
      this.fileOver = false
    }

  }

  // Drop listener
  @HostListener('drop', ['$event']) public ondrop(event: any) {
    event.preventDefault();
    event.stopPropagation();
    this.fileOver = false;
    let files = event.dataTransfer.files;

    if (files.length > 0 && this.noDrop) {
      this.fileDropped.emit(files);
    }

  }

  private isCursorWithinElement(event: DragEvent): boolean {
    const rect = this.elementRef.nativeElement.getBoundingClientRect();
    const x = event.clientX;
    const y = event.clientY;
    return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
  }
}