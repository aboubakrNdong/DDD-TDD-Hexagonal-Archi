import { CurrencyPipe } from '@angular/common';
import { Directive, HostListener, Input } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, Validators } from '@angular/forms';

@Directive({
  selector: '[appTicksize]',
  providers: [
    {
      provide: NG_VALIDATORS,
      multi: true,
      useExisting: TicksizeDirective

    }
  ]
})
export class TicksizeDirective implements Validators {
  @Input('ticksize') tickSize: number;
  @Input('coursReel') coursReel: number;
  constructor( 
    private currencyPipe: CurrencyPipe) { }

  validate(control: AbstractControl): { [key: string]: any } | boolean {
    // plus ou moins 20%
    const valu = control.value.replace(',', '.')
    let value = Number(this.sanitizeInput(valu))
    if (value > (this.coursReel * 120 / 100) || value < (this.coursReel * 80 / 100)) {
      return { outoflimit: true };
    }
    else if (this.isTickRespected(value)) {
      const minValid = this.minCotation(value, this.tickSize)
      const maxValid = this.maxCotation(value, this.tickSize)
      return { courlimite: true, min: minValid, max: maxValid };
    }
    return true;
  }

  isTickRespected(value: number) {
    const precision = Math.pow(10, this.numDigitsAfterDecimal(this.tickSize))
    const numberInt = Math.round(value * precision)
    const tickInt = Math.round(this.tickSize * precision)
    return numberInt % tickInt !== 0 && (value * precision) % tickInt !== 0;

  }

  minCotation(value: number, tick: number) {
    const rounded = Math.floor(value / tick) * tick;
    return parseFloat(rounded.toFixed(this.numDigitsAfterDecimal(tick)))
  }

  maxCotation(value: number, tick: number) {
    const rounded = Math.ceil(value / tick) * tick;
    return parseFloat(rounded.toFixed(this.numDigitsAfterDecimal(tick)))


  }

  numDigitsAfterDecimal(value: number) {
    let afterDecimalStr = value.toString().split('.')[1] || ''
    return afterDecimalStr.length
  }

  @HostListener('input', ['$event'])
  onInput(event: InputEvent): void {
    const inputElement = event.target as HTMLInputElement;
    const inputWithoutDecimal = this.extractValWithoutDecimal(inputElement.value)
    const tickDegits = this.numDigitsAfterDecimal(this.tickSize);
    const commaIndex = inputElement.value.indexOf(',');
    let parts = inputElement.value.split('.');
    if (commaIndex !== -1) {
      parts = inputElement.value.split(',');
    }

    if (parts.length > 1 && parts[1].length > tickDegits) {
      parts[1] = parts[1].substring(0, tickDegits);
      inputElement.value = parts.join('.');
    }

    if (inputWithoutDecimal.toString().length > 6) {
      inputElement.value = inputWithoutDecimal.toString().substring(0, 6)
    }
  }

  sanitizeInput(value: string) {
    return value.replace(/[^0-9.]+/g, '');

  }



  formattedAsCurrency(value: string): any {
    const numericValue = this.parseNumericValue(value);
    if (!isNaN(numericValue)) {
      return this.currencyPipe.transform(value, 'EUR', 'symbol', '1.2-2')
    }
    return numericValue;

  }
  private parseNumericValue(value: string): number {
    console.log(value);

    const numericValue = parseFloat(value.replace(/[^0-9.]+/g, ''));
    return isNaN(numericValue) ? 0 : numericValue
  }
  private extractValWithoutDecimal(value: string) {
    const decimalIndex = value.indexOf('.');
    const commaIndex = value.indexOf(',');
    let separatorIndex = -1;
    if (decimalIndex !== -1 && commaIndex !== -1) {
      separatorIndex = Math.min(decimalIndex, commaIndex);
    } else {
      separatorIndex = Math.max(decimalIndex, commaIndex);
    }
    if (separatorIndex !== -1) {
      return value.substring(0, separatorIndex)
    }
    return value

  }

}
