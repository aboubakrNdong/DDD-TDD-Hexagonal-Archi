export interface AvoirTitre {
    disponible: boolean;
    quantite:  number;
    restriction: string,
    coursAcquisition: number;
    coursLevee: number;
    prixSouscription: number;
    valorisation: number;
    categorie: string,
    admiIden: string,
    dateAcquisition: any,
    dateSouscription: any,
    dateDispo: any,
    dateLevee: any
}