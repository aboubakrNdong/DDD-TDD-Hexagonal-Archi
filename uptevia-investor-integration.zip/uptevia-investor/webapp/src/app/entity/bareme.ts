export interface Bareme {
    idextBarcomms: string;
    emetIden: number;
    baremeWeb: string;
    amount0D: number;
    amount1D: number;
    amount2D: number;
    amount3D: number;
    amount4D: number;
    amount5D: number;
    amount6D: number;
    amount7D: number;
    amount8D: number;
    amount9D: number;
    percent0D: number;
    percent1D: number;
    percent2D: number;
    percent3D: number;
    percent4D: number;
    percent5D: number;
    percent6D: number;
    percent7D: number;
    percent8D: number;
    percent9D: number;
    mtMinD: number;
    mtMaxD: number;
}