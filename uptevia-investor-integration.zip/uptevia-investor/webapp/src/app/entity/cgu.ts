export interface CGU {
    choix: string;
  };