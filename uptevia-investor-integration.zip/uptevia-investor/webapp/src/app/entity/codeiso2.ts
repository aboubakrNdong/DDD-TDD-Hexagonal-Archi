export interface CodeIso2 {   

        libelle: string,
        paysIso2: string,
        paysIndiSepa: string,
        paysIso2Bic: string
        
}