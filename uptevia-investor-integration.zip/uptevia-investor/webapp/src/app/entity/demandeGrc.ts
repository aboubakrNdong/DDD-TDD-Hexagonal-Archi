export interface DemandeGrc {
    emetIden: number;
    actiIden: number;
    tituNume: string;
    category: string;
    subCategory: string;
    firstName: string;
    lastName: string;
    telephone: string;
    selectphone: string;
    email: string;
    pays: string;
    dob: string;
    message: string;
    acceptTerms: true
    identifier: string
    lang: string
  }


