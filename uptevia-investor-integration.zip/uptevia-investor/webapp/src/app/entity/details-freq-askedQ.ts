export interface DetailsFreqAskedQ {
    keyFaqCategory: string;
    logoNameFaqCategory: string;
    faqQuestionKey: string;
    faqAnswerKey: string;
}