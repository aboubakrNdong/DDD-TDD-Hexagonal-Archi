export interface DonneesBancaire {
    type: string,
    sCodePaysReglement: string,
    sDevise: string,
    sModeReglement: string,
    sAgence: string,
    sBanque: string,
    sCle: string,
    sCompte: string,
    sDomiciliation: string,
    sBeneficiaire: string,
    sRibeBankCode: string,
    sRibeAgen: string,
    sRibCtrlInte: string,
    sRibCpt1: string,
    sRibCpt2: string,
    sRibCtrlFin: string
    sRibBic: string
    sRibBankNom: string
    sRibBankAdress: string
    sRibIban: string
    sRibBicIntermediaire: string
    sRibBicCouverture: string
    sRibBankIntermediaireNom: string
    sRibBankIntermediaireNomAdress: string
    sRibeCptBankBenefChezBankIntermediaire: string
    sRibeBankCouvertureNom: string
    sRibeBankCouvertureNomAdre: string
    sRibeCptBankInterChezBankCouverture: string
    
}