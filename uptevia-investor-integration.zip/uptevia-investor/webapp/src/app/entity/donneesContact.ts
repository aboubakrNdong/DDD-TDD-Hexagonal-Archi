
export interface DonneesContact {

    emetIden: number,
    actiIden: number,
    tituNum: number,
    tituEmail: string,
    tituEmail2: string,
    tituNumMobilePerso: string,
    tituNumMobilePersoIndiPays: string,
    tituNumMobilePro: string,
    tituNumMobileProIndiPays: string,
    tituNumTel: string,
    tituNumTelIndiPays: string,
    tituNumTel2: string,
    tituNumTel2IndiPays: string,
    typecontact: string,
    typeCoord: string,
    numFaxPro: string,
    numFaxProIndiPays: string,
    numFaxPerso: string,
    numFaxPersoIndiPays: string
}


