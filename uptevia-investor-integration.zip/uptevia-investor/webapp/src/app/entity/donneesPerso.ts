
export interface DonneesPerso {
    emetIden: number,
    actiIden: number,
    tituNum: number,
    typeAdre: "string",
    adreInfoRue: "string",
    adreComp: "string",
    adreCodp: "string",
    adreNomComu: "string",
    adrePaysIden: "string",
    adreBati: "string",
    adreFiscDept: "string",
    adreFiscCodeComu: "string"

}
