export interface EAbonnement {
    
    param_choix: string
}