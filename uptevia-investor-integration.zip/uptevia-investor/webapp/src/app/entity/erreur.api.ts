
export interface ErrorApi {
    errorCode: string;
    errorCodeDetail: string;
    message: string;
    contextParams: any;
}
