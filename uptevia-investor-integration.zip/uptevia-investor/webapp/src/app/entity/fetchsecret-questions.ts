export interface FetchSecretQuestions{
     idQuestion : number,
     questionKey : string,    
}
  