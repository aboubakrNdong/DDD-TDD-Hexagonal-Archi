export interface File {
    

    documentId: 0,
    documentFileName: string,
    documentContentType: string,
    documentContent: string //($byte64)
    
}