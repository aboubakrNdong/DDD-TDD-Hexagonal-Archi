export interface UserDocs {
    categorieDoc: string;
    codeCouleur: string;
    listDocsByCode?: DocsByCode[];
}

export interface DocsByCode {
    documentCode?: string;
    listDocs?: DocumentGed[];
}

export interface DocumentGed {
    uuid: string;
    technicalName?: string;
    functionalName?: string;
    documentCode?: string;
    operationCode?: string;
    status?: string;
    keyTitle?: string;
    extension?: string;
    generationDate?: string;
    busDate?: string;
    dateArrete?: string;
    lifeCycleActiveEndDate?: string;
    lifeCycleArchiveEndDate?: string;
    indiDemat?: number;
    languageCode?: string;
}

 
 
 
 
