export interface iFrameParams {
    module: string;
    theme: string;
    langue: string;
    montant: number;
    modalite: number;
    coursLimite: number;
    typeValidite: string;
    dateValidite: string;
    moisValiditeMax: number;
    isDirect: boolean,
    isMontantReel: boolean,
    quantite: number;
}
