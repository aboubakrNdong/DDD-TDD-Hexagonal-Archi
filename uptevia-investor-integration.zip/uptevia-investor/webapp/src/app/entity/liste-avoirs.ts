import { LigneAvoir } from "./ligne-avoirs";

export interface listAvoir {
    [key: string]: LigneAvoir[]

}