export interface Logo {
    emetIden: number,
    type: string,
    format: string,
    file: string,//($byte)
    url: string,
    display: boolean
}