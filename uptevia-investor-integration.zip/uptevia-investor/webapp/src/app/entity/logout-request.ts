export interface LogOutRequest{
    token: string;
}