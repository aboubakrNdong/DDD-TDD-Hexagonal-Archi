export interface Notification {
    message: string;
    srcImage: string;
    buttonLabel: string;
    notificationNavigateRoute: string;

}