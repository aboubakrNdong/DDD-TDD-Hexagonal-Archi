import { DetailPlan } from "./detailPlan";

export interface Plan {
    typePosition:string,
    derniereMaj: string,
    qteTotale: number,
    valorisationTotale: number,
    devise: string,
    details: DetailPlan[],
}