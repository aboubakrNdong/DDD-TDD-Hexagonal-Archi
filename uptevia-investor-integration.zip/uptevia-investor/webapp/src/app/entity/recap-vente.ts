import { StockCount } from "./stock-count";

export interface RecapVente {
    modalite: number;
    titresAvendre: StockCount;
    recapData:any,
    estimationInfo?:any
}