export interface SecretQuestions{
     
     login : number,
     firstQuestion : string,
     firstAnswer : string,
     secondQuestion : string, 
     secondAnswer : string
     buttonChoice: string,
     lang?: string ;

    
}
  