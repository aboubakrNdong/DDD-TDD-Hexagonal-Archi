export interface Titre {
   natureJuridique: string;
   restrictionJuridique: string;
   libePlan: string;
   valeIdenPlan: string;
   regptAvoir: number;
   rubCompta: number;
   numAvoa: number;
   nbActionDispo: number;
   nbActionAVendre: number;
   priorite: number;
   categorie: string;
   qualificatif: string;
   prixAcquisition: number;
   dateDispo: string;
   dateLevee: string;
   dateSoaa: string;
}