export interface TokenLogin {
    login: string;
    email: string;
    error:string | null;
}