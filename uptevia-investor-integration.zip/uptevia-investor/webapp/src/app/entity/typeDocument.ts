export interface TypeDocument {
   
    documentId: number;
    documentLangueIso3: string;
    versionLangueIso3: string;
    documentTraductionKey: string;
    documentTypeId: number;
    documentTypeTraductionKey: string;
}