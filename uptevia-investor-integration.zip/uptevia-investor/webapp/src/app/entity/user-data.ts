import { OnboardingSteps } from "./vialink/onboarding-steps";

export interface UserData {
  login: string;
  email: string;
  numTel: string;
  onBoardingStatus?: OnboardingSteps;
  verificationKey?: string;
}