import { OTP_STATUS } from "./vialink/enum-otp-status"

 

export interface UserAccess {
    dateValiditeFin: string
    email: string
    indiCompteBloque: boolean
    indiPwdExpire: boolean
    indiStepQuestion: boolean
    indiWillBePwdExpired: boolean
    login: string
    token: string,
    error:OTP_STATUS
}
