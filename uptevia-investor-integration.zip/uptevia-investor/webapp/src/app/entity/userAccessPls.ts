export interface UserAccessPls {
    loginUpi: string;
    emetIden?: number;
    actiIden?: number;
    tituNume?: number;
    email:  string;
    numMobile: string | null;
    onBoardingStatus?:string | null;

}
