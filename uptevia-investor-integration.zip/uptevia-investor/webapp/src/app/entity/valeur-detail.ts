import { Bareme } from "./bareme";
import { PasCotation } from "./pas-cotation";

export interface ValeurDetail {
    pasCotation: PasCotation[];
    bareme: Bareme;
}