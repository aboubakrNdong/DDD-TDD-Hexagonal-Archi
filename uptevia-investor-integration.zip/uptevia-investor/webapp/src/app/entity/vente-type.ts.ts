export interface VenteType {
    title?: string;
    dispo: number;
    indispo?: number;
    type?: string;
}