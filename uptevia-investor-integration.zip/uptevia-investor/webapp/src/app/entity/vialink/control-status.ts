
export interface ControlStatus {
  id: string
  score: number
  secondToken: string;
  status: string
}