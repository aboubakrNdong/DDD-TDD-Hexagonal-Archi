export interface ControlData {
    login: string;

    email: string;
    phone: string;
    numTel: string
    onBoardingStatus: string
    verificationKey: string;

}