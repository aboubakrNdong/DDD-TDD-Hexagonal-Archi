
export interface DocumentUpload {
    id: number;
    type: string;
    subType: string;
    number: number;
    status: string; 
    sheets?:any[];
}