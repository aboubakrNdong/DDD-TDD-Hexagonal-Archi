export interface Files {
    id: number;
    type: string;
    subType: string;
    number: number;
    status: string;
    file?: File;
    file2?: File;
    sheets?: any[];

}