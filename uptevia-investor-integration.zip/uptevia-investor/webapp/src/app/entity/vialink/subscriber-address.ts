export interface Address {
    address: string;
    city: string;
    province: string;
    country: string;
    countryIso: string;
    zipCode: string;
}