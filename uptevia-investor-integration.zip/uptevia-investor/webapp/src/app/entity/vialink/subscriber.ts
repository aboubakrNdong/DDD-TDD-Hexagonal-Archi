import { Address } from "./subscriber-address";

export interface Subscriber{
  
        type:string;
        id: string;
        spaceId: string;
        address: Address;
        complementaryData: any;
        contact: any;
        email: string;
        firstName:string;
        lastName:string;
        usageName: string;
        nationality: string;
        nationalityIso: string;
        gender: string;
        birthday: string;
        placeOfBirth: string;
        departmentOfBirth: string;
        phoneNumber: any;
      }
 