import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FaqdetailsComponent } from './faq-list.component';
import { RubriqueResolver } from 'src/app/services/resolvers/rubrique.resolver';


const routes: Routes = [

  {
    path: '', component: FaqdetailsComponent,
    resolve: { category: RubriqueResolver },
    data: { breadcrumb: '@category' },
    children: [
      {
        path: 'question', loadChildren: () => import('./question/question.module').then(d => d.QuestionModule),
      },
      {
        path: 'tuto', loadChildren: () => import('./tuto/tuto.module').then(d => d.TutoModule),
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FaqdetailsRoutingModule { }
