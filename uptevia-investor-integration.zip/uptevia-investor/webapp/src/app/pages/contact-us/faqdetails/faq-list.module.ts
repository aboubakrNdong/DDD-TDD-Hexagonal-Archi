import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FaqdetailsRoutingModule } from './faq-list-routing.module';
import { FaqdetailsComponent } from './faq-list.component';
import { ComponentsModule } from 'src/app/components/components.module';
import { QuestionModule } from './question/question.module';
import { TutoModule } from './tuto/tuto.module';


@NgModule({
  declarations: [FaqdetailsComponent],
  imports: [
    CommonModule,
    FaqdetailsRoutingModule,
    ComponentsModule,
    QuestionModule,
    TutoModule
  ],

  exports: [
    FaqdetailsRoutingModule
  ]
})
export class FaqDetailsModule { }
