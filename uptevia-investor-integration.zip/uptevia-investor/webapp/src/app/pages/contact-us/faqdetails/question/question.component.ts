import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';


@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {
  question: any;
  constructor(
    private loginService: LoginService,
    public router: Router,
    private location: Location,
    public translate: TranslateService) { }

  ngOnInit(): void {
    this.getFaqs();
  }

  async getFaqs() {
    const state: any = this.location.getState();
    this.question = state.question;
  }



  goToFormCall() {
const parent = this.loginService.isAuthenticated() ? 'contact' : 'contact-us'
    this.router.navigate([`${parent}/form-call`]);
  }



}
