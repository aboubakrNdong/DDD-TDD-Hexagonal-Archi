import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TutoComponent } from './tuto.component';
import { RubriqueResolver } from 'src/app/services/resolvers/rubrique.resolver';

const routes: Routes = [
  {
    path:'', component:TutoComponent,
    resolve: { tuto: RubriqueResolver },
    data: { breadcrumb: '@tuto',hasTowLevels:true },
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TutoRoutingModule { }
