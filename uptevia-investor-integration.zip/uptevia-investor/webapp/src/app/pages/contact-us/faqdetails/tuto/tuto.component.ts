import { Component, Input } from '@angular/core';



@Component({
  selector: 'app-tuto',
  templateUrl: './tuto.component.html',
  styleUrls: ['./tuto.component.css']
})
export class TutoComponent  {

  @Input() lienTuto: any;
  
  constructor() { }


}
