import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TutoRoutingModule } from './tuto-routing.module';
import { TutoComponent } from './tuto.component';
import { ComponentsModule } from 'src/app/components/components.module';


@NgModule({
  declarations: [TutoComponent],
  imports: [
    CommonModule,
    TutoRoutingModule,
    ComponentsModule
  ],
  exports:[TutoComponent]
})
export class TutoModule { }
