import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { UserIdleService } from 'angular-user-idle';
import { Observable, Subscription } from 'rxjs';
import { TimeoutComponent } from 'src/app/components/timer/timer.component';
import { WarningModalComponent } from 'src/app/components/warning-modal/warning-modal.component';
import { LogOutRequest } from 'src/app/entity/logout-request';
import { Modules } from 'src/app/entity/module';
import { Profil } from 'src/app/entity/profil';
import { UserAccess } from 'src/app/entity/user';
import { BreadcrumbService } from 'src/app/services/breadcrumb.service';
import { LoginService } from 'src/app/services/login.service';
import { MessageService } from 'src/app/services/message.service';
import { StorageService } from 'src/app/services/storage-service';
import { fetchOpsData, fetchPortefeuilleTitres, fetchRessources, setProfile } from 'src/app/store/actions/app.action';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit {

  titulaire: Profil;
  isTimeOutModal = false;
  lienPicto = "assets/pictos/illustration-popin.svg";
  iconSource = "assets/pictos/profil.svg";
  timerSub: Subscription;
  modalRef: any
  menu: Modules[];
  modules$: Observable<Modules[]>;
  profile: any;

  constructor(
    private store: Store,
    private modal: NgbModal,
    public route: ActivatedRoute,
    public breadcrumbService: BreadcrumbService,
    public loginService: LoginService,
    private userIdle: UserIdleService,
    private storageService: StorageService,
    private messageService: MessageService,
    public translate: TranslateService) { }




  ngOnInit(): void {
    this.titulaire = JSON.parse(this.storageService.getItem("titulaire") ?? '{}');
    this.getProfilData();

    //getMenu
    this.getMenu();
    this.getOpsData();
    //set Default Url to file d'ariane component
    this.breadcrumbService.setBreadcrubs([{ label: "dashboard.item.title", url: "/dashboard" }]);
    this.handleUserIdle();

    const lang: string = localStorage.getItem('lang') ?? ''
    this.translate.use(lang);

  }


  showModal() {
    this.modalRef = this.modal.open(TimeoutComponent, { backdrop: 'static', keyboard: false, });
    this.modalRef.result.then((res: any) => {
      if (res) {
        this.userIdle.stopTimer();
        this.userIdle.resetTimer();
      }
    })
  }

  handleUserIdle() {
    this.configIDLE();
    //Start watching for user inactivity.
    this.userIdle.startWatching();
    // Start watching when user idle is starting.
    //display modal for 2 minutes
    this.timerSub = this.userIdle.onTimerStart().subscribe(res => {
      //display toumeOut modal after 2sec
      if (res === 1) {
        this.showModal();
      }
      this.isTimeOutModal = true;

    })
    // Stop watch when time is up.
    this.userIdle.onTimeout().subscribe((res) => {
      //Ontimeout disconnect and stopwatching()
      const user: UserAccess = JSON.parse(localStorage.getItem("user") ?? '{}');
      const logout: LogOutRequest = {
        token: user?.token
      }
      this.loginService.logout(logout);
      this.userIdle.stopWatching();
      this.userIdle.stopTimer();
      this.isTimeOutModal = false;
      this.timerSub.unsubscribe();
      if (this.modalRef) {
        this.modalRef.close();
      }

    });
  }

  configIDLE() {
    //stopWatching before set Config
    this.userIdle.stopWatching();
    //set IDLE Config 
    this.userIdle.setConfigValues({
      idle: environment.idle,
      timeout: environment.sessionTimout,
      ping: 600
    })
  }
  stayConnected() {
    this.userIdle.stopTimer();
    this.userIdle.resetTimer();
    this.isTimeOutModal = false;
  }

  getMenu() {
    this.store.dispatch(fetchRessources())
    this.modules$ = this.store.select((state: any) => state.form.modules)

  }
  getOpsData() {
    this.store.dispatch(fetchOpsData());
    this.store.dispatch(fetchPortefeuilleTitres());

  }

  getProfilData() {
    const user: UserAccess = JSON.parse(localStorage.getItem("user") ?? '{}');

    this.loginService.getTitulaire().subscribe(
      (reponse: Profil) => {
        if (reponse) {
          this.profile = reponse;
          //Save Data to store
          this.store.dispatch(setProfile({ profil: reponse, username: user.login }));
          console.log('set profile data', this.profile);

        } else {
          const status = this.messageService.getValueParam();
          if (status === 403) {
            this.onTokenExpire()
          }

        }

      });
  }

  onTokenExpire() {
    const modalRef: NgbModalRef = this.modal.open(WarningModalComponent, { backdrop: 'static', keyboard: false });
    const user: UserAccess = JSON.parse(localStorage.getItem("user") || '{}');
    const logout: LogOutRequest = {
      token: user?.token
    }
    modalRef.componentInstance.title = 'general.warning.alert';
    modalRef.componentInstance.description = ['general.session.expired'];
    modalRef.componentInstance.buttonLabel = 'general.bouton.fermer';
    modalRef.result.then(() => { }, (reason) => {
      this.loginService.logout(logout);
    })
  }


  ngOnDestroy() {
    this.timerSub.unsubscribe();
  }



}
