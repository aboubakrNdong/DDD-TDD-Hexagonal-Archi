import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentationsTabComponent } from './documentations-tab.component';

describe('DocumentationsTabComponent', () => {
  let component: DocumentationsTabComponent;
  let fixture: ComponentFixture<DocumentationsTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentationsTabComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DocumentationsTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
