import { Component, Input } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { UserDocs } from 'src/app/entity/ged';
import { BffService } from 'src/app/services/bff.service';

@Component({
  selector: 'documentations-tab',
  templateUrl: './documentations-tab.component.html',
  styleUrls: ['./documentations-tab.component.css']
})
export class DocumentationsTabComponent {

  documentationForm: FormGroup;

  @Input() titulaire: any = null;

  //profilForm: FormGroup;

  //concatNumCompte: any;
  gedDocuments: any;

  constructor(private fb: FormBuilder, private bffService: BffService) { }

  ngOnInit(): void {
    this.createProfilForm();
    this.getUserDocsGed();
  }

  createProfilForm(): void {

    this.documentationForm = this.fb.group({
      generalite: this.fb.group({
        tituMode: [],
        tituDevise: [],
      })
    });
  }

  getUserDocsGed() {

    //TODO: Use effects
    this.bffService.getDocsGed()
      .subscribe((reponse: Array<UserDocs>) => {
        if (reponse) {
          this.gedDocuments = reponse;
          console.log('ges documents ', this.gedDocuments);

        } else {
          console.log('Any user Docs from Ged')
          this.gedDocuments = [];
        }
      },
      );

  }
}
