import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DocumentationsTabComponent } from './documentations-tab.component';

const routes: Routes = [
  {
    path: '',  component: DocumentationsTabComponent, data: { breadcrumb: 'menu.item.documentation.title'}
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DocumentationsRoutingModule { }
