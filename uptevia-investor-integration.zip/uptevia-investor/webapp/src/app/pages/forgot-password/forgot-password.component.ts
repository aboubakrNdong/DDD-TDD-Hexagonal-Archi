import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent {


  public step: number = 0;

  currentStep = "write_identifiant";
  buttonChoice = "forgotpassword"
  submitted = false;

  constructor(private router: Router,) {
  }

  navigateTo(nextStep: string) {
    this.currentStep = nextStep;
    console.log("curreenct step", this.currentStep);
  }


  /**
* Vialink upload check if mail and number not null
*/
  onclickUpload() {
    console.log("send mail after good vialink sss");
    this.submitted = true;
  }

  /**
 * on vialink score is valid >90%
 */

  onSuccess(event: boolean) {
    console.log("send mail after good vialink bb");

    // event ==true=> score Vialink >90%
    // event = false ==>score Vialink < 90%
    if (event) {
      console.log("send mail after good vialink");
    }

  }

  goToProfil() {
    this.router.navigate(['login']);
  }

}


