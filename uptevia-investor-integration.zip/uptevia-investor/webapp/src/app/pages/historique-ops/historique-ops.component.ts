import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Subject, takeUntil } from 'rxjs';
import { Operation } from 'src/app/entity/operation';
import { Profil } from 'src/app/entity/profil';
import { UserAccess } from 'src/app/entity/user';
import { StorageService } from 'src/app/services/storage-service';
import { getOperationHisto } from 'src/app/store/actions/app.action';
import { selectAppState } from 'src/app/store/selectors/app.selector';
import { OPERTOINS_LIST_COLORS } from 'src/app/utils/colors.map';

@Component({
  selector: 'app-historique-ops',
  templateUrl: './historique-ops.component.html',
  styleUrls: ['./historique-ops.component.css']
})
export class HistoriqueOpsPage implements OnInit {
  public operations: Operation[];
  operationsColors = OPERTOINS_LIST_COLORS;
  ngDestroyed$ = new Subject<void>();
  p: any = 1; //pagination index
  user: Profil;
  constructor(
    private store: Store,
    private storageService: StorageService
  ) { }
  ngOnInit(): void {
    this.getHistorique();
    this.retreiveStoreData();
  }

  private getHistorique() {
    const  login:any = this.storageService.getItem('login');
    if(login){
      this.store.dispatch(getOperationHisto({login}))

    }
  }

  private retreiveStoreData() {
    this.store.select(selectAppState)
      .pipe(takeUntil(this.ngDestroyed$))
      .subscribe((data) => {
        if (data?.operationHisto) {
          this.operations = data.operationHisto
        }
      })
  }



  ngOnDestroy() {
    this.ngDestroyed$.next();
    this.ngDestroyed$.complete();
  }
}
