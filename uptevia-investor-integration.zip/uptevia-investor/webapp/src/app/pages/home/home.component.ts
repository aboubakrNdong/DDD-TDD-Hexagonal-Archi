import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { Subject, takeUntil } from 'rxjs';
import { WelcomeModalComponent } from 'src/app/components/signup/welcome-modal/welcome-modal.component';
import { Logo } from 'src/app/entity/logo';
// import { Modules } from 'src/app/entity/module';
import { Notification } from 'src/app/entity/notification';
import { UserAccess } from 'src/app/entity/user';
import { BffService } from 'src/app/services/bff.service';
import { StorageService } from 'src/app/services/storage-service';
import { AppState } from 'src/app/store/reducers/app.reducer';
import { QUICK_ACESS_DASHBOARD } from 'src/app/utils/const-vars';


@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  quickAccess = QUICK_ACESS_DASHBOARD;
  titulaire: any;
  news!: any
  user: UserAccess;
  link = "";
  thumbnail: any;
  urlUptevia = "";
  private ngUnsubscribe = new Subject<void>();
  isCguOpen = false;

  notification: Notification;

  constructor(
    private store: Store,
    private bffService: BffService,
    private storageService: StorageService,
    private modal: NgbModal,
    public translate: TranslateService,
    private sanitizer: DomSanitizer,) { }


  ngOnInit(): void {

    this.titulaire = JSON.parse(this.storageService.getItem("titulaire") ?? '{}');
    if (this.titulaire) {
      this.refreshNews();
      this.user = JSON.parse(localStorage.getItem("user") ?? '{}');
      console.log('user', this.user);

      if (this.user.indiWillBePwdExpired) {
        this.notification = {
          message: "login.info.password.will.be.expired",
          srcImage: "assets/images/logo-uptevia.svg",
          buttonLabel: "parametres.general.bouton.title",
          notificationNavigateRoute: "maj_password"
        };

      }
    }
    this.getLogo();
    this.UpdatequickAccess();

  }

  refreshNews() {
    this.bffService.getActualites().subscribe(
      (reponse) => {
        if (reponse) {
          this.news = reponse.actus;
        }
      }
    );
  }

  UpdatequickAccess() {
    this.store.select((state: any) => state.form)
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe((data: AppState) => {
        if (data?.profil?.acceptCGU === false) {
          this.openCguPopin();
        }
      })
  }

  private openCguPopin() {
    if (!this.isCguOpen) {
      this.isCguOpen = true;
      this.modal.open(WelcomeModalComponent, { backdrop: 'static', keyboard: false, centered: true, });

    }
  }
  ngOnDestroy() {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }

  getLogo() {
    this.bffService.getLogo()
      .subscribe((logo: Logo) => {
        if (logo?.display) {
          let objectURL = `data:image/${logo.format};base64,` + logo.file;
          this.thumbnail = this.sanitizer.bypassSecurityTrustUrl(objectURL);
          if (logo?.url.length > 0 && logo?.url !== null) {
            let url = this.translate.instant(logo.url);
            if (url !== logo.url)
              this.link = url

          }
        }
      });
  }

}
