import { Component, OnInit } from '@angular/core';
import { StorageService } from 'src/app/services/storage-service';



@Component({
  selector: 'app-profil-access',
  template: `<div class="gray-container profil-access">
  <div class="white-container-component">
    <div>
      <div class="title label">
          <h4>{{ 'contact.text.myAccount' | translate }}</h4>
      </div>
        <p class="question">{{'general.input.identifiant' | translate }} : {{user.login}}</p>
        <p class="question">{{'general.input.codeEmet' | translate }} : {{concatNumCompte}}</p>
        <p class="question">{{'general.input.typeCpte' | translate }} : {{classTypeLabel | translate}}</p>
        <p class="question">{{'general.input.titunume' | translate }} : 1</p>

    </div>
  </div>
</div>`,
  styleUrls: ['./profil-access.component.css']
})
export class ProfilAccessComponent implements OnInit {
  titulaire = JSON.parse(this.storageService.getItem("titulaire") ?? '{}');
  user = JSON.parse(localStorage.getItem("user") || '{}');
  concatNumCompte: any;
  classTypeLabel: any;
  constructor(private storageService: StorageService,) { }

  ngOnInit(): void {
    this.createActiTypeCpte();
    this.createNumCompte();
  }



  createNumCompte(): string {
    this.concatNumCompte = this.titulaire.emetIden + "/" + this.titulaire.actiIden;
    return this.concatNumCompte;
  }


  createActiTypeCpte() {
    let classTypeCpte = 'general.typecpte.' + this.titulaire.actiTypeCpte;
    let lastIndex = classTypeCpte.lastIndexOf(".");
    classTypeCpte = classTypeCpte.substring(0, lastIndex);
    let classTypeCpteToLower = classTypeCpte.toLowerCase();
    this.classTypeLabel = classTypeCpteToLower.split(" ").join("");
  }


}