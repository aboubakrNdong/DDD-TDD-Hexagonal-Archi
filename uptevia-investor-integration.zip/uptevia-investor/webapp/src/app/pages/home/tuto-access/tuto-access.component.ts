import { Component } from '@angular/core';
import { StorageService } from 'src/app/services/storage-service';


@Component({
  selector: 'app-tuto-access',
  template: `<div class="tuto">
  <div class="text-center label">
      <h4>{{'dashboard.operation.tuto' | translate}}</h4>
  </div>
  <div class="flex-container">
    <img src="assets/images/video.svg" alt="">
    <div class="subtitle">
        <uptevia-ui-label size="small" label="{{'general.soon.available' | translate}}"></uptevia-ui-label>
    </div>
  </div>
</div>`,
  styleUrls: ['./tuto-access.component.css']
})
export class TutoAccessComponent {
  constructor(private storageService: StorageService,){}

  titulaire = JSON.parse(this.storageService.getItem("titulaire") ?? '{}');



}
