import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AncienOlisComponent } from './ancienolis.component';

describe('IdentityComponent', () => {
  let component: AncienOlisComponent;
  let fixture: ComponentFixture<AncienOlisComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AncienOlisComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AncienOlisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
