import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AncienOlisOrPlsComponent} from './ancienolisorpls.component';

const routes: Routes = [
  { path: '', component: AncienOlisOrPlsComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AncienOlisRoutingModule { }
