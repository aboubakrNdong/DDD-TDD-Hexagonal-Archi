import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ancienolisorpls',
  templateUrl: './ancienolisorpls.component.html',
  styleUrls: ['./ancienolisorpls.component.css']
})
export class AncienOlisOrPlsComponent {

  constructor(
    private router: Router,) { }

  beginOldOlis() {
    this.router.navigate(['ancienolis']);
  }

  beginOldPls() {
    this.router.navigate(['ancienpls']);
  }

  goToProfil() {
    this.router.navigateByUrl('login', { replaceUrl: true })
  }
}
