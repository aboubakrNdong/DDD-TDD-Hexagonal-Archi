import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ComponentsModule } from 'src/app/components/components.module';
import { AncienOlisOrPlsComponent  } from './ancienolisorpls.component';
import { AncienOlisRoutingModule } from './ancienolisorpls-routing.module';


@NgModule({
  declarations: [AncienOlisOrPlsComponent],
  imports: [
    CommonModule,
    AncienOlisRoutingModule,
    ComponentsModule
  ],
  exports:[AncienOlisOrPlsComponent]
})
export class AncienOrPlsModule { }
