import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AncienPlsComponent } from './ancienpls.component';

describe('IdentityComponent', () => {
  let component: AncienPlsComponent;
  let fixture: ComponentFixture<AncienPlsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AncienPlsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AncienPlsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
